"""Pricing engine, promo codes, cancellation refunds, commission."""
from __future__ import annotations
from datetime import timedelta
from app import db
from app.security import now, now_str
from app.services import settings_service as S
from app.services import pricing as P
from .harness import Suite
from . import fixtures as F


def _next_weekday(target: int, base_days: int = 30) -> int:
    """Offset (in days from today) of the next date landing on `target` weekday."""
    d = now().date() + timedelta(days=base_days)
    while d.weekday() != target:
        d += timedelta(days=1)
    return (d - now().date()).days


def run() -> bool:
    s = Suite("Moteur tarifaire")
    print("\n  Tarification")
    S.set_value("max_pending_bookings_per_user", 999)
    S.set_value("max_bookings_per_day_per_user", 999)
    S.set_value("vat_enabled", False)
    S.set_value("vat_rate_percent", 0.0)
    S.set_value("service_fee_percent", 0.0)
    S.set_value("long_rental_discount", [])
    S.set_value("platform_commission_percent", 12.0)
    db.execute("UPDATE pricing_rules SET active = 0")

    admin = F.make_admin()
    owner, company_id = F.make_fleet_owner(admin, name="Loueur Tarifs")
    customer = F.make_customer()
    F.approve_licence(customer, admin)

    vehicle = F.make_vehicle(owner, admin, daily_price=5000, deposit=20000,
                             weekly_price=28000, monthly_price=100000)

    def quote(a, b, **extra):
        pickup, ret = F.dates(a, b)
        body = {"vehicle_id": vehicle, "pickup_at": pickup, "return_at": ret}
        body.update(extra)
        return customer.post("/api/v1/quote", body)

    # ── daily / weekly / monthly tiers ────────────────────────────────────────
    r = quote(30, 33)
    s.status(r, 200, "devis calculé")
    s.eq(r.data["days"], 3, "3 jours facturés")
    s.eq(r.data["base_amount"], 15000, "tarif journalier : 3 × 5 000")
    s.eq(r.data["total_amount"], 15000, "total sans frais ni taxe")
    s.eq(r.data["deposit_amount"], 20000, "caution du véhicule appliquée")
    s.eq(r.data["commission_amount"], 1800, "commission plateforme 12 % = 1 800")

    r = quote(30, 37)
    s.eq(r.data["days"], 7, "7 jours")
    s.eq(r.data["base_amount"], 28000, "tarif hebdomadaire appliqué (28 000 < 35 000)")

    r = quote(30, 40)
    s.eq(r.data["days"], 10, "10 jours")
    s.eq(r.data["base_amount"], 28000 + 3 * 5000, "1 semaine + 3 jours")

    r = quote(30, 60)
    s.eq(r.data["days"], 30, "30 jours")
    s.eq(r.data["base_amount"], 100000, "tarif mensuel appliqué")

    r = quote(30, 65)
    s.eq(r.data["days"], 35, "35 jours")
    s.eq(r.data["base_amount"], 100000 + 5 * 5000, "1 mois + 5 jours")

    # ── hourly rounding: any started 24 h period is a full day ────────────────
    pickup = (now() + timedelta(days=30)).strftime("%Y-%m-%d") + " 10:00"
    for ret_str, expect, label in [
            ((now() + timedelta(days=30)).strftime("%Y-%m-%d") + " 18:00", 1, "8 h → 1 jour"),
            ((now() + timedelta(days=31)).strftime("%Y-%m-%d") + " 09:00", 1, "23 h → 1 jour"),
            ((now() + timedelta(days=31)).strftime("%Y-%m-%d") + " 11:00", 2, "25 h → 2 jours"),
            ((now() + timedelta(days=33)).strftime("%Y-%m-%d") + " 10:00", 3, "72 h → 3 jours")]:
        r = customer.post("/api/v1/quote", {"vehicle_id": vehicle, "pickup_at": pickup,
                                            "return_at": ret_str})
        s.eq(r.data["days"] if r.ok else None, expect, f"arrondi horaire : {label}")

    # ── weekend pricing (Fri/Sat in Algeria) ──────────────────────────────────
    wk_vehicle = F.make_vehicle(owner, admin, brand="Kia", model="Rio",
                                daily_price=4000, weekend_price=6000)
    friday = _next_weekday(4, 40)
    r = customer.post("/api/v1/quote", {
        "vehicle_id": wk_vehicle, **dict(zip(("pickup_at", "return_at"),
                                             F.dates(friday, friday + 2)))})
    s.check(r.ok, "devis week-end calculé")
    if r.ok:
        labels = [l["code"] for l in r.data["lines"]["base"]]
        s.eq(r.data["days"], 2, "vendredi 10 h → dimanche 10 h = 2 jours facturés")
        s.check("weekend" in labels, "le tarif week-end apparaît dans le détail", str(labels))
        s.eq(r.data["base_amount"], 6000 * 2, "les deux jours de week-end au tarif majoré")
    # a Monday-to-Wednesday rental must stay on the standard rate
    monday = _next_weekday(0, 40)
    r = customer.post("/api/v1/quote", {
        "vehicle_id": wk_vehicle, **dict(zip(("pickup_at", "return_at"),
                                             F.dates(monday, monday + 2)))})
    if r.ok:
        s.eq(r.data["base_amount"], 4000 * 2, "lundi → mercredi au tarif normal")

    # ── VAT is a setting, never hardcoded ─────────────────────────────────────
    S.set_value("vat_enabled", True)
    S.set_value("vat_rate_percent", 19.0)
    r = quote(30, 33)
    s.eq(r.data["tax_amount"], 2850, "TVA 19 % appliquée sur 15 000 = 2 850")
    s.eq(r.data["total_amount"], 17850, "total TVA incluse")
    s.check(any("19" in l["label"] for l in r.data["lines"]["taxes"]),
            "le taux est affiché dans le détail")
    S.set_value("vat_rate_percent", 9.0)
    r = quote(30, 33)
    s.eq(r.data["tax_amount"], 1350, "changement de taux immédiat (9 % = 1 350)")
    S.set_value("vat_enabled", False)
    r = quote(30, 33)
    s.eq(r.data["tax_amount"], 0, "TVA désactivée : aucune taxe")

    # ── service fee ───────────────────────────────────────────────────────────
    S.set_value("service_fee_percent", 5.0)
    r = quote(30, 33)
    s.eq(r.data["fees_amount"], 750, "frais de service 5 % = 750")
    s.eq(r.data["total_amount"], 15750, "frais inclus dans le total")
    S.set_value("service_fee_percent", 0.0)

    # ── long rental discount tiers ────────────────────────────────────────────
    S.set_value("long_rental_discount", [{"min_days": 7, "percent": 5},
                                         {"min_days": 30, "percent": 12}])
    r = quote(30, 33)
    s.eq(r.data["discount_amount"], 0, "pas de remise en dessous de 7 jours")
    r = quote(30, 37)
    s.eq(r.data["discount_amount"], 1400, "remise 5 % sur 28 000 = 1 400")
    r = quote(30, 60)
    s.eq(r.data["discount_amount"], 12000, "palier 30 jours : 12 % de 100 000")
    s.check(all(l["amount"] < 0 for l in r.data["lines"]["discounts"]),
            "les remises apparaissent en négatif dans le détail")
    S.set_value("long_rental_discount", [])

    # ── optional services ─────────────────────────────────────────────────────
    svc = db.rows_to_dicts(db.query(
        "SELECT id, code, price, price_type FROM services WHERE company_id IS NULL"))
    per_day = next(x for x in svc if x["price_type"] == "per_day")
    per_booking = next(x for x in svc if x["price_type"] == "per_booking")
    r = quote(30, 33, services=[{"id": per_day["id"]}])
    s.eq(r.data["services_amount"], per_day["price"] * 3,
         "service à la journée multiplié par la durée")
    r = quote(30, 33, services=[{"id": per_booking["id"]}])
    s.eq(r.data["services_amount"], per_booking["price"],
         "service forfaitaire compté une seule fois")
    r = quote(30, 33, services=[{"id": per_day["id"]}, {"id": per_booking["id"]}])
    s.eq(r.data["services_amount"], per_day["price"] * 3 + per_booking["price"],
         "cumul des services")
    s.eq(r.data["total_amount"], 15000 + per_day["price"] * 3 + per_booking["price"],
         "services inclus dans le total")
    r = quote(30, 33, services=[{"id": 999999}])
    s.status(r, 422, "service inexistant refusé")

    # ── location fees ─────────────────────────────────────────────────────────
    airport = db.one("SELECT id, extra_fee FROM locations WHERE kind='airport' AND extra_fee > 0 LIMIT 1")
    r = quote(30, 33, pickup_location_id=airport["id"])
    s.check(r.ok, "devis avec prise en charge à l'aéroport")
    if r.ok:
        s.eq(r.data["fees_amount"], airport["extra_fee"],
             "supplément aéroport appliqué")
        s.check(any("aéroport" in l["label"].lower() or "prise en charge" in l["label"].lower()
                    for l in r.data["lines"]["fees"]), "le supplément est détaillé")

    # ── promo codes ───────────────────────────────────────────────────────────
    r = admin.post("/api/v1/admin/promo-codes", {"code": "TEST20", "kind": "percent",
                                                 "value": 20, "per_user_limit": 1})
    s.status(r, 201, "code promo en pourcentage créé")
    r = admin.post("/api/v1/admin/promo-codes", {"code": "MOINS2000", "kind": "fixed",
                                                 "value": 2000, "min_amount": 10000})
    s.status(r, 201, "code promo à montant fixe créé")
    r = admin.post("/api/v1/admin/promo-codes", {"code": "PLAFOND", "kind": "percent",
                                                 "value": 50, "max_discount": 1000})
    s.status(r, 201, "code promo plafonné créé")
    r = admin.post("/api/v1/admin/promo-codes", {"code": "TEST20", "kind": "percent", "value": 5})
    s.status(r, 409, "code promo en doublon refusé")

    r = quote(30, 33, promo_code="TEST20")
    s.eq(r.data["discount_amount"], 3000, "remise 20 % = 3 000")
    s.eq(r.data["total_amount"], 12000, "total après remise")
    r = quote(30, 33, promo_code="test20")
    s.eq(r.data["discount_amount"] if r.ok else None, 3000, "code promo insensible à la casse")
    r = quote(30, 33, promo_code="MOINS2000")
    s.eq(r.data["discount_amount"], 2000, "remise fixe de 2 000")
    r = quote(30, 33, promo_code="PLAFOND")
    s.eq(r.data["discount_amount"], 1000, "remise plafonnée à 1 000 malgré 50 %")
    r = quote(30, 31, promo_code="MOINS2000")
    s.status(r, 422, "montant minimum non atteint : code refusé")
    r = quote(30, 33, promo_code="INEXISTANT")
    s.status(r, 422, "code promo inconnu refusé")

    r = admin.post("/api/v1/admin/promo-codes", {"code": "EXPIRE", "kind": "percent", "value": 10,
                                                 "ends_at": "2020-01-01 00:00"})
    s.check(r.ok, "code promo expiré créé pour le test")
    r = quote(30, 33, promo_code="EXPIRE")
    s.status(r, 422, "code promo expiré refusé")

    # per-user limit enforced on booking, and usage recorded
    r = F.book(customer, vehicle, 300, 303, promo_code="TEST20")
    s.status(r, 201, "réservation avec code promo acceptée")
    booking_id = r.data["id"]
    s.eq(r.data["discount_amount"], 3000, "remise enregistrée sur la réservation")
    s.eq(db.scalar("SELECT used_count FROM promo_codes WHERE code='TEST20'", (), 0), 1,
         "compteur d'utilisation incrémenté")
    s.eq(db.scalar("SELECT COUNT(*) FROM promo_redemptions WHERE booking_id = ?",
                   (booking_id,), 0), 1, "utilisation tracée pour ce client")
    r = quote(310, 313, promo_code="TEST20")
    s.status(r, 422, "limite par client atteinte : code refusé")
    other = F.make_customer()
    F.approve_licence(other, admin)
    r = other.post("/api/v1/quote", {"vehicle_id": vehicle,
                                     **dict(zip(("pickup_at", "return_at"), F.dates(320, 323))),
                                     "promo_code": "TEST20"})
    s.check(r.ok and r.data["discount_amount"] == 3000,
            "un autre client peut encore utiliser le code")

    # usage limit
    r = admin.post("/api/v1/admin/promo-codes", {"code": "UNIQUE1", "kind": "percent",
                                                 "value": 10, "usage_limit": 1,
                                                 "per_user_limit": 5})
    c1 = F.make_customer(); F.approve_licence(c1, admin)
    c2 = F.make_customer(); F.approve_licence(c2, admin)
    v2 = F.make_vehicle(owner, admin, brand="Peugeot", model="208")
    r1 = F.book(c1, v2, 330, 332, promo_code="UNIQUE1")
    s.status(r1, 201, "première (et unique) utilisation du code global")
    r2 = c2.post("/api/v1/quote", {"vehicle_id": v2,
                                   **dict(zip(("pickup_at", "return_at"), F.dates(340, 342))),
                                   "promo_code": "UNIQUE1"})
    s.status(r2, 422, "limite globale d'utilisation atteinte")

    # ── seasonal / early-booking pricing rules ────────────────────────────────
    today = now().date()
    db.execute("UPDATE pricing_rules SET active = 0")
    rule_id = db.insert("pricing_rules", {
        "scope": "vehicle", "vehicle_id": vehicle, "kind": "seasonal",
        "label": "Haute saison test (+20 %)",
        "start_date": (today + timedelta(days=25)).isoformat(),
        "end_date": (today + timedelta(days=45)).isoformat(),
        "adjust_type": "percent", "adjust_value": 20, "priority": 10, "active": 1,
        "created_at": now_str()})
    r = quote(30, 33)
    s.eq(r.data["base_amount"], 18000, "règle saisonnière +20 % appliquée (15 000 → 18 000)")
    s.check(any("saison" in a["label"].lower() for a in r.data["lines"]["adjustments"]),
            "la règle est visible dans le détail du prix")
    r = quote(60, 63)
    s.eq(r.data["base_amount"], 15000, "hors période : tarif normal")
    db.update("pricing_rules", rule_id, {"active": 0})

    rule2 = db.insert("pricing_rules", {
        "scope": "global", "kind": "early_booking", "label": "Réservation anticipée (−10 %)",
        "min_days_ahead": 60, "adjust_type": "percent", "adjust_value": -10,
        "priority": 5, "active": 1, "created_at": now_str()})
    r = quote(90, 93)
    s.eq(r.data["base_amount"], 13500, "remise anticipée −10 % au-delà de 60 jours")
    r = quote(30, 33)
    s.eq(r.data["base_amount"], 15000, "pas de remise anticipée à 30 jours")
    db.update("pricing_rules", rule2, {"active": 0})

    # ── company-specific commission overrides the platform default ────────────
    r = admin.put(f"/api/v1/admin/companies/{company_id}", {"commission_rate": 20})
    s.check(r.ok, "commission spécifique définie par l'administrateur")
    r = quote(30, 33)
    s.eq(r.data["commission_amount"], 3000, "commission 20 % de la société appliquée")
    r = admin.put(f"/api/v1/admin/companies/{company_id}", {"commission_rate": None})
    r = quote(30, 33)
    s.eq(r.data["commission_amount"], 1800, "retour au taux par défaut de la plateforme")

    # ── price snapshot is immutable after booking ─────────────────────────────
    snap_vehicle = F.make_vehicle(owner, admin, brand="Toyota", model="Yaris", daily_price=6000)
    r = F.book(customer, snap_vehicle, 350, 353)
    s.status(r, 201, "réservation créée avant changement de tarif")
    snap_id = r.data["id"]
    original_total = r.data["total_amount"]
    s.eq(original_total, 18000, "total initial : 3 × 6 000")
    r = owner.put(f"/api/v1/fleet/vehicles/{snap_vehicle}", {"daily_price": 12000})
    s.check(r.ok, "le loueur double son tarif journalier")
    r = customer.get(f"/api/v1/bookings/{snap_id}")
    s.eq(r.data["total_amount"], original_total,
         "le prix de la réservation existante ne change pas")
    s.check(r.data["breakdown"]["base_amount"] == 18000,
            "le détail tarifaire figé est conservé")

    # ── cancellation refund ladder ────────────────────────────────────────────
    S.set_value("cancellation_policy", [
        {"hours_before": 48, "refund_percent": 100, "label": "Gratuite jusqu'à 48 h"},
        {"hours_before": 24, "refund_percent": 50, "label": "50 % entre 48 h et 24 h"},
        {"hours_before": 0, "refund_percent": 0, "label": "Aucun remboursement sous 24 h"},
    ])
    booking = {"pickup_at": (now() + timedelta(days=10)).strftime("%Y-%m-%d %H:%M"),
               "paid_amount": 20000}
    res = P.refund_for_cancellation(booking)
    s.eq(res["refund_percent"], 100, "annulation à 10 jours : remboursement intégral")
    s.eq(res["refund_amount"], 20000, "montant remboursé complet")
    booking["pickup_at"] = (now() + timedelta(hours=30)).strftime("%Y-%m-%d %H:%M")
    res = P.refund_for_cancellation(booking)
    s.eq(res["refund_percent"], 50, "annulation à 30 h : 50 %")
    s.eq(res["refund_amount"], 10000, "moitié remboursée")
    booking["pickup_at"] = (now() + timedelta(hours=5)).strftime("%Y-%m-%d %H:%M")
    res = P.refund_for_cancellation(booking)
    s.eq(res["refund_percent"], 0, "annulation à 5 h : aucun remboursement")

    # via the API, on a real paid booking
    paid_vehicle = F.make_vehicle(owner, admin, brand="Dacia", model="Logan", daily_price=5000)
    r = F.book(customer, paid_vehicle, 20, 23)
    pid_booking = r.data["id"]
    pay = customer.post("/api/v1/payments", {"booking_id": pid_booking,
                                             "provider_code": "cash_on_pickup", "kind": "full"})
    payment_id = pay.data["payment"]["id"]
    admin.post(f"/api/v1/payments/{payment_id}/confirm", {})
    r = customer.get(f"/api/v1/bookings/{pid_booking}/cancellation-preview")
    s.check(r.ok and r.data["refund_percent"] == 100,
            "aperçu du remboursement avant annulation")
    s.eq(r.data["paid_amount"], 15000, "montant payé pris en compte")
    r = customer.post(f"/api/v1/bookings/{pid_booking}/cancel", {"reason": "Imprévu"})
    s.status(r, 200, "annulation avec remboursement intégral")
    s.eq(db.scalar("SELECT refund_amount FROM bookings WHERE id = ?", (pid_booking,), 0), 15000,
         "montant du remboursement enregistré")
    s.check(bool(db.one("SELECT 1 FROM refunds WHERE booking_id = ?", (pid_booking,))),
            "un remboursement est créé pour traitement")
    s.eq(db.scalar("SELECT payment_status FROM bookings WHERE id = ?", (pid_booking,)), "refunded",
         "statut de paiement passé à remboursé")

    # ── negative totals are impossible ────────────────────────────────────────
    r = admin.post("/api/v1/admin/promo-codes", {"code": "ENORME", "kind": "fixed",
                                                 "value": 9999999})
    r = quote(30, 33, promo_code="ENORME")
    s.check(r.ok and r.data["total_amount"] >= 0, "le total ne peut pas devenir négatif",
            str(r.data.get("total_amount") if r.ok else r.message))
    s.check(r.ok and r.data["discount_amount"] <= 15000,
            "la remise est bornée au montant de la location")

    return s.report()
