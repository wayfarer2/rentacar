"""Shared fixtures. Admin bootstrap is done in the DB (as `manage.py createadmin`
would); everything else goes through the real API so the tests exercise it."""
from __future__ import annotations
from datetime import timedelta
from app import db
from app.security import hash_password, now, now_str
from app.services import auth_service as A
from .harness import Client

PASSWORD = "MotDePasse2026"
_counter = {"n": 0}


def uniq(prefix="user") -> str:
    _counter["n"] += 1
    return f"{prefix}{_counter['n']}@test.dz"


def make_admin(email="admin@test.dz", role="super_admin") -> Client:
    with db.transaction():
        A.seed_roles()
        row = db.one("SELECT id FROM users WHERE email = ?", (email,))
        if row:
            uid = row["id"]
        else:
            uid = db.insert("users", {
                "email": email, "password_hash": hash_password(PASSWORD),
                "full_name": "Admin Test", "status": "active",
                "email_verified_at": now_str(), "created_at": now_str(), "updated_at": now_str()})
        A.grant_role(uid, role)
        if role == "super_admin":
            A.grant_role(uid, "admin")
    c = Client()
    c.login(email, PASSWORD)
    return c


def make_staff(role: str, email=None) -> Client:
    email = email or uniq(role)
    with db.transaction():
        uid = db.insert("users", {
            "email": email, "password_hash": hash_password(PASSWORD),
            "full_name": f"Staff {role}", "status": "active", "email_verified_at": now_str(),
            "created_at": now_str(), "updated_at": now_str()})
        A.grant_role(uid, role)
    c = Client()
    c.login(email, PASSWORD)
    return c


def make_customer(email=None, phone="0555123456") -> Client:
    c = Client()
    r = c.register(email or uniq("client"), PASSWORD, "Client Test", phone, "customer")
    assert r.ok, f"registration failed: {r.status} {r.message}"
    return c


def make_fleet_owner(admin: Client, name="Loueur Test", wilaya_id=16,
                     approve=True, email=None) -> tuple[Client, int]:
    c = Client()
    r = c.register(email or uniq("loueur"), PASSWORD, "Propriétaire Test",
                   "0555987654", "fleet_owner")
    assert r.ok, f"vendor registration failed: {r.message}"
    r = c.post("/api/v1/companies", {
        "name": name, "phone": "0555987654", "wilaya_id": wilaya_id,
        "rc_number": "16/00-1234B5", "nif": "001612345678901",
        "address": "Rue de test, Alger", "email": "contact@loueur.test"})
    assert r.ok, f"company creation failed: {r.message}"
    company_id = r.data["id"]
    if approve:
        ar = admin.post(f"/api/v1/admin/companies/{company_id}/status",
                        {"status": "approved", "reason": "Dossier conforme"})
        assert ar.ok, f"company approval failed: {ar.message}"
    c.refresh_csrf()          # roles/company membership changed
    return c, company_id


def make_vehicle(owner: Client, admin: Client, *, daily_price=5000, deposit=20000,
                 approve=True, category="compact", seats=5, transmission="manual",
                 fuel="petrol", min_days=1, max_days=60, weekly_price=None,
                 monthly_price=None, weekend_price=None, brand="Renault",
                 model="Clio", location_id=None) -> int:
    payload = {
        "brand": brand, "model": model, "year": 2023, "category": category,
        "transmission": transmission, "fuel": fuel, "seats": seats, "doors": 5,
        "daily_price": daily_price, "deposit": deposit, "min_days": min_days,
        "max_days": max_days, "color": "Blanc", "mileage": 25000,
        "registration_number": "12345-116-16",
        "description": "Véhicule de test, propre et révisé.",
        "features": ["air_conditioning", "bluetooth"],
    }
    if weekly_price:  payload["weekly_price"] = weekly_price
    if monthly_price: payload["monthly_price"] = monthly_price
    if weekend_price: payload["weekend_price"] = weekend_price
    if location_id:   payload["primary_location_id"] = location_id
    else:
        loc = db.one("SELECT id FROM locations WHERE kind='office' LIMIT 1")
        if loc:
            payload["primary_location_id"] = loc["id"]
    r = owner.post("/api/v1/fleet/vehicles", payload)
    assert r.ok, f"vehicle creation failed: {r.status} {r.message}"
    vid = r.data["id"]
    if approve:
        ar = admin.post(f"/api/v1/admin/vehicles/{vid}/approval",
                        {"decision": "approved", "reason": ""})
        assert ar.ok, f"vehicle approval failed: {ar.message}"
    return vid


def dates(start_offset: int, end_offset: int, hour="10:00") -> tuple[str, str]:
    d1 = (now() + timedelta(days=start_offset)).strftime("%Y-%m-%d")
    d2 = (now() + timedelta(days=end_offset)).strftime("%Y-%m-%d")
    return f"{d1} {hour}", f"{d2} {hour}"


def book(client: Client, vehicle_id: int, start_offset: int, end_offset: int, **extra):
    pickup, ret = dates(start_offset, end_offset)
    payload = {
        "vehicle_id": vehicle_id, "pickup_at": pickup, "return_at": ret,
        "full_name": "Client Test", "phone": "0555123456",
        "date_of_birth": "1990-05-20", "address": "Cité 200 logements, Alger",
        "license_number": "DZ998877",
        "license_issued_at": "2015-03-01",
        "license_expires_at": (now() + timedelta(days=900)).strftime("%Y-%m-%d"),
    }
    payload.update(extra)
    return client.post("/api/v1/bookings", payload)


def approve_licence(customer: Client, admin: Client) -> None:
    """Upload + approve a driving licence so vendors can confirm bookings."""
    from .harness import PNG_1PX
    r = customer.upload("/api/v1/documents", {"kind": "driver_license"},
                        {"file": ("permis.png", PNG_1PX, "image/png")})
    assert r.ok, f"document upload failed: {r.message}"
    doc_id = r.data["id"]
    ar = admin.post(f"/api/v1/documents/{doc_id}/review", {"decision": "approved"})
    assert ar.ok, f"document approval failed: {ar.message}"
