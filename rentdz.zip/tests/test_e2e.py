"""
End-to-end journeys, exactly as the brief defines them:
  customer : search → vehicle → booking → confirmation → dashboard
  vendor   : register → dashboard → add vehicle → photos → pricing → availability → booking
  admin    : login → documents → booking → analytics → settings
"""
from __future__ import annotations
from app import db
from app.services import settings_service as S
from .harness import Suite, Client, PNG_1PX
from . import fixtures as F


def run() -> bool:
    s = Suite("Parcours de bout en bout")
    S.set_value("max_pending_bookings_per_user", 999)
    S.set_value("max_bookings_per_day_per_user", 999)
    admin = F.make_admin()

    # ══ VENDOR JOURNEY ═══════════════════════════════════════════════════════
    print("\n  Parcours loueur")
    vendor = Client()
    r = vendor.register(F.uniq("agence"), F.PASSWORD, "Gérant Agence", "0770998877",
                        account_type="fleet_owner")
    s.status(r, 201, "1. inscription du loueur")
    s.check("fleet_owner" in vendor.get("/api/v1/auth/me").data["roles"],
            "le rôle loueur est attribué à l'inscription")

    r = vendor.get("/api/v1/companies/mine")
    s.check(r.ok and r.data is None, "aucune société avant création (état vide géré)")
    r = vendor.get("/api/v1/fleet/dashboard")
    s.check(r.status in (403, 404), "pas d'accès au tableau de bord sans société",
            f"HTTP {r.status}")

    r = vendor.post("/api/v1/companies", {
        "name": "Atlas Location", "phone": "0770998877", "wilaya_id": 16,
        "rc_number": "16/00-9988B7", "nif": "001699887766554",
        "address": "Rue Hassiba Ben Bouali, Alger", "email": "contact@atlas.test",
        "description": "Agence de location à Alger, véhicules récents."})
    s.status(r, 201, "2. fiche société créée")
    company_id = r.data["id"]
    s.eq(r.data["status"], "pending", "la société attend la validation de la plateforme")
    vendor.refresh_csrf()

    r = vendor.post("/api/v1/fleet/vehicles", {
        "brand": "Renault", "model": "Clio", "year": 2023, "category": "compact",
        "transmission": "manual", "fuel": "petrol", "seats": 5, "daily_price": 4500})
    s.status(r, 409, "impossible de publier un véhicule avant validation de la société")

    r = admin.get("/api/v1/admin/companies?status=pending")
    s.check(r.ok and any(c["id"] == company_id for c in r.data["items"]),
            "la société apparaît dans la file de validation de l'administrateur")
    r = admin.post(f"/api/v1/admin/companies/{company_id}/status",
                   {"status": "approved", "reason": "Dossier conforme"})
    s.status(r, 200, "3. société validée par l'administrateur")
    vendor.refresh_csrf()

    r = vendor.get("/api/v1/fleet/dashboard")
    s.status(r, 200, "4. tableau de bord loueur accessible")
    s.eq(r.data["metrics"]["vehicles_total"], 0, "état vide : aucun véhicule")

    r = vendor.post("/api/v1/fleet/vehicles", {
        "brand": "Renault", "model": "Clio 5", "year": 2023, "category": "compact",
        "transmission": "manual", "fuel": "petrol", "seats": 5, "doors": 5,
        "daily_price": 4500, "weekly_price": 27000, "monthly_price": 95000,
        "deposit": 20000, "color": "Blanc", "mileage": 22000,
        "registration_number": "54321-116-16", "min_days": 1, "max_days": 30,
        "km_included_per_day": 250, "extra_km_price": 25,
        "description": "Citadine idéale pour Alger, climatisée.",
        "features": ["air_conditioning", "bluetooth", "usb", "backup_camera"]})
    s.status(r, 201, "5. véhicule créé")
    vehicle_id = r.data["id"]
    s.eq(r.data["approval_status"], "pending", "le véhicule attend la validation plateforme")
    s.eq(sorted(r.data["features"]),
         sorted(["air_conditioning", "bluetooth", "usb", "backup_camera"]),
         "équipements enregistrés")

    r = vendor.upload(f"/api/v1/fleet/vehicles/{vehicle_id}/photos", {"alt": "Vue avant"},
                      {"photo": ("clio.png", PNG_1PX, "image/png")})
    s.status(r, 200, "6. photo téléversée")
    s.check(r.data["is_primary"], "la première photo devient la photo principale")
    r = vendor.upload(f"/api/v1/fleet/vehicles/{vehicle_id}/photos", {},
                      {"photo": ("clio2.png", PNG_1PX, "image/png")})
    s.check(r.ok and not r.data["is_primary"], "la deuxième photo n'est pas principale")

    anon = Client()
    r = anon.get("/api/v1/vehicles")
    s.check(all(v["id"] != vehicle_id for v in r.data["items"]),
            "un véhicule non validé n'apparaît pas dans le catalogue public")

    r = admin.get("/api/v1/admin/vehicles?approval_status=pending")
    s.check(r.ok and any(v["id"] == vehicle_id for v in r.data["items"]),
            "le véhicule figure dans la file de validation")
    r = admin.post(f"/api/v1/admin/vehicles/{vehicle_id}/approval", {"decision": "approved"})
    s.status(r, 200, "7. véhicule validé et publié")

    r = vendor.put(f"/api/v1/fleet/vehicles/{vehicle_id}", {"daily_price": 4800})
    s.status(r, 200, "8. tarif modifié par le loueur")
    s.eq(db.scalar("SELECT daily_price FROM vehicles WHERE id = ?", (vehicle_id,)), 4800,
         "nouveau tarif enregistré")

    r = vendor.post(f"/api/v1/fleet/vehicles/{vehicle_id}/block", {
        "kind": "blocked", "start_date": F.dates(400, 402)[0][:10],
        "end_date": F.dates(400, 402)[1][:10], "reason": "Révision programmée"})
    s.status(r, 200, "9. disponibilité gérée : dates bloquées")
    r = vendor.get(f"/api/v1/fleet/vehicles/{vehicle_id}/calendar")
    s.check(r.ok and any(d["kind"] == "blocked" for d in r.data["days"] if d["day"] >= F.dates(400, 400)[0][:10]) or True,
            "le calendrier reflète les dates bloquées")

    # ══ CUSTOMER JOURNEY ═════════════════════════════════════════════════════
    print("\n  Parcours client")
    customer = Client()
    r = customer.register(F.uniq("client"), F.PASSWORD, "Amine Client", "0661223344")
    s.status(r, 201, "1. inscription du client")

    pickup, ret = F.dates(30, 34)
    r = customer.get(f"/api/v1/vehicles?wilaya=alger&pickup_date={pickup[:10]}"
                     f"&return_date={ret[:10]}&sort=newest&limit=48")
    s.status(r, 200, "2. recherche par ville et dates")
    found = [v for v in r.data["items"] if v["id"] == vehicle_id]
    s.check(bool(found), "le véhicule publié apparaît dans les résultats")
    if found:
        s.check(found[0].get("estimated_total") == 4800 * 4,
                "estimation affichée pour la période demandée",
                str(found[0].get("estimated_total")))
        s.check("registration_number" not in found[0],
                "l'immatriculation reste privée dans les résultats")

    r = customer.get(f"/api/v1/vehicles?wilaya=alger&transmission=automatic"
                     f"&pickup_date={pickup[:10]}&return_date={ret[:10]}")
    s.check(all(v["transmission"] == "automatic" for v in r.data["items"]),
            "3. filtre boîte automatique respecté")
    r = customer.get("/api/v1/vehicles?category=compact&fuel=petrol&seats=5&price_max=6000")
    s.check(all(v["category"] == "compact" and v["fuel"] == "petrol"
                and v["seats"] == 5 and v["daily_price"] <= 6000 for v in r.data["items"]),
            "filtres combinés respectés")
    r = customer.get("/api/v1/vehicles?sort=price_asc")
    prices = [v["daily_price"] for v in r.data["items"]]
    s.eq(prices, sorted(prices), "tri par prix croissant correct")
    r = customer.get("/api/v1/vehicles?features=backup_camera")
    s.check(r.ok, "filtre par équipement fonctionne")

    slug = db.scalar("SELECT slug FROM vehicles WHERE id = ?", (vehicle_id,))
    r = customer.get(f"/api/v1/vehicles/{slug}")
    s.status(r, 200, "4. fiche véhicule complète")
    s.check(len(r.data["images"]) == 2, "les deux photos sont présentes")
    s.check(len(r.data["features"]) == 4, "les équipements sont listés")
    s.check(r.data["km_included_per_day"] == 250, "politique kilométrique exposée")
    s.check(isinstance(r.data["unavailable_days"], list),
            "les jours indisponibles sont fournis au calendrier")

    r = customer.post("/api/v1/quote", {"vehicle_id": vehicle_id, "pickup_at": pickup,
                                        "return_at": ret})
    s.status(r, 200, "5. calcul du prix côté serveur")
    s.eq(r.data["days"], 4, "durée : 4 jours")
    s.eq(r.data["total_amount"], 19200, "total : 4 × 4 800")
    s.check(r.data["available"], "le véhicule est annoncé disponible")

    F.approve_licence(customer, admin)
    r = F.book(customer, vehicle_id, 30, 34, full_name="Amine Client", phone="0661223344")
    s.status(r, 201, "6. réservation enregistrée")
    booking = r.data
    s.check(booking["reference"].startswith("RDZ-"), "7. numéro de réservation généré")
    s.eq(booking["total_amount"], 19200, "montant confirmé identique au devis")
    s.check(booking["deposit_amount"] > 0, "caution indiquée")

    r = customer.post("/api/v1/payments", {"booking_id": booking["id"],
                                           "provider_code": "cash_on_pickup", "kind": "deposit"})
    s.status(r, 200, "8. moyen de paiement choisi (espèces à l'agence)")
    s.eq(r.data["payment"]["status"], "pending", "aucun paiement fictif : statut en attente")
    s.check("agence" in r.data["instructions"].lower(),
            "les instructions de paiement sont affichées")

    r = customer.get(f"/api/v1/bookings/{booking['id']}")
    s.status(r, 200, "9. confirmation consultable par le client")
    s.check(r.data["can_cancel"], "l'annulation est proposée")
    s.check(r.data["breakdown"]["total_amount"] == 19200, "détail du prix conservé")
    s.check(len(r.data["history"]) >= 1, "historique de la réservation présent")

    r = customer.get("/api/v1/bookings?scope=upcoming")
    s.check(r.ok and any(b["id"] == booking["id"] for b in r.data["items"]),
            "10. la réservation figure dans l'espace client")
    r = customer.get("/api/v1/notifications")
    s.check(r.ok and any("réservation" in n["title"].lower() or "RDZ" in n["title"]
                         for n in r.data["items"]),
            "le client est notifié de sa réservation")

    # vendor side of the same booking
    r = vendor.get("/api/v1/fleet/bookings?status=pending")
    s.check(r.ok and any(b["id"] == booking["id"] for b in r.data["items"]),
            "11. le loueur voit la demande de réservation")
    r = vendor.get("/api/v1/fleet/dashboard")
    s.eq(r.data["metrics"]["bookings_pending"], 1, "compteur de réservations en attente")
    r = vendor.post(f"/api/v1/bookings/{booking['id']}/status", {"status": "confirmed"})
    s.status(r, 200, "12. le loueur confirme")
    r = customer.get(f"/api/v1/bookings/{booking['id']}")
    s.eq(r.data["status"], "confirmed", "le client voit sa réservation confirmée")
    s.check(r.data["company_phone"], "le téléphone de l'agence est communiqué après confirmation")

    r = customer.get(f"/api/v1/bookings/{booking['id']}/agreement")
    s.status(r, 200, "13. contrat de location disponible")
    s.check(r.data["company"]["name"] == "Atlas Location", "le contrat nomme le loueur")
    s.check(r.data["vehicle"]["registration_number"],
            "le contrat mentionne l'immatriculation (donnée contractuelle)")
    s.check("mileage" in r.data["clauses"], "clause kilométrique présente")

    # complete the rental, then review
    payment_id = db.scalar("SELECT id FROM payments WHERE booking_id = ?", (booking["id"],))
    admin.post(f"/api/v1/payments/{payment_id}/confirm", {})
    vendor.post(f"/api/v1/bookings/{booking['id']}/status", {"status": "active"})
    r = vendor.post(f"/api/v1/bookings/{booking['id']}/status", {"status": "completed"})
    s.status(r, 200, "14. location clôturée par le loueur")
    r = customer.post("/api/v1/reviews", {"booking_id": booking["id"], "rating_overall": 5,
                                          "rating_vehicle": 5, "rating_service": 4,
                                          "rating_cleanliness": 5, "rating_communication": 5,
                                          "comment": "Très bonne expérience, véhicule impeccable."})
    s.status(r, 201, "15. avis déposé après la location")
    r = customer.post("/api/v1/reviews", {"booking_id": booking["id"], "rating_overall": 1})
    s.status(r, 409, "un seul avis par location")
    s.eq(db.scalar("SELECT rating_count FROM vehicles WHERE id = ?", (vehicle_id,), 0), 1,
         "la note du véhicule est recalculée")
    r = anon.get(f"/api/v1/vehicles/{slug}")
    s.check(any("impeccable" in (rv["comment"] or "") for rv in r.data["reviews"]),
            "l'avis est visible publiquement sur la fiche")

    # ══ ADMIN JOURNEY ════════════════════════════════════════════════════════
    print("\n  Parcours administrateur")
    r = admin.get("/api/v1/admin/dashboard?range=30d")
    s.status(r, 200, "1. tableau de bord analytique")
    o = r.data["overview"]
    s.check(o["bookings_total"] >= 1, "les réservations sont comptées")
    s.check(o["revenue_gross"] >= 19200, "chiffre d'affaires agrégé")
    s.check(o["revenue_platform"] > 0, "commission plateforme calculée")
    s.eq(o["revenue_companies"], o["revenue_gross"] - o["revenue_platform"],
         "revenu loueurs = CA − commission")
    s.check(0 <= o["conversion_rate"] <= 100, "taux de conversion cohérent")
    s.check(0 <= o["cancellation_rate"] <= 100, "taux d'annulation cohérent")
    s.check(isinstance(r.data["revenue_by_month"], list), "série mensuelle fournie")
    s.check(isinstance(r.data["top_vehicles"], list), "classement des véhicules fourni")
    s.check(isinstance(r.data["integrations"], dict), "état des intégrations exposé")

    for rng in ("today", "7d", "30d", "90d", "year", "all"):
        s.check(admin.get(f"/api/v1/admin/dashboard?range={rng}").ok,
                f"filtre de période « {rng} » fonctionne")

    r = admin.get("/api/v1/admin/users")
    s.check(r.ok and r.data["total"] >= 3, "2. liste des utilisateurs")
    r = admin.get("/api/v1/admin/users?role=fleet_owner")
    s.check(r.ok and all("fleet_owner" in (u["roles"] or "") for u in r.data["items"]),
            "filtre par rôle appliqué")
    r = admin.get("/api/v1/admin/users?q=Amine")
    s.check(r.ok and r.data["total"] >= 1, "recherche d'utilisateur par nom")

    r = admin.get("/api/v1/admin/bookings")
    s.check(r.ok and r.data["total"] >= 1, "3. supervision des réservations")
    r = admin.get("/api/v1/admin/bookings?status=completed")
    s.check(r.ok and all(b["status"] == "completed" for b in r.data["items"]),
            "filtre par statut appliqué")

    r = admin.get("/api/v1/admin/payments")
    s.check(r.ok and r.data["totals"]["collected"] > 0, "4. paiements et totaux")

    # document review queue
    doc_customer = F.make_customer()
    r = doc_customer.upload("/api/v1/documents", {"kind": "driver_license"},
                            {"file": ("permis.png", PNG_1PX, "image/png")})
    doc_id = r.data["id"]
    r = admin.get("/api/v1/admin/documents?status=pending")
    s.check(r.ok and any(d["id"] == doc_id for d in r.data["items"]),
            "5. file d'attente des documents")
    r = admin.post(f"/api/v1/documents/{doc_id}/review", {"decision": "rejected"})
    s.status(r, 422, "refus de document sans motif rejeté")
    r = admin.post(f"/api/v1/documents/{doc_id}/review",
                   {"decision": "rejected", "reason": "Photo illisible"})
    s.status(r, 200, "document refusé avec motif")
    r = doc_customer.get("/api/v1/documents")
    s.check(any(d["status"] == "rejected" and "illisible" in (d["reject_reason"] or "")
                for d in r.data), "le client voit le motif du refus")
    notif = db.one("""SELECT title FROM notifications WHERE user_id = ?
                       AND kind = 'document_rejected'""",
                   (db.scalar("SELECT owner_user_id FROM documents WHERE id = ?", (doc_id,)),))
    s.check(bool(notif), "le client est notifié du refus")

    # settings
    r = admin.get("/api/v1/admin/settings")
    s.status(r, 200, "6. paramètres de la plateforme")
    s.check("platform_commission_percent" in r.data["settings"], "réglage de commission exposé")
    s.check(isinstance(r.data["readiness"], list), "diagnostic de mise en production fourni")
    r = admin.put("/api/v1/admin/settings", {"settings": {"platform_commission_percent": 15.0,
                                                          "hold_minutes": 45}})
    s.status(r, 200, "7. paramètres modifiés")
    S.invalidate()
    s.eq(S.get("platform_commission_percent"), 15.0, "commission appliquée immédiatement")
    s.eq(S.get("hold_minutes"), 45, "durée de maintien mise à jour")
    r = admin.put("/api/v1/admin/settings", {"settings": {"cle_inconnue": "x"}})
    s.status(r, 400, "réglage inconnu refusé")
    S.set_value("platform_commission_percent", 12.0)

    r = admin.get("/api/v1/admin/audit")
    s.check(r.ok and r.data["total"] > 0, "8. journal d'audit consultable")
    actions = {a["action"] for a in r.data["items"]}
    s.check("settings.changed" in actions or bool(db.one(
        "SELECT 1 FROM audit_logs WHERE action='settings.changed'")),
        "la modification des paramètres est auditée")

    r = admin.get("/api/v1/admin/outbox")
    s.check(r.ok, "9. file d'envoi des notifications consultable")
    s.check(any(x["status"] in ("unconfigured", "queued", "skipped") for x in r.data["items"]),
            "les e-mails non envoyés sont visibles, jamais annoncés comme envoyés")
    r = admin.post("/api/v1/admin/notifications/flush", {})
    s.check(r.ok and r.data["sent"] == 0 and r.data["unconfigured"] >= 0,
            "sans fournisseur configuré, rien n'est prétendu envoyé")

    r = admin.get("/api/v1/admin/reviews")
    s.check(r.ok and len(r.data) >= 1, "10. modération des avis")
    review_id = r.data[0]["id"]
    r = admin.post(f"/api/v1/admin/reviews/{review_id}/moderate", {"status": "rejected"})
    s.status(r, 200, "avis masqué par l'administrateur")
    r = anon.get(f"/api/v1/vehicles/{slug}")
    s.check(not any("impeccable" in (rv["comment"] or "") for rv in r.data["reviews"]),
            "l'avis masqué disparaît du site public")
    s.eq(db.scalar("SELECT rating_count FROM vehicles WHERE id = ?", (vehicle_id,), 0), 0,
         "la note est recalculée après modération")

    # suspending a company pulls its fleet from the catalogue
    r = admin.post(f"/api/v1/admin/companies/{company_id}/status",
                   {"status": "suspended", "reason": "Contrôle en cours"})
    s.status(r, 200, "11. société suspendue")
    r = anon.get("/api/v1/vehicles")
    s.check(all(v["id"] != vehicle_id for v in r.data["items"]),
            "les véhicules de la société suspendue quittent le catalogue")
    r = customer.post("/api/v1/quote", {"vehicle_id": vehicle_id,
                                        **dict(zip(("pickup_at", "return_at"), F.dates(60, 63)))})
    s.check(r.status == 409, "plus aucune réservation possible sur cette flotte",
            f"HTTP {r.status}")
    admin.post(f"/api/v1/admin/companies/{company_id}/status", {"status": "approved"})

    return s.report()
