"""Run every suite against one live server instance."""
from __future__ import annotations
import sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

SUITES = ["test_auth", "test_booking", "test_pricing", "test_security",
          "test_ui", "test_performance", "test_e2e"]


def main(args=None) -> int:
    args = args or []
    only = [a for a in args if not a.startswith("-")]
    from tests.harness import start_server, stop_server
    base = start_server()
    print("=" * 74)
    print("  RENTDZ — suite de tests automatisés")
    print(f"  serveur de test : {base}")
    print("=" * 74)
    results = {}
    started = time.time()
    try:
        for name in SUITES:
            if only and not any(o in name for o in only):
                continue
            module = __import__(f"tests.{name}", fromlist=["run"])
            try:
                results[name] = module.run()
            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"\n  [ERREUR] {name} s'est interrompu : {e}")
                results[name] = False
    finally:
        stop_server()

    elapsed = time.time() - started
    print("\n" + "=" * 74)
    print("  RÉSULTAT GLOBAL")
    print("=" * 74)
    for name, ok in results.items():
        print(f"  {'PASS' if ok else 'FAIL'}  {name}")
    failed = [n for n, ok in results.items() if not ok]
    print(f"\n  {len(results) - len(failed)}/{len(results)} suites réussies en {elapsed:.1f}s")
    if failed:
        print(f"  Suites en échec : {', '.join(failed)}")
        return 1
    print("  V1 validée : aucune régression détectée.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
