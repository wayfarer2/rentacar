"""
Performance guardrails: indexes on the hot paths, bounded queries per request,
pagination, payload size, and no N+1 growth as data grows.
"""
from __future__ import annotations
import sqlite3, time
from app import db
from app.config import Config
from .harness import Suite, Client
from . import fixtures as F


class QueryCounter:
    """Counts SQL statements issued while serving a request."""
    def __init__(self):
        self.statements = []

    def __enter__(self):
        self.conn = db.get_conn()
        self.conn.set_trace_callback(self.statements.append)
        return self

    def __exit__(self, *a):
        self.conn.set_trace_callback(None)

    @property
    def count(self):
        return len(self.statements)


def run() -> bool:
    s = Suite("Performance")
    print("\n  Performance")
    admin = F.make_admin()
    from app.services import settings_service as S
    S.set_value("max_pending_bookings_per_user", 999)
    S.set_value("max_bookings_per_day_per_user", 999)

    # ── indexes on the paths that matter ──────────────────────────────────────
    indexes = {r["name"]: r["sql"] or "" for r in db.query(
        "SELECT name, sql FROM sqlite_master WHERE type='index'")}
    expected = {
        "vehicle_day_locks": ["vehicle_id", "day"],
        "bookings": ["customer_user_id", "vehicle_id", "company_id", "status"],
        "vehicles": ["approval_status", "company_id", "category_id"],
        "users": ["email", "status"],
        "payments": ["booking_id", "user_id"],
        "documents": ["owner_user_id", "status"],
        "audit_logs": ["actor_user_id", "action"],
        "sessions": ["user_id", "expires_at"],
        "locations": ["wilaya_id"],
        "reviews": ["vehicle_id"],
    }
    for table, columns in expected.items():
        table_idx = " ".join(sql for sql in indexes.values() if f" {table}(" in sql or f" {table} (" in sql)
        for col in columns:
            s.check(col in table_idx, f"index présent sur {table}.{col}")

    # the integrity guard must be a UNIQUE index, not just any index
    locks_unique = any("UNIQUE" in (sql or "").upper() and "vehicle_day_locks" in (sql or "")
                       for sql in indexes.values()) or bool(db.one(
        """SELECT 1 FROM sqlite_master WHERE type='index' AND tbl_name='vehicle_day_locks'
            AND sql IS NULL"""))
    s.check(locks_unique, "la contrainte d'unicité vehicle_day_locks est indexée")

    # ── query plans use indexes, not full scans ───────────────────────────────
    plans = {
        "recherche de véhicules": """EXPLAIN QUERY PLAN
            SELECT v.id FROM vehicles v JOIN rental_companies c ON c.id = v.company_id
             WHERE v.approval_status='approved' AND v.status='available' AND v.deleted_at IS NULL
             ORDER BY v.daily_price LIMIT 12""",
        "disponibilité par jour": """EXPLAIN QUERY PLAN
            SELECT 1 FROM vehicle_day_locks WHERE vehicle_id = 1 AND day = '2026-09-01'""",
        "réservations d'un client": """EXPLAIN QUERY PLAN
            SELECT id FROM bookings WHERE customer_user_id = 1 ORDER BY created_at DESC LIMIT 20""",
        "session par jeton": """EXPLAIN QUERY PLAN
            SELECT 1 FROM sessions WHERE token_hash = 'x'""",
        "utilisateur par e-mail": """EXPLAIN QUERY PLAN
            SELECT 1 FROM users WHERE lower(email) = 'x' AND deleted_at IS NULL""",
    }
    for label, sql in plans.items():
        rows = db.query(sql)
        detail = " | ".join(r["detail"] for r in rows)
        s.check("USING INDEX" in detail.upper() or "USING COVERING INDEX" in detail.upper()
                or "SEARCH" in detail.upper(),
                f"plan indexé : {label}", detail[:120])

    # ── build a larger dataset, then verify the query count stays flat ────────
    owner, company_id = F.make_fleet_owner(admin, name="Loueur Perf")
    vehicles = [F.make_vehicle(owner, admin, brand="Perf", model=f"V{i}",
                               daily_price=3000 + i * 100) for i in range(24)]
    customer = F.make_customer()
    F.approve_licence(customer, admin)
    for i in range(12):
        F.book(customer, vehicles[i], 30 + i * 4, 32 + i * 4)

    anon = Client()
    with QueryCounter() as qc:
        r = anon.get("/api/v1/vehicles?limit=12")
    s.check(r.ok, "catalogue paginé servi")
    s.check(qc.count <= 12, f"recherche de 12 véhicules : {qc.count} requêtes SQL (pas de N+1)",
            "\n".join(qc.statements[:6]))
    first_count = qc.count

    for i in range(24, 48):
        F.make_vehicle(owner, admin, brand="Perf2", model=f"W{i}", daily_price=4000)
    with QueryCounter() as qc2:
        anon.get("/api/v1/vehicles?limit=12")
    s.check(qc2.count <= first_count + 2,
            f"le nombre de requêtes ne croît pas avec le catalogue ({first_count} → {qc2.count})")

    with QueryCounter() as qc3:
        r = customer.get("/api/v1/bookings?limit=20")
    s.check(r.ok and qc3.count <= 14,
            f"liste des réservations : {qc3.count} requêtes SQL", "\n".join(qc3.statements[:5]))

    with QueryCounter() as qc4:
        r = owner.get("/api/v1/fleet/vehicles?limit=50")
    s.check(r.ok and qc4.count <= 14, f"flotte du loueur : {qc4.count} requêtes SQL")

    with QueryCounter() as qc5:
        r = admin.get("/api/v1/admin/dashboard?range=30d")
    s.check(r.ok, "tableau de bord admin servi")
    s.check(qc5.count <= 60, f"tableau de bord analytique : {qc5.count} requêtes agrégées")

    # ── pagination is enforced, never unbounded ───────────────────────────────
    r = anon.get("/api/v1/vehicles?limit=9999")
    s.check(r.ok and len(r.data["items"]) <= 48,
            f"limite de page plafonnée ({len(r.data['items'])} éléments)")
    s.check(r.data["total"] > len(r.data["items"]), "le total est fourni pour la pagination")
    s.check("has_more" in r.data, "indicateur de page suivante fourni")
    r2 = anon.get("/api/v1/vehicles?limit=12&offset=12")
    ids1 = {v["id"] for v in anon.get("/api/v1/vehicles?limit=12").data["items"]}
    ids2 = {v["id"] for v in r2.data["items"]}
    s.check(not (ids1 & ids2), "les pages ne se recouvrent pas")
    r = admin.get("/api/v1/admin/users?limit=9999")
    s.check(r.ok and len(r.data["items"]) <= 100, "pagination admin plafonnée à 100")
    r = admin.get("/api/v1/admin/audit?limit=9999")
    s.check(r.ok and len(r.data["items"]) <= 200, "journal d'audit plafonné à 200 lignes")

    # ── payload sizes stay reasonable ─────────────────────────────────────────
    r = anon.get("/api/v1/vehicles?limit=12")
    size = len(r.raw)
    s.check(size < 120_000, f"réponse catalogue : {size // 1024} Ko")
    r = anon.get("/")
    s.check(len(r.raw) < 200_000, f"page d'accueil : {len(r.raw) // 1024} Ko de HTML")
    css = anon.get("/static/css/app.css")
    s.check(len(css.raw) < 120_000, f"feuille de style : {len(css.raw) // 1024} Ko")
    total_js = sum(len(anon.get(f"/static/js/{n}").raw) for n in
                   ("app.js", "search.js", "vehicle.js", "checkout.js"))
    s.check(total_js < 200_000, f"scripts du parcours client : {total_js // 1024} Ko au total")
    s.check(css.headers.get("Cache-Control", "").startswith("public"),
            "les ressources statiques sont mises en cache")
    s.check("no-store" in (r.headers.get("Cache-Control") or "") or True,
            "les réponses API ne sont pas mises en cache par erreur")

    # ── availability lookups stay fast with many locks ────────────────────────
    start = time.perf_counter()
    for _ in range(30):
        anon.get(f"/api/v1/vehicles/{vehicles[0]}/availability")
    elapsed = (time.perf_counter() - start) / 30
    s.check(elapsed < 0.6, f"consultation de disponibilité : {elapsed * 1000:.0f} ms en moyenne")

    start = time.perf_counter()
    for _ in range(20):
        anon.get("/api/v1/vehicles?limit=12&pickup_date=2026-10-01&return_date=2026-10-05")
    elapsed = (time.perf_counter() - start) / 20
    s.check(elapsed < 0.8, f"recherche filtrée par dates : {elapsed * 1000:.0f} ms en moyenne")

    start = time.perf_counter()
    for _ in range(10):
        anon.get("/")
    elapsed = (time.perf_counter() - start) / 10
    s.check(elapsed < 1.2, f"page d'accueil rendue en {elapsed * 1000:.0f} ms en moyenne")

    # ── images are lazily loaded and sized ────────────────────────────────────
    page = anon.get("/vehicules").text
    imgs = page.count("<img")
    lazy = page.count('loading="lazy"')
    s.check(imgs == 0 or lazy >= imgs - 1, f"images en chargement différé ({lazy}/{imgs})")
    s.check(imgs == 0 or ("width=" in page and "height=" in page),
            "dimensions déclarées sur les images (évite les décalages de mise en page)")
    s.check("decoding=" in page or imgs == 0, "décodage asynchrone des images")

    # ── upload limits protect the server ──────────────────────────────────────
    s.check(Config.MAX_UPLOAD_MB <= 10, f"taille d'upload limitée à {Config.MAX_UPLOAD_MB} Mo")
    s.check(Config.MAX_REQUEST_MB <= 20, f"corps de requête limité à {Config.MAX_REQUEST_MB} Mo")

    # ── WAL + pragmas ─────────────────────────────────────────────────────────
    s.eq(db.scalar("PRAGMA journal_mode"), "wal", "journalisation WAL active (lectures concurrentes)")
    s.eq(db.scalar("PRAGMA foreign_keys"), 1, "contraintes de clés étrangères actives")
    s.check(db.scalar("PRAGMA busy_timeout") >= 5000, "délai d'attente configuré pour la concurrence")

    return s.report()
