"""Authentication, registration, sessions, password reset, profile."""
from __future__ import annotations
from app import db
from app.config import Config
from .harness import Suite, Client
from . import fixtures as F


def run() -> bool:
    s = Suite("Authentification et comptes")
    print("\n  Authentification")

    # ── registration validation ───────────────────────────────────────────────
    c = Client()
    r = c.post("/api/v1/auth/register", {"email": "pas-un-email", "password": "court",
                                         "full_name": "A"})
    s.status(r, 422, "inscription rejetée avec des données invalides")
    fields = r.error.get("fields", {})
    s.check("email" in fields and "password" in fields and "full_name" in fields,
            "les trois champs invalides sont signalés", str(fields))

    r = c.post("/api/v1/auth/register", {"email": F.uniq("weak"), "password": "abcdefghij",
                                         "full_name": "Test Sans Chiffre"})
    s.status(r, 422, "mot de passe sans chiffre refusé")

    # ── successful registration ───────────────────────────────────────────────
    email = F.uniq("nouveau")
    c2 = Client()
    r = c2.register(email, F.PASSWORD, "Nouveau Client", "0770112233")
    s.status(r, 201, "inscription valide acceptée")
    s.check(r.data and r.data["user"]["email"] == email, "l'utilisateur est renvoyé connecté")
    s.check(bool(r.data.get("csrf_token")), "un jeton CSRF est fourni à la session")
    s.check("password" not in str(r.payload) and "password_hash" not in str(r.payload),
            "aucune donnée de mot de passe dans la réponse")

    # ── duplicate registration must not leak account existence ────────────────
    c3 = Client()
    r = c3.post("/api/v1/auth/register", {"email": email, "password": F.PASSWORD,
                                          "full_name": "Doublon Test"})
    s.status(r, 409, "deuxième inscription avec le même e-mail refusée")
    s.check("existe" not in r.message.lower() and "déjà" not in r.message.lower(),
            "le message ne confirme pas l'existence du compte", r.message)

    # ── password hashing ──────────────────────────────────────────────────────
    row = db.one("SELECT password_hash FROM users WHERE email = ?", (email,))
    s.check(row and row["password_hash"].startswith("pbkdf2_sha256$"),
            "mot de passe stocké avec PBKDF2-SHA256")
    s.check(F.PASSWORD not in (row["password_hash"] if row else ""),
            "le mot de passe en clair n'apparaît pas en base")

    # ── login ─────────────────────────────────────────────────────────────────
    c4 = Client()
    r = c4.post("/api/v1/auth/login", {"email": email, "password": "MauvaisMotDePasse1"})
    s.status(r, 401, "connexion refusée avec un mauvais mot de passe")
    wrong_pw_message = r.message
    r = c4.post("/api/v1/auth/login", {"email": "inconnu@nulle-part.dz", "password": "MauvaisMotDePasse1"})
    s.status(r, 401, "connexion refusée pour un compte inexistant")
    s.eq(r.message, wrong_pw_message, "message identique : pas d'énumération de comptes")

    r = c4.login(email, F.PASSWORD)
    s.status(r, 200, "connexion réussie")
    s.check(bool(c4.csrf), "session établie avec jeton CSRF")

    cookie_names = [ck.name for ck in c4.jar]
    s.check("rentdz_session" in cookie_names, "cookie de session posé")
    session_cookie = next((ck for ck in c4.jar if ck.name == "rentdz_session"), None)
    s.check(session_cookie is not None and session_cookie.has_nonstandard_attr("HttpOnly"),
            "cookie de session marqué HttpOnly")
    s.check(session_cookie is not None
            and not db.one("SELECT 1 FROM sessions WHERE token_hash = ?", (session_cookie.value,)),
            "le jeton de session brut n'est pas stocké en base (haché seulement)")

    # ── session identity ──────────────────────────────────────────────────────
    r = c4.get("/api/v1/auth/me")
    s.check(r.ok and r.data["user"]["email"] == email, "/auth/me renvoie l'utilisateur connecté")
    s.check("customer" in r.data["roles"], "rôle client attribué par défaut")
    s.check("booking.create" in r.data["permissions"], "permission de réservation accordée")
    s.check("user.manage" not in r.data["permissions"],
            "aucune permission d'administration pour un client")

    # ── logout kills the session ──────────────────────────────────────────────
    c4.logout()
    r = c4.get("/api/v1/auth/me")
    s.check(r.ok and r.data["user"] is None, "après déconnexion, plus d'utilisateur en session")
    r = c4.get("/api/v1/bookings")
    s.status(r, 401, "les routes protégées refusent la session révoquée")

    # ── password reset ────────────────────────────────────────────────────────
    c5 = Client()
    r = c5.post("/api/v1/auth/password/forgot", {"email": email})
    s.status(r, 200, "demande de réinitialisation acceptée")
    token = r.data.get("debug_token")
    s.check(bool(token), "jeton de réinitialisation généré (mode développement)")
    r2 = c5.post("/api/v1/auth/password/forgot", {"email": "aucun-compte@nulle-part.dz"})
    s.check(r2.ok and r2.data["message"] == r.data["message"],
            "réponse identique pour un e-mail inconnu")

    r = c5.post("/api/v1/auth/password/reset", {"token": "jeton-invalide", "password": "NouveauMdp2026"})
    s.status(r, 400, "jeton de réinitialisation invalide refusé")
    r = c5.post("/api/v1/auth/password/reset", {"token": token, "password": "faible"})
    s.status(r, 422, "nouveau mot de passe faible refusé")
    r = c5.post("/api/v1/auth/password/reset", {"token": token, "password": "NouveauMdp2026"})
    s.status(r, 200, "réinitialisation effectuée avec un jeton valide")
    r = c5.post("/api/v1/auth/password/reset", {"token": token, "password": "EncoreUnAutre2026"})
    s.status(r, 400, "le jeton de réinitialisation ne peut pas être réutilisé")

    c6 = Client()
    s.check(c6.login(email, "NouveauMdp2026").ok, "connexion avec le nouveau mot de passe")
    s.check(not Client().login(email, F.PASSWORD).ok, "l'ancien mot de passe ne fonctionne plus")

    # ── email verification ────────────────────────────────────────────────────
    c7 = Client()
    vemail = F.uniq("verif")
    r = c7.register(vemail, F.PASSWORD, "Client À Vérifier")
    vtoken = r.payload.get("verification_token")
    s.check(bool(vtoken), "jeton de vérification d'e-mail émis à l'inscription")
    s.status(c7.post("/api/v1/auth/verify-email", {"token": "faux"}), 400,
             "jeton de vérification invalide refusé")
    s.status(c7.post("/api/v1/auth/verify-email", {"token": vtoken}), 200,
             "vérification d'e-mail acceptée")
    s.check(bool(db.scalar("SELECT email_verified_at FROM users WHERE email = ?", (vemail,))),
            "date de vérification enregistrée")

    # ── profile ───────────────────────────────────────────────────────────────
    r = c7.post("/api/v1/profile", {"full_name": "Nom Modifié", "phone": "0661445566",
                                    "address": "Nouvelle adresse, Oran"})
    s.status(r, 200, "mise à jour du profil acceptée")
    s.eq(r.data["full_name"], "Nom Modifié", "nom mis à jour")
    s.eq(r.data["phone"], "0661445566", "téléphone algérien normalisé et enregistré")
    r = c7.post("/api/v1/profile", {"phone": "+213 770 11 22 33"})
    s.eq(r.data["phone"], "0770112233", "format international +213 normalisé en 0…")
    r = c7.post("/api/v1/profile", {"phone": "12345"})
    s.status(r, 400, "numéro non algérien refusé")

    # ── password change revokes sessions ──────────────────────────────────────
    r = c7.post("/api/v1/auth/password/change", {"current_password": "faux",
                                                 "password": "AutreMdp2026"})
    s.status(r, 422, "changement refusé si le mot de passe actuel est faux")
    r = c7.post("/api/v1/auth/password/change", {"current_password": F.PASSWORD,
                                                 "password": "AutreMdp2026"})
    s.status(r, 200, "changement de mot de passe accepté")
    s.status(c7.get("/api/v1/bookings"), 401,
             "les sessions existantes sont révoquées après changement de mot de passe")

    # ── account suspension blocks access ──────────────────────────────────────
    admin = F.make_admin()
    victim_email = F.uniq("suspendu")
    victim = F.make_customer(victim_email)
    uid = db.scalar("SELECT id FROM users WHERE email = ?", (victim_email,))
    r = admin.post(f"/api/v1/admin/users/{uid}/suspend", {"action": "suspend"})
    s.status(r, 400, "suspension refusée sans motif")
    r = admin.post(f"/api/v1/admin/users/{uid}/suspend",
                   {"action": "suspend", "reason": "Fraude suspectée"})
    s.status(r, 200, "suspension acceptée avec motif")
    s.status(victim.get("/api/v1/bookings"), 401,
             "la session du compte suspendu est immédiatement révoquée")
    r = Client().login(victim_email, F.PASSWORD)
    s.status(r, 403, "un compte suspendu ne peut plus se connecter")
    r = admin.post(f"/api/v1/admin/users/{uid}/suspend", {"action": "reactivate"})
    s.check(r.ok and Client().login(victim_email, F.PASSWORD).ok,
            "réactivation rétablit l'accès")

    return s.report()
