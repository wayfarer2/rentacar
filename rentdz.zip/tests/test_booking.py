"""
Booking engine. The central guarantee under test: a vehicle can never hold two
overlapping blocking bookings, including under concurrent requests.
"""
from __future__ import annotations
import threading
from datetime import timedelta
from app import db
from app.security import now, utc_str
from app.services import settings_service as S
from .harness import Suite, Client
from . import fixtures as F


def overlap_count() -> int:
    """Any vehicle+day appearing twice in the lock table would be a breach."""
    return db.scalar("""SELECT COUNT(*) FROM (
        SELECT vehicle_id, day, COUNT(*) c FROM vehicle_day_locks
         GROUP BY vehicle_id, day HAVING c > 1)""", (), 0)


def sql_overlap_breach() -> list:
    """Independent check straight against bookings, ignoring the lock table."""
    return db.rows_to_dicts(db.query("""
        SELECT a.reference AS a_ref, b.reference AS b_ref, a.vehicle_id
          FROM bookings a JOIN bookings b
            ON a.vehicle_id = b.vehicle_id AND a.id < b.id
         WHERE a.status IN ('pending','awaiting_payment','confirmed','active')
           AND b.status IN ('pending','awaiting_payment','confirmed','active')
           AND a.pickup_date <= b.return_date
           AND b.pickup_date <= a.return_date"""))


def run() -> bool:
    s = Suite("Moteur de réservation")
    print("\n  Moteur de réservation")
    # Anti-abuse quotas are exercised in their own section further down; keep them
    # out of the way while testing the engine itself.
    S.set_value("max_pending_bookings_per_user", 999)
    S.set_value("max_bookings_per_day_per_user", 999)
    admin = F.make_admin()
    owner, company_id = F.make_fleet_owner(admin, name="Loueur Réservation")
    vehicle = F.make_vehicle(owner, admin, daily_price=5000, deposit=20000)
    customer = F.make_customer()
    F.approve_licence(customer, admin)

    # ── happy path ────────────────────────────────────────────────────────────
    r = F.book(customer, vehicle, 10, 13)
    s.status(r, 201, "réservation créée sur des dates libres")
    booking = r.data
    s.check(booking["reference"].startswith("RDZ-"), "référence lisible générée",
            str(booking.get("reference")))
    s.eq(booking["status"], "pending", "statut initial : en attente de confirmation")
    s.eq(booking["days"], 3, "durée calculée : 3 jours")
    s.eq(booking["total_amount"], 15000, "montant = 3 × 5 000 DA")
    s.eq(booking["deposit_amount"], 20000, "caution reprise du véhicule")
    s.check(booking["hold_expires_at"] is not None, "un délai de maintien est posé")
    locked = db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?",
                       (booking["id"],), 0)
    s.eq(locked, 4, "4 jours bloqués (départ → retour inclus)")

    # ── exact same dates ──────────────────────────────────────────────────────
    other = F.make_customer()
    F.approve_licence(other, admin)
    r = F.book(other, vehicle, 10, 13)
    s.status(r, 409, "mêmes dates exactes refusées")
    s.eq(r.code, "dates_unavailable", "code d'erreur explicite")

    # ── every overlap shape ───────────────────────────────────────────────────
    for label, a, b in [("chevauchement au début", 8, 11),
                        ("chevauchement à la fin", 12, 15),
                        ("période englobante", 5, 20),
                        ("période incluse", 11, 12),
                        ("un seul jour commun", 13, 16)]:
        r = F.book(other, vehicle, a, b)
        s.status(r, 409, f"refusé : {label}")

    # ── adjacency: the day after the return is bookable ───────────────────────
    r = F.book(other, vehicle, 14, 17)
    s.status(r, 201, "dates adjacentes acceptées (départ le lendemain du retour)")
    adjacent_id = r.data["id"] if r.ok else None

    # ── same-day rental ───────────────────────────────────────────────────────
    r = F.book(other, vehicle, 30, 30, pickup_at=F.dates(30, 30, "09:00")[0],
               return_at=F.dates(30, 30, "18:00")[1])
    s.status(r, 201, "location sur la journée acceptée")
    if r.ok:
        s.eq(r.data["days"], 1, "location du jour facturée 1 jour")
        s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?",
                       (r.data["id"],), 0), 1, "un seul jour bloqué")

    # ── concurrency: 8 clients, same vehicle, same dates, simultaneously ───────
    race_vehicle = F.make_vehicle(owner, admin, brand="Kia", model="Rio", daily_price=4000)
    racers = []
    for _ in range(8):
        c = F.make_customer()
        F.approve_licence(c, admin)
        racers.append(c)
    results, lock = [], threading.Lock()
    barrier = threading.Barrier(len(racers))

    def attempt(client):
        barrier.wait()
        resp = F.book(client, race_vehicle, 45, 48)
        with lock:
            results.append(resp)

    threads = [threading.Thread(target=attempt, args=(c,)) for c in racers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=45)

    created = [r for r in results if r.status == 201]
    conflicts = [r for r in results if r.status == 409]
    s.eq(len(results), len(racers), "toutes les requêtes concurrentes ont abouti à une réponse")
    s.eq(len(created), 1, "exactement une réservation créée sur 8 tentatives simultanées")
    s.eq(len(conflicts), len(racers) - 1, "les 7 autres reçoivent un conflit propre (409)")
    s.check(all(r.code == "dates_unavailable" for r in conflicts),
            "tous les échecs portent le code métier attendu",
            str({r.code for r in conflicts}))
    s.eq(db.scalar("""SELECT COUNT(*) FROM bookings WHERE vehicle_id = ?
                       AND status IN ('pending','awaiting_payment','confirmed','active')""",
                   (race_vehicle,), 0), 1,
         "une seule réservation active en base pour ce véhicule")
    orphans = db.scalar("""SELECT COUNT(*) FROM vehicle_day_locks l
                            LEFT JOIN bookings b ON b.id = l.booking_id
                           WHERE l.booking_id IS NOT NULL AND b.id IS NULL""", (), 0)
    s.eq(orphans, 0, "aucun verrou orphelin après les transactions annulées")

    # ── the invariant, checked two independent ways ────────────────────────────
    s.eq(overlap_count(), 0, "invariant : aucun jour-véhicule verrouillé deux fois")
    s.eq(len(sql_overlap_breach()), 0,
         "invariant : aucune paire de réservations actives qui se chevauchent",
         str(sql_overlap_breach()[:3]))

    # ── database-level enforcement, bypassing the service layer ───────────────
    import sqlite3
    day = (now().date() + timedelta(days=200)).isoformat()
    with db.transaction():
        db.insert("vehicle_day_locks", {"vehicle_id": vehicle, "day": day, "kind": "blocked"})
    raised = False
    try:
        with db.transaction():
            db.insert("vehicle_day_locks", {"vehicle_id": vehicle, "day": day, "kind": "booking"})
    except sqlite3.IntegrityError:
        raised = True
    s.check(raised, "la contrainte UNIQUE de la base refuse un second verrou sur le même jour")
    db.execute("DELETE FROM vehicle_day_locks WHERE vehicle_id = ? AND day = ?", (vehicle, day))

    # ── maintenance blocks booking ────────────────────────────────────────────
    maint_vehicle = F.make_vehicle(owner, admin, brand="Dacia", model="Duster")
    start = (now() + timedelta(days=60)).strftime("%Y-%m-%d")
    end = (now() + timedelta(days=64)).strftime("%Y-%m-%d")
    r = owner.post(f"/api/v1/fleet/vehicles/{maint_vehicle}/block",
                   {"kind": "maintenance", "start_date": start, "end_date": end,
                    "reason": "Révision des 60 000 km"})
    s.status(r, 200, "période de maintenance enregistrée")
    r = F.book(customer, maint_vehicle, 61, 63)
    s.status(r, 409, "réservation refusée pendant une maintenance")
    r = F.book(customer, maint_vehicle, 59, 61)
    s.status(r, 409, "refusée aussi en chevauchement partiel de la maintenance")
    r = F.book(customer, maint_vehicle, 66, 68)
    s.status(r, 201, "réservation acceptée après la maintenance")

    # ── manual block ──────────────────────────────────────────────────────────
    block_vehicle = F.make_vehicle(owner, admin, brand="Peugeot", model="208")
    bstart = (now() + timedelta(days=70)).strftime("%Y-%m-%d")
    bend = (now() + timedelta(days=72)).strftime("%Y-%m-%d")
    r = owner.post(f"/api/v1/fleet/vehicles/{block_vehicle}/block",
                   {"kind": "blocked", "start_date": bstart, "end_date": bend,
                    "reason": "Usage personnel"})
    s.status(r, 200, "dates bloquées par le loueur")
    s.status(F.book(customer, block_vehicle, 71, 73), 409,
             "réservation refusée sur des dates bloquées")
    r = owner.post(f"/api/v1/fleet/vehicles/{block_vehicle}/block",
                   {"kind": "blocked", "start_date": bstart, "end_date": bend, "reason": "Doublon"})
    s.status(r, 409, "un blocage ne peut pas chevaucher un blocage existant")
    s.check(bool(r.error.get("conflicts")), "les jours en conflit sont retournés au loueur")

    # unblock frees the days
    block_id = db.scalar("SELECT id FROM vehicle_blocks WHERE vehicle_id = ? ORDER BY id DESC LIMIT 1",
                         (block_vehicle,))
    r = owner.delete(f"/api/v1/fleet/vehicles/{block_vehicle}/block/blocked/{block_id}")
    s.status(r, 200, "déblocage effectué")
    s.status(F.book(customer, block_vehicle, 71, 73), 201,
             "les dates redeviennent réservables après déblocage")

    # ── cancellation releases the days ────────────────────────────────────────
    cancel_vehicle = F.make_vehicle(owner, admin, brand="Hyundai", model="i10")
    r = F.book(customer, cancel_vehicle, 80, 84)
    s.status(r, 201, "réservation créée pour test d'annulation")
    cid = r.data["id"]
    s.status(F.book(other, cancel_vehicle, 81, 83), 409, "dates occupées avant annulation")
    r = customer.post(f"/api/v1/bookings/{cid}/cancel", {"reason": "Changement de programme"})
    s.status(r, 200, "annulation acceptée")
    s.eq(db.scalar("SELECT status FROM bookings WHERE id = ?", (cid,)), "cancelled",
         "statut passé à annulée")
    s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?", (cid,), 0), 0,
         "les verrous de la réservation annulée sont supprimés")
    s.status(F.book(other, cancel_vehicle, 81, 83), 201,
             "les dates sont réservables après annulation")
    r = customer.post(f"/api/v1/bookings/{cid}/cancel", {"reason": "Encore"})
    s.status(r, 409, "une réservation déjà annulée ne peut pas être re-annulée")

    # ── hold expiry frees inventory ───────────────────────────────────────────
    exp_vehicle = F.make_vehicle(owner, admin, brand="Seat", model="Ibiza")
    r = F.book(customer, exp_vehicle, 90, 93)
    exp_id = r.data["id"]
    db.execute("UPDATE bookings SET hold_expires_at = ? WHERE id = ?",
               ((now() - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"), exp_id))
    r = admin.post("/api/v1/maintenance/release-holds")
    s.status(r, 200, "traitement des réservations expirées exécuté")
    s.check(r.data["expired_bookings"] >= 1, "au moins une réservation expirée traitée")
    s.eq(db.scalar("SELECT status FROM bookings WHERE id = ?", (exp_id,)), "expired",
         "réservation marquée expirée")
    s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?", (exp_id,), 0), 0,
         "véhicule libéré après expiration")
    s.status(F.book(other, exp_vehicle, 90, 93), 201,
             "les dates expirées sont réattribuables")

    # ── date validation ───────────────────────────────────────────────────────
    r = F.book(customer, vehicle, 5, 3)
    s.check(r.status in (409, 422), "retour avant départ refusé", f"HTTP {r.status}")
    r = F.book(customer, vehicle, -3, 2)
    s.check(r.status in (409, 422), "départ dans le passé refusé", f"HTTP {r.status}")
    pickup, ret = F.dates(400, 405)
    r = F.book(customer, vehicle, 400, 405)
    s.check(r.status in (409, 422), "départ trop loin dans le futur refusé", f"HTTP {r.status}")
    r = customer.post("/api/v1/bookings", {"vehicle_id": vehicle, "pickup_at": "pas-une-date",
                                           "return_at": "n'importe quoi"})
    s.status(r, 422, "dates malformées refusées")
    r = customer.post("/api/v1/bookings", {"vehicle_id": 999999, **dict(zip(
        ("pickup_at", "return_at"), F.dates(10, 12)))})
    s.status(r, 404, "véhicule inexistant → 404")

    # ── min / max duration on the vehicle ─────────────────────────────────────
    strict = F.make_vehicle(owner, admin, brand="Toyota", model="Corolla",
                            min_days=3, max_days=10)
    s.check(F.book(customer, strict, 100, 101).status in (409, 422),
            "durée inférieure au minimum du véhicule refusée")
    s.check(F.book(customer, strict, 100, 115).status in (409, 422),
            "durée supérieure au maximum du véhicule refusée")
    s.status(F.book(customer, strict, 100, 104), 201, "durée dans les bornes acceptée")

    # ── unapproved vehicle / company are not bookable ─────────────────────────
    pending_vehicle = F.make_vehicle(owner, admin, brand="Fiat", model="Doblo", approve=False)
    r = F.book(customer, pending_vehicle, 120, 123)
    s.status(r, 409, "véhicule non validé par la plateforme non réservable")
    s.eq(r.code, "vehicle_not_approved", "code d'erreur : véhicule non approuvé")

    owner2, company2 = F.make_fleet_owner(admin, name="Loueur Non Validé", approve=False)
    r = owner2.post("/api/v1/fleet/vehicles", {
        "brand": "Skoda", "model": "Octavia", "year": 2023, "category": "sedan",
        "transmission": "manual", "fuel": "diesel", "seats": 5, "daily_price": 6000})
    s.status(r, 409, "un loueur non validé ne peut pas publier de véhicule")

    # ── vendor workflow transitions ───────────────────────────────────────────
    flow_vehicle = F.make_vehicle(owner, admin, brand="Renault", model="Symbol")
    r = F.book(customer, flow_vehicle, 130, 133)
    fid = r.data["id"]
    r = owner.post(f"/api/v1/bookings/{fid}/status", {"status": "completed"})
    s.status(r, 409, "transition invalide refusée (en attente → terminée)")
    s.eq(r.code, "invalid_transition", "code de transition invalide")
    r = owner.post(f"/api/v1/bookings/{fid}/status", {"status": "confirmed"})
    s.status(r, 200, "le loueur confirme la réservation")
    s.eq(db.scalar("SELECT status FROM bookings WHERE id = ?", (fid,)), "confirmed",
         "statut confirmé enregistré")
    s.check(db.scalar("SELECT hold_expires_at FROM bookings WHERE id = ?", (fid,)) is None,
            "le délai de maintien est levé après confirmation")
    s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?", (fid,), 0), 4,
         "les dates restent bloquées après confirmation")
    r = owner.post(f"/api/v1/bookings/{fid}/status", {"status": "active"})
    s.status(r, 200, "remise des clés : réservation active")
    s.eq(db.scalar("SELECT status FROM vehicles WHERE id = ?", (flow_vehicle,)), "rented",
         "le véhicule passe à l'état loué")
    r = customer.post(f"/api/v1/bookings/{fid}/cancel", {"reason": "Trop tard"})
    s.status(r, 409, "une location en cours ne peut pas être annulée par le client")
    r = owner.post(f"/api/v1/bookings/{fid}/status", {"status": "completed"})
    s.status(r, 200, "clôture de la location")
    s.eq(db.scalar("SELECT status FROM vehicles WHERE id = ?", (flow_vehicle,)), "available",
         "le véhicule redevient disponible")
    s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?", (fid,), 0), 0,
         "les dates sont libérées après clôture")
    history = db.scalar("SELECT COUNT(*) FROM booking_status_history WHERE booking_id = ?", (fid,), 0)
    s.check(history >= 4, f"historique complet des transitions ({history} entrées)")

    # ── rejection requires a reason and frees the dates ───────────────────────
    rej_vehicle = F.make_vehicle(owner, admin, brand="Suzuki", model="Swift")
    r = F.book(customer, rej_vehicle, 140, 143)
    rid = r.data["id"]
    s.status(owner.post(f"/api/v1/bookings/{rid}/status", {"status": "rejected"}), 400,
             "refus sans motif rejeté")
    r = owner.post(f"/api/v1/bookings/{rid}/status",
                   {"status": "rejected", "reason": "Véhicule immobilisé"})
    s.status(r, 200, "refus accepté avec motif")
    s.eq(db.scalar("SELECT COUNT(*) FROM vehicle_day_locks WHERE booking_id = ?", (rid,), 0), 0,
         "dates libérées après refus")

    # ── documents-before-confirmation rule ────────────────────────────────────
    S.set_value("require_documents_before_confirm", True)
    nodoc = F.make_customer()
    doc_vehicle = F.make_vehicle(owner, admin, brand="Chery", model="Tiggo")
    r = F.book(nodoc, doc_vehicle, 150, 152)
    ndid = r.data["id"]
    r = owner.post(f"/api/v1/bookings/{ndid}/status", {"status": "confirmed"})
    s.status(r, 409, "confirmation bloquée sans permis approuvé")
    s.eq(r.code, "documents_required", "code d'erreur : documents requis")
    F.approve_licence(nodoc, admin)
    r = owner.post(f"/api/v1/bookings/{ndid}/status", {"status": "confirmed"})
    s.status(r, 200, "confirmation possible une fois le permis approuvé")

    # ── expired licence must not be accepted at booking time ─────────────────
    exp_lic = F.make_customer()
    F.approve_licence(exp_lic, admin)
    pickup, ret = F.dates(160, 163)
    r = exp_lic.post("/api/v1/bookings", {
        "vehicle_id": vehicle, "pickup_at": pickup, "return_at": ret,
        "full_name": "Permis Expiré", "phone": "0555123456",
        "license_number": "DZ111", "license_expires_at": (now() + timedelta(days=5)).strftime("%Y-%m-%d")})
    s.status(r, 422, "permis expirant avant le départ refusé")

    # ── fraud guard: too many pending bookings ────────────────────────────────
    S.set_value("max_pending_bookings_per_user", 2)
    spammer = F.make_customer()
    F.approve_licence(spammer, admin)
    spam_vehicles = [F.make_vehicle(owner, admin, brand="Test", model=f"Spam{i}") for i in range(4)]
    statuses = [F.book(spammer, spam_vehicles[i], 170 + i * 5, 172 + i * 5).status for i in range(4)]
    s.eq(statuses[:2], [201, 201], "les deux premières réservations en attente passent")
    s.check(409 in statuses[2:], "la limite de réservations en attente est appliquée",
            str(statuses))
    S.set_value("max_pending_bookings_per_user", 999)

    # ── final invariant sweep ────────────────────────────────────────────────
    s.eq(overlap_count(), 0, "invariant final : aucun chevauchement de verrous")
    s.eq(len(sql_overlap_breach()), 0, "invariant final : aucun chevauchement de réservations")
    return s.report()
