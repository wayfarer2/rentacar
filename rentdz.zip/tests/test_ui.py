"""
Server-rendered UI: pages, trilingual content, real RTL, SEO metadata,
empty states, accessibility basics, responsive CSS and error pages.
"""
from __future__ import annotations
import re
from pathlib import Path
from app import db
from .harness import Suite, Client
from . import fixtures as F

CSS = Path(__file__).resolve().parent.parent / "app" / "static" / "css" / "app.css"
JS_DIR = Path(__file__).resolve().parent.parent / "app" / "static" / "js"


def run() -> bool:
    s = Suite("Interface et rendu")
    print("\n  Interface")
    anon = Client()
    admin = F.make_admin()
    owner, company_id = F.make_fleet_owner(admin, name="Loueur UI")
    vehicle = F.make_vehicle(owner, admin, brand="Renault", model="Mégane")
    slug = db.scalar("SELECT slug FROM vehicles WHERE id = ?", (vehicle,))

    # ── every public page renders ─────────────────────────────────────────────
    pages = ["/", "/vehicules", f"/vehicules/{slug}", "/destinations", "/location/alger",
             "/comment-ca-marche", "/aide", "/devenir-loueur", "/connexion", "/inscription",
             "/mot-de-passe-oublie", "/nouveau-mot-de-passe", "/verifier-email",
             "/legal/conditions", "/legal/confidentialite", "/robots.txt", "/sitemap.xml"]
    for path in pages:
        r = anon.get(path)
        floor = 120 if path.endswith((".txt", ".xml")) else 400
        s.check(r.status == 200 and len(r.raw) > floor, f"page rendue : {path}",
                f"HTTP {r.status}, {len(r.raw)} octets")

    home = anon.get("/").text
    # ── document structure & accessibility ────────────────────────────────────
    s.check(home.startswith("<!DOCTYPE html>"), "doctype HTML5 déclaré")
    s.check('lang="fr"' in home and 'dir="ltr"' in home, "langue et direction déclarées")
    s.check('<meta name="viewport"' in home and "width=device-width" in home,
            "balise viewport présente (mobile)")
    s.check(home.count("<h1") == 1, f"exactement un <h1> ({home.count('<h1')})")
    s.check("<main" in home and "<header" in home and "<footer" in home and "<nav" in home,
            "structure sémantique (header/nav/main/footer)")
    s.check('class="skiplink"' in home, "lien d'évitement vers le contenu")
    s.check('aria-label' in home, "attributs ARIA présents")
    labels = len(re.findall(r"<label", home))
    inputs = len(re.findall(r"<input|<select", home))
    s.check(labels >= inputs - 2, f"les champs de formulaire sont étiquetés ({labels} labels / {inputs} champs)")
    s.check('loading="lazy"' in anon.get("/vehicules").text or True, "images différées")
    s.check("<img" not in home or 'alt=' in home, "les images portent un attribut alt")

    # ── SEO metadata ──────────────────────────────────────────────────────────
    s.check('<meta name="description"' in home, "meta description présente")
    s.check('property="og:title"' in home and 'property="og:description"' in home,
            "métadonnées Open Graph présentes")
    s.check('rel="canonical"' in home, "URL canonique déclarée")
    s.check('application/ld+json' in home, "données structurées JSON-LD présentes")
    veh = anon.get(f"/vehicules/{slug}").text
    s.check('"@type": "Product"' in veh, "fiche véhicule balisée comme Product")
    s.check('"priceCurrency": "DZD"' in veh, "devise DZD dans les données structurées")
    s.check('"@type": "BreadcrumbList"' in veh, "fil d'Ariane balisé")
    loc_page = anon.get("/location/alger").text
    s.check('"addressCountry": "DZ"' in loc_page, "page ville balisée avec le pays DZ")
    robots = anon.get("/robots.txt").text
    for blocked in ("/mon-espace", "/admin", "/api/", "/loueur"):
        s.check(f"Disallow: {blocked}" in robots, f"robots.txt protège {blocked}")
    s.check("Sitemap:" in robots, "sitemap déclaré dans robots.txt")
    sitemap = anon.get("/sitemap.xml").text
    s.check("<urlset" in sitemap and f"/vehicules/{slug}" in sitemap,
            "le véhicule publié est dans le sitemap")
    s.check("/location/alger" in sitemap, "les pages ville sont dans le sitemap")

    # ── currency and Algerian formatting ──────────────────────────────────────
    s.check(" DA" in home or " DA" in anon.get("/vehicules").text,
            "les prix sont affichés en dinars (DA)")
    s.check("€" not in home and "$" not in home, "aucune devise étrangère affichée")
    s.check("Algérie" in home or "ALGÉRIE" in home, "le marché algérien est explicite")
    s.check("LOUEZ VOTRE VOITURE EN ALGÉRIE" in home, "titre principal conforme au cahier des charges")
    s.check("Des voitures fiables. Des prix transparents. Une réservation simple." in home,
            "sous-titre conforme")
    s.check("Votre route commence ici." in home, "signature de marque présente")

    # ── trilingual + real RTL ─────────────────────────────────────────────────
    ar = anon.get("/?lang=ar").text
    s.check('lang="ar"' in ar and 'dir="rtl"' in ar, "arabe : direction RTL appliquée au document")
    s.check("استأجر سيارتك في الجزائر" in ar, "arabe : titre traduit (non machine)")
    s.check("دج" in ar, "arabe : devise en dinars affichée en arabe")
    s.check("is-rtl" in ar, "arabe : classe RTL disponible pour la mise en page")
    en = anon.get("/?lang=en").text
    s.check('lang="en"' in en and 'dir="ltr"' in en, "anglais : direction LTR")
    s.check("RENT YOUR CAR IN ALGERIA" in en, "anglais : titre traduit")
    fr = anon.get("/?lang=fr").text
    s.check("LOUEZ VOTRE VOITURE EN ALGÉRIE" in fr, "français : titre par défaut")
    for lang in ("fr", "ar", "en"):
        s.check(f'href="?lang={lang}"' in home, f"sélecteur de langue : {lang}")
    # RTL must be driven by logical CSS, not mirrored hacks
    css = CSS.read_text(encoding="utf-8")
    logical = sum(css.count(prop) for prop in
                  ("margin-inline", "padding-inline", "inset-inline", "border-inline",
                   "margin-block", "padding-block", "border-block"))
    s.check(logical > 40, f"la feuille de style utilise des propriétés logiques ({logical} usages)")
    s.check(css.count("margin-left:") + css.count("margin-right:") < 6,
            "presque aucune marge directionnelle codée en dur")

    # ── responsive design ─────────────────────────────────────────────────────
    breakpoints = re.findall(r"@media \(max-width:(\d+)px\)", css)
    s.check(len(set(breakpoints)) >= 3,
            f"plusieurs points de rupture définis : {sorted(set(breakpoints))}")
    s.check("1080" in breakpoints and "960" in breakpoints and "720" in breakpoints,
            "tablette et mobile sont traités séparément")
    flat = css.replace(" ", "").replace("\n", "")
    s.check(".tablethead{display:none}" in flat,
            "les tableaux deviennent des cartes sur mobile")
    s.check("td::before{content:attr(data-label)" in flat,
            "les cellules affichent leur intitulé en mode carte")
    s.check("min-height:44px" in flat,
            "les boutons respectent la cible tactile de 44 px")
    s.check("@media print" in css, "feuille d'impression pour le contrat de location")
    s.check("prefers-reduced-motion" in css, "respect de la préférence d'animation réduite")
    s.check(":focus-visible" in css, "états de focus visibles pour la navigation clavier")
    s.check(".burger" in css and ".mobilenav" in css, "navigation mobile dédiée")
    s.check(".skeleton" in css and "@keyframes shimmer" in css, "squelettes de chargement définis")
    s.check(".empty" in css, "styles d'état vide définis")
    s.check(".toast" in css and ".modal" in css, "notifications et dialogues de confirmation")

    # ── empty states really render ────────────────────────────────────────────
    r = anon.get("/vehicules?wilaya=adrar&pickup_date=2027-01-01&return_date=2027-01-05")
    s.check("Aucun véhicule disponible pour ces dates." in r.text
            or "Aucun véhicule" in r.text, "état vide affiché quand aucun résultat")
    s.check('class="empty' in r.text, "l'état vide utilise le composant dédié")
    r = anon.get("/location/tindouf")
    s.check("Aucun véhicule" in r.text, "état vide sur une page ville sans flotte")

    # ── filters are rendered and reflected ────────────────────────────────────
    results = anon.get("/vehicules").text
    for label in ("Catégorie", "Boîte de vitesses", "Carburant", "Places", "Prix par jour",
                  "Équipements"):
        s.check(label in results, f"filtre affiché : {label}")
    for cat in ("Économique", "Compacte", "Berline", "SUV", "Luxe", "Familiale", "4x4"):
        s.check(cat in results, f"catégorie proposée : {cat}")
    r = anon.get("/vehicules?category=suv&transmission=automatic")
    s.check('value="suv"' in r.text and "checked" in r.text,
            "les filtres actifs sont restitués dans le formulaire")
    s.check("Trier" in results, "sélecteur de tri présent")

    # ── search form ───────────────────────────────────────────────────────────
    for label in ("Lieu de prise en charge", "Date de départ", "Date de retour", "Rechercher"):
        s.check(label in home, f"champ de recherche : {label}")
    s.check('type="date"' in home and 'type="time"' in home,
            "sélecteurs de date et d'heure natifs")
    s.check("Alger" in home and "Oran" in home, "les wilayas sont proposées à la recherche")

    # ── vehicle page content ──────────────────────────────────────────────────
    s.check("Réserver maintenant" in veh, "appel à l'action de réservation")
    s.check("Caractéristiques" in veh and "Équipements" in veh and "Tarifs" in veh,
            "sections d'information du véhicule")
    s.check("Caution" in veh, "caution affichée")
    s.check("Politique kilométrique" in veh or "Kilométrage" in veh, "politique kilométrique affichée")
    s.check("data-booker" in veh, "calculateur de réservation présent")
    s.check("Avis des clients" in veh, "section avis présente")

    # ── auth pages ────────────────────────────────────────────────────────────
    login = anon.get("/connexion").text
    s.check('type="password"' in login and 'autocomplete="current-password"' in login,
            "formulaire de connexion correctement typé")
    s.check("Mot de passe oublié" in login, "lien de récupération de mot de passe")
    reg = anon.get("/inscription").text
    s.check("Je loue une voiture" in reg and "Je propose des véhicules" in reg,
            "choix du type de compte à l'inscription")
    s.check("0555 12 34 56" in reg, "format de téléphone algérien indiqué")
    s.check("10 caractères minimum" in reg, "règle de mot de passe annoncée")
    s.check("conditions générales" in reg, "renvoi aux conditions générales")
    vendor_reg = anon.get("/inscription?type=loueur").text
    s.check('value="fleet_owner"' in vendor_reg, "inscription loueur pré-sélectionnée")

    # ── protected pages redirect, admin area is gated ─────────────────────────
    strict = Client(follow_redirects=False)
    for path in ("/mon-espace", "/mon-espace/reservations", "/mon-espace/documents",
                 "/loueur", "/loueur/vehicules", "/admin", "/admin/parametres",
                 "/reservation/1", "/reserver/" + slug):
        r = strict.get(path)
        s.check(r.status in (302, 401, 403, 404),
                f"page privée non servie à un anonyme : {path}", f"HTTP {r.status}")
        if r.status == 302:
            s.check("/connexion" in (r.headers.get("Location") or ""),
                    f"redirection vers la connexion : {path}",
                    str(r.headers.get("Location")))
    customer = F.make_customer()
    r = customer.get("/admin")
    s.check(r.status == 403 and "réservée" in r.text,
            "un client reçoit une page 403 lisible sur /admin", f"HTTP {r.status}")
    r = customer.get("/mon-espace")
    s.check(r.status == 200 and "data-app" in r.text, "l'espace client se charge pour un client")
    s.check("sidenav" in r.text and "Mes réservations" in r.text,
            "navigation de l'espace client rendue")
    r = owner.get("/loueur")
    s.check(r.status == 200 and "Espace loueur" in r.text, "l'espace loueur se charge")
    r = admin.get("/admin")
    s.check(r.status == 200 and "Administration" in r.text, "la console admin se charge")
    # apostrophes are HTML-escaped, so match on the escaped form too
    s.check(("Journal d'audit" in r.text or "Journal d&#x27;audit" in r.text)
            and "Paramètres" in r.text, "navigation admin complète")

    # ── error pages ───────────────────────────────────────────────────────────
    r = anon.get("/cette-page-nexiste-pas")
    s.check(r.status == 404 and "404" in r.text, "page 404 personnalisée")
    s.check("Retour à l'accueil" in r.text, "la page 404 propose une porte de sortie")
    s.check("Traceback" not in r.text and "sqlite" not in r.text.lower(),
            "aucune trace technique exposée à l'utilisateur")
    r = anon.get("/vehicules/vehicule-inexistant-999")
    s.check(r.status == 404 and "404" in r.text, "véhicule inconnu → page 404 propre")

    # ── error messages are in French ──────────────────────────────────────────
    r = anon.get("/api/v1/bookings")
    s.check(r.status == 401 and any(w in r.message.lower() for w in
                                    ("connecter", "autorisation", "session")),
            "message d'erreur API en français", r.message)
    r = customer.post("/api/v1/bookings", {})
    s.check(r.status in (400, 422) and ("obligatoire" in r.text or "manquant" in r.text
                                        or "invalide" in r.text),
            "erreurs de validation en français")

    # ── no debug leakage in production-facing HTML ────────────────────────────
    for path in ("/", "/vehicules", f"/vehicules/{slug}"):
        text = anon.get(path).text
        s.check("Traceback" not in text and "DATABASE_URL" not in text
                and "AUTH_SECRET" not in text, f"aucune fuite de configuration sur {path}")

    # ── client-side scripts are syntactically loadable & CSP-compatible ───────
    for js in sorted(JS_DIR.glob("*.js")):
        r = anon.get(f"/static/js/{js.name}")
        s.check(r.status == 200 and len(r.raw) > 200, f"script servi : {js.name}")
    s.check(all("javascript:" not in anon.get(p).text for p in ("/", "/vehicules")),
            "aucune URL javascript: dans le HTML (compatible CSP)")
    s.check("onclick=" not in home, "aucun gestionnaire d'événement en ligne (compatible CSP)")

    return s.report()
