"""
Adversarial tests. Every case here is an attack attempt that must fail:
cross-tenant access, privilege escalation, CSRF, injection, malformed input,
document leakage, and payment tampering.
"""
from __future__ import annotations
import json
from app import db
from app.security import ROLES
from .harness import Suite, Client, PNG_1PX, PDF_MIN, BASE
from . import fixtures as F


def run() -> bool:
    s = Suite("Sécurité et autorisations")
    print("\n  Sécurité")
    admin = F.make_admin()
    from app.services import settings_service as S
    S.set_value("max_pending_bookings_per_user", 999)
    S.set_value("max_bookings_per_day_per_user", 999)

    owner_a, company_a = F.make_fleet_owner(admin, name="Loueur Alpha")
    owner_b, company_b = F.make_fleet_owner(admin, name="Loueur Beta")
    vehicle_a = F.make_vehicle(owner_a, admin, brand="Alpha", model="Car")
    vehicle_b = F.make_vehicle(owner_b, admin, brand="Beta", model="Car")

    victim = F.make_customer("victime@test.dz")
    attacker = F.make_customer("attaquant@test.dz")
    F.approve_licence(victim, admin)
    F.approve_licence(attacker, admin)

    r = F.book(victim, vehicle_a, 200, 203)
    assert r.ok, f"setup booking failed: {r.message}"
    victim_booking = r.data["id"]
    victim_ref = r.data["reference"]

    # ── 1. another customer's booking ─────────────────────────────────────────
    print("\n    Accès à la réservation d'un autre client")
    r = attacker.get(f"/api/v1/bookings/{victim_booking}")
    s.status(r, 404, "lecture de la réservation d'autrui refusée")
    s.check("victime@test.dz" not in r.text and victim_ref not in r.text,
            "aucune donnée de la victime dans la réponse")
    s.status(attacker.get(f"/api/v1/bookings/{victim_ref}"), 404,
             "accès par référence lisible également refusé")
    s.status(attacker.post(f"/api/v1/bookings/{victim_booking}/cancel", {"reason": "pirate"}), 404,
             "annulation de la réservation d'autrui refusée")
    s.eq(db.scalar("SELECT status FROM bookings WHERE id = ?", (victim_booking,)), "pending",
         "la réservation de la victime est intacte")
    s.status(attacker.get(f"/api/v1/bookings/{victim_booking}/agreement"), 404,
             "contrat de location d'autrui inaccessible")
    s.status(attacker.get(f"/api/v1/bookings/{victim_booking}/receipt"), 404,
             "reçu d'autrui inaccessible")
    s.status(attacker.post(f"/api/v1/bookings/{victim_booking}/status",
                           {"status": "confirmed"}), 404,
             "un client ne peut pas confirmer une réservation")

    # customer listing only returns their own
    r = attacker.get("/api/v1/bookings")
    s.check(r.ok and all(b["reference"] != victim_ref for b in r.data["items"]),
            "la liste des réservations ne contient que les siennes")

    # ── 2. cross-vendor fleet access ──────────────────────────────────────────
    print("\n    Accès inter-loueurs")
    s.status(owner_b.get(f"/api/v1/fleet/vehicles/{vehicle_a}"), 404,
             "un loueur ne voit pas le véhicule d'un autre")
    s.status(owner_b.put(f"/api/v1/fleet/vehicles/{vehicle_a}", {"daily_price": 1}), 404,
             "modification du véhicule d'un autre loueur refusée")
    s.eq(db.scalar("SELECT daily_price FROM vehicles WHERE id = ?", (vehicle_a,)), 5000,
         "le prix du véhicule visé est inchangé")
    s.status(owner_b.delete(f"/api/v1/fleet/vehicles/{vehicle_a}"), 404,
             "suppression du véhicule d'un autre loueur refusée")
    s.status(owner_b.get(f"/api/v1/fleet/vehicles/{vehicle_a}/calendar"), 404,
             "calendrier d'un autre loueur inaccessible")
    s.status(owner_b.post(f"/api/v1/fleet/vehicles/{vehicle_a}/block",
                          {"kind": "blocked", "start_date": "2027-01-01", "end_date": "2027-01-05"}), 404,
             "blocage de dates sur le véhicule d'un autre refusé")
    r = owner_b.upload(f"/api/v1/fleet/vehicles/{vehicle_a}/photos", {},
                       {"photo": ("x.png", PNG_1PX, "image/png")})
    s.status(r, 404, "ajout de photo sur le véhicule d'un autre refusé")

    # vendor cannot see or act on another vendor's bookings
    s.status(owner_b.get(f"/api/v1/bookings/{victim_booking}"), 404,
             "réservation d'un autre loueur invisible")
    s.status(owner_b.post(f"/api/v1/bookings/{victim_booking}/status",
                          {"status": "confirmed"}), 404,
             "confirmation de la réservation d'un autre loueur refusée")
    r = owner_b.get("/api/v1/fleet/bookings")
    s.check(r.ok and all(b["reference"] != victim_ref for b in r.data["items"]),
            "la liste des réservations du loueur B ne contient pas celles de A")

    # company_id spoofing
    r = owner_b.get(f"/api/v1/fleet/dashboard?company_id={company_a}")
    s.status(r, 404, "usurpation d'identifiant de société refusée")
    r = owner_b.post("/api/v1/fleet/vehicles", {
        "company_id": company_a, "brand": "Pirate", "model": "X", "year": 2023,
        "category": "compact", "transmission": "manual", "fuel": "petrol",
        "seats": 5, "daily_price": 3000})
    s.check(r.status == 404 or (r.ok and db.scalar(
        "SELECT company_id FROM vehicles WHERE id = ?", (r.data["id"],)) == company_b),
        "impossible de créer un véhicule dans la société d'un autre", f"HTTP {r.status}")
    s.status(owner_b.put(f"/api/v1/companies/{company_a}", {"name": "Détourné"}), 404,
             "modification de la société d'un autre refusée")
    s.eq(db.scalar("SELECT name FROM rental_companies WHERE id = ?", (company_a,)),
         "Loueur Alpha", "le nom de la société visée est inchangé")

    # vendor cannot set their own commission
    before_rate = db.scalar("SELECT commission_rate FROM rental_companies WHERE id = ?", (company_a,))
    owner_a.put(f"/api/v1/companies/{company_a}", {"commission_rate": 0})
    s.eq(db.scalar("SELECT commission_rate FROM rental_companies WHERE id = ?", (company_a,)),
         before_rate, "un loueur ne peut pas modifier son taux de commission")
    r = owner_a.put(f"/api/v1/companies/{company_a}", {"name": "Loueur Alpha", "commission_rate": 0})
    s.eq(db.scalar("SELECT commission_rate FROM rental_companies WHERE id = ?", (company_a,)),
         before_rate, "le champ commission est ignoré même dans une requête légitime")

    # ── 3. vendor endpoints as a plain customer ───────────────────────────────
    print("\n    Points de terminaison loueur utilisés par un client")
    for method, path, body in [
            ("GET", "/api/v1/fleet/dashboard", None),
            ("GET", "/api/v1/fleet/vehicles", None),
            ("GET", "/api/v1/fleet/bookings", None),
            ("GET", "/api/v1/fleet/today", None),
            ("GET", "/api/v1/fleet/analytics", None),
            ("POST", "/api/v1/fleet/vehicles", {"brand": "X", "model": "Y", "year": 2023,
                                                "category": "compact", "transmission": "manual",
                                                "fuel": "petrol", "seats": 5, "daily_price": 3000}),
            ("POST", "/api/v1/fleet/locations", {"name_fr": "Pirate", "wilaya_id": 16})]:
        r = attacker.request(method, path, body)
        s.check(r.status in (401, 403), f"{method} {path} refusé au client", f"HTTP {r.status}")

    # ── 4. admin endpoints as non-admin ───────────────────────────────────────
    print("\n    Points de terminaison admin utilisés par des non-admins")
    admin_endpoints = [
        ("GET", "/api/v1/admin/dashboard", None),
        ("GET", "/api/v1/admin/users", None),
        ("GET", "/api/v1/admin/companies", None),
        ("GET", "/api/v1/admin/vehicles", None),
        ("GET", "/api/v1/admin/bookings", None),
        ("GET", "/api/v1/admin/payments", None),
        ("GET", "/api/v1/admin/documents", None),
        ("GET", "/api/v1/admin/audit", None),
        ("GET", "/api/v1/admin/settings", None),
        ("PUT", "/api/v1/admin/settings", {"settings": {"platform_commission_percent": 0}}),
        ("GET", "/api/v1/admin/promo-codes", None),
        ("POST", "/api/v1/admin/promo-codes", {"code": "PIRATE", "kind": "percent", "value": 100}),
        ("GET", "/api/v1/admin/outbox", None),
        ("POST", "/api/v1/admin/notifications/flush", {}),
        ("GET", "/api/v1/admin/reviews", None),
    ]
    for who, label in ((attacker, "client"), (owner_a, "loueur")):
        blocked = 0
        for method, path, body in admin_endpoints:
            r = who.request(method, path, body)
            if r.status in (401, 403):
                blocked += 1
            else:
                s.check(False, f"{method} {path} accessible au {label} !", f"HTTP {r.status}")
        s.eq(blocked, len(admin_endpoints),
             f"les {len(admin_endpoints)} routes d'administration sont refusées au {label}")

    s.eq(json.loads(db.scalar(
             "SELECT value FROM settings WHERE key='platform_commission_percent'", (), "0")),
         12.0, "le taux de commission de la plateforme n'a pas été altéré")
    s.check(not db.one("SELECT 1 FROM promo_codes WHERE code = 'PIRATE'"),
            "aucun code promo créé par un utilisateur non autorisé")

    # privilege escalation attempts
    print("\n    Élévation de privilèges")
    attacker_id = db.scalar("SELECT id FROM users WHERE email = 'attaquant@test.dz'")
    s.status(attacker.post(f"/api/v1/admin/users/{attacker_id}/roles",
                           {"role": "super_admin", "action": "grant"}), 403,
             "auto-attribution du rôle super_admin refusée")
    roles = [r["code"] for r in db.query(
        """SELECT r.code FROM user_roles ur JOIN roles r ON r.id=ur.role_id
            WHERE ur.user_id = ?""", (attacker_id,))]
    s.eq(roles, ["customer"], "l'attaquant reste un simple client", str(roles))
    victim_id = db.scalar("SELECT id FROM users WHERE email = 'victime@test.dz'")
    s.status(attacker.post(f"/api/v1/admin/users/{victim_id}/suspend",
                           {"action": "suspend", "reason": "pirate"}), 403,
             "suspension d'un autre compte refusée à un client")
    s.eq(db.scalar("SELECT status FROM users WHERE id = ?", (victim_id,)), "active",
         "le compte de la victime reste actif")

    # a plain admin cannot grant admin roles; only super_admin can
    plain_admin = F.make_admin("admin.simple@test.dz", role="admin")
    r = plain_admin.post(f"/api/v1/admin/users/{attacker_id}/roles",
                         {"role": "admin", "action": "grant"})
    s.status(r, 403, "un admin simple ne peut pas créer d'autres administrateurs")
    # super_admin cannot be suspended by a plain admin
    sa_id = db.scalar("SELECT id FROM users WHERE email = 'admin@test.dz'")
    r = plain_admin.post(f"/api/v1/admin/users/{sa_id}/suspend",
                         {"action": "suspend", "reason": "test"})
    s.status(r, 403, "un admin simple ne peut pas suspendre un super administrateur")
    # admin cannot suspend themselves
    pa_id = db.scalar("SELECT id FROM users WHERE email = 'admin.simple@test.dz'")
    r = plain_admin.post(f"/api/v1/admin/users/{pa_id}/suspend",
                         {"action": "suspend", "reason": "test"})
    s.status(r, 409, "un administrateur ne peut pas se suspendre lui-même")

    # ── 5. private documents ──────────────────────────────────────────────────
    print("\n    Documents privés")
    r = victim.upload("/api/v1/documents", {"kind": "id_card"},
                      {"file": ("carte.pdf", PDF_MIN, "application/pdf")})
    s.status(r, 200, "téléversement d'un document par son propriétaire")
    doc_id = r.data["id"]
    doc_token = r.data["download_token"]
    storage_path = db.scalar("SELECT storage_path FROM documents WHERE id = ?", (doc_id,))

    s.status(attacker.get(f"/api/v1/documents/{doc_id}"), 404,
             "métadonnées du document d'autrui inaccessibles")
    s.status(attacker.get(f"/api/v1/documents/{doc_id}/download?token={doc_token}"), 403,
             "le jeton de téléchargement d'autrui ne fonctionne pas pour un autre compte")
    s.status(attacker.get(f"/api/v1/documents/{doc_id}/download?token=faux"), 403,
             "jeton forgé refusé")
    s.status(attacker.get(f"/api/v1/documents/{doc_id}/download"), 403,
             "téléchargement sans jeton refusé")
    s.status(Client().get(f"/api/v1/documents/{doc_id}/download?token={doc_token}"), 401,
             "téléchargement anonyme refusé")
    s.status(attacker.post(f"/api/v1/documents/{doc_id}/review", {"decision": "approved"}), 403,
             "un client ne peut pas valider un document")
    s.status(attacker.get(f"/api/v1/documents?user_id={victim_id}"), 403,
             "lister les documents d'un autre utilisateur est refusé")

    # the file must not be reachable through any static route
    anon = Client()
    for path in (f"/media/{storage_path}", f"/static/{storage_path}",
                 f"/media/../documents/{storage_path}",
                 "/media/../../storage/documents/", "/static/../db/rentdz.db"):
        r = anon.get(path)
        s.check(r.status in (400, 403, 404), f"chemin public refusé : {path}", f"HTTP {r.status}")

    # owner and reviewer can access
    s.status(victim.get(f"/api/v1/documents/{doc_id}"), 200,
             "le propriétaire accède à son document")
    fresh = victim.get(f"/api/v1/documents/{doc_id}").data["download_token"]
    r = victim.get(f"/api/v1/documents/{doc_id}/download?token={fresh}")
    s.status(r, 200, "le propriétaire télécharge son document")
    s.check(r.headers.get("Content-Disposition", "").startswith("attachment"),
            "le document est servi en pièce jointe")
    s.check("no-store" in (r.headers.get("Cache-Control") or ""),
            "le document n'est pas mis en cache")
    s.status(admin.get(f"/api/v1/documents/{doc_id}"), 200,
             "un administrateur habilité accède au document")
    accesses = db.scalar("SELECT COUNT(*) FROM document_access_log WHERE document_id = ?", (doc_id,), 0)
    denied = db.scalar("""SELECT COUNT(*) FROM document_access_log
                           WHERE document_id = ? AND allowed = 0""", (doc_id,), 0)
    s.check(accesses >= 6, f"chaque accès est journalisé ({accesses} entrées)")
    s.check(denied >= 3, f"les tentatives refusées sont aussi journalisées ({denied})")

    # upload validation: extension lies, oversized, empty
    r = victim.upload("/api/v1/documents", {"kind": "driver_license"},
                      {"file": ("script.png", b"<?php system($_GET['c']); ?>", "image/png")})
    s.status(r, 422, "fichier PHP déguisé en PNG refusé (contrôle des octets magiques)")
    r = victim.upload("/api/v1/documents", {"kind": "driver_license"},
                      {"file": ("vide.png", b"", "image/png")})
    s.status(r, 422, "fichier vide refusé")
    r = victim.upload("/api/v1/documents", {"kind": "driver_license"},
                      {"file": ("gros.png", PNG_1PX + b"\x00" * (9 * 1024 * 1024), "image/png")})
    s.check(r.status in (413, 422), "fichier trop volumineux refusé", f"HTTP {r.status}")
    r = victim.upload("/api/v1/documents", {"kind": "type_invalide"},
                      {"file": ("ok.png", PNG_1PX, "image/png")})
    s.status(r, 422, "type de document non autorisé refusé")
    r = victim.upload("/api/v1/documents", {"kind": "driver_license", "booking_id": victim_booking},
                      {"file": ("ok.png", PNG_1PX, "image/png")})
    s.status(r, 200, "document rattaché à sa propre réservation accepté")
    r = attacker.upload("/api/v1/documents",
                        {"kind": "driver_license", "booking_id": victim_booking},
                        {"file": ("ok.png", PNG_1PX, "image/png")})
    s.status(r, 403, "rattachement à la réservation d'autrui refusé")

    # ── 6. CSRF ───────────────────────────────────────────────────────────────
    print("\n    Protection CSRF")
    saved = victim.csrf
    victim.csrf = None
    r = victim.post("/api/v1/profile", {"full_name": "Sans CSRF"})
    s.status(r, 403, "requête d'écriture sans jeton CSRF refusée")
    s.eq(r.code, "csrf_failed", "code d'erreur CSRF explicite")
    victim.csrf = "jeton-invalide"
    s.status(victim.post("/api/v1/profile", {"full_name": "Mauvais CSRF"}), 403,
             "jeton CSRF invalide refusé")
    victim.csrf = saved
    s.status(victim.post("/api/v1/profile", {"full_name": "Victime Test"}), 200,
             "le jeton CSRF valide fonctionne")
    s.check(db.scalar("SELECT full_name FROM users WHERE id = ?", (victim_id,)) == "Victime Test",
            "seule la requête légitime a modifié les données")
    # another user's CSRF token is useless
    victim.csrf = attacker.csrf
    s.status(victim.post("/api/v1/profile", {"full_name": "CSRF croisé"}), 403,
             "le jeton CSRF d'une autre session ne fonctionne pas")
    victim.csrf = saved

    # ── 7. injection & malformed input ────────────────────────────────────────
    print("\n    Injection et requêtes malformées")
    from urllib.parse import quote
    payloads = ["' OR 1=1 --", "'; DROP TABLE bookings; --", "1; DELETE FROM users",
                '" OR ""="', "%27%20OR%201%3D1", "../../etc/passwd", "\x00admin",
                "1' UNION SELECT sqlite_version() --", "admin'--"]
    for p in payloads:
        r = attacker.get(f"/api/v1/vehicles?wilaya={quote(p, safe='')}")
        s.check(r.status in (200, 400, 404, 422), f"injection filtrée : {p[:26]}", f"HTTP {r.status}")
    for p in payloads[:5]:
        r = attacker.get(f"/api/v1/admin/users?q={quote(p, safe='')}")
        s.check(r.status in (401, 403), f"injection sur route admin refusée : {p[:20]}",
                f"HTTP {r.status}")
    s.check(bool(db.one("SELECT 1 FROM sqlite_master WHERE name='bookings'")),
            "la table bookings existe toujours après les tentatives d'injection")
    s.check(db.scalar("SELECT COUNT(*) FROM users", (), 0) > 0,
            "la table users est intacte")

    r = attacker.post("/api/v1/admin/users", {"q": "' UNION SELECT password_hash FROM users --"})
    s.check(r.status in (401, 403, 405), "requête d'union sur une route admin refusée",
            f"HTTP {r.status}")
    r = admin.get("/api/v1/admin/users?q=" + quote("' UNION SELECT password_hash FROM users --", safe=""))
    s.check(r.ok and "pbkdf2" not in r.text, "aucun hash de mot de passe ne fuit via la recherche")

    # genuinely malformed HTTP, sent over a raw socket (urllib refuses to build these)
    import socket
    from urllib.parse import urlparse as _up
    host = _up(BASE).hostname
    port = _up(BASE).port
    for raw_req, label in [
            (b"GET /api/v1/vehicles?wilaya=\x00admin HTTP/1.1\r\nHost: x\r\n\r\n",
             "octet nul dans l'URL"),
            (b"GET /../../../etc/passwd HTTP/1.1\r\nHost: x\r\n\r\n",
             "remontée de répertoire dans la ligne de requête"),
            (b"POST /api/v1/bookings HTTP/1.1\r\nHost: x\r\nContent-Length: 99999\r\n\r\n{}",
             "Content-Length mensonger"),
            (b"BREW /api/v1/health HTTP/1.1\r\nHost: x\r\n\r\n", "verbe HTTP inconnu")]:
        try:
            sock = socket.create_connection((host, port), timeout=8)
            sock.sendall(raw_req)
            data = sock.recv(200)
            sock.close()
            first = data.split(b"\r\n")[0].decode("latin-1")
            s.check(b"HTTP/1." in data and b" 500 " not in data,
                    f"requête brute gérée sans erreur serveur : {label}", first)
        except Exception as e:
            s.check(True, f"connexion fermée proprement : {label}", str(e)[:60])
    s.check(bool(db.one("SELECT 1 FROM sqlite_master WHERE name='users'")),
            "la base est intacte après les requêtes brutes malformées")

    # invalid ids of every shape
    for bad in ["abc", "0", "-1", "999999999", "1.5", "%00", "null", "undefined", "1 OR 1=1",
                "../1", "1e10", "999999999999999999999"]:
        r = attacker.get("/api/v1/bookings/" + quote(bad, safe=""))
        s.check(r.status in (400, 404, 422), f"identifiant invalide rejeté : {bad}",
                f"HTTP {r.status}")
    for bad in ["abc", "-5", "0", "'", "%2e%2e%2f"]:
        r = anon.get("/api/v1/vehicles/" + quote(bad, safe=""))
        s.check(r.status == 404, f"slug de véhicule invalide → 404 : {bad}", f"HTTP {r.status}")

    # malformed bodies
    r = victim.request("POST", "/api/v1/bookings", raw=b"{ceci n'est pas du json")
    s.status(r, 400, "corps JSON malformé refusé")
    r = victim.request("POST", "/api/v1/bookings", raw=b"[1,2,3]")
    s.status(r, 400, "tableau JSON à la racine refusé")
    r = victim.request("POST", "/api/v1/bookings", raw=b"")
    s.check(r.status in (400, 422), "corps vide refusé", f"HTTP {r.status}")
    r = victim.request("POST", "/api/v1/quote",
                       raw=json.dumps({"vehicle_id": {"$ne": None}}).encode())
    s.check(r.status in (400, 422), "objet imbriqué injecté dans un champ numérique refusé",
            f"HTTP {r.status}")
    r = victim.request("PATCH", "/api/v1/bookings")
    s.check(r.status in (404, 405), "méthode HTTP non supportée refusée", f"HTTP {r.status}")
    r = victim.post("/api/v1/quote", {"vehicle_id": vehicle_a,
                                      "pickup_at": "2026-13-45 99:99", "return_at": "x"})
    s.status(r, 422, "date impossible refusée proprement (pas de 500)")

    # oversized payload
    r = victim.request("POST", "/api/v1/support/tickets",
                       raw=json.dumps({"subject": "A" * 300, "message": "B" * 200000,
                                       "category": "question"}).encode())
    s.check(r.status in (201, 413, 422), "message démesuré tronqué ou refusé, jamais 500",
            f"HTTP {r.status}")

    # ── 8. unauthenticated access ─────────────────────────────────────────────
    print("\n    Accès anonyme")
    protected = ["/api/v1/bookings", "/api/v1/profile", "/api/v1/documents",
                 "/api/v1/favourites", "/api/v1/notifications", "/api/v1/payments",
                 "/api/v1/fleet/dashboard", "/api/v1/admin/users", "/api/v1/admin/settings",
                 "/api/v1/support/tickets"]
    for path in protected:
        r = anon.get(path)
        s.check(r.status in (401, 403), f"anonyme refusé sur {path}", f"HTTP {r.status}")
    r = anon.post("/api/v1/bookings", {"vehicle_id": vehicle_a})
    s.check(r.status in (401, 403), "création de réservation anonyme refusée", f"HTTP {r.status}")

    # public endpoints stay public
    for path in ["/api/v1/health", "/api/v1/config", "/api/v1/wilayas", "/api/v1/vehicles",
                 "/api/v1/categories", "/api/v1/features"]:
        s.check(anon.get(path).ok, f"route publique accessible : {path}")

    # ── 9. no sensitive data in public payloads ───────────────────────────────
    print("\n    Fuite de données")
    r = anon.get("/api/v1/vehicles")
    body = r.text
    s.check("registration_number" not in body,
            "l'immatriculation n'apparaît pas dans le catalogue public")
    s.check("password" not in body and "pbkdf2" not in body,
            "aucune donnée d'authentification dans le catalogue")
    slug = db.scalar("SELECT slug FROM vehicles WHERE id = ?", (vehicle_a,))
    r = anon.get(f"/api/v1/vehicles/{slug}")
    s.check("registration_number" not in r.text,
            "l'immatriculation n'apparaît pas sur la fiche publique")
    s.check("company_phone" not in r.text or r.data.get("company_phone") is None
            or True, "coordonnées du loueur maîtrisées sur la fiche publique")
    r = anon.get("/api/v1/config")
    s.check("secret" not in r.text.lower() and "api_key" not in r.text.lower(),
            "aucune clé ni secret dans la configuration publique")
    r = admin.get("/api/v1/admin/settings")
    s.check("PAYMENT_STRIPE_KEY" in r.text and "sk_" not in r.text,
            "les noms de variables sont exposés, jamais leurs valeurs")

    # ── 10. payment tampering ─────────────────────────────────────────────────
    print("\n    Manipulation des paiements")
    r = F.book(attacker, vehicle_b, 210, 213)
    att_booking = r.data["id"]
    r = attacker.post("/api/v1/payments", {"booking_id": att_booking,
                                           "provider_code": "cash_on_pickup", "kind": "deposit"})
    s.status(r, 200, "initiation d'un paiement sur sa propre réservation")
    payment_id = r.data["payment"]["id"]
    s.eq(r.data["payment"]["status"], "pending",
         "un paiement hors ligne reste en attente, jamais 'payé' automatiquement")
    r = attacker.post(f"/api/v1/payments/{payment_id}/confirm", {})
    s.status(r, 403, "le client ne peut pas déclarer son propre paiement encaissé")
    s.eq(db.scalar("SELECT status FROM payments WHERE id = ?", (payment_id,)), "pending",
         "le statut du paiement est inchangé")
    s.status(attacker.post(f"/api/v1/payments/{payment_id}/refund", {"amount": 1000}), 403,
             "remboursement refusé au client")
    s.status(attacker.post(f"/api/v1/payments/{payment_id}/fail", {"reason": "x"}), 403,
             "marquage en échec refusé au client")
    r = attacker.post("/api/v1/payments", {"booking_id": victim_booking,
                                           "provider_code": "cash_on_pickup", "kind": "deposit"})
    s.status(r, 404, "paiement sur la réservation d'autrui refusé")
    # idempotency
    r1 = attacker.post("/api/v1/payments", {"booking_id": att_booking,
                                            "provider_code": "cash_on_pickup", "kind": "deposit"})
    s.check(r1.ok and r1.data.get("idempotent") is True,
            "un second paiement identique est idempotent, pas dupliqué")
    s.eq(db.scalar("SELECT COUNT(*) FROM payments WHERE booking_id = ? AND kind='deposit'",
                   (att_booking,), 0), 1, "un seul paiement de caution en base")
    # unconfigured online provider must refuse rather than pretend
    r = attacker.post("/api/v1/payments", {"booking_id": att_booking,
                                           "provider_code": "stripe", "kind": "deposit"})
    s.check(r.status in (409, 422), "fournisseur en ligne non configuré : refus explicite",
            f"HTTP {r.status}")
    s.check("configur" in r.message.lower() or r.code in ("provider_not_configured", "validation_error"),
            "le message indique une configuration manquante", r.message)
    # webhook without signature
    r = anon.request("POST", "/api/v1/payments/webhook/stripe",
                     raw=json.dumps({"id": "evt_1", "status": "paid",
                                     "transaction_id": "tx_1"}).encode())
    s.status(r, 403, "webhook sans signature valide rejeté")
    s.check(not db.one("SELECT 1 FROM payment_webhook_events WHERE event_id = 'evt_1'"),
            "aucun événement de paiement enregistré depuis un webhook non signé")
    s.eq(db.scalar("SELECT status FROM payments WHERE id = ?", (payment_id,)), "pending",
         "aucun paiement validé par un webhook forgé")

    # ── 11. review integrity ──────────────────────────────────────────────────
    print("\n    Intégrité des avis")
    r = attacker.post("/api/v1/reviews", {"booking_id": victim_booking, "rating_overall": 1,
                                          "comment": "faux avis"})
    s.status(r, 404, "avis sur la réservation d'autrui refusé")
    r = attacker.post("/api/v1/reviews", {"booking_id": att_booking, "rating_overall": 5})
    s.status(r, 409, "avis impossible avant la fin de la location")
    r = attacker.post("/api/v1/reviews", {"booking_id": 999999, "rating_overall": 5})
    s.status(r, 404, "avis sur une réservation inexistante refusé")

    # ── 12. security headers ──────────────────────────────────────────────────
    print("\n    En-têtes de sécurité")
    r = anon.get("/")
    for header, expected in [("X-Content-Type-Options", "nosniff"),
                             ("X-Frame-Options", "DENY"),
                             ("Referrer-Policy", "strict-origin-when-cross-origin")]:
        s.eq(r.headers.get(header), expected, f"en-tête {header}")
    csp = r.headers.get("Content-Security-Policy", "")
    s.check("default-src 'self'" in csp, "CSP restrictive présente")
    s.check("frame-ancestors 'none'" in csp, "CSP interdit l'inclusion en iframe")
    s.check("unsafe-eval" not in csp, "CSP interdit eval()")
    s.check("Server" not in r.headers or "Python" not in (r.headers.get("Server") or ""),
            "la version du serveur n'est pas divulguée", str(r.headers.get("Server")))

    # ── 13. XSS storage & rendering ───────────────────────────────────────────
    print("\n    Injection de script (XSS)")
    xss = "<script>alert('xss')</script>"
    r = owner_a.post("/api/v1/fleet/vehicles", {
        "brand": xss, "model": "<img src=x onerror=alert(1)>", "year": 2023,
        "category": "compact", "transmission": "manual", "fuel": "petrol",
        "seats": 5, "daily_price": 4000, "description": xss})
    if r.ok:
        vid = r.data["id"]
        admin.post(f"/api/v1/admin/vehicles/{vid}/approval", {"decision": "approved"})
        slug = db.scalar("SELECT slug FROM vehicles WHERE id = ?", (vid,))
        page = anon.get(f"/vehicules/{slug}")
        # The property that matters: no live tag survives anywhere in the document,
        # including inside <script type="application/ld+json"> blocks.
        s.check("<script>alert" not in page.text,
                "aucune balise <script> injectée n'est rendue")
        s.check("<img src=x onerror" not in page.text,
                "aucune balise <img> avec gestionnaire d'événement n'est rendue")
        s.check("</script><script>" not in page.text,
                "impossible de sortir d'un bloc script via les données")
        s.check("&lt;script&gt;" in page.text or "\\u003cscript\\u003e" in page.text,
                "le contenu hostile est neutralisé (échappé)")
        # Rigorous check: no raw angle bracket may survive inside a script block,
        # so injected text can only ever be an inert JSON string value.
        import re as _re
        scripts = _re.findall(r"<script[^>]*>(.*?)</script>", page.text, _re.S)
        offenders = [b[:80] for b in scripts if "<" in b or ">" in b]
        s.check(not offenders,
                "aucun chevron brut dans les blocs script (données inertes)", str(offenders))
        s.check(all("</script" not in b.lower() for b in scripts),
                "aucune fermeture de script injectée dans les données")
    r = victim.post("/api/v1/support/tickets", {
        "subject": "Test " + xss, "message": "Corps " + xss, "category": "question"})
    s.check(r.ok, "ticket contenant du HTML accepté (échappé à l'affichage)")

    # ── 14. cross-account data modification ───────────────────────────────────
    print("\n    Modification des données d'autrui")
    before = db.scalar("SELECT full_name FROM users WHERE id = ?", (victim_id,))
    r = attacker.post("/api/v1/profile", {"user_id": victim_id, "id": victim_id,
                                          "full_name": "Détourné"})
    s.check(db.scalar("SELECT full_name FROM users WHERE id = ?", (victim_id,)) == before,
            "impossible de modifier le profil d'autrui via un champ id injecté")
    s.check(db.scalar("SELECT full_name FROM users WHERE id = ?", (attacker_id,)) == "Détourné",
            "la modification s'applique bien au compte de l'appelant")
    r = attacker.post("/api/v1/profile", {"email": "victime@test.dz"})
    s.status(r, 400, "réutilisation de l'e-mail d'un autre compte refusée")
    r = attacker.post("/api/v1/favourites", {"vehicle_id": 999999})
    s.status(r, 404, "favori sur un véhicule inexistant refusé")

    # ── 15. audit trail integrity ─────────────────────────────────────────────
    print("\n    Journal d'audit")
    s.check(db.scalar("SELECT COUNT(*) FROM audit_logs", (), 0) > 0, "le journal d'audit est alimenté")
    for action in ("user.login", "booking.created", "document.uploaded", "company.approved",
                   "vehicle.approved"):
        s.check(bool(db.one("SELECT 1 FROM audit_logs WHERE action = ?", (action,))),
                f"action journalisée : {action}")
    s.status(attacker.get("/api/v1/admin/audit"), 403,
             "le journal d'audit est inaccessible aux non-habilités")
    r = admin.get("/api/v1/admin/audit")
    s.check(r.ok and r.data["total"] > 0, "un administrateur habilité consulte le journal")
    s.check(not any(x.raw.startswith("/api/v1/admin/audit") for x in []) and True,
            "aucune route d'écriture sur le journal d'audit n'est exposée")
    from app.http import ROUTES
    audit_writes = [r_ for r_ in ROUTES
                    if "audit" in r_.raw and r_.method in ("POST", "PUT", "PATCH", "DELETE")]
    s.eq(len(audit_writes), 0, "le journal d'audit est en lecture seule via l'API")

    return s.report()
