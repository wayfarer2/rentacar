"""
Test harness: boots the real WSGI-less HTTP server on a random port against a
throwaway SQLite database, and drives it over real HTTP with cookies + CSRF.
No mocks: what the tests exercise is what production runs.
"""
from __future__ import annotations
import json, os, socket, sys, threading, time, tempfile, shutil, urllib.request, urllib.error
from http.cookiejar import CookieJar
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

TMP = Path(tempfile.mkdtemp(prefix="rentdz-test-"))
os.environ["APP_ENV"] = "development"
os.environ["DEBUG"] = "true"
os.environ["DATABASE_URL"] = f"sqlite:///{TMP / 'test.db'}"
os.environ["AUTH_SECRET"] = "test-secret-not-for-production-0123456789"
os.environ["RATE_LIMIT_ENABLED"] = "false"
os.environ["PBKDF2_ITERATIONS"] = "1000"          # keep the suite fast
os.environ["COOKIE_SECURE"] = "false"
os.environ["APP_URL"] = "http://127.0.0.1"

from app import db                                  # noqa: E402
from app.config import Config, STORAGE_DIR          # noqa: E402

# `manage.py test` imports app.config before this module runs, so the class
# attributes above may already hold the developer's real settings. Override them
# explicitly: the suite must never touch the development database, and the rate
# limiter would otherwise throttle the tests themselves.
Config.DATABASE_URL = f"sqlite:///{TMP / 'test.db'}"
Config.APP_ENV = "development"
Config.DEBUG = True
Config.RATE_LIMIT_ENABLED = False
Config.PBKDF2_ITERATIONS = 1000
Config.COOKIE_SECURE = False
Config.AUTH_SECRET = "test-secret-not-for-production-0123456789"
Config.APP_URL = "http://127.0.0.1"
Config.DEMO_MODE = True
db.close_conn()          # drop any connection opened against the real database
from app.http import Handler                        # noqa: E402
from http.server import ThreadingHTTPServer         # noqa: E402

_server = None
_thread = None
BASE = ""


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def start_server():
    global _server, _thread, BASE
    if _server:
        return BASE
    import app.routes_all  # noqa: F401  registers routes
    db.migrate(fresh=True)
    from app.services import auth_service, settings_service
    from app.services.payment import seed_providers
    from app.seeds import geography
    with db.transaction():
        auth_service.seed_roles()
        settings_service.seed_defaults()
        seed_providers()
        geography.seed()
    port = free_port()
    _server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    _server.daemon_threads = True
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    BASE = f"http://127.0.0.1:{port}"
    for _ in range(60):
        try:
            urllib.request.urlopen(f"{BASE}/api/v1/health", timeout=2).read()
            break
        except Exception:
            time.sleep(0.05)
    return BASE


def stop_server():
    global _server
    if _server:
        _server.shutdown()
        _server = None
    shutil.rmtree(TMP, ignore_errors=True)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None            # surface the 3xx instead of following it


class Client:
    """One client == one browser session (own cookie jar and CSRF token)."""

    def __init__(self, follow_redirects: bool = True):
        self.jar = CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(self.jar)]
        if not follow_redirects:
            handlers.append(_NoRedirect())
        self.opener = urllib.request.build_opener(*handlers)
        self.csrf = None
        self.user = None

    def request(self, method: str, path: str, data=None, *, raw=None, headers=None,
                content_type="application/json"):
        url = path if path.startswith("http") else BASE + path
        body = None
        hdrs = {"Accept": "application/json"}
        if raw is not None:
            body = raw
            hdrs["Content-Type"] = content_type
        elif data is not None:
            body = json.dumps(data).encode()
            hdrs["Content-Type"] = "application/json"
        if method not in ("GET", "HEAD") and self.csrf:
            hdrs["X-CSRF-Token"] = self.csrf
        hdrs.update(headers or {})
        req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
        try:
            with self.opener.open(req, timeout=25) as res:
                payload = res.read()
                status = res.status
                ctype = res.headers.get("Content-Type", "")
                resp_headers = dict(res.headers)
        except urllib.error.HTTPError as e:
            payload = e.read()
            status = e.code
            ctype = e.headers.get("Content-Type", "")
            resp_headers = dict(e.headers)
        parsed = None
        if "application/json" in ctype:
            try:
                parsed = json.loads(payload.decode("utf-8"))
            except Exception:
                parsed = None
        return Response(status, parsed, payload, resp_headers)

    def get(self, path, **kw):    return self.request("GET", path, **kw)
    def post(self, path, data=None, **kw):  return self.request("POST", path, data, **kw)
    def put(self, path, data=None, **kw):   return self.request("PUT", path, data, **kw)
    def delete(self, path, **kw): return self.request("DELETE", path, **kw)

    def refresh_csrf(self):
        r = self.get("/api/v1/auth/me")
        if r.data and r.data.get("csrf_token"):
            self.csrf = r.data["csrf_token"]
            self.user = r.data.get("user")
        return self.csrf

    def register(self, email, password="MotDePasse2026", name="Client Test",
                 phone="0555123456", account_type="customer"):
        r = self.post("/api/v1/auth/register", {
            "email": email, "password": password, "full_name": name,
            "phone": phone, "account_type": account_type})
        if r.ok:
            self.refresh_csrf()
        return r

    def login(self, email, password="MotDePasse2026"):
        r = self.post("/api/v1/auth/login", {"email": email, "password": password})
        if r.ok:
            self.refresh_csrf()
        return r

    def logout(self):
        r = self.post("/api/v1/auth/logout")
        self.csrf = None
        self.user = None
        return r

    def upload(self, path, fields: dict, files: dict):
        boundary = "----RENTDZTEST1234567890"
        parts = []
        for k, v in fields.items():
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
        for k, (filename, content, mime) in files.items():
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; "
                         f"filename=\"{filename}\"\r\nContent-Type: {mime}\r\n\r\n".encode())
            parts.append(content + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        return self.request("POST", path, raw=b"".join(parts),
                            content_type=f"multipart/form-data; boundary={boundary}")


class Response:
    def __init__(self, status, payload, raw, headers):
        self.status = status
        self.payload = payload or {}
        self.raw = raw
        self.headers = headers

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300 and self.payload.get("ok") is not False

    @property
    def data(self):
        return self.payload.get("data") if isinstance(self.payload, dict) else None

    @property
    def error(self) -> dict:
        return (self.payload or {}).get("error", {}) if isinstance(self.payload, dict) else {}

    @property
    def code(self) -> str:
        return self.error.get("code", "")

    @property
    def message(self) -> str:
        return self.error.get("message", "")

    @property
    def text(self) -> str:
        return self.raw.decode("utf-8", "replace")

    def __repr__(self):
        return f"<Response {self.status} {self.code or 'ok'}>"


# ── tiny assertion toolkit with readable output ──────────────────────────────
class Suite:
    def __init__(self, name: str):
        self.name = name
        self.passed = 0
        self.failures: list[str] = []
        self._current = ""

    def case(self, label: str):
        self._current = label
        return self

    def check(self, condition, label: str, detail: str = ""):
        if condition:
            self.passed += 1
            print(f"    ok   {label}")
        else:
            self.failures.append(f"{label}{(' — ' + detail) if detail else ''}")
            print(f"    FAIL {label}" + (f"\n         {detail}" if detail else ""))
        return bool(condition)

    def eq(self, actual, expected, label: str, detail: str = ""):
        return self.check(actual == expected, label,
                          detail or f"attendu {expected!r}, obtenu {actual!r}")

    def status(self, response: Response, expected: int, label: str):
        return self.check(response.status == expected, label,
                          f"HTTP {response.status} ({response.code}) au lieu de {expected} "
                          f"· {response.message[:120]}")

    def report(self) -> bool:
        total = self.passed + len(self.failures)
        mark = "PASS" if not self.failures else "FAIL"
        print(f"\n  [{mark}] {self.name} — {self.passed}/{total} vérifications")
        for f in self.failures:
            print(f"        · {f}")
        return not self.failures


PNG_1PX = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06"
           b"\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05"
           b"\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82")
PDF_MIN = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
