"""Trilingual UI strings (FR default, AR with real RTL, EN). Not machine-translated."""
from __future__ import annotations
from .config import Config

STRINGS: dict[str, dict[str, str]] = {
    "brand.tagline": {"fr": "Votre route commence ici.", "ar": "طريقك يبدأ من هنا.", "en": "Your road starts here."},
    "hero.title": {"fr": "LOUEZ VOTRE VOITURE EN ALGÉRIE", "ar": "استأجر سيارتك في الجزائر", "en": "RENT YOUR CAR IN ALGERIA"},
    "hero.subtitle": {"fr": "Des voitures fiables. Des prix transparents. Une réservation simple.",
                      "ar": "سيارات موثوقة. أسعار واضحة. حجز بسيط.",
                      "en": "Reliable cars. Transparent prices. Simple booking."},
    "search.pickup_location": {"fr": "Lieu de prise en charge", "ar": "مكان الاستلام", "en": "Pickup location"},
    "search.dropoff_location": {"fr": "Lieu de restitution", "ar": "مكان التسليم", "en": "Drop-off location"},
    "search.same_location": {"fr": "Restituer au même endroit", "ar": "التسليم في نفس المكان", "en": "Return to same place"},
    "search.pickup_date": {"fr": "Date de départ", "ar": "تاريخ الاستلام", "en": "Pickup date"},
    "search.pickup_time": {"fr": "Heure", "ar": "الساعة", "en": "Time"},
    "search.return_date": {"fr": "Date de retour", "ar": "تاريخ الإرجاع", "en": "Return date"},
    "search.return_time": {"fr": "Heure", "ar": "الساعة", "en": "Time"},
    "search.submit": {"fr": "Rechercher", "ar": "ابحث", "en": "Search"},
    "search.results_count": {"fr": "%d véhicule(s) disponible(s)", "ar": "%d سيارة متوفرة", "en": "%d vehicle(s) available"},
    "nav.vehicles": {"fr": "Véhicules", "ar": "السيارات", "en": "Vehicles"},
    "nav.how": {"fr": "Comment ça marche", "ar": "كيف يعمل", "en": "How it works"},
    "nav.destinations": {"fr": "Destinations", "ar": "المدن", "en": "Destinations"},
    "nav.help": {"fr": "Aide", "ar": "المساعدة", "en": "Help"},
    "nav.login": {"fr": "Connexion", "ar": "تسجيل الدخول", "en": "Log in"},
    "nav.register": {"fr": "Créer un compte", "ar": "إنشاء حساب", "en": "Sign up"},
    "nav.logout": {"fr": "Déconnexion", "ar": "تسجيل الخروج", "en": "Log out"},
    "nav.dashboard": {"fr": "Mon espace", "ar": "حسابي", "en": "Dashboard"},
    "nav.bookings": {"fr": "Mes réservations", "ar": "حجوزاتي", "en": "My bookings"},
    "nav.fleet": {"fr": "Espace loueur", "ar": "فضاء المؤجر", "en": "Fleet portal"},
    "nav.admin": {"fr": "Administration", "ar": "الإدارة", "en": "Admin"},
    "filters.title": {"fr": "Filtres", "ar": "التصفية", "en": "Filters"},
    "filters.category": {"fr": "Catégorie", "ar": "الفئة", "en": "Category"},
    "filters.transmission": {"fr": "Boîte de vitesses", "ar": "علبة السرعات", "en": "Transmission"},
    "filters.fuel": {"fr": "Carburant", "ar": "الوقود", "en": "Fuel"},
    "filters.seats": {"fr": "Places", "ar": "المقاعد", "en": "Seats"},
    "filters.price": {"fr": "Prix par jour", "ar": "السعر اليومي", "en": "Price per day"},
    "filters.features": {"fr": "Équipements", "ar": "التجهيزات", "en": "Features"},
    "filters.reset": {"fr": "Réinitialiser", "ar": "إعادة تعيين", "en": "Reset"},
    "sort.recommended": {"fr": "Recommandés", "ar": "الأنسب", "en": "Recommended"},
    "sort.price_asc": {"fr": "Prix croissant", "ar": "الأرخص أولاً", "en": "Price: low to high"},
    "sort.price_desc": {"fr": "Prix décroissant", "ar": "الأغلى أولاً", "en": "Price: high to low"},
    "sort.rating": {"fr": "Mieux notés", "ar": "الأعلى تقييماً", "en": "Top rated"},
    "sort.newest": {"fr": "Plus récents", "ar": "الأحدث", "en": "Newest"},
    "vehicle.per_day": {"fr": "/ jour", "ar": "/ يوم", "en": "/ day"},
    "vehicle.book": {"fr": "Réserver maintenant", "ar": "احجز الآن", "en": "Book now"},
    "vehicle.details": {"fr": "Voir le détail", "ar": "التفاصيل", "en": "View details"},
    "vehicle.deposit": {"fr": "Caution", "ar": "الضمان", "en": "Deposit"},
    "vehicle.transmission": {"fr": "Transmission", "ar": "ناقل الحركة", "en": "Transmission"},
    "vehicle.mileage_policy": {"fr": "Politique kilométrique", "ar": "سياسة الكيلومترات", "en": "Mileage policy"},
    "vehicle.unlimited_km": {"fr": "Kilométrage illimité", "ar": "كيلومتراج غير محدود", "en": "Unlimited mileage"},
    "price.base": {"fr": "Location", "ar": "الإيجار", "en": "Rental"},
    "price.services": {"fr": "Services optionnels", "ar": "خدمات إضافية", "en": "Optional services"},
    "price.fees": {"fr": "Frais", "ar": "الرسوم", "en": "Fees"},
    "price.discount": {"fr": "Remise", "ar": "الخصم", "en": "Discount"},
    "price.tax": {"fr": "TVA", "ar": "الرسم على القيمة المضافة", "en": "VAT"},
    "price.total": {"fr": "Total à payer", "ar": "المجموع", "en": "Total"},
    "price.days": {"fr": "jour(s)", "ar": "يوم", "en": "day(s)"},
    "booking.step_dates": {"fr": "Dates", "ar": "التواريخ", "en": "Dates"},
    "booking.step_customer": {"fr": "Vos informations", "ar": "معلوماتك", "en": "Your details"},
    "booking.step_driver": {"fr": "Permis de conduire", "ar": "رخصة السياقة", "en": "Driving licence"},
    "booking.step_services": {"fr": "Options", "ar": "الخيارات", "en": "Extras"},
    "booking.step_summary": {"fr": "Récapitulatif", "ar": "الملخص", "en": "Summary"},
    "booking.step_payment": {"fr": "Paiement", "ar": "الدفع", "en": "Payment"},
    "booking.step_done": {"fr": "Confirmation", "ar": "التأكيد", "en": "Confirmation"},
    "booking.confirmed": {"fr": "Réservation enregistrée", "ar": "تم تسجيل الحجز", "en": "Booking recorded"},
    "booking.cancel": {"fr": "Annuler la réservation", "ar": "إلغاء الحجز", "en": "Cancel booking"},
    "empty.no_vehicles": {"fr": "Aucun véhicule disponible pour ces dates.",
                          "ar": "لا توجد سيارات متوفرة في هذه التواريخ.",
                          "en": "No vehicles available for these dates."},
    "empty.no_bookings": {"fr": "Aucune réservation à venir.", "ar": "لا توجد حجوزات قادمة.", "en": "No upcoming reservations."},
    "empty.no_documents": {"fr": "Aucun document téléversé.", "ar": "لم يتم تحميل أي وثيقة.", "en": "No documents uploaded."},
    "empty.no_tickets": {"fr": "Aucun ticket de support.", "ar": "لا توجد تذاكر دعم.", "en": "No support tickets."},
    "empty.no_fleet": {"fr": "Aucun véhicule ajouté pour le moment.", "ar": "لم تتم إضافة أي سيارة بعد.", "en": "No vehicles added yet."},
    "empty.no_notifications": {"fr": "Aucune notification.", "ar": "لا توجد إشعارات.", "en": "No notifications."},
    "error.generic": {"fr": "Une erreur est survenue. Veuillez réessayer.",
                      "ar": "حدث خطأ. الرجاء المحاولة مرة أخرى.",
                      "en": "Something went wrong. Please try again."},
    "error.not_found": {"fr": "Page introuvable.", "ar": "الصفحة غير موجودة.", "en": "Page not found."},
    "common.loading": {"fr": "Chargement…", "ar": "جار التحميل…", "en": "Loading…"},
    "common.save": {"fr": "Enregistrer", "ar": "حفظ", "en": "Save"},
    "common.cancel": {"fr": "Annuler", "ar": "إلغاء", "en": "Cancel"},
    "common.confirm": {"fr": "Confirmer", "ar": "تأكيد", "en": "Confirm"},
    "common.back": {"fr": "Retour", "ar": "رجوع", "en": "Back"},
    "common.next": {"fr": "Continuer", "ar": "متابعة", "en": "Continue"},
    "common.search": {"fr": "Rechercher", "ar": "بحث", "en": "Search"},
    "common.status": {"fr": "Statut", "ar": "الحالة", "en": "Status"},
    "common.actions": {"fr": "Actions", "ar": "إجراءات", "en": "Actions"},
    "common.currency": {"fr": "DA", "ar": "دج", "en": "DZD"},
}

CATEGORY_LABELS = {
    "economy": {"fr": "Économique", "ar": "اقتصادية", "en": "Economy"},
    "compact": {"fr": "Compacte", "ar": "مدمجة", "en": "Compact"},
    "sedan": {"fr": "Berline", "ar": "سيدان", "en": "Sedan"},
    "suv": {"fr": "SUV", "ar": "دفع رباعي حضري", "en": "SUV"},
    "luxury": {"fr": "Luxe", "ar": "فخمة", "en": "Luxury"},
    "family": {"fr": "Familiale", "ar": "عائلية", "en": "Family"},
    "van": {"fr": "Utilitaire / Van", "ar": "شاحنة صغيرة", "en": "Van"},
    "4x4": {"fr": "4x4", "ar": "دفع رباعي", "en": "4x4"},
}

STATUS_LABELS = {
    "pending": {"fr": "En attente", "ar": "قيد الانتظار", "en": "Pending"},
    "awaiting_payment": {"fr": "Paiement attendu", "ar": "بانتظار الدفع", "en": "Awaiting payment"},
    "confirmed": {"fr": "Confirmée", "ar": "مؤكد", "en": "Confirmed"},
    "active": {"fr": "En cours", "ar": "جارٍ", "en": "Active"},
    "completed": {"fr": "Terminée", "ar": "منتهي", "en": "Completed"},
    "cancelled": {"fr": "Annulée", "ar": "ملغى", "en": "Cancelled"},
    "rejected": {"fr": "Refusée", "ar": "مرفوض", "en": "Rejected"},
    "expired": {"fr": "Expirée", "ar": "انتهت صلاحيته", "en": "Expired"},
    "no_show": {"fr": "Non présenté", "ar": "لم يحضر", "en": "No-show"},
    "approved": {"fr": "Approuvé", "ar": "موافق عليه", "en": "Approved"},
    "suspended": {"fr": "Suspendu", "ar": "موقوف", "en": "Suspended"},
    "available": {"fr": "Disponible", "ar": "متوفرة", "en": "Available"},
    "reserved": {"fr": "Réservé", "ar": "محجوزة", "en": "Reserved"},
    "rented": {"fr": "Loué", "ar": "مؤجرة", "en": "Rented"},
    "maintenance": {"fr": "Maintenance", "ar": "الصيانة", "en": "Maintenance"},
    "unavailable": {"fr": "Indisponible", "ar": "غير متوفرة", "en": "Unavailable"},
    "inactive": {"fr": "Inactif", "ar": "غير نشط", "en": "Inactive"},
    "paid": {"fr": "Payé", "ar": "مدفوع", "en": "Paid"},
    "partially_paid": {"fr": "Partiellement payé", "ar": "مدفوع جزئياً", "en": "Partially paid"},
    "failed": {"fr": "Échoué", "ar": "فشل", "en": "Failed"},
    "refunded": {"fr": "Remboursé", "ar": "مُسترد", "en": "Refunded"},
    "partially_refunded": {"fr": "Partiellement remboursé", "ar": "مسترد جزئياً", "en": "Partially refunded"},
    "processing": {"fr": "En traitement", "ar": "قيد المعالجة", "en": "Processing"},
}


def t(key: str, locale: str = None, *args) -> str:
    loc = locale if locale in Config.LOCALES else Config.DEFAULT_LOCALE
    entry = STRINGS.get(key)
    if not entry:
        return key
    text = entry.get(loc) or entry.get("fr") or key
    return (text % args) if args else text


def label(mapping: dict, code: str, locale: str = "fr") -> str:
    entry = mapping.get(code)
    if not entry:
        return code
    return entry.get(locale) or entry.get("fr") or code


def is_rtl(locale: str) -> bool:
    return locale in Config.RTL_LOCALES


def direction(locale: str) -> str:
    return "rtl" if is_rtl(locale) else "ltr"


def money(amount, locale: str = "fr") -> str:
    """Format DZD the Algerian way: 12 500 DA (spaces, no decimals)."""
    try:
        n = int(round(float(amount or 0)))
    except (TypeError, ValueError):
        n = 0
    s = f"{n:,}".replace(",", "\u00a0")
    return f"{s} دج" if locale == "ar" else f"{s} DA"


MONTHS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
             "août", "septembre", "octobre", "novembre", "décembre"]
MONTHS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية",
             "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def human_date(value: str, locale: str = "fr") -> str:
    """'2026-09-14 10:00' -> '14 septembre 2026 à 10:00' (DD/MM order, Algerian)."""
    if not value:
        return ""
    try:
        d = value[:10].split("-")
        y, m, day = int(d[0]), int(d[1]), int(d[2])
    except Exception:
        return value
    time_part = value[11:16] if len(value) >= 16 else ""
    if locale == "ar":
        out = f"{day} {MONTHS_AR[m-1]} {y}"
        return f"{out} على {time_part}" if time_part else out
    if locale == "en":
        out = f"{day:02d}/{m:02d}/{y}"
        return f"{out} {time_part}" if time_part else out
    out = f"{day} {MONTHS_FR[m-1]} {y}"
    return f"{out} à {time_part}" if time_part else out
