/* Admin console: dashboard, bookings, vehicles, companies, users, documents,
   payments, reviews, promos, audit, settings. */
document.addEventListener("DOMContentLoaded", async () => {
  const R = window.RENTDZ;
  const box = document.querySelector("[data-app]");
  if (!box) return;
  const path = location.pathname.replace(/\/$/, "");
  await R.session();
  if (!R.user) { location.href = "/connexion?next=" + encodeURIComponent(path); return; }

  const table = (headers, rows) => `<div class="tablewrap"><table class="table">
    <thead><tr>${headers.map(h => `<th>${R.esc(h)}</th>`).join("")}</tr></thead>
    <tbody>${rows}</tbody></table></div>`;

  function filterBar(fields) {
    return `<form class="card" data-filter style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
      ${fields.map(f => f.type === "select"
        ? `<div class="field" style="min-width:170px"><label for="f_${f.name}">${R.esc(f.label)}</label>
            <select id="f_${f.name}" name="${f.name}">${f.options.map(([v, l]) =>
              `<option value="${R.esc(v)}">${R.esc(l)}</option>`).join("")}</select></div>`
        : `<div class="field" style="min-width:200px"><label for="f_${f.name}">${R.esc(f.label)}</label>
            <input id="f_${f.name}" name="${f.name}" placeholder="${R.esc(f.placeholder || "")}"></div>`).join("")}
      <button class="btn btn--primary" type="submit">Filtrer</button>
    </form>`;
  }

  const views = {
    "/admin": dashboard, "/admin/reservations": bookings, "/admin/vehicules": vehicles,
    "/admin/loueurs": companies, "/admin/utilisateurs": users, "/admin/documents": documents,
    "/admin/paiements": payments, "/admin/avis": reviews, "/admin/promos": promos,
    "/admin/audit": audit, "/admin/parametres": settings,
  };
  try { await (views[path] || dashboard)(); }
  catch (e) { box.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>`; }

  async function dashboard() {
    box.innerHTML = R.skeleton(5);
    const range = new URLSearchParams(location.search).get("range") || "30d";
    const d = await R.api(`/api/v1/admin/dashboard?range=${range}`);
    const o = d.overview;
    const max = Math.max(1, ...d.revenue_by_month.map(r => r.revenue));
    const unconfigured = Object.entries(d.integrations).filter(([, v]) =>
      v.status === "configuration_required");
    const ranges = [["today","Aujourd'hui"],["7d","7 jours"],["30d","30 jours"],
                    ["90d","90 jours"],["year","Cette année"],["all","Tout"]];
    box.innerHTML = `
      <div class="tabs">${ranges.map(([k, l]) =>
        `<a class="tab${k === range ? " is-active" : ""}" href="?range=${k}">${l}</a>`).join("")}</div>
      ${o.companies_pending || o.vehicles_pending || o.documents_pending ? `
        <div class="banner banner--warn"><div><strong>Actions en attente :</strong>
          ${o.companies_pending ? `${o.companies_pending} société(s) à valider · ` : ""}
          ${o.vehicles_pending ? `${o.vehicles_pending} véhicule(s) à valider · ` : ""}
          ${o.documents_pending ? `${o.documents_pending} document(s) à vérifier` : ""}</div></div>` : ""}
      ${unconfigured.length ? `<div class="banner banner--info"><div>
        <strong>Intégrations à configurer :</strong> ${unconfigured.map(([k]) => R.esc(k)).join(", ")}.
        <a class="link" href="/admin/parametres">Voir la configuration requise</a></div></div>` : ""}
      <div class="grid grid--stats">
        <div class="stat stat--accent"><div class="stat__label">Chiffre d'affaires</div>
          <div class="stat__value">${R.money(o.revenue_gross)}</div>
          <div class="stat__hint">dont ${R.money(o.revenue_platform)} de commission</div></div>
        <div class="stat"><div class="stat__label">Encaissé</div>
          <div class="stat__value">${R.money(o.payments_collected)}</div>
          <div class="stat__hint">${R.money(o.refunds_total)} remboursé</div></div>
        <div class="stat"><div class="stat__label">Réservations</div>
          <div class="stat__value">${o.bookings_total}</div>
          <div class="stat__hint">${o.bookings_confirmed} confirmées · ${o.bookings_cancelled} annulées</div></div>
        <div class="stat"><div class="stat__label">Panier moyen</div>
          <div class="stat__value">${R.money(o.average_booking_value)}</div></div>
      </div>
      <div class="grid grid--stats">
        <div class="stat"><div class="stat__label">Taux de conversion</div>
          <div class="stat__value">${o.conversion_rate}%</div></div>
        <div class="stat"><div class="stat__label">Taux d'annulation</div>
          <div class="stat__value">${o.cancellation_rate}%</div></div>
        <div class="stat"><div class="stat__label">Utilisation de la flotte</div>
          <div class="stat__value">${o.vehicle_utilisation_percent}%</div>
          <div class="stat__hint">${o.vehicles_total} véhicules</div></div>
        <div class="stat"><div class="stat__label">Clients</div>
          <div class="stat__value">${o.customers_total}</div>
          <div class="stat__hint">+${o.customers_new} sur la période</div></div>
      </div>
      <div class="card"><h2>Chiffre d'affaires par mois</h2>
        ${d.revenue_by_month.length ? `<div class="bars">${d.revenue_by_month.map(r => `
          <div class="bars__item" title="${R.esc(r.month)} · ${R.money(r.revenue)} · ${r.bookings} réservations">
            <div class="bars__bar" style="height:${Math.round(r.revenue / max * 100)}%"></div>
            <span class="bars__label">${R.esc(r.month.slice(5))}/${R.esc(r.month.slice(2,4))}</span>
          </div>`).join("")}</div>` : R.emptyState("📈", "Pas encore de données")}
      </div>
      <div class="grid grid--2">
        <div class="card"><h2>Véhicules les plus loués</h2>${d.top_vehicles.length
          ? table(["Véhicule","Loueur","Réservations","CA"], d.top_vehicles.map(v => `
              <tr><td data-label="Véhicule">${R.esc(v.brand)} ${R.esc(v.model)}</td>
                <td data-label="Loueur">${R.esc(v.company)}</td>
                <td data-label="Réservations">${v.bookings}</td>
                <td data-label="CA">${R.money(v.revenue)}</td></tr>`).join(""))
          : R.emptyState("🚗", "Aucune donnée")}</div>
        <div class="card"><h2>Meilleures wilayas</h2>${d.top_locations.length
          ? table(["Wilaya","Réservations","CA"], d.top_locations.map(l => `
              <tr><td data-label="Wilaya">${R.esc(l.wilaya)}</td>
                <td data-label="Réservations">${l.bookings}</td>
                <td data-label="CA">${R.money(l.revenue)}</td></tr>`).join(""))
          : R.emptyState("📍", "Aucune donnée")}</div>
      </div>
      <div class="card"><h2>Réservations par statut</h2>
        ${table(["Statut","Nombre","Montant"], d.bookings_by_status.map(s => `
          <tr><td data-label="Statut">${R.pill(s.status)}</td>
            <td data-label="Nombre">${s.n}</td>
            <td data-label="Montant">${R.money(s.amount)}</td></tr>`).join(""))}
      </div>`;
  }

  function paged(loader) {
    let offset = 0, limit = 25;
    const list = document.createElement("div");
    async function go(params = "") {
      list.innerHTML = R.skeleton(3);
      const data = await loader(`limit=${limit}&offset=${offset}${params}`);
      list.innerHTML = data.html;
      if (data.total > limit) {
        const nav = document.createElement("nav");
        nav.className = "pager";
        nav.innerHTML = `
          ${offset > 0 ? '<button class="btn btn--ghost" data-prev>← Précédent</button>' : "<span></span>"}
          <span class="pager__info">${offset + 1}–${Math.min(offset + limit, data.total)} sur ${data.total}</span>
          ${offset + limit < data.total ? '<button class="btn btn--ghost" data-next>Suivant →</button>' : "<span></span>"}`;
        list.appendChild(nav);
        const prev = nav.querySelector("[data-prev]"), next = nav.querySelector("[data-next]");
        if (prev) prev.onclick = () => { offset = Math.max(0, offset - limit); go(params); };
        if (next) next.onclick = () => { offset += limit; go(params); };
      }
      if (data.after) data.after(list);
    }
    return { el: list, go, reset: () => { offset = 0; } };
  }

  async function bookings() {
    box.innerHTML = filterBar([
      { name: "q", label: "Recherche", placeholder: "Référence, client, e-mail" },
      { name: "status", label: "Statut", type: "select", options: [["","Tous"],["pending","En attente"],
        ["confirmed","Confirmée"],["active","En cours"],["completed","Terminée"],
        ["cancelled","Annulée"],["rejected","Refusée"],["expired","Expirée"]] },
    ]);
    const p = paged(async (qs) => {
      const data = await R.api(`/api/v1/admin/bookings?${qs}`);
      return { total: data.total, html: data.items.length
        ? table(["Référence","Client","Loueur","Véhicule","Dates","Total","Commission","Statut","Actions"],
            data.items.map(b => `<tr>
              <td data-label="Référence">${R.esc(b.reference)}</td>
              <td data-label="Client">${R.esc(b.customer_name)}<br>
                <small class="muted">${R.esc(b.customer_email)}</small></td>
              <td data-label="Loueur">${R.esc(b.company_name)}</td>
              <td data-label="Véhicule">${R.esc(b.brand)} ${R.esc(b.model)}</td>
              <td data-label="Dates">${R.shortDate(b.pickup_at)} → ${R.shortDate(b.return_at)}</td>
              <td data-label="Total">${R.money(b.total_amount)}<br>
                <small class="muted">payé ${R.money(b.paid_amount)}</small></td>
              <td data-label="Commission">${R.money(b.commission_amount)}</td>
              <td data-label="Statut">${R.pill(b.status)}<br>${R.pill(b.payment_status)}</td>
              <td data-label="Actions" class="table__actions">
                <a class="btn btn--ghost btn--sm" href="/reservation/${b.id}">Ouvrir</a>
              </td></tr>`).join(""))
        : R.emptyState("📋", "Aucune réservation trouvée") };
    });
    box.appendChild(p.el);
    const form = box.querySelector("[data-filter]");
    form.onsubmit = (ev) => {
      ev.preventDefault();
      const d = R.formData(form);
      p.reset();
      p.go(`${d.q ? "&q=" + encodeURIComponent(d.q) : ""}${d.status ? "&status=" + d.status : ""}`);
    };
    p.go();
  }

  async function vehicles() {
    box.innerHTML = filterBar([
      { name: "q", label: "Recherche", placeholder: "Marque ou modèle" },
      { name: "approval_status", label: "Validation", type: "select",
        options: [["","Toutes"],["pending","En attente"],["approved","Approuvés"],["rejected","Refusés"]] },
    ]);
    const p = paged(async (qs) => {
      const data = await R.api(`/api/v1/admin/vehicles?${qs}`);
      return {
        total: data.total,
        html: data.items.length
          ? table(["Véhicule","Loueur","Prix/jour","État","Validation","Actions"],
              data.items.map(v => `<tr>
                <td data-label="Véhicule">${R.esc(v.brand)} ${R.esc(v.model)} <small class="muted">${v.year}</small></td>
                <td data-label="Loueur">${R.esc(v.company_name)}</td>
                <td data-label="Prix/jour">${R.money(v.daily_price)}</td>
                <td data-label="État">${R.pill(v.status)}</td>
                <td data-label="Validation">${R.pill(v.approval_status)}</td>
                <td data-label="Actions" class="table__actions">
                  <a class="btn btn--ghost btn--sm" href="/vehicules/${R.esc(v.slug)}" target="_blank">Voir</a>
                  ${v.approval_status !== "approved"
                    ? `<button class="btn btn--primary btn--sm" data-approve="${v.id}">Approuver</button>` : ""}
                  ${v.approval_status !== "rejected"
                    ? `<button class="btn btn--danger btn--sm" data-reject="${v.id}">Refuser</button>` : ""}
                </td></tr>`).join(""))
          : R.emptyState("🚗", "Aucun véhicule"),
        after: (root) => {
          root.querySelectorAll("[data-approve]").forEach(b => b.onclick = () =>
            decide(`/api/v1/admin/vehicles/${b.dataset.approve}/approval`, "approved",
                   "Approuver ce véhicule ?", "Il deviendra visible et réservable.", () => p.go()));
          root.querySelectorAll("[data-reject]").forEach(b => b.onclick = () =>
            decide(`/api/v1/admin/vehicles/${b.dataset.reject}/approval`, "rejected",
                   "Refuser ce véhicule ?", "Le loueur sera notifié du motif.", () => p.go(), true));
        },
      };
    });
    box.appendChild(p.el);
    box.querySelector("[data-filter]").onsubmit = (ev) => {
      ev.preventDefault();
      const d = R.formData(ev.target);
      p.reset();
      p.go(`${d.q ? "&q=" + encodeURIComponent(d.q) : ""}${d.approval_status ? "&approval_status=" + d.approval_status : ""}`);
    };
    p.go();
  }

  function decide(url, decision, title, text, after, danger) {
    R.modal({
      title, danger: !!danger, confirmLabel: "Confirmer",
      body: `<p>${R.esc(text)}</p>
        <div class="field"><label for="reason">Motif ${decision === "rejected" ? "(obligatoire)" : "(optionnel)"}</label>
          <input id="reason" maxlength="300"></div>
        <p class="form__error" data-formerror hidden></p>`,
      onConfirm: async (root) => {
        const reason = root.querySelector("#reason").value;
        const err = root.querySelector("[data-formerror]");
        if (decision === "rejected" && !reason.trim()) {
          err.textContent = "Le motif est obligatoire."; err.hidden = false; throw new Error("x");
        }
        try {
          await R.api(url, { method: "POST", body: { decision, status: decision, reason } });
          R.toast("Décision enregistrée.", "ok"); after();
        } catch (e) { err.textContent = e.message; err.hidden = false; throw e; }
      },
    });
  }

  async function companies() {
    box.innerHTML = filterBar([
      { name: "q", label: "Recherche", placeholder: "Nom ou téléphone" },
      { name: "status", label: "Statut", type: "select", options: [["","Tous"],["pending","En attente"],
        ["approved","Approuvés"],["rejected","Refusés"],["suspended","Suspendus"]] },
    ]);
    const p = paged(async (qs) => {
      const data = await R.api(`/api/v1/admin/companies?${qs}`);
      return {
        total: data.total,
        html: data.items.length
          ? table(["Société","Propriétaire","Wilaya","RC / NIF","Véhicules","Commission","Statut","Actions"],
              data.items.map(c => `<tr>
                <td data-label="Société">${R.esc(c.name)}<br><small class="muted">${R.esc(c.phone)}</small></td>
                <td data-label="Propriétaire">${R.esc(c.owner_name)}<br>
                  <small class="muted">${R.esc(c.owner_email)}</small></td>
                <td data-label="Wilaya">${R.esc(c.wilaya || "—")}</td>
                <td data-label="RC / NIF">${R.esc(c.rc_number || "—")}<br>
                  <small class="muted">${R.esc(c.nif || "—")}</small></td>
                <td data-label="Véhicules">${c.vehicles}<br><small class="muted">${c.bookings} résa.</small></td>
                <td data-label="Commission">${c.commission_rate != null ? c.commission_rate + "%" : "défaut"}</td>
                <td data-label="Statut">${R.pill(c.status)}</td>
                <td data-label="Actions" class="table__actions">
                  ${c.status !== "approved"
                    ? `<button class="btn btn--primary btn--sm" data-appr="${c.id}">Approuver</button>` : ""}
                  ${c.status === "approved"
                    ? `<button class="btn btn--danger btn--sm" data-susp="${c.id}">Suspendre</button>` : ""}
                  ${c.status === "pending"
                    ? `<button class="btn btn--danger btn--sm" data-rej="${c.id}">Refuser</button>` : ""}
                  <button class="btn btn--ghost btn--sm" data-comm="${c.id}"
                    data-rate="${c.commission_rate == null ? "" : c.commission_rate}">Commission</button>
                </td></tr>`).join(""))
          : R.emptyState("🏢", "Aucun loueur"),
        after: (root) => {
          const url = id => `/api/v1/admin/companies/${id}/status`;
          root.querySelectorAll("[data-appr]").forEach(b => b.onclick = () =>
            decide(url(b.dataset.appr), "approved", "Approuver cette société ?",
              "Elle pourra publier ses véhicules.", () => p.go()));
          root.querySelectorAll("[data-rej]").forEach(b => b.onclick = () =>
            decide(url(b.dataset.rej), "rejected", "Refuser cette société ?",
              "Le propriétaire sera notifié.", () => p.go(), true));
          root.querySelectorAll("[data-susp]").forEach(b => b.onclick = () =>
            decide(url(b.dataset.susp), "suspended", "Suspendre cette société ?",
              "Ses véhicules seront immédiatement retirés du catalogue.", () => p.go(), true));
          root.querySelectorAll("[data-comm]").forEach(b => b.onclick = () => {
            R.modal({
              title: "Taux de commission", confirmLabel: "Enregistrer",
              body: `<div class="field"><label for="rate">Commission (%)</label>
                  <input id="rate" type="number" step="0.5" min="0" max="60" value="${R.esc(b.dataset.rate)}">
                  <p class="field__hint">Laisser vide pour utiliser le taux par défaut de la plateforme.</p></div>`,
              onConfirm: async (root2) => {
                const v = root2.querySelector("#rate").value;
                await R.api(`/api/v1/admin/companies/${b.dataset.comm}`, {
                  method: "PUT", body: v === "" ? { commission_rate: null } : { commission_rate: Number(v) } });
                R.toast("Commission mise à jour.", "ok"); p.go();
              },
            });
          });
        },
      };
    });
    box.appendChild(p.el);
    box.querySelector("[data-filter]").onsubmit = (ev) => {
      ev.preventDefault();
      const d = R.formData(ev.target);
      p.reset();
      p.go(`${d.q ? "&q=" + encodeURIComponent(d.q) : ""}${d.status ? "&status=" + d.status : ""}`);
    };
    p.go();
  }

  async function users() {
    box.innerHTML = filterBar([
      { name: "q", label: "Recherche", placeholder: "Nom, e-mail, téléphone" },
      { name: "role", label: "Rôle", type: "select", options: [["","Tous"],["customer","Clients"],
        ["fleet_owner","Loueurs"],["admin","Administrateurs"],["support_agent","Support"],
        ["finance_manager","Finance"]] },
      { name: "status", label: "Statut", type: "select",
        options: [["","Tous"],["active","Actifs"],["suspended","Suspendus"]] },
    ]);
    const p = paged(async (qs) => {
      const data = await R.api(`/api/v1/admin/users?${qs}`);
      return {
        total: data.total,
        html: data.items.length
          ? table(["Utilisateur","Téléphone","Rôles","Réservations","Inscrit le","Statut","Actions"],
              data.items.map(u => `<tr>
                <td data-label="Utilisateur">${R.esc(u.full_name)}<br>
                  <small class="muted">${R.esc(u.email)}${u.email_verified_at ? " ✓" : ""}</small></td>
                <td data-label="Téléphone">${R.esc(u.phone || "—")}</td>
                <td data-label="Rôles">${R.esc(u.roles || "—")}</td>
                <td data-label="Réservations">${u.bookings}</td>
                <td data-label="Inscrit le">${R.shortDate(u.created_at)}</td>
                <td data-label="Statut">${R.pill(u.status)}</td>
                <td data-label="Actions" class="table__actions">
                  ${u.status === "active"
                    ? `<button class="btn btn--danger btn--sm" data-susp="${u.id}">Suspendre</button>`
                    : `<button class="btn btn--primary btn--sm" data-react="${u.id}">Réactiver</button>`}
                </td></tr>`).join(""))
          : R.emptyState("👥", "Aucun utilisateur"),
        after: (root) => {
          root.querySelectorAll("[data-susp]").forEach(b => b.onclick = () => R.modal({
            title: "Suspendre ce compte ?", danger: true, confirmLabel: "Suspendre",
            body: `<p>Toutes ses sessions seront révoquées immédiatement.</p>
              <div class="field"><label for="reason">Motif (obligatoire)</label>
                <input id="reason" maxlength="300"></div>
              <p class="form__error" data-formerror hidden></p>`,
            onConfirm: async (root2) => {
              const reason = root2.querySelector("#reason").value;
              const err = root2.querySelector("[data-formerror]");
              if (!reason.trim()) { err.textContent = "Le motif est obligatoire."; err.hidden = false; throw new Error("x"); }
              try {
                await R.api(`/api/v1/admin/users/${b.dataset.susp}/suspend`, {
                  method: "POST", body: { action: "suspend", reason } });
                R.toast("Compte suspendu.", "ok"); p.go();
              } catch (e) { err.textContent = e.message; err.hidden = false; throw e; }
            },
          }));
          root.querySelectorAll("[data-react]").forEach(b => b.onclick = () =>
            R.confirmAction("Réactiver ce compte ?", "L'utilisateur pourra se reconnecter.",
              async () => {
                await R.api(`/api/v1/admin/users/${b.dataset.react}/suspend`, {
                  method: "POST", body: { action: "reactivate" } });
                R.toast("Compte réactivé.", "ok"); p.go();
              }));
        },
      };
    });
    box.appendChild(p.el);
    box.querySelector("[data-filter]").onsubmit = (ev) => {
      ev.preventDefault();
      const d = R.formData(ev.target);
      p.reset();
      p.go(`${d.q ? "&q=" + encodeURIComponent(d.q) : ""}${d.role ? "&role=" + d.role : ""}${d.status ? "&status=" + d.status : ""}`);
    };
    p.go();
  }

  async function documents() {
    box.innerHTML = `<div class="tabs">
        ${[["pending","À vérifier"],["approved","Approuvés"],["rejected","Refusés"]].map(([k, l], i) =>
          `<button class="tab${i === 0 ? " is-active" : ""}" data-st="${k}">${l}</button>`).join("")}
      </div>
      <div class="banner banner--info">L'ouverture d'un document est enregistrée dans le journal d'accès.</div>
      <div data-list>${R.skeleton(3)}</div>`;
    const list = box.querySelector("[data-list]");
    async function load(status) {
      list.innerHTML = R.skeleton(3);
      const data = await R.api(`/api/v1/admin/documents?status=${status}&limit=50`);
      list.innerHTML = data.items.length
        ? table(["Titulaire","Type","Fichier","Reçu le","Statut","Actions"], data.items.map(d => `
            <tr><td data-label="Titulaire">${R.esc(d.owner_name)}<br>
                  <small class="muted">${R.esc(d.owner_email || "")}</small></td>
              <td data-label="Type">${R.esc(d.kind)}</td>
              <td data-label="Fichier">${R.esc(d.original_name)}<br>
                <small class="muted">${Math.round(d.size_bytes / 1024)} Ko</small></td>
              <td data-label="Reçu le">${R.shortDate(d.created_at)}</td>
              <td data-label="Statut">${R.pill(d.status)}</td>
              <td data-label="Actions" class="table__actions">
                <button class="btn btn--ghost btn--sm" data-open="${d.id}">Consulter</button>
                ${status === "pending" ? `
                  <button class="btn btn--primary btn--sm" data-ok="${d.id}">Approuver</button>
                  <button class="btn btn--danger btn--sm" data-no="${d.id}">Refuser</button>` : ""}
              </td></tr>`).join(""))
        : R.emptyState("📄", "Aucun document dans cette file");
      list.querySelectorAll("[data-open]").forEach(b => b.onclick = async () => {
        try {
          const doc = await R.api(`/api/v1/documents/${b.dataset.open}`);
          window.open(doc.download_url, "_blank");
        } catch (e) { R.toast(e.message, "bad"); }
      });
      list.querySelectorAll("[data-ok]").forEach(b => b.onclick = () =>
        decide(`/api/v1/documents/${b.dataset.ok}/review`, "approved", "Approuver ce document ?",
          "Le client pourra être confirmé par les loueurs.", () => load(status)));
      list.querySelectorAll("[data-no]").forEach(b => b.onclick = () =>
        decide(`/api/v1/documents/${b.dataset.no}/review`, "rejected", "Refuser ce document ?",
          "Le client sera invité à en téléverser un nouveau.", () => load(status), true));
    }
    box.querySelectorAll("[data-st]").forEach(btn => btn.onclick = () => {
      box.querySelectorAll(".tab").forEach(t => t.classList.remove("is-active"));
      btn.classList.add("is-active");
      load(btn.dataset.st);
    });
    load("pending");
  }

  async function payments() {
    box.innerHTML = R.skeleton(3);
    const data = await R.api("/api/v1/admin/payments?limit=50");
    box.innerHTML = `
      <div class="grid grid--stats">
        <div class="stat stat--accent"><div class="stat__label">Encaissé</div>
          <div class="stat__value">${R.money(data.totals.collected)}</div></div>
        <div class="stat"><div class="stat__label">En attente</div>
          <div class="stat__value">${R.money(data.totals.pending)}</div></div>
        <div class="stat"><div class="stat__label">Remboursé</div>
          <div class="stat__value">${R.money(data.totals.refunded)}</div></div>
      </div>
      <div class="card"><h2>Paiements</h2>${data.items.length
        ? table(["Réservation","Client","Moyen","Type","Montant","Statut","Actions"], data.items.map(p => `
            <tr><td data-label="Réservation"><a href="/reservation/${p.booking_id}">${R.esc(p.reference)}</a></td>
              <td data-label="Client">${R.esc(p.customer_name)}</td>
              <td data-label="Moyen">${R.esc((R.STATUS[p.provider_code] || [p.provider_code])[0])}</td>
              <td data-label="Type">${p.kind === "deposit" ? "Caution" : "Paiement"}</td>
              <td data-label="Montant">${R.money(p.amount)}</td>
              <td data-label="Statut">${R.pill(p.status)}</td>
              <td data-label="Actions" class="table__actions">
                ${["pending","processing"].includes(p.status)
                  ? `<button class="btn btn--primary btn--sm" data-paid="${p.id}">Marquer payé</button>
                     <button class="btn btn--ghost btn--sm" data-failed="${p.id}">Échec</button>` : ""}
                ${["paid","partially_refunded"].includes(p.status)
                  ? `<button class="btn btn--danger btn--sm" data-refund="${p.id}"
                       data-amount="${p.amount}">Rembourser</button>` : ""}
              </td></tr>`).join(""))
        : R.emptyState("₪", "Aucun paiement")}</div>
      ${data.refunds.length ? `<div class="card"><h2>Remboursements</h2>
        ${table(["Réservation","Montant","Statut","Motif","Date"], data.refunds.map(r => `
          <tr><td data-label="Réservation">${R.esc(r.reference)}</td>
            <td data-label="Montant">${R.money(r.amount)}</td>
            <td data-label="Statut">${R.pill(r.status)}</td>
            <td data-label="Motif">${R.esc(r.reason || "—")}</td>
            <td data-label="Date">${R.shortDate(r.created_at)}</td></tr>`).join(""))}</div>` : ""}`;

    box.querySelectorAll("[data-paid]").forEach(b => b.onclick = () =>
      R.confirmAction("Confirmer la réception du paiement ?",
        "À utiliser uniquement après encaissement effectif (espèces ou virement reçu).",
        async () => {
          await R.api(`/api/v1/payments/${b.dataset.paid}/confirm`, { method: "POST", body: {} });
          R.toast("Paiement confirmé.", "ok"); payments();
        }));
    box.querySelectorAll("[data-failed]").forEach(b => b.onclick = () => R.modal({
      title: "Marquer ce paiement en échec ?", danger: true, confirmLabel: "Confirmer",
      body: `<div class="field"><label for="reason">Motif</label><input id="reason" maxlength="250"></div>`,
      onConfirm: async (root) => {
        await R.api(`/api/v1/payments/${b.dataset.failed}/fail`, {
          method: "POST", body: { reason: root.querySelector("#reason").value || "Échec constaté" } });
        R.toast("Paiement marqué en échec.", "warn"); payments();
      },
    }));
    box.querySelectorAll("[data-refund]").forEach(b => b.onclick = () => R.modal({
      title: "Rembourser ce paiement", danger: true, confirmLabel: "Enregistrer le remboursement",
      body: `<div class="field"><label for="amount">Montant (DA)</label>
          <input id="amount" type="number" min="1" max="${b.dataset.amount}" value="${b.dataset.amount}"></div>
        <div class="field"><label for="reason">Motif</label><input id="reason" maxlength="300"></div>
        <p class="form__error" data-formerror hidden></p>`,
      onConfirm: async (root) => {
        const err = root.querySelector("[data-formerror]");
        try {
          await R.api(`/api/v1/payments/${b.dataset.refund}/refund`, { method: "POST", body: {
            amount: Number(root.querySelector("#amount").value),
            reason: root.querySelector("#reason").value } });
          R.toast("Remboursement enregistré.", "ok"); payments();
        } catch (e) {
          err.textContent = e.fields ? Object.values(e.fields)[0] : e.message;
          err.hidden = false; throw e;
        }
      },
    }));
  }

  async function reviews() {
    box.innerHTML = R.skeleton(3);
    const items = await R.api("/api/v1/admin/reviews");
    box.innerHTML = items.length
      ? table(["Auteur","Véhicule","Note","Commentaire","Statut","Actions"], items.map(r => `
          <tr><td data-label="Auteur">${R.esc(r.author)}</td>
            <td data-label="Véhicule">${R.esc(r.brand)} ${R.esc(r.model)}</td>
            <td data-label="Note">${"★".repeat(r.rating_overall)}</td>
            <td data-label="Commentaire">${R.esc((r.comment || "").slice(0, 140))}</td>
            <td data-label="Statut">${R.pill(r.status)}</td>
            <td data-label="Actions" class="table__actions">
              ${r.status !== "published"
                ? `<button class="btn btn--primary btn--sm" data-pub="${r.id}">Publier</button>` : ""}
              ${r.status !== "rejected"
                ? `<button class="btn btn--danger btn--sm" data-hide="${r.id}">Masquer</button>` : ""}
            </td></tr>`).join(""))
      : R.emptyState("★", "Aucun avis client");
    const moderate = (id, status) => R.confirmAction(
      status === "published" ? "Publier cet avis ?" : "Masquer cet avis ?",
      status === "published" ? "Il sera visible sur la fiche du véhicule."
                             : "Il ne sera plus visible publiquement.",
      async () => {
        await R.api(`/api/v1/admin/reviews/${id}/moderate`, { method: "POST", body: { status } });
        R.toast("Avis mis à jour.", "ok"); reviews();
      }, { danger: status === "rejected" });
    box.querySelectorAll("[data-pub]").forEach(b => b.onclick = () => moderate(b.dataset.pub, "published"));
    box.querySelectorAll("[data-hide]").forEach(b => b.onclick = () => moderate(b.dataset.hide, "rejected"));
  }

  async function promos() {
    box.innerHTML = R.skeleton(3);
    const items = await R.api("/api/v1/admin/promo-codes");
    document.querySelector("[data-head-actions]").innerHTML =
      `<button class="btn btn--primary" data-newpromo>+ Nouveau code</button>`;
    document.querySelector("[data-newpromo]").onclick = () => R.modal({
      title: "Nouveau code promo", confirmLabel: "Créer",
      body: `<form class="form" data-promoform>
        <div class="formgrid">
          <div class="field"><label for="code">Code</label>
            <input id="code" name="code" required minlength="3" style="text-transform:uppercase"></div>
          <div class="field"><label for="kind">Type</label>
            <select id="kind" name="kind"><option value="percent">Pourcentage</option>
              <option value="fixed">Montant fixe (DA)</option></select></div>
          <div class="field"><label for="value">Valeur</label>
            <input id="value" name="value" type="number" min="1" required></div>
          <div class="field"><label for="min_amount">Montant minimum (DA)</label>
            <input id="min_amount" name="min_amount" type="number" min="0" value="0"></div>
          <div class="field"><label for="max_discount">Remise maximale (DA)</label>
            <input id="max_discount" name="max_discount" type="number" min="0"></div>
          <div class="field"><label for="usage_limit">Limite d'utilisation</label>
            <input id="usage_limit" name="usage_limit" type="number" min="1"></div>
          <div class="field"><label for="per_user_limit">Limite par client</label>
            <input id="per_user_limit" name="per_user_limit" type="number" min="1" value="1"></div>
          <div class="field"><label for="ends_at">Expire le</label>
            <input id="ends_at" name="ends_at" type="date"></div>
        </div>
        <p class="form__error" data-formerror hidden></p></form>`,
      onConfirm: async (root) => {
        const form = root.querySelector("[data-promoform]");
        const body = R.formData(form);
        Object.keys(body).forEach(k => { if (body[k] === "") delete body[k]; });
        if (body.ends_at) body.ends_at = body.ends_at + " 23:59";
        try {
          await R.api("/api/v1/admin/promo-codes", { method: "POST", body });
          R.toast("Code promo créé.", "ok"); promos();
        } catch (e) {
          R.formError(form, e.fields ? Object.values(e.fields)[0] : e.message); throw e;
        }
      },
    });
    box.innerHTML = items.length
      ? table(["Code","Type","Valeur","Min.","Utilisations","Expire","Statut"], items.map(p => `
          <tr><td data-label="Code"><strong>${R.esc(p.code)}</strong></td>
            <td data-label="Type">${p.kind === "percent" ? "Pourcentage" : "Montant fixe"}</td>
            <td data-label="Valeur">${p.kind === "percent" ? p.value + "%" : R.money(p.value)}</td>
            <td data-label="Min.">${R.money(p.min_amount)}</td>
            <td data-label="Utilisations">${p.used_count}${p.usage_limit ? " / " + p.usage_limit : ""}</td>
            <td data-label="Expire">${p.ends_at ? R.shortDate(p.ends_at) : "—"}</td>
            <td data-label="Statut">${R.pill(p.active ? "approved" : "inactive")}</td></tr>`).join(""))
      : R.emptyState("🎟", "Aucun code promo", "Créez une remise pour stimuler les réservations.");
  }

  async function audit() {
    box.innerHTML = filterBar([
      { name: "action", label: "Action", placeholder: "booking, payment, user…" },
      { name: "target_type", label: "Cible", type: "select", options: [["","Toutes"],["booking","Réservation"],
        ["vehicle","Véhicule"],["company","Société"],["user","Utilisateur"],["document","Document"],
        ["payment","Paiement"],["settings","Paramètres"]] },
    ]);
    const p = paged(async (qs) => {
      const data = await R.api(`/api/v1/admin/audit?${qs}`);
      return { total: data.total, html: data.items.length
        ? table(["Date","Acteur","Action","Cible","IP","Détails"], data.items.map(a => `
            <tr><td data-label="Date">${R.humanDate(a.created_at, true)}</td>
              <td data-label="Acteur">${R.esc(a.actor_name || a.actor_email || "système")}</td>
              <td data-label="Action"><code>${R.esc(a.action)}</code></td>
              <td data-label="Cible">${R.esc(a.target_type || "")} ${R.esc(a.target_id || "")}</td>
              <td data-label="IP">${R.esc(a.ip || "—")}</td>
              <td data-label="Détails"><small class="muted">${R.esc((a.metadata || "").slice(0, 90))}</small></td>
            </tr>`).join(""))
        : R.emptyState("🛡", "Aucune entrée d'audit") };
    });
    box.appendChild(p.el);
    box.querySelector("[data-filter]").onsubmit = (ev) => {
      ev.preventDefault();
      const d = R.formData(ev.target);
      p.reset();
      p.go(`${d.action ? "&action=" + encodeURIComponent(d.action) : ""}${d.target_type ? "&target_type=" + d.target_type : ""}`);
    };
    p.go();
  }

  async function settings() {
    box.innerHTML = R.skeleton(4);
    const [data, outbox] = await Promise.all([
      R.api("/api/v1/admin/settings"), R.api("/api/v1/admin/outbox"),
    ]);
    const groups = {};
    Object.entries(data.settings).forEach(([key, meta]) => {
      (groups[meta.group] = groups[meta.group] || []).push([key, meta]);
    });
    const GROUP_LABELS = { brand: "Identité", localisation: "Localisation", booking: "Règles de réservation",
      finance: "Finances et commissions", cancellation: "Politique d'annulation", documents: "Documents",
      payments: "Paiements", integrations: "Intégrations", fraud: "Protection anti-abus", legal: "Mentions légales" };

    function inputFor(key, meta) {
      const v = meta.value;
      if (typeof v === "boolean")
        return `<label class="check"><input type="checkbox" data-key="${key}" ${v ? "checked" : ""}>
                <span>Activé</span></label>`;
      if (typeof v === "number")
        return `<input type="number" step="any" data-key="${key}" value="${R.esc(v)}">`;
      if (typeof v === "object")
        return `<textarea rows="4" data-key="${key}" data-json="1">${R.esc(JSON.stringify(v, null, 1))}</textarea>`;
      return `<input type="text" data-key="${key}" value="${R.esc(v)}">`;
    }

    box.innerHTML = `
      <div class="card"><h2>État de préparation à la production</h2>
        <ul class="list">${data.readiness.map(c => `<li>
          ${c.ok ? '<span class="pill pill--ok">OK</span>' : '<span class="pill pill--warn">À faire</span>'}
          <strong style="margin-inline-start:8px">${R.esc(c.check)}</strong><br>
          <small class="muted">${R.esc(c.detail)}</small></li>`).join("")}</ul></div>

      <div class="card"><h2>Intégrations externes</h2>
        <p class="muted" style="margin-block-end:12px">Les variables d'environnement se définissent
          côté serveur (fichier <code>.env</code>). Aucune clé n'est affichée ici.</p>
        ${table(["Service","Fournisseur","État","Variables requises"],
          Object.entries(data.integrations).map(([k, v]) => `
            <tr><td data-label="Service">${R.esc(k)}</td>
              <td data-label="Fournisseur">${R.esc(v.provider)}</td>
              <td data-label="État">${v.status === "configured"
                ? '<span class="pill pill--ok">Configuré</span>'
                : '<span class="pill pill--warn">Configuration requise</span>'}</td>
              <td data-label="Variables"><small><code>${v.vars.join("</code> <code>")}</code></small></td>
            </tr>`).join(""))}</div>

      <div class="card"><h2>File d'envoi (e-mail / SMS)</h2>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-block-end:12px">
          ${outbox.summary.map(s => `<span class="pill pill--${
            s.status === "sent" ? "ok" : s.status === "failed" ? "bad" : "warn"}">${
            R.esc(s.status)} : ${s.n}</span>`).join("") || '<span class="muted">File vide</span>'}
          <button class="btn btn--ghost btn--sm" data-flush>Tenter l'envoi</button>
        </div>
        ${outbox.items.length ? table(["Canal","Destinataire","Modèle","État","Erreur"],
          outbox.items.slice(0, 15).map(o => `
            <tr><td data-label="Canal">${R.esc(o.channel)}</td>
              <td data-label="Destinataire">${R.esc(o.recipient || "—")}</td>
              <td data-label="Modèle">${R.esc(o.template)}</td>
              <td data-label="État">${R.pill(o.status === "sent" ? "paid" : o.status === "failed" ? "failed" : "pending")}
                <small class="muted">${R.esc(o.status)}</small></td>
              <td data-label="Erreur"><small class="muted">${R.esc((o.error || "").slice(0, 60))}</small></td>
            </tr>`).join("")) : ""}</div>

      ${Object.entries(groups).map(([g, entries]) => `
        <div class="card"><h2>${R.esc(GROUP_LABELS[g] || g)}</h2>
          <div class="formgrid">${entries.map(([key, meta]) => `
            <div class="field"><label>${R.esc(key)}</label>${inputFor(key, meta)}</div>`).join("")}</div>
        </div>`).join("")}

      <div class="actionsrow"><span></span>
        <button class="btn btn--primary btn--lg" data-savesettings>Enregistrer les paramètres</button></div>`;

    box.querySelector("[data-flush]").onclick = async (ev) => {
      R.busy(ev.target, true);
      try {
        const r = await R.api("/api/v1/admin/notifications/flush", { method: "POST", body: {} });
        R.toast(`Envoyés : ${r.sent} · échecs : ${r.failed} · non configurés : ${r.unconfigured}`,
                r.unconfigured ? "warn" : "ok");
        settings();
      } catch (e) { R.toast(e.message, "bad"); }
      finally { R.busy(ev.target, false); }
    };

    box.querySelector("[data-savesettings]").onclick = async (ev) => {
      const payload = {};
      let bad = null;
      box.querySelectorAll("[data-key]").forEach(el => {
        const key = el.dataset.key;
        if (el.type === "checkbox") payload[key] = el.checked;
        else if (el.dataset.json) {
          try { payload[key] = JSON.parse(el.value); }
          catch (e) { bad = key; }
        } else if (el.type === "number") payload[key] = Number(el.value);
        else payload[key] = el.value;
      });
      if (bad) return R.toast(`JSON invalide pour « ${bad} ».`, "bad");
      R.busy(ev.target, true);
      try {
        await R.api("/api/v1/admin/settings", { method: "PUT", body: { settings: payload } });
        R.toast("Paramètres enregistrés.", "ok");
      } catch (e) { R.toast(e.message, "bad"); }
      finally { R.busy(ev.target, false); }
    };
  }
});
