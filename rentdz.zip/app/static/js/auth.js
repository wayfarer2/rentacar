/* Auth forms: client-side hints + server-validated submission. */
document.addEventListener("DOMContentLoaded", () => {
  const R = window.RENTDZ;
  const next = new URLSearchParams(location.search).get("next");

  function wire(selector, endpoint, onSuccess) {
    const form = document.querySelector(selector);
    if (!form) return;
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      R.clearErrors(form);
      const btn = form.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        const data = await R.api(endpoint, { method: "POST", body: R.formData(form) });
        onSuccess(data, form);
      } catch (e) {
        if (e.fields) R.fieldErrors(form, e.fields);
        R.formError(form, e.message);
      } finally { R.busy(btn, false); }
    });
  }

  wire("[data-loginform]", "/api/v1/auth/login", () => {
    location.href = next && next.startsWith("/") ? next : "/mon-espace";
  });

  wire("[data-registerform]", "/api/v1/auth/register", (data, form) => {
    const isVendor = form.querySelector('[name="account_type"]').value === "fleet_owner";
    R.toast("Compte créé. Bienvenue sur RENTDZ.", "ok");
    location.href = isVendor ? "/loueur/societe" : "/mon-espace";
  });

  wire("[data-forgotform]", "/api/v1/auth/password/forgot", (data, form) => {
    const ok = form.querySelector("[data-formok]");
    ok.textContent = data.message;
    ok.hidden = false;
    if (data.debug_token) {
      const link = `/nouveau-mot-de-passe?token=${data.debug_token}`;
      ok.innerHTML += ` <a class="link" href="${link}">Lien de réinitialisation (mode développement)</a>`;
    }
    form.reset();
  });

  wire("[data-resetform]", "/api/v1/auth/password/reset", (data, form) => {
    const ok = form.querySelector("[data-formok]");
    ok.textContent = data.message + " Redirection…";
    ok.hidden = false;
    setTimeout(() => location.href = "/connexion", 1400);
  });

  const verify = document.querySelector("[data-verify]");
  if (verify) {
    const msg = verify.querySelector("[data-verify-msg]");
    const token = verify.dataset.token;
    if (!token) { msg.textContent = "Lien de confirmation incomplet."; }
    else {
      R.api("/api/v1/auth/verify-email", { method: "POST", body: { token } })
        .then(() => { msg.textContent = "Votre adresse e-mail est confirmée. Merci !"; })
        .catch(e => { msg.textContent = e.message; });
    }
  }

  // Password strength hint (advisory only; the server enforces the rule)
  const pw = document.querySelector('[data-registerform] [name="password"]');
  if (pw) {
    const hint = pw.parentElement.querySelector(".field__hint");
    const base = hint.textContent;
    pw.addEventListener("input", () => {
      const v = pw.value;
      if (!v) { hint.textContent = base; return; }
      const strong = v.length >= 10 && /[A-Za-z]/.test(v) && /\d/.test(v);
      hint.textContent = strong ? "Mot de passe valide ✓" : base;
      hint.style.color = strong ? "var(--ok)" : "";
    });
  }
});
