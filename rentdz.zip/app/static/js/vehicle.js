/* Vehicle page: gallery, live server-side quote, availability guard, favourite. */
document.addEventListener("DOMContentLoaded", () => {
  const R = window.RENTDZ;
  const booker = document.querySelector("[data-booker]");

  /* gallery */
  const main = document.querySelector("[data-gallery-main]");
  document.querySelectorAll("[data-gallery-thumb]").forEach(btn => {
    btn.addEventListener("click", () => {
      const src = btn.dataset.galleryThumb;
      const img = main && main.querySelector("img");
      if (img) img.src = src;
      document.querySelectorAll("[data-gallery-thumb]").forEach(b => b.classList.remove("is-active"));
      btn.classList.add("is-active");
    });
  });

  /* favourite */
  const fav = document.querySelector("[data-favourite]");
  if (fav) {
    fav.addEventListener("click", async () => {
      try {
        const data = await R.api("/api/v1/favourites", {
          method: "POST", body: { vehicle_id: Number(fav.dataset.favourite) } });
        fav.style.color = data.favourite ? "var(--bad)" : "";
        R.toast(data.favourite ? "Ajouté à vos véhicules sauvegardés." : "Retiré de vos favoris.", "ok");
      } catch (e) {
        if (e.status === 401) { location.href = "/connexion?next=" + encodeURIComponent(location.pathname); return; }
        R.toast(e.message, "bad");
      }
    });
  }

  if (!booker) return;
  const form = booker.querySelector("[data-quoteform]");
  const out = booker.querySelector("[data-quote]");
  const errBox = booker.querySelector("[data-quote-error]");
  const bookBtn = booker.querySelector("[data-book]");
  const unavailable = new Set(JSON.parse(booker.dataset.unavailable || "[]"));
  let timer = null, latest = null;

  function dtValue(dateName, timeName) {
    const d = form.querySelector(`[name="${dateName}"]`).value;
    const t = form.querySelector(`[name="${timeName}"]`).value || "10:00";
    return d ? `${d} ${t}` : "";
  }

  function localConflict(from, to) {
    if (!from || !to) return null;
    const start = new Date(from + "T00:00:00");
    const end = new Date(to + "T00:00:00");
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const iso = d.toISOString().slice(0, 10);
      if (unavailable.has(iso)) return iso;
    }
    return null;
  }

  function showError(message) {
    errBox.textContent = message;
    errBox.hidden = false;
    bookBtn.disabled = true;
    out.innerHTML = "";
  }

  function render(q) {
    latest = q;
    errBox.hidden = true;
    const rows = [];
    (q.lines.base || []).forEach(l => rows.push([l.label, R.money(l.amount)]));
    (q.lines.adjustments || []).forEach(l =>
      rows.push([l.label, (l.amount >= 0 ? "+" : "") + R.money(l.amount)]));
    (q.lines.services || []).forEach(l =>
      rows.push([`${l.label}${l.qty > 1 ? ` ×${l.qty}` : ""}`, R.money(l.amount)]));
    (q.lines.fees || []).forEach(l => rows.push([l.label, R.money(l.amount)]));

    let html = `<div class="quote__row quote__row--muted">
        <span>${q.days} ${q.days > 1 ? "jours" : "jour"} de location</span>
        <span>${R.money(q.daily_price)} / jour</span></div>`;
    html += rows.map(([k, v]) =>
      `<div class="quote__row"><span>${R.esc(k)}</span><span>${v}</span></div>`).join("");
    (q.lines.discounts || []).forEach(l => {
      html += `<div class="quote__row quote__row--discount"><span>${R.esc(l.label)}</span>
               <span>${R.money(l.amount)}</span></div>`;
    });
    (q.lines.taxes || []).forEach(l => {
      html += `<div class="quote__row"><span>${R.esc(l.label)}</span><span>${R.money(l.amount)}</span></div>`;
    });
    html += `<div class="quote__row quote__row--total"><span>Total à payer</span>
             <span>${R.money(q.total_amount)}</span></div>`;
    if (q.deposit_amount) {
      html += `<div class="quote__row quote__row--muted"><span>Caution (restituée au retour)</span>
               <span>${R.money(q.deposit_amount)}</span></div>`;
    }
    html += q.available
      ? `<span class="quote__badge quote__badge--ok">Disponible à ces dates</span>`
      : `<span class="quote__badge quote__badge--bad">Indisponible à ces dates</span>`;
    out.innerHTML = html;
    bookBtn.disabled = !q.available;
  }

  async function refresh() {
    const pickup = dtValue("pickup_date", "pickup_time");
    const ret = dtValue("return_date", "return_time");
    if (!pickup || !ret) return;
    if (ret <= pickup) { showError("La date de retour doit suivre la date de départ."); return; }
    const clash = localConflict(pickup.slice(0, 10), ret.slice(0, 10));
    if (clash) { showError(`Véhicule déjà réservé le ${R.shortDate(clash)}. Choisissez d'autres dates.`); return; }

    out.innerHTML = R.skeleton(3);
    const services = Array.from(form.querySelectorAll('[name="service"]:checked'))
      .map(el => ({ id: Number(el.value) }));
    const body = {
      vehicle_id: Number(booker.dataset.vehicle),
      pickup_at: pickup, return_at: ret, services,
    };
    const loc = form.querySelector('[name="pickup_location_id"]');
    if (loc && loc.value) body.pickup_location_id = Number(loc.value);
    const promo = form.querySelector('[name="promo_code"]');
    if (promo && promo.value.trim()) body.promo_code = promo.value.trim();
    try {
      render(await R.api("/api/v1/quote", { method: "POST", body }));
    } catch (e) {
      showError(e.fields ? Object.values(e.fields)[0] : e.message);
    }
  }

  const debounced = () => { clearTimeout(timer); timer = setTimeout(refresh, 320); };
  form.addEventListener("change", debounced);
  form.querySelector('[name="promo_code"]').addEventListener("input", debounced);
  const pickupInput = form.querySelector('[name="pickup_date"]');
  const returnInput = form.querySelector('[name="return_date"]');
  pickupInput.addEventListener("change", () => {
    returnInput.min = pickupInput.value;
    if (returnInput.value < pickupInput.value) returnInput.value = pickupInput.value;
  });

  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    if (!latest || !latest.available) return;
    const params = new URLSearchParams({
      pickup_at: latest.pickup_at, return_at: latest.return_at,
    });
    const services = Array.from(form.querySelectorAll('[name="service"]:checked')).map(e => e.value);
    if (services.length) params.set("services", services.join(","));
    const loc = form.querySelector('[name="pickup_location_id"]');
    if (loc && loc.value) params.set("pickup_location_id", loc.value);
    const promo = form.querySelector('[name="promo_code"]');
    if (promo && promo.value.trim()) params.set("promo_code", promo.value.trim());
    location.href = `/reserver/${booker.dataset.slug}?${params.toString()}`;
  });

  refresh();
});
