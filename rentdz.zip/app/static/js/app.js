/* RENTDZ core: API client with CSRF, toasts, modals, nav, formatting. */
(function () {
  "use strict";
  const RENTDZ = {};
  const LOCALE = document.body.dataset.locale || "fr";
  let csrf = null;

  /* ---------- API ---------- */
  async function api(path, options = {}) {
    const opts = Object.assign({ method: "GET", headers: {}, credentials: "same-origin" }, options);
    if (opts.body && !(opts.body instanceof FormData)) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }
    if (!["GET", "HEAD"].includes(opts.method)) {
      if (!csrf) await session();
      if (csrf) opts.headers["X-CSRF-Token"] = csrf;
    }
    let res, payload;
    try {
      res = await fetch(path, opts);
    } catch (err) {
      throw { code: "network", message: "Connexion au serveur impossible. Vérifiez votre réseau." };
    }
    try { payload = await res.json(); } catch (e) { payload = {}; }
    if (!res.ok || payload.ok === false) {
      const e = (payload && payload.error) || {};
      throw {
        status: res.status,
        code: e.code || "error",
        message: e.message || "Une erreur est survenue. Veuillez réessayer.",
        fields: e.fields || null,
        extra: e,
      };
    }
    return payload.data !== undefined ? payload.data : payload;
  }

  async function session() {
    try {
      const data = await api("/api/v1/auth/me");
      csrf = data.csrf_token || null;
      RENTDZ.user = data.user || null;
      RENTDZ.permissions = data.permissions || [];
      RENTDZ.roles = data.roles || [];
      return data;
    } catch (e) { return { user: null }; }
  }

  /* ---------- formatting ---------- */
  function money(n) {
    const v = Math.round(Number(n) || 0);
    const s = v.toLocaleString(LOCALE === "ar" ? "ar-DZ" : "fr-DZ").replace(/\u202f|,/g, "\u00a0");
    return LOCALE === "ar" ? s + " دج" : s + " DA";
  }
  const MONTHS = ["janvier","février","mars","avril","mai","juin","juillet","août",
                  "septembre","octobre","novembre","décembre"];
  function humanDate(value, withTime) {
    if (!value) return "";
    const d = String(value).slice(0, 10).split("-");
    if (d.length < 3) return value;
    const out = `${Number(d[2])} ${MONTHS[Number(d[1]) - 1]} ${d[0]}`;
    const time = String(value).slice(11, 16);
    return withTime && time ? `${out} à ${time}` : out;
  }
  function shortDate(value) {
    if (!value) return "";
    const d = String(value).slice(0, 10).split("-");
    return d.length === 3 ? `${d[2]}/${d[1]}/${d[0]}` : value;
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g,
      c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  const STATUS = {
    pending:["En attente","warn"], awaiting_payment:["Paiement attendu","warn"],
    confirmed:["Confirmée","ok"], active:["En cours","ok"], completed:["Terminée","neutral"],
    cancelled:["Annulée","bad"], rejected:["Refusée","bad"], expired:["Expirée","bad"],
    no_show:["Non présenté","bad"], paid:["Payé","ok"], partially_paid:["Partiel","warn"],
    failed:["Échoué","bad"], refunded:["Remboursé","neutral"],
    partially_refunded:["Part. remboursé","neutral"], processing:["En traitement","warn"],
    approved:["Approuvé","ok"], suspended:["Suspendu","bad"], available:["Disponible","ok"],
    reserved:["Réservé","warn"], rented:["Loué","info"], maintenance:["Maintenance","warn"],
    unavailable:["Indisponible","bad"], inactive:["Inactif","neutral"], open:["Ouvert","warn"],
    in_progress:["En cours","warn"], waiting_customer:["Attente client","warn"],
    resolved:["Résolu","ok"], closed:["Fermé","neutral"], published:["Publié","ok"],
    cash_on_pickup:["Espèces à l'agence","neutral"], bank_transfer:["Virement","neutral"],
  };
  function pill(status) {
    const [label, tone] = STATUS[status] || [status, "neutral"];
    return `<span class="pill pill--${tone}">${esc(label)}</span>`;
  }

  /* ---------- toasts ---------- */
  let toastBox;
  function toast(message, tone) {
    if (!toastBox) {
      toastBox = document.createElement("div");
      toastBox.className = "toasts";
      toastBox.setAttribute("role", "status");
      toastBox.setAttribute("aria-live", "polite");
      document.body.appendChild(toastBox);
    }
    const el = document.createElement("div");
    el.className = "toast toast--" + (tone || "info");
    el.textContent = message;
    toastBox.appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; setTimeout(() => el.remove(), 250); }, 4200);
  }

  /* ---------- modal / confirm ---------- */
  function modal({ title, body, confirmLabel = "Confirmer", cancelLabel = "Annuler",
                   danger = false, onConfirm }) {
    const back = document.createElement("div");
    back.className = "modal";
    back.innerHTML = `
      <div class="modal__box" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <h2 class="modal__title">${esc(title)}</h2>
        <div class="modal__text">${body || ""}</div>
        <div class="modal__actions">
          <button class="btn btn--ghost" data-cancel>${esc(cancelLabel)}</button>
          <button class="btn ${danger ? "btn--danger" : "btn--primary"}" data-ok>${esc(confirmLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(back);
    const close = () => { back.remove(); document.removeEventListener("keydown", onKey); };
    const onKey = (ev) => { if (ev.key === "Escape") close(); };
    document.addEventListener("keydown", onKey);
    back.addEventListener("click", (ev) => { if (ev.target === back) close(); });
    back.querySelector("[data-cancel]").onclick = close;
    const okBtn = back.querySelector("[data-ok]");
    okBtn.onclick = async () => {
      okBtn.classList.add("is-loading");
      okBtn.disabled = true;
      try { await (onConfirm && onConfirm(back)); close(); }
      catch (e) { toast(e.message || "Action impossible.", "bad"); okBtn.classList.remove("is-loading"); okBtn.disabled = false; }
    };
    setTimeout(() => okBtn.focus(), 40);
    return { close, root: back };
  }
  const confirmAction = (title, text, onConfirm, opts = {}) =>
    modal(Object.assign({ title, body: `<p>${esc(text)}</p>`, onConfirm }, opts));

  /* ---------- form helpers ---------- */
  function fieldErrors(form, fields) {
    form.querySelectorAll("[data-error-for]").forEach(el => { el.hidden = true; el.textContent = ""; });
    form.querySelectorAll("[aria-invalid]").forEach(el => el.removeAttribute("aria-invalid"));
    Object.entries(fields || {}).forEach(([name, message]) => {
      const holder = form.querySelector(`[data-error-for="${name}"]`);
      const input = form.querySelector(`[name="${name}"]`);
      if (input) input.setAttribute("aria-invalid", "true");
      if (holder) { holder.textContent = message; holder.hidden = false; }
      else if (input) toast(message, "bad");
    });
  }
  function formError(form, message) {
    const box = form.querySelector("[data-formerror]");
    if (box) { box.textContent = message; box.hidden = false; }
    else toast(message, "bad");
  }
  function clearErrors(form) {
    const box = form.querySelector("[data-formerror]");
    if (box) box.hidden = true;
    fieldErrors(form, {});
  }
  function formData(form) {
    const out = {};
    new FormData(form).forEach((v, k) => {
      if (out[k] === undefined) out[k] = v;
      else if (Array.isArray(out[k])) out[k].push(v);
      else out[k] = [out[k], v];
    });
    return out;
  }
  function busy(btn, on) {
    if (!btn) return;
    btn.classList.toggle("is-loading", !!on);
    btn.disabled = !!on;
  }
  const skeleton = (n = 3) =>
    Array.from({ length: n }, () => '<div class="skeleton skeleton__line"></div>').join("");
  function emptyState(icon, title, text, cta) {
    return `<div class="empty"><div class="empty__icon" aria-hidden="true">${icon}</div>
      <h3 class="empty__title">${esc(title)}</h3>
      ${text ? `<p class="empty__text">${esc(text)}</p>` : ""}
      ${cta ? `<a class="btn btn--primary" href="${esc(cta[1])}">${esc(cta[0])}</a>` : ""}</div>`;
  }

  /* ---------- chrome ---------- */
  function initChrome() {
    const menu = document.querySelector("[data-usermenu]");
    if (menu) {
      const btn = menu.querySelector(".usermenu__btn");
      btn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const open = menu.classList.toggle("is-open");
        btn.setAttribute("aria-expanded", String(open));
      });
      document.addEventListener("click", () => {
        menu.classList.remove("is-open");
        btn.setAttribute("aria-expanded", "false");
      });
      menu.addEventListener("keydown", (ev) => { if (ev.key === "Escape") menu.classList.remove("is-open"); });
    }
    const burger = document.querySelector("[data-burger]");
    const mobile = document.querySelector("[data-mobilenav]");
    if (burger && mobile) {
      burger.addEventListener("click", () => {
        const open = mobile.classList.toggle("is-open");
        burger.setAttribute("aria-expanded", String(open));
      });
    }
    document.querySelectorAll("[data-logout]").forEach(btn => {
      btn.addEventListener("click", async () => {
        busy(btn, true);
        try { await api("/api/v1/auth/logout", { method: "POST" }); location.href = "/"; }
        catch (e) { toast(e.message, "bad"); busy(btn, false); }
      });
    });
    const toggle = document.querySelector("[data-filters-toggle]");
    if (toggle) toggle.addEventListener("click", () =>
      document.querySelector("[data-filters]").classList.toggle("is-open"));
  }

  function preloaded() {
    const el = document.getElementById("preload-state");
    if (!el) return null;
    try { return JSON.parse(el.textContent); } catch (e) { return null; }
  }

  Object.assign(RENTDZ, {
    api, session, money, humanDate, shortDate, esc, pill, toast, modal, confirmAction,
    fieldErrors, formError, clearErrors, formData, busy, skeleton, emptyState, preloaded,
    locale: LOCALE, STATUS,
    get csrf() { return csrf; },
  });
  window.RENTDZ = RENTDZ;
  document.addEventListener("DOMContentLoaded", () => { initChrome(); session(); });
})();
