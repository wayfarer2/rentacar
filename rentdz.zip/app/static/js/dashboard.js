/* Customer area: dashboard, bookings, documents, favourites, payments, notifications, support, profile. */
document.addEventListener("DOMContentLoaded", async () => {
  const R = window.RENTDZ;
  const box = document.querySelector("[data-app]");
  if (!box) return;
  const path = location.pathname.replace(/\/$/, "");
  await R.session();
  if (!R.user) { location.href = "/connexion?next=" + encodeURIComponent(path); return; }

  const views = {
    "/mon-espace": dashboard,
    "/mon-espace/reservations": bookings,
    "/mon-espace/documents": documents,
    "/mon-espace/favoris": favourites,
    "/mon-espace/paiements": payments,
    "/mon-espace/notifications": notifications,
    "/mon-espace/support": support,
    "/mon-espace/profil": profile,
  };
  const view = views[path] || dashboard;
  try { await view(); }
  catch (e) { box.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>`; }

  function bookingRow(b) {
    return `<tr>
      <td data-label="Référence"><a href="/reservation/${b.id}">${R.esc(b.reference)}</a></td>
      <td data-label="Véhicule">${R.esc(b.brand)} ${R.esc(b.model)}<br>
        <small class="muted">${R.esc(b.company_name)}</small></td>
      <td data-label="Dates">${R.shortDate(b.pickup_at)} → ${R.shortDate(b.return_at)}<br>
        <small class="muted">${b.days} jour(s)</small></td>
      <td data-label="Montant">${R.money(b.total_amount)}</td>
      <td data-label="Statut">${R.pill(b.status)}</td>
      <td data-label="Paiement">${R.pill(b.payment_status)}</td>
      <td data-label="Actions" class="table__actions">
        <a class="btn btn--ghost btn--sm" href="/reservation/${b.id}">Détail</a>
        ${b.status === "completed" && !b.has_review
          ? `<button class="btn btn--ghost btn--sm" data-review="${b.id}">Laisser un avis</button>` : ""}
      </td></tr>`;
  }

  function table(headers, rows) {
    return `<div class="tablewrap"><table class="table">
      <thead><tr>${headers.map(h => `<th>${R.esc(h)}</th>`).join("")}</tr></thead>
      <tbody>${rows}</tbody></table></div>`;
  }

  async function dashboard() {
    box.innerHTML = R.skeleton(4);
    const [upcoming, docs, notifs] = await Promise.all([
      R.api("/api/v1/bookings?scope=upcoming&limit=5"),
      R.api("/api/v1/documents"),
      R.api("/api/v1/notifications"),
    ]);
    const pastCount = (await R.api("/api/v1/bookings?scope=past&limit=1")).total;
    const pendingDocs = docs.filter(d => d.status === "pending").length;
    const rejected = docs.filter(d => d.status === "rejected").length;
    const approved = docs.filter(d => d.status === "approved").length;

    const alerts = [];
    if (!R.user.email_verified_at)
      alerts.push(`<div class="banner banner--warn">Votre adresse e-mail n'est pas confirmée.
        Consultez votre boîte de réception pour valider votre compte.</div>`);
    if (!approved)
      alerts.push(`<div class="banner banner--info">Ajoutez votre permis de conduire pour que les
        loueurs puissent confirmer vos réservations.
        <a class="link" href="/mon-espace/documents">Téléverser maintenant</a></div>`);
    if (rejected)
      alerts.push(`<div class="banner banner--bad">${rejected} document(s) refusé(s).
        <a class="link" href="/mon-espace/documents">Voir le motif</a></div>`);

    box.innerHTML = `
      ${alerts.join("")}
      <div class="grid grid--stats">
        <div class="stat stat--accent"><div class="stat__label">Réservations à venir</div>
          <div class="stat__value">${upcoming.total}</div>
          <div class="stat__hint">Locations confirmées ou en attente</div></div>
        <div class="stat"><div class="stat__label">Locations passées</div>
          <div class="stat__value">${pastCount}</div></div>
        <div class="stat"><div class="stat__label">Documents</div>
          <div class="stat__value">${approved}/${docs.length || 0}</div>
          <div class="stat__hint">${pendingDocs} en attente de validation</div></div>
        <div class="stat"><div class="stat__label">Notifications</div>
          <div class="stat__value">${notifs.unread}</div>
          <div class="stat__hint">non lues</div></div>
      </div>
      <div class="card"><h2>Prochaines locations</h2>
        ${upcoming.items.length
          ? table(["Référence","Véhicule","Dates","Montant","Statut","Paiement","Actions"],
                  upcoming.items.map(bookingRow).join(""))
          : R.emptyState("🗓", "Aucune réservation à venir",
              "Trouvez un véhicule et réservez en quelques minutes.",
              ["Chercher un véhicule", "/vehicules"])}
      </div>`;
    wireReviews();
  }

  async function bookings() {
    const scopes = [["upcoming","À venir"],["active","En cours"],["past","Passées"],
                    ["cancelled","Annulées"],["all","Toutes"]];
    box.innerHTML = `<div class="tabs">${scopes.map(([k, l], i) =>
      `<button class="tab${i === 0 ? " is-active" : ""}" data-scope="${k}">${l}</button>`).join("")}</div>
      <div data-list>${R.skeleton(3)}</div>`;
    const list = box.querySelector("[data-list]");
    async function loadScope(scope) {
      list.innerHTML = R.skeleton(3);
      const data = await R.api(`/api/v1/bookings?scope=${scope}&limit=25`);
      list.innerHTML = data.items.length
        ? table(["Référence","Véhicule","Dates","Montant","Statut","Paiement","Actions"],
                data.items.map(bookingRow).join(""))
        : R.emptyState("🗓", "Aucune réservation ici", "", ["Voir les véhicules", "/vehicules"]);
      wireReviews();
    }
    box.querySelectorAll("[data-scope]").forEach(btn => {
      btn.onclick = () => {
        box.querySelectorAll(".tab").forEach(t => t.classList.remove("is-active"));
        btn.classList.add("is-active");
        loadScope(btn.dataset.scope);
      };
    });
    loadScope("upcoming");
  }

  function wireReviews() {
    box.querySelectorAll("[data-review]").forEach(btn => {
      btn.onclick = () => R.modal({
        title: "Votre avis sur cette location",
        confirmLabel: "Publier mon avis",
        body: `
          ${["overall","vehicle","service","cleanliness","communication"].map((k, i) => `
            <div class="field"><label for="r_${k}">${
              ["Note globale","Véhicule","Service","Propreté","Communication"][i]}</label>
              <select id="r_${k}" name="rating_${k}">
                ${[5,4,3,2,1].map(n => `<option value="${n}">${"★".repeat(n)}</option>`).join("")}
              </select></div>`).join("")}
          <div class="field"><label for="r_comment">Commentaire</label>
            <textarea id="r_comment" rows="4" maxlength="2000"></textarea></div>`,
        onConfirm: async (root) => {
          const body = { booking_id: Number(btn.dataset.review),
            comment: root.querySelector("#r_comment").value };
          ["overall","vehicle","service","cleanliness","communication"].forEach(k => {
            body["rating_" + k] = Number(root.querySelector("#r_" + k).value);
          });
          await R.api("/api/v1/reviews", { method: "POST", body });
          R.toast("Merci, votre avis est publié.", "ok");
          location.reload();
        },
      });
    });
  }

  async function documents() {
    box.innerHTML = R.skeleton(3);
    const docs = await R.api("/api/v1/documents");
    const kinds = [["driver_license","Permis de conduire"],["id_card","Carte d'identité"],
                   ["passport","Passeport"],["other","Autre document"]];
    box.innerHTML = `
      <div class="banner banner--info">Vos documents sont stockés de façon privée. Les liens de
        consultation expirent après quelques minutes et chaque accès est journalisé.</div>
      <div class="card">
        <h2>Ajouter un document</h2>
        <form class="form" data-upload>
          <div class="field"><label for="kind">Type de document</label>
            <select id="kind" name="kind">${kinds.map(([k, l]) =>
              `<option value="${k}">${l}</option>`).join("")}</select></div>
          <div class="field"><label for="expires">Date d'expiration (optionnel)</label>
            <input id="expires" name="expires_at" type="date"></div>
          <label class="uploadzone" data-drop>
            <input type="file" name="file" hidden accept="image/jpeg,image/png,image/webp,application/pdf">
            <strong data-filename>Choisir un fichier</strong>
            <p class="muted">JPEG, PNG, WEBP ou PDF · 8 Mo maximum</p>
          </label>
          <p class="form__error" data-formerror hidden></p>
          <button class="btn btn--primary" type="submit">Téléverser</button>
        </form>
      </div>
      <div class="card"><h2>Mes documents</h2><div data-docs>${
        docs.length ? docs.map(d => `
          <div class="filerow">
            <span>${R.esc(d.original_name)}<br>
              <small class="muted">${(R.STATUS[d.kind] || [])[0] || d.kind} ·
                ${Math.round(d.size_bytes / 1024)} Ko · ${R.shortDate(d.created_at)}</small>
              ${d.status === "rejected" && d.reject_reason
                ? `<br><small class="field__error">${R.esc(d.reject_reason)}</small>` : ""}</span>
            <span style="display:flex;gap:8px;align-items:center">${R.pill(d.status)}
              <a class="btn btn--ghost btn--sm" href="${R.esc(d.download_url)}">Consulter</a></span>
          </div>`).join("")
        : R.emptyState("📄", "Aucun document téléversé", "Ajoutez votre permis de conduire.")}</div></div>`;

    const form = box.querySelector("[data-upload]");
    const input = form.querySelector('input[type="file"]');
    const zone = form.querySelector("[data-drop]");
    const nameEl = form.querySelector("[data-filename]");
    input.onchange = () => { nameEl.textContent = input.files[0] ? input.files[0].name : "Choisir un fichier"; };
    ["dragover","dragenter"].forEach(ev => zone.addEventListener(ev, e => {
      e.preventDefault(); zone.classList.add("is-drag"); }));
    ["dragleave","drop"].forEach(ev => zone.addEventListener(ev, () => zone.classList.remove("is-drag")));
    zone.addEventListener("drop", e => {
      e.preventDefault();
      if (e.dataTransfer.files[0]) { input.files = e.dataTransfer.files; input.onchange(); }
    });
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(form);
      if (!input.files[0]) return R.formError(form, "Sélectionnez un fichier.");
      const fd = new FormData();
      fd.append("file", input.files[0]);
      fd.append("kind", form.querySelector("#kind").value);
      const exp = form.querySelector("#expires").value;
      if (exp) fd.append("expires_at", exp);
      const btn = form.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        await R.api("/api/v1/documents", { method: "POST", body: fd });
        R.toast("Document téléversé.", "ok");
        documents();
      } catch (e) { R.formError(form, e.fields ? Object.values(e.fields)[0] : e.message); }
      finally { R.busy(btn, false); }
    };
  }

  async function favourites() {
    box.innerHTML = R.skeleton(3);
    const items = await R.api("/api/v1/favourites");
    box.innerHTML = items.length ? `<div class="grid grid--cards">${items.map(v => `
      <article class="vcard">
        <a class="vcard__media" href="/vehicules/${R.esc(v.slug)}">
          ${v.image ? `<img src="/media/${R.esc(v.image)}" alt="" loading="lazy">`
                    : `<div class="vcard__placeholder">🚗</div>`}</a>
        <div class="vcard__body">
          <h3 class="vcard__title"><a href="/vehicules/${R.esc(v.slug)}">${R.esc(v.brand)} ${R.esc(v.model)}</a></h3>
          <div class="vcard__foot">
            <div class="vcard__price"><strong>${R.money(v.daily_price)}</strong><span>/ jour</span></div>
            <button class="btn btn--ghost btn--sm" data-unfav="${v.id}">Retirer</button>
          </div></div></article>`).join("")}</div>`
      : R.emptyState("♥", "Aucun véhicule sauvegardé",
          "Cliquez sur le cœur d'une fiche véhicule pour la retrouver ici.",
          ["Explorer les véhicules", "/vehicules"]);
    box.querySelectorAll("[data-unfav]").forEach(btn => {
      btn.onclick = async () => {
        await R.api("/api/v1/favourites", { method: "POST", body: { vehicle_id: Number(btn.dataset.unfav) } });
        favourites();
      };
    });
  }

  async function payments() {
    box.innerHTML = R.skeleton(3);
    const items = await R.api("/api/v1/payments");
    box.innerHTML = items.length
      ? table(["Référence","Moyen","Type","Montant","Statut","Date"], items.map(p => `
          <tr><td data-label="Référence"><a href="/reservation/${p.booking_id}">${R.esc(p.reference)}</a></td>
            <td data-label="Moyen">${R.esc((R.STATUS[p.provider_code] || [p.provider_code])[0])}</td>
            <td data-label="Type">${p.kind === "deposit" ? "Caution" : "Paiement"}</td>
            <td data-label="Montant">${R.money(p.amount)}</td>
            <td data-label="Statut">${R.pill(p.status)}</td>
            <td data-label="Date">${R.shortDate(p.created_at)}</td></tr>`).join(""))
      : R.emptyState("₪", "Aucun paiement enregistré",
          "Vos paiements et cautions apparaîtront ici.");
  }

  async function notifications() {
    box.innerHTML = R.skeleton(3);
    const data = await R.api("/api/v1/notifications");
    box.innerHTML = `
      ${data.unread ? `<div class="actionsrow"><span></span>
        <button class="btn btn--ghost btn--sm" data-readall>Tout marquer comme lu</button></div>` : ""}
      <div class="card card--flush">${data.items.length ? data.items.map(n => `
        <div class="filerow" style="border:0;border-bottom:1px solid var(--line);
             ${n.read_at ? "" : "background:var(--brand-soft)"}">
          <span><strong>${R.esc(n.title)}</strong><br><small class="muted">${R.esc(n.body)}</small></span>
          <small class="muted">${R.humanDate(n.created_at, true)}</small>
        </div>`).join("") : R.emptyState("🔔", "Aucune notification")}</div>`;
    const btn = box.querySelector("[data-readall]");
    if (btn) btn.onclick = async () => {
      await R.api("/api/v1/notifications/read", { method: "POST", body: {} });
      notifications();
    };
  }

  async function support() {
    box.innerHTML = R.skeleton(3);
    const tickets = await R.api("/api/v1/support/tickets");
    const cats = [["question","Question"],["booking_problem","Problème de réservation"],
                  ["payment_problem","Problème de paiement"],["vehicle_problem","Problème de véhicule"],
                  ["refund_request","Demande de remboursement"],["complaint","Réclamation"],["other","Autre"]];
    box.innerHTML = `
      <div class="card"><h2>Nouveau ticket</h2>
        <form class="form" data-ticket>
          <div class="field"><label for="category">Catégorie</label>
            <select id="category" name="category">${cats.map(([k, l]) =>
              `<option value="${k}">${l}</option>`).join("")}</select></div>
          <div class="field"><label for="subject">Objet</label>
            <input id="subject" name="subject" required minlength="4" maxlength="160"></div>
          <div class="field"><label for="message">Message</label>
            <textarea id="message" name="message" rows="5" required minlength="10"></textarea></div>
          <p class="form__error" data-formerror hidden></p>
          <button class="btn btn--primary" type="submit">Envoyer</button>
        </form></div>
      <div class="card"><h2>Mes tickets</h2>${tickets.length
        ? table(["Référence","Objet","Catégorie","Statut","Mise à jour"], tickets.map(t => `
            <tr><td data-label="Référence">${R.esc(t.reference)}</td>
              <td data-label="Objet">${R.esc(t.subject)}</td>
              <td data-label="Catégorie">${R.esc((cats.find(c => c[0] === t.category) || [,t.category])[1])}</td>
              <td data-label="Statut">${R.pill(t.status)}</td>
              <td data-label="Mise à jour">${R.shortDate(t.updated_at)}</td></tr>`).join(""))
        : R.emptyState("💬", "Aucun ticket de support")}</div>`;
    const form = box.querySelector("[data-ticket]");
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(form);
      const btn = form.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        await R.api("/api/v1/support/tickets", { method: "POST", body: R.formData(form) });
        R.toast("Ticket créé. Notre équipe vous répondra.", "ok");
        support();
      } catch (e) { R.formError(form, e.message); }
      finally { R.busy(btn, false); }
    };
  }

  async function profile() {
    box.innerHTML = R.skeleton(3);
    const [me, wilayas] = await Promise.all([R.api("/api/v1/profile"), R.api("/api/v1/wilayas")]);
    const p = me.profile || {};
    box.innerHTML = `
      <div class="card"><h2>Informations personnelles</h2>
        <form class="form" data-profile>
          <div class="formgrid">
            <div class="field"><label for="full_name">Nom complet</label>
              <input id="full_name" name="full_name" value="${R.esc(me.full_name)}" required>
              <p class="field__error" data-error-for="full_name" hidden></p></div>
            <div class="field"><label for="email">E-mail</label>
              <input id="email" name="email" type="email" value="${R.esc(me.email)}" required>
              <p class="field__hint">${me.email_verified_at ? "Adresse confirmée ✓"
                : "Adresse non confirmée"}</p>
              <p class="field__error" data-error-for="email" hidden></p></div>
            <div class="field"><label for="phone">Téléphone</label>
              <input id="phone" name="phone" value="${R.esc(me.phone || "")}" placeholder="0555 12 34 56">
              <p class="field__error" data-error-for="phone" hidden></p></div>
            <div class="field"><label for="date_of_birth">Date de naissance</label>
              <input id="date_of_birth" name="date_of_birth" type="date" value="${R.esc(p.date_of_birth || "")}"></div>
            <div class="field"><label for="wilaya_id">Wilaya</label>
              <select id="wilaya_id" name="wilaya_id"><option value="">—</option>
                ${wilayas.map(w => `<option value="${w.id}"${p.wilaya_id === w.id ? " selected" : ""}>
                  ${R.esc(w.name_fr)}</option>`).join("")}</select></div>
            <div class="field"><label for="address">Adresse</label>
              <input id="address" name="address" value="${R.esc(p.address || "")}"></div>
            <div class="field"><label for="license_number">N° de permis</label>
              <input id="license_number" name="license_number" value="${R.esc(p.license_number || "")}"></div>
            <div class="field"><label for="license_expires_at">Expiration du permis</label>
              <input id="license_expires_at" name="license_expires_at" type="date"
                value="${R.esc(p.license_expires_at || "")}"></div>
            <div class="field"><label for="locale">Langue</label>
              <select id="locale" name="locale">
                ${[["fr","Français"],["ar","العربية"],["en","English"]].map(([k, l]) =>
                  `<option value="${k}"${me.locale === k ? " selected" : ""}>${l}</option>`).join("")}
              </select></div>
          </div>
          <p class="form__error" data-formerror hidden></p>
          <p class="form__ok" data-formok hidden></p>
          <button class="btn btn--primary" type="submit">Enregistrer</button>
        </form></div>
      <div class="card"><h2>Mot de passe</h2>
        <form class="form" data-password>
          <div class="formgrid">
            <div class="field"><label for="current_password">Mot de passe actuel</label>
              <input id="current_password" name="current_password" type="password" required>
              <p class="field__error" data-error-for="current_password" hidden></p></div>
            <div class="field"><label for="password">Nouveau mot de passe</label>
              <input id="password" name="password" type="password" required minlength="10">
              <p class="field__hint">10 caractères minimum, lettres et chiffres.</p>
              <p class="field__error" data-error-for="password" hidden></p></div>
          </div>
          <p class="form__error" data-formerror hidden></p>
          <button class="btn btn--ghost" type="submit">Modifier le mot de passe</button>
        </form></div>`;

    const pform = box.querySelector("[data-profile]");
    pform.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(pform);
      const btn = pform.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        await R.api("/api/v1/profile", { method: "POST", body: R.formData(pform) });
        const ok = pform.querySelector("[data-formok]");
        ok.textContent = "Profil mis à jour.";
        ok.hidden = false;
        R.toast("Profil enregistré.", "ok");
      } catch (e) {
        if (e.fields) R.fieldErrors(pform, e.fields);
        R.formError(pform, e.message);
      } finally { R.busy(btn, false); }
    };
    const wform = box.querySelector("[data-password]");
    wform.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(wform);
      const btn = wform.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        await R.api("/api/v1/auth/password/change", { method: "POST", body: R.formData(wform) });
        R.toast("Mot de passe modifié. Reconnectez-vous.", "ok");
        setTimeout(() => location.href = "/connexion", 1200);
      } catch (e) {
        if (e.fields) R.fieldErrors(wform, e.fields);
        R.formError(wform, e.message);
      } finally { R.busy(btn, false); }
    };
  }
});
