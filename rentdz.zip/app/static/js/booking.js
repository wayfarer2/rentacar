/* Single booking view: details, documents, payment, cancellation, agreement. */
document.addEventListener("DOMContentLoaded", async () => {
  const R = window.RENTDZ;
  const root = document.querySelector("[data-booking]");
  if (!root) return;
  const id = root.dataset.booking;
  const justCreated = new URLSearchParams(location.search).get("created") === "1";

  async function load() {
    root.innerHTML = R.skeleton(5);
    try {
      const b = await R.api(`/api/v1/bookings/${id}`);
      render(b);
    } catch (e) {
      root.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>
        <a class="btn btn--ghost" href="/mon-espace/reservations">Mes réservations</a>`;
    }
  }

  function priceBlock(b) {
    const q = b.breakdown || {};
    const l = q.lines || {};
    const row = (k, v, cls = "") =>
      `<div class="quote__row ${cls}"><span>${R.esc(k)}</span><span>${v}</span></div>`;
    let html = "";
    (l.base || []).forEach(x => html += row(x.label, R.money(x.amount)));
    (l.adjustments || []).forEach(x => html += row(x.label, R.money(x.amount)));
    (l.services || []).forEach(x => html += row(x.label, R.money(x.amount)));
    (l.fees || []).forEach(x => html += row(x.label, R.money(x.amount)));
    (l.discounts || []).forEach(x => html += row(x.label, R.money(x.amount), "quote__row--discount"));
    (l.taxes || []).forEach(x => html += row(x.label, R.money(x.amount)));
    html += row("Total", R.money(b.total_amount), "quote__row--total");
    html += row("Caution", R.money(b.deposit_amount), "quote__row--muted");
    if (b.paid_amount) html += row("Déjà payé", R.money(b.paid_amount), "quote__row--muted");
    if (b.refund_amount) html += row("Remboursé", R.money(b.refund_amount), "quote__row--muted");
    return `<div class="quote">${html}</div>`;
  }

  function render(b) {
    const created = justCreated
      ? `<div class="banner banner--ok"><div><strong>Réservation enregistrée.</strong>
          Référence <strong>${R.esc(b.reference)}</strong>. Le loueur va confirmer votre demande.
          ${b.status === "pending" ? "Téléversez votre permis pour accélérer la validation." : ""}</div></div>`
      : "";
    const services = (b.services || []).map(s =>
      `<li>${R.esc(s.name_snapshot)} ${s.qty > 1 ? `×${s.qty}` : ""} — ${R.money(s.amount)}</li>`).join("");
    const history = (b.history || []).map(h => `
      <div class="timeline__item">
        <div><strong>${R.esc((R.STATUS[h.to_status] || [h.to_status])[0])}</strong></div>
        <div class="timeline__meta">${R.humanDate(h.created_at, true)}
          ${h.actor ? "· " + R.esc(h.actor) : ""}${h.reason ? " · " + R.esc(h.reason) : ""}</div>
      </div>`).join("");
    const payments = (b.payments || []).map(p => `
      <tr>
        <td data-label="Moyen">${R.esc((R.STATUS[p.provider_code] || [p.provider_code])[0])}</td>
        <td data-label="Type">${p.kind === "deposit" ? "Caution" : p.kind === "full" ? "Paiement total" : "Solde"}</td>
        <td data-label="Montant">${R.money(p.amount)}</td>
        <td data-label="Statut">${R.pill(p.status)}</td>
        <td data-label="Date">${R.shortDate(p.created_at)}</td>
      </tr>`).join("");

    root.innerHTML = `
      ${created}
      <div class="card">
        <div class="appmain__head" style="margin:0">
          <div>
            <p class="muted">Réservation ${R.esc(b.reference)}</p>
            <h1>${R.esc(b.brand)} ${R.esc(b.model)} ${b.year}</h1>
            <p class="muted">${R.esc(b.company_name)}</p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            ${R.pill(b.status)} ${R.pill(b.payment_status)}
          </div>
        </div>
        <dl class="kv" style="margin-block-start:20px">
          <div class="kv__item"><dt>Départ</dt><dd>${R.humanDate(b.pickup_at, true)}</dd></div>
          <div class="kv__item"><dt>Retour</dt><dd>${R.humanDate(b.return_at, true)}</dd></div>
          <div class="kv__item"><dt>Durée</dt><dd>${b.days} jour(s)</dd></div>
          <div class="kv__item"><dt>Prise en charge</dt><dd>${R.esc(b.pickup_location || "À convenir")}</dd></div>
          ${["confirmed","active","completed"].includes(b.status)
            ? `<div class="kv__item"><dt>Contact agence</dt><dd>${R.esc(b.company_phone || "-")}</dd></div>` : ""}
        </dl>
        ${services ? `<h2 style="margin-block:20px 8px">Options</h2><ul class="list">${services}</ul>` : ""}
      </div>

      <div class="card"><h2>Détail du prix</h2>${priceBlock(b)}</div>

      <div class="card">
        <h2>Mon permis de conduire</h2>
        <p class="muted" style="margin-block-end:14px">Document privé : seuls vous, l'agence et notre
          équipe de vérification pouvez y accéder, via un lien temporaire.</p>
        <div data-docs>${R.skeleton(2)}</div>
        <label class="uploadzone" style="margin-block-start:14px">
          <input type="file" name="file" accept="image/jpeg,image/png,image/webp,application/pdf" hidden data-docinput>
          <strong>Téléverser mon permis</strong>
          <p class="muted">JPEG, PNG, WEBP ou PDF · 8 Mo maximum</p>
        </label>
      </div>

      ${payments ? `<div class="card"><h2>Paiements</h2><div class="tablewrap"><table class="table">
        <thead><tr><th>Moyen</th><th>Type</th><th>Montant</th><th>Statut</th><th>Date</th></tr></thead>
        <tbody>${payments}</tbody></table></div></div>` : ""}

      <div class="card"><h2>Historique</h2><div class="timeline">${history}</div></div>

      <div class="actionsrow">
        <a class="btn btn--ghost" href="/mon-espace/reservations">← Mes réservations</a>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          ${["confirmed","active","completed"].includes(b.status)
            ? `<button class="btn btn--ghost" data-agreement>Contrat de location</button>` : ""}
          ${b.can_cancel ? `<button class="btn btn--danger" data-cancel>Annuler la réservation</button>` : ""}
        </div>
      </div>`;

    loadDocs();
    const cancelBtn = root.querySelector("[data-cancel]");
    if (cancelBtn) cancelBtn.onclick = () => cancelFlow(b);
    const agr = root.querySelector("[data-agreement]");
    if (agr) agr.onclick = () => showAgreement(b);
    const input = root.querySelector("[data-docinput]");
    if (input) input.onchange = () => uploadDoc(input, b.id);
  }

  async function loadDocs() {
    const box = root.querySelector("[data-docs]");
    if (!box) return;
    try {
      const docs = await R.api("/api/v1/documents");
      const licences = docs.filter(d => d.kind === "driver_license");
      box.innerHTML = licences.length ? licences.map(d => `
        <div class="filerow">
          <span>${R.esc(d.original_name)} <small class="muted">${Math.round(d.size_bytes/1024)} Ko</small></span>
          <span style="display:flex;gap:8px;align-items:center">
            ${R.pill(d.status)}
            <a class="btn btn--ghost btn--sm" href="${R.esc(d.download_url)}">Voir</a>
          </span>
        </div>
        ${d.status === "rejected" && d.reject_reason
          ? `<p class="field__error">Motif du refus : ${R.esc(d.reject_reason)}</p>` : ""}`).join("")
        : R.emptyState("📄", "Aucun document téléversé", "Ajoutez la photo de votre permis de conduire.");
    } catch (e) { box.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>`; }
  }

  async function uploadDoc(input, bookingId) {
    const file = input.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    fd.append("kind", "driver_license");
    fd.append("booking_id", bookingId);
    try {
      await R.api("/api/v1/documents", { method: "POST", body: fd });
      R.toast("Document téléversé. En attente de vérification.", "ok");
      loadDocs();
    } catch (e) {
      R.toast(e.fields ? Object.values(e.fields)[0] : e.message, "bad");
    } finally { input.value = ""; }
  }

  async function cancelFlow(b) {
    let preview;
    try { preview = await R.api(`/api/v1/bookings/${b.id}/cancellation-preview`); }
    catch (e) { return R.toast(e.message, "bad"); }
    R.modal({
      title: "Annuler cette réservation ?",
      danger: true, confirmLabel: "Confirmer l'annulation", cancelLabel: "Garder ma réservation",
      body: `
        <p>${R.esc(preview.policy_label)}</p>
        <div class="quote" style="margin-block:12px">
          <div class="quote__row"><span>Déjà payé</span><span>${R.money(preview.paid_amount)}</span></div>
          <div class="quote__row"><span>Remboursement</span><span>${preview.refund_percent}%</span></div>
          <div class="quote__row quote__row--total"><span>Montant remboursé</span>
            <span>${R.money(preview.refund_amount)}</span></div>
        </div>
        <div class="field"><label for="reason">Motif (optionnel)</label>
          <input id="reason" name="reason" maxlength="300"></div>`,
      onConfirm: async (box) => {
        const reason = box.querySelector("#reason").value;
        await R.api(`/api/v1/bookings/${b.id}/cancel`, { method: "POST", body: { reason } });
        R.toast("Réservation annulée.", "ok");
        load();
      },
    });
  }

  async function showAgreement(b) {
    try {
      const a = await R.api(`/api/v1/bookings/${b.id}/agreement`);
      const w = window.open("", "_blank");
      if (!w) return R.toast("Autorisez les fenêtres pop-up pour afficher le contrat.", "warn");
      w.document.write(`<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
        <title>Contrat ${R.esc(a.booking.reference)}</title>
        <style>body{font-family:system-ui,sans-serif;max-width:820px;margin:32px auto;padding:0 20px;
          color:#16202f;line-height:1.6} h1{letter-spacing:-.02em} h2{font-size:1.05rem;margin-top:26px;
          border-bottom:1px solid #ddd;padding-bottom:6px} table{width:100%;border-collapse:collapse;
          font-size:.9rem} td{padding:6px 0;vertical-align:top} .sig{display:flex;gap:40px;margin-top:48px}
          .sig div{flex:1;border-top:1px solid #333;padding-top:8px;font-size:.85rem}
          @media print{button{display:none}}</style></head><body>
        <button onclick="window.print()" style="padding:10px 16px;margin-block-end:20px">Imprimer / PDF</button>
        <h1>Contrat de location de véhicule</h1>
        <p><strong>Référence :</strong> ${R.esc(a.booking.reference)}</p>
        <p>${R.esc(a.clauses.intro)}</p>
        <h2>Le loueur</h2><table>
          <tr><td>Société</td><td>${R.esc(a.company.name)}</td></tr>
          <tr><td>RC / NIF</td><td>${R.esc(a.company.rc_number || "-")} / ${R.esc(a.company.nif || "-")}</td></tr>
          <tr><td>Téléphone</td><td>${R.esc(a.company.phone)}</td></tr>
          <tr><td>Adresse</td><td>${R.esc(a.company.address || "-")}</td></tr></table>
        <h2>Le locataire</h2><table>
          <tr><td>Nom</td><td>${R.esc(a.customer.full_name)}</td></tr>
          <tr><td>Téléphone</td><td>${R.esc(a.customer.phone || "-")}</td></tr>
          <tr><td>Permis n°</td><td>${R.esc(a.customer.licence || "-")}</td></tr>
          <tr><td>Adresse</td><td>${R.esc(a.customer.address || "-")}</td></tr></table>
        <h2>Le véhicule</h2><table>
          <tr><td>Véhicule</td><td>${R.esc(a.vehicle.brand)} ${R.esc(a.vehicle.model)} (${a.vehicle.year})</td></tr>
          <tr><td>Immatriculation</td><td>${R.esc(a.vehicle.registration_number || "-")}</td></tr>
          <tr><td>Couleur / Places</td><td>${R.esc(a.vehicle.color || "-")} / ${a.vehicle.seats}</td></tr>
          <tr><td>Kilométrage au départ</td><td>${a.vehicle.mileage} km</td></tr></table>
        <h2>Location</h2><table>
          <tr><td>Départ</td><td>${R.esc(a.booking.pickup_at)} — ${R.esc(a.booking.pickup_location || "-")}</td></tr>
          <tr><td>Retour</td><td>${R.esc(a.booking.return_at)} — ${R.esc(a.booking.dropoff_location || "-")}</td></tr>
          <tr><td>Durée</td><td>${a.booking.days} jour(s)</td></tr>
          <tr><td>Montant total</td><td>${R.money(a.booking.total_amount)}</td></tr>
          <tr><td>Caution</td><td>${R.money(a.booking.deposit_amount)}</td></tr></table>
        <h2>Conditions</h2>
        <p><strong>Kilométrage :</strong> ${R.esc(a.clauses.mileage)}</p>
        <p><strong>Carburant :</strong> ${R.esc(a.clauses.fuel)}</p>
        <p><strong>Dommages :</strong> ${R.esc(a.clauses.damage)}</p>
        <p><strong>Annulation :</strong> ${(a.clauses.cancellation || []).map(c => R.esc(c.label)).join(" · ")}</p>
        <div class="sig"><div>Signature du locataire</div><div>Signature et cachet du loueur</div></div>
        </body></html>`);
      w.document.close();
    } catch (e) { R.toast(e.message, "bad"); }
  }

  await R.session();
  load();
});
