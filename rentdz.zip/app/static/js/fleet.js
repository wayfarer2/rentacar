/* Fleet owner portal: dashboard, vehicles, calendar, bookings, today, revenue, company. */
document.addEventListener("DOMContentLoaded", async () => {
  const R = window.RENTDZ;
  const box = document.querySelector("[data-app]");
  if (!box) return;
  const path = location.pathname.replace(/\/$/, "");
  await R.session();
  if (!R.user) { location.href = "/connexion?next=" + encodeURIComponent(path); return; }

  const CATS = [["economy","Économique"],["compact","Compacte"],["sedan","Berline"],["suv","SUV"],
                ["luxury","Luxe"],["family","Familiale"],["van","Utilitaire / Van"],["4x4","4x4"]];
  const FUELS = [["petrol","Essence"],["diesel","Diesel"],["hybrid","Hybride"],
                 ["electric","Électrique"],["gpl","GPL"]];
  let company = null, features = [];

  function table(headers, rows) {
    return `<div class="tablewrap"><table class="table">
      <thead><tr>${headers.map(h => `<th>${R.esc(h)}</th>`).join("")}</tr></thead>
      <tbody>${rows}</tbody></table></div>`;
  }

  try {
    company = await R.api("/api/v1/companies/mine");
  } catch (e) { /* handled below */ }

  if (!company) return onboarding();
  if (company.status !== "approved" && path !== "/loueur/societe") {
    box.innerHTML = `<div class="banner banner--warn">
        <div><strong>Votre société est ${company.status === "pending" ? "en cours de validation"
          : "actuellement " + ((R.STATUS[company.status] || [company.status])[0]).toLowerCase()}.</strong><br>
        ${company.status === "pending"
          ? "Notre équipe vérifie vos informations. Vous pourrez publier vos véhicules dès validation."
          : R.esc(company.reject_reason || "Contactez le support pour plus d'informations.")}</div></div>
      <a class="btn btn--ghost" href="/loueur/societe">Voir ma société</a>`;
    if (company.status !== "pending") return;
  }

  const views = {
    "/loueur": dashboard, "/loueur/vehicules": vehicles, "/loueur/calendrier": calendar,
    "/loueur/reservations": bookings, "/loueur/aujourdhui": today,
    "/loueur/revenus": revenue, "/loueur/societe": companyView,
  };
  try { await (views[path] || dashboard)(); }
  catch (e) { box.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>`; }

  async function onboarding() {
    const wilayas = await R.api("/api/v1/wilayas");
    box.innerHTML = `
      <div class="banner banner--info">Créez votre fiche société pour commencer à publier des véhicules.
        Notre équipe la validera avant publication.</div>
      <div class="card"><h2>Ma société de location</h2>
        <form class="form" data-company>
          <div class="formgrid">
            <div class="field"><label for="name">Nom commercial</label>
              <input id="name" name="name" required minlength="2">
              <p class="field__error" data-error-for="name" hidden></p></div>
            <div class="field"><label for="legal_name">Raison sociale</label>
              <input id="legal_name" name="legal_name"></div>
            <div class="field"><label for="rc_number">N° Registre de Commerce</label>
              <input id="rc_number" name="rc_number"></div>
            <div class="field"><label for="nif">NIF</label><input id="nif" name="nif"></div>
            <div class="field"><label for="phone">Téléphone</label>
              <input id="phone" name="phone" required placeholder="0555 12 34 56">
              <p class="field__error" data-error-for="phone" hidden></p></div>
            <div class="field"><label for="email">E-mail de contact</label>
              <input id="email" name="email" type="email">
              <p class="field__error" data-error-for="email" hidden></p></div>
            <div class="field"><label for="wilaya_id">Wilaya</label>
              <select id="wilaya_id" name="wilaya_id" required><option value="">Choisir…</option>
                ${wilayas.map(w => `<option value="${w.id}">${R.esc(w.name_fr)}</option>`).join("")}
              </select></div>
            <div class="field"><label for="address">Adresse</label><input id="address" name="address"></div>
          </div>
          <div class="field"><label for="description">Présentation</label>
            <textarea id="description" name="description" rows="4" maxlength="2000"></textarea></div>
          <p class="form__error" data-formerror hidden></p>
          <button class="btn btn--primary btn--lg" type="submit">Enregistrer ma société</button>
        </form></div>`;
    const form = box.querySelector("[data-company]");
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(form);
      const btn = form.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        const body = R.formData(form);
        body.wilaya_id = Number(body.wilaya_id);
        await R.api("/api/v1/companies", { method: "POST", body });
        R.toast("Société enregistrée. En attente de validation.", "ok");
        location.href = "/loueur";
      } catch (e) {
        if (e.fields) R.fieldErrors(form, e.fields);
        R.formError(form, e.message);
      } finally { R.busy(btn, false); }
    };
  }

  async function dashboard() {
    box.innerHTML = R.skeleton(4);
    const [data, todayData] = await Promise.all([
      R.api("/api/v1/fleet/dashboard"), R.api("/api/v1/fleet/today"),
    ]);
    const m = data.metrics;
    box.innerHTML = `
      ${m.vehicles_pending_approval ? `<div class="banner banner--info">
        ${m.vehicles_pending_approval} véhicule(s) en attente de validation par la plateforme.</div>` : ""}
      ${m.bookings_pending ? `<div class="banner banner--warn">
        ${m.bookings_pending} réservation(s) attendent votre confirmation.
        <a class="link" href="/loueur/reservations">Traiter maintenant</a></div>` : ""}
      <div class="grid grid--stats">
        <div class="stat stat--accent"><div class="stat__label">Revenu du mois</div>
          <div class="stat__value">${R.money(m.revenue_month)}</div>
          <div class="stat__hint">net de commission plateforme</div></div>
        <div class="stat"><div class="stat__label">Véhicules</div>
          <div class="stat__value">${m.vehicles_total}</div>
          <div class="stat__hint">${m.vehicles_available} disponibles · ${m.vehicles_rented} loués</div></div>
        <div class="stat"><div class="stat__label">Réservations à venir</div>
          <div class="stat__value">${m.bookings_upcoming}</div>
          <div class="stat__hint">${m.bookings_active} en cours</div></div>
        <div class="stat"><div class="stat__label">Aujourd'hui</div>
          <div class="stat__value">${m.pickups_today} / ${m.returns_today}</div>
          <div class="stat__hint">départs / retours</div></div>
      </div>
      <div class="grid grid--2">
        <div class="card"><h2>Départs du jour</h2>${todayData.pickups.length
          ? `<ul class="list">${todayData.pickups.map(p => `<li>
              <strong>${R.esc(p.reference)}</strong> · ${R.esc(p.brand)} ${R.esc(p.model)}<br>
              <small class="muted">${String(p.pickup_at).slice(11,16)} · ${R.esc(p.customer)} · ${R.esc(p.phone || "")}</small>
            </li>`).join("")}</ul>`
          : R.emptyState("🔑", "Aucun départ aujourd'hui")}</div>
        <div class="card"><h2>Retours du jour</h2>${todayData.returns.length
          ? `<ul class="list">${todayData.returns.map(p => `<li>
              <strong>${R.esc(p.reference)}</strong> · ${R.esc(p.brand)} ${R.esc(p.model)}<br>
              <small class="muted">${String(p.return_at).slice(11,16)} · ${R.esc(p.customer)}</small>
            </li>`).join("")}</ul>`
          : R.emptyState("↩", "Aucun retour aujourd'hui")}</div>
      </div>
      <div class="grid grid--stats">
        <div class="stat"><div class="stat__label">Maintenance</div>
          <div class="stat__value">${m.vehicles_maintenance}</div></div>
        <div class="stat"><div class="stat__label">Documents à vérifier</div>
          <div class="stat__value">${m.pending_documents}</div></div>
        <div class="stat"><div class="stat__label">Note moyenne</div>
          <div class="stat__value">${m.rating ? m.rating.toFixed(1) + " ★" : "—"}</div></div>
        <div class="stat"><div class="stat__label">Revenu total</div>
          <div class="stat__value">${R.money(m.revenue_total)}</div></div>
      </div>`;
  }

  async function vehicles() {
    box.innerHTML = R.skeleton(3);
    const [fleet, feats] = await Promise.all([
      R.api("/api/v1/fleet/vehicles?limit=100"), R.api("/api/v1/features"),
    ]);
    features = feats;
    document.querySelector("[data-head-actions]").innerHTML =
      `<button class="btn btn--primary" data-newvehicle>+ Ajouter un véhicule</button>`;
    document.querySelector("[data-newvehicle]").onclick = () => vehicleForm(null);
    box.innerHTML = fleet.items.length
      ? table(["Véhicule","Catégorie","Prix/jour","État","Validation","Réservations","Actions"],
          fleet.items.map(v => `<tr>
            <td data-label="Véhicule">${R.esc(v.brand)} ${R.esc(v.model)} <small class="muted">${v.year}</small></td>
            <td data-label="Catégorie">${R.esc((CATS.find(c => c[0] === v.category) || [,v.category])[1])}</td>
            <td data-label="Prix/jour">${R.money(v.daily_price)}</td>
            <td data-label="État">${R.pill(v.status)}</td>
            <td data-label="Validation">${R.pill(v.approval_status)}</td>
            <td data-label="Réservations">${v.active_bookings} en cours</td>
            <td data-label="Actions" class="table__actions">
              <button class="btn btn--ghost btn--sm" data-edit="${v.id}">Modifier</button>
              <button class="btn btn--ghost btn--sm" data-photos="${v.id}">Photos</button>
              <a class="btn btn--ghost btn--sm" href="/loueur/calendrier?vehicle=${v.id}">Calendrier</a>
              <button class="btn btn--danger btn--sm" data-del="${v.id}">Retirer</button>
            </td></tr>`).join(""))
      : R.emptyState("🚗", "Aucun véhicule ajouté", "Publiez votre premier véhicule pour recevoir des réservations.");
    box.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => vehicleForm(Number(b.dataset.edit)));
    box.querySelectorAll("[data-photos]").forEach(b => b.onclick = () => photoManager(Number(b.dataset.photos)));
    box.querySelectorAll("[data-del]").forEach(b => b.onclick = () =>
      R.confirmAction("Retirer ce véhicule ?",
        "Il ne sera plus visible des clients. Les réservations passées sont conservées.",
        async () => {
          await R.api(`/api/v1/fleet/vehicles/${b.dataset.del}`, { method: "DELETE" });
          R.toast("Véhicule retiré.", "ok"); vehicles();
        }, { danger: true, confirmLabel: "Retirer" }));
  }

  async function vehicleForm(id) {
    let v = {};
    const locations = await R.api("/api/v1/fleet/locations");
    if (id) v = await R.api(`/api/v1/fleet/vehicles/${id}`);
    const sel = (val, target) => val === target ? " selected" : "";
    R.modal({
      title: id ? "Modifier le véhicule" : "Nouveau véhicule",
      confirmLabel: id ? "Enregistrer" : "Créer le véhicule",
      body: `<form class="form" data-vform>
        <div class="formgrid">
          <div class="field"><label for="brand">Marque</label>
            <input id="brand" name="brand" required value="${R.esc(v.brand || "")}">
            <p class="field__error" data-error-for="brand" hidden></p></div>
          <div class="field"><label for="model">Modèle</label>
            <input id="model" name="model" required value="${R.esc(v.model || "")}">
            <p class="field__error" data-error-for="model" hidden></p></div>
          <div class="field"><label for="year">Année</label>
            <input id="year" name="year" type="number" min="1990" max="${new Date().getFullYear() + 1}"
              required value="${v.year || new Date().getFullYear()}">
            <p class="field__error" data-error-for="year" hidden></p></div>
          <div class="field"><label for="category">Catégorie</label>
            <select id="category" name="category">${CATS.map(([k, l]) =>
              `<option value="${k}"${sel(v.category, k)}>${l}</option>`).join("")}</select></div>
          <div class="field"><label for="transmission">Boîte</label>
            <select id="transmission" name="transmission">
              <option value="manual"${sel(v.transmission,"manual")}>Manuelle</option>
              <option value="automatic"${sel(v.transmission,"automatic")}>Automatique</option>
            </select></div>
          <div class="field"><label for="fuel">Carburant</label>
            <select id="fuel" name="fuel">${FUELS.map(([k, l]) =>
              `<option value="${k}"${sel(v.fuel, k)}>${l}</option>`).join("")}</select></div>
          <div class="field"><label for="seats">Places</label>
            <input id="seats" name="seats" type="number" min="1" max="20" required value="${v.seats || 5}">
            <p class="field__error" data-error-for="seats" hidden></p></div>
          <div class="field"><label for="doors">Portes</label>
            <input id="doors" name="doors" type="number" min="2" max="6" value="${v.doors || 5}"></div>
          <div class="field"><label for="color">Couleur</label>
            <input id="color" name="color" value="${R.esc(v.color || "")}"></div>
          <div class="field"><label for="mileage">Kilométrage</label>
            <input id="mileage" name="mileage" type="number" min="0" value="${v.mileage || 0}"></div>
          <div class="field"><label for="registration_number">Immatriculation</label>
            <input id="registration_number" name="registration_number" value="${R.esc(v.registration_number || "")}">
            <p class="field__hint">Jamais affichée publiquement.</p></div>
          <div class="field"><label for="daily_price">Prix / jour (DA)</label>
            <input id="daily_price" name="daily_price" type="number" min="500" required value="${v.daily_price || ""}">
            <p class="field__error" data-error-for="daily_price" hidden></p></div>
          <div class="field"><label for="weekly_price">Prix / semaine (DA)</label>
            <input id="weekly_price" name="weekly_price" type="number" min="0" value="${v.weekly_price || ""}"></div>
          <div class="field"><label for="monthly_price">Prix / mois (DA)</label>
            <input id="monthly_price" name="monthly_price" type="number" min="0" value="${v.monthly_price || ""}"></div>
          <div class="field"><label for="weekend_price">Tarif week-end / jour</label>
            <input id="weekend_price" name="weekend_price" type="number" min="0" value="${v.weekend_price || ""}"></div>
          <div class="field"><label for="deposit">Caution (DA)</label>
            <input id="deposit" name="deposit" type="number" min="0" value="${v.deposit || 0}"></div>
          <div class="field"><label for="min_days">Durée min. (jours)</label>
            <input id="min_days" name="min_days" type="number" min="1" max="90" value="${v.min_days || 1}"></div>
          <div class="field"><label for="max_days">Durée max. (jours)</label>
            <input id="max_days" name="max_days" type="number" min="1" max="365" value="${v.max_days || 90}"></div>
          <div class="field"><label for="km_included_per_day">Km inclus / jour</label>
            <input id="km_included_per_day" name="km_included_per_day" type="number" min="0"
              value="${v.km_included_per_day || ""}">
            <p class="field__hint">Vide = illimité</p></div>
          <div class="field"><label for="extra_km_price">Prix km supp. (DA)</label>
            <input id="extra_km_price" name="extra_km_price" type="number" min="0" value="${v.extra_km_price || 0}"></div>
          <div class="field"><label for="primary_location_id">Agence de retrait</label>
            <select id="primary_location_id" name="primary_location_id"><option value="">—</option>
              ${locations.map(l => `<option value="${l.id}"${sel(v.primary_location_id, l.id)}>
                ${R.esc(l.name_fr)}</option>`).join("")}</select></div>
          ${id ? `<div class="field"><label for="status">État</label>
            <select id="status" name="status">
              ${[["available","Disponible"],["maintenance","Maintenance"],
                 ["unavailable","Indisponible"],["inactive","Inactif"]].map(x =>
                 `<option value="${x[0]}"${sel(v.status, x[0])}>${x[1]}</option>`).join("")}
            </select></div>` : ""}
        </div>
        <div class="field"><label for="description">Description</label>
          <textarea id="description" name="description" rows="3" maxlength="3000">${R.esc(v.description || "")}</textarea></div>
        <fieldset class="field"><legend>Équipements</legend>
          <div style="display:flex;flex-wrap:wrap;gap:6px">${features.map(f => `
            <label class="check" style="flex:0 0 auto;padding-inline-end:10px">
              <input type="checkbox" name="features" value="${f.code}"
                ${(v.features || []).includes(f.code) ? "checked" : ""}>
              <span>${R.esc(f.name_fr)}</span></label>`).join("")}</div></fieldset>
        <p class="form__error" data-formerror hidden></p>
      </form>`,
      onConfirm: async (root) => {
        const form = root.querySelector("[data-vform]");
        R.clearErrors(form);
        const body = R.formData(form);
        body.features = Array.from(form.querySelectorAll('[name="features"]:checked')).map(e => e.value);
        ["year","seats","doors","mileage","daily_price","weekly_price","monthly_price","weekend_price",
         "deposit","min_days","max_days","km_included_per_day","extra_km_price","primary_location_id"]
          .forEach(k => { if (body[k] === "") delete body[k]; else if (body[k] != null) body[k] = Number(body[k]); });
        try {
          if (id) await R.api(`/api/v1/fleet/vehicles/${id}`, { method: "PUT", body });
          else await R.api("/api/v1/fleet/vehicles", { method: "POST", body });
          R.toast(id ? "Véhicule mis à jour." : "Véhicule créé. En attente de validation.", "ok");
          vehicles();
        } catch (e) {
          if (e.fields) R.fieldErrors(form, e.fields);
          R.formError(form, e.message);
          throw e;
        }
      },
    });
  }

  async function photoManager(id) {
    const v = await R.api(`/api/v1/fleet/vehicles/${id}`);
    const m = R.modal({
      title: `Photos · ${v.brand} ${v.model}`,
      confirmLabel: "Terminé", cancelLabel: "Fermer",
      body: `<div data-photolist>${(v.images || []).map(img => `
          <div class="filerow">
            <span style="display:flex;gap:10px;align-items:center">
              <img src="/media/${R.esc(img.path)}" alt="" width="60" height="42"
                   style="border-radius:6px;object-fit:cover">
              ${img.is_primary ? '<span class="pill pill--ok">Principale</span>' : ""}</span>
            <button class="btn btn--danger btn--sm" data-delphoto="${img.id}">Supprimer</button>
          </div>`).join("") || '<p class="muted">Aucune photo. La première photo ajoutée devient la principale.</p>'}
        </div>
        <label class="uploadzone" style="margin-block-start:14px">
          <input type="file" hidden accept="image/jpeg,image/png,image/webp" data-photoinput>
          <strong>Ajouter une photo</strong>
          <p class="muted">JPEG, PNG ou WEBP · 8 Mo maximum · 12 photos par véhicule</p>
        </label>`,
      onConfirm: () => vehicles(),
    });
    const input = m.root.querySelector("[data-photoinput]");
    input.onchange = async () => {
      if (!input.files[0]) return;
      const fd = new FormData();
      fd.append("photo", input.files[0]);
      try {
        await R.api(`/api/v1/fleet/vehicles/${id}/photos`, { method: "POST", body: fd });
        R.toast("Photo ajoutée.", "ok");
        m.close(); photoManager(id);
      } catch (e) { R.toast(e.fields ? Object.values(e.fields)[0] : e.message, "bad"); }
    };
    m.root.querySelectorAll("[data-delphoto]").forEach(btn => {
      btn.onclick = async () => {
        try {
          await R.api(`/api/v1/fleet/vehicles/${id}/photos/${btn.dataset.delphoto}`, { method: "DELETE" });
          m.close(); photoManager(id);
        } catch (e) { R.toast(e.message, "bad"); }
      };
    });
  }

  async function calendar() {
    const fleet = await R.api("/api/v1/fleet/vehicles?limit=100");
    if (!fleet.items.length) {
      box.innerHTML = R.emptyState("🗓", "Aucun véhicule", "Ajoutez un véhicule pour gérer son calendrier.",
        ["Ajouter un véhicule", "/loueur/vehicules"]);
      return;
    }
    const preselect = Number(new URLSearchParams(location.search).get("vehicle")) || fleet.items[0].id;
    box.innerHTML = `
      <div class="card">
        <div class="actionsrow" style="margin-block-end:16px">
          <label class="sortsel"><span>Véhicule</span>
            <select data-calvehicle>${fleet.items.map(v =>
              `<option value="${v.id}"${v.id === preselect ? " selected" : ""}>
                ${R.esc(v.brand)} ${R.esc(v.model)} (${v.year})</option>`).join("")}</select></label>
          <div style="display:flex;gap:8px">
            <button class="btn btn--ghost btn--sm" data-block="blocked">Bloquer des dates</button>
            <button class="btn btn--ghost btn--sm" data-block="maintenance">Planifier une maintenance</button>
          </div>
        </div>
        <div class="callegend">
          <span><i style="background:var(--info-soft);border:1px solid var(--info)"></i>Réservation</span>
          <span><i style="background:var(--warn-soft);border:1px solid var(--warn)"></i>Maintenance</span>
          <span><i style="background:var(--paper-3);border:1px solid var(--line-2)"></i>Bloqué</span>
          <span><i style="background:var(--paper);border:1px solid var(--line)"></i>Disponible</span>
        </div>
        <div data-calendar style="margin-block-start:16px">${R.skeleton(3)}</div>
      </div>`;
    const select = box.querySelector("[data-calvehicle]");
    const target = box.querySelector("[data-calendar]");

    async function draw() {
      target.innerHTML = R.skeleton(3);
      const start = new Date();
      const end = new Date(); end.setDate(end.getDate() + 89);
      const iso = d => d.toISOString().slice(0, 10);
      const data = await R.api(
        `/api/v1/fleet/vehicles/${select.value}/calendar?start=${iso(start)}&end=${iso(end)}`);
      const byDay = {};
      data.days.forEach(d => byDay[d.day] = d);
      const months = {};
      data.days.forEach(d => {
        const key = d.day.slice(0, 7);
        (months[key] = months[key] || []).push(d);
      });
      const DOW = ["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"];
      target.innerHTML = Object.entries(months).map(([key, days]) => {
        const first = new Date(days[0].day + "T00:00:00");
        const offset = (first.getDay() + 6) % 7;
        const label = first.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
        return `<h3 style="margin-block:18px 10px;text-transform:capitalize">${R.esc(label)}</h3>
          <div class="cal">
            ${DOW.map(d => `<div class="cal__dow">${d}</div>`).join("")}
            ${Array.from({ length: offset }, () => '<div></div>').join("")}
            ${days.map(d => {
              const kind = d.kind === "available" ? "" : ` cal__day--${d.kind}`;
              const title = d.reference ? `${d.reference} · ${d.customer || ""}`
                : d.maintenance_reason || d.block_reason || "Disponible";
              return `<div class="cal__day${kind}" title="${R.esc(title)}"
                        data-day="${d.day}" data-kind="${d.kind}"
                        data-booking="${d.booking_id || ""}"
                        data-maint="${d.maintenance_id || ""}" data-blockid="${d.block_id || ""}">
                <span>${Number(d.day.slice(8))}</span>
                ${d.kind !== "available" ? `<small>${
                  d.kind === "booking" ? "Réservé" : d.kind === "maintenance" ? "Entretien" : "Bloqué"}</small>` : ""}
              </div>`;
            }).join("")}
          </div>`;
      }).join("");

      target.querySelectorAll(".cal__day").forEach(cell => {
        cell.onclick = () => {
          const { kind, booking, maint, blockid, day } = cell.dataset;
          if (kind === "booking" && booking) { location.href = `/reservation/${booking}`; return; }
          if (kind === "maintenance" && maint) return removeBlock("maintenance", maint, day);
          if (kind === "blocked" && blockid) return removeBlock("blocked", blockid, day);
        };
      });
    }

    function removeBlock(kind, recordId, day) {
      R.confirmAction(kind === "maintenance" ? "Annuler cette maintenance ?" : "Débloquer cette période ?",
        `La période contenant le ${R.shortDate(day)} sera libérée et redeviendra réservable.`,
        async () => {
          await R.api(`/api/v1/fleet/vehicles/${select.value}/block/${kind}/${recordId}`, { method: "DELETE" });
          R.toast("Période libérée.", "ok"); draw();
        });
    }

    box.querySelectorAll("[data-block]").forEach(btn => {
      btn.onclick = () => {
        const kind = btn.dataset.block;
        R.modal({
          title: kind === "maintenance" ? "Planifier une maintenance" : "Bloquer des dates",
          confirmLabel: "Enregistrer",
          body: `<form class="form" data-blockform>
            <div class="formgrid">
              <div class="field"><label for="start_date">Du</label>
                <input id="start_date" name="start_date" type="date" required
                  min="${new Date().toISOString().slice(0,10)}"></div>
              <div class="field"><label for="end_date">Au</label>
                <input id="end_date" name="end_date" type="date" required
                  min="${new Date().toISOString().slice(0,10)}"></div>
            </div>
            <div class="field"><label for="reason">Motif</label>
              <input id="reason" name="reason" maxlength="300"
                placeholder="${kind === "maintenance" ? "Révision, vidange…" : "Usage personnel, indisponible…"}"></div>
            <p class="form__error" data-formerror hidden></p></form>`,
          onConfirm: async (root) => {
            const form = root.querySelector("[data-blockform]");
            const body = R.formData(form);
            body.kind = kind;
            if (!body.start_date || !body.end_date) { R.formError(form, "Indiquez les deux dates."); throw new Error("x"); }
            if (body.end_date < body.start_date) { R.formError(form, "La date de fin précède la date de début."); throw new Error("x"); }
            try {
              await R.api(`/api/v1/fleet/vehicles/${select.value}/block`, { method: "POST", body });
              R.toast("Période enregistrée.", "ok"); draw();
            } catch (e) {
              const conflicts = (e.extra && e.extra.conflicts) || [];
              R.formError(form, e.message + (conflicts.length
                ? " Jours en conflit : " + conflicts.map(c => R.shortDate(c.day)).join(", ") : ""));
              throw e;
            }
          },
        });
      };
    });
    select.onchange = draw;
    draw();
  }

  async function bookings() {
    box.innerHTML = R.skeleton(3);
    const statuses = [["","Toutes"],["pending","En attente"],["confirmed","Confirmées"],
                      ["active","En cours"],["completed","Terminées"],["cancelled","Annulées"]];
    box.innerHTML = `<div class="tabs">${statuses.map(([k, l], i) =>
      `<button class="tab${i === 0 ? " is-active" : ""}" data-status="${k}">${l}</button>`).join("")}</div>
      <div data-list>${R.skeleton(3)}</div>`;
    const list = box.querySelector("[data-list]");
    async function load(status) {
      list.innerHTML = R.skeleton(3);
      const data = await R.api(`/api/v1/fleet/bookings?limit=50${status ? "&status=" + status : ""}`);
      list.innerHTML = data.items.length
        ? table(["Référence","Client","Véhicule","Dates","Montant","Statut","Actions"],
            data.items.map(b => `<tr>
              <td data-label="Référence"><a href="/reservation/${b.id}">${R.esc(b.reference)}</a></td>
              <td data-label="Client">${R.esc(b.customer_name)}<br>
                <small class="muted">${R.esc(b.customer_phone || b.customer_email)}</small></td>
              <td data-label="Véhicule">${R.esc(b.brand)} ${R.esc(b.model)}</td>
              <td data-label="Dates">${R.shortDate(b.pickup_at)} → ${R.shortDate(b.return_at)}</td>
              <td data-label="Montant">${R.money(b.total_amount)}<br>
                <small class="muted">${R.pill(b.payment_status)}</small></td>
              <td data-label="Statut">${R.pill(b.status)}</td>
              <td data-label="Actions" class="table__actions">
                ${b.status === "pending" ? `
                  <button class="btn btn--primary btn--sm" data-act="confirmed" data-id="${b.id}">Confirmer</button>
                  <button class="btn btn--danger btn--sm" data-act="rejected" data-id="${b.id}">Refuser</button>` : ""}
                ${b.status === "confirmed" ? `
                  <button class="btn btn--primary btn--sm" data-act="active" data-id="${b.id}">Remettre les clés</button>
                  <button class="btn btn--ghost btn--sm" data-act="no_show" data-id="${b.id}">Non présenté</button>` : ""}
                ${b.status === "active" ? `
                  <button class="btn btn--primary btn--sm" data-act="completed" data-id="${b.id}">Clôturer</button>` : ""}
                <a class="btn btn--ghost btn--sm" href="/reservation/${b.id}">Détail</a>
              </td></tr>`).join(""))
        : R.emptyState("📋", "Aucune réservation", "Les demandes de vos clients apparaîtront ici.");
      list.querySelectorAll("[data-act]").forEach(btn => {
        btn.onclick = () => act(btn.dataset.id, btn.dataset.act, () => load(status));
      });
    }
    box.querySelectorAll("[data-status]").forEach(btn => {
      btn.onclick = () => {
        box.querySelectorAll(".tab").forEach(t => t.classList.remove("is-active"));
        btn.classList.add("is-active");
        load(btn.dataset.status);
      };
    });
    load("");
  }

  function act(id, status, after) {
    const labels = {
      confirmed: ["Confirmer cette réservation ?", "Le client sera notifié et les dates restent bloquées."],
      rejected: ["Refuser cette réservation ?", "Les dates seront libérées et le client notifié."],
      active: ["Démarrer la location ?", "À faire au moment de la remise des clés."],
      completed: ["Clôturer la location ?", "Le véhicule redevient disponible."],
      no_show: ["Marquer comme non présenté ?", "Le client ne s'est pas présenté à l'heure convenue."],
    }[status] || ["Changer le statut ?", ""];
    R.modal({
      title: labels[0], danger: ["rejected","no_show"].includes(status),
      confirmLabel: "Confirmer",
      body: `<p>${R.esc(labels[1])}</p>
        <div class="field"><label for="reason">Motif ${status === "rejected" ? "(obligatoire)" : "(optionnel)"}</label>
          <input id="reason" maxlength="300"></div>
        <p class="form__error" data-formerror hidden></p>`,
      onConfirm: async (root) => {
        const reason = root.querySelector("#reason").value;
        if (status === "rejected" && !reason.trim()) {
          const box2 = root.querySelector("[data-formerror]");
          box2.textContent = "Indiquez le motif du refus."; box2.hidden = false;
          throw new Error("reason");
        }
        try {
          await R.api(`/api/v1/bookings/${id}/status`, { method: "POST", body: { status, reason } });
          R.toast("Réservation mise à jour.", "ok");
          after();
        } catch (e) {
          const box2 = root.querySelector("[data-formerror]");
          box2.textContent = e.message; box2.hidden = false;
          throw e;
        }
      },
    });
  }

  async function today() {
    box.innerHTML = R.skeleton(3);
    const data = await R.api("/api/v1/fleet/today");
    const block = (items, kind) => items.length
      ? table(["Heure","Référence","Client","Véhicule","Statut","Actions"], items.map(p => `
          <tr><td data-label="Heure">${String(kind === "pickup" ? p.pickup_at : p.return_at).slice(11,16)}</td>
            <td data-label="Référence"><a href="/reservation/${p.id}">${R.esc(p.reference)}</a></td>
            <td data-label="Client">${R.esc(p.customer)}<br><small class="muted">${R.esc(p.phone || "")}</small></td>
            <td data-label="Véhicule">${R.esc(p.brand)} ${R.esc(p.model)}</td>
            <td data-label="Statut">${R.pill(p.status)}</td>
            <td data-label="Actions" class="table__actions">
              ${kind === "pickup" && p.status === "confirmed"
                ? `<button class="btn btn--primary btn--sm" data-act="active" data-id="${p.id}">Remettre les clés</button>` : ""}
              ${kind === "return" && p.status === "active"
                ? `<button class="btn btn--primary btn--sm" data-act="completed" data-id="${p.id}">Clôturer</button>` : ""}
            </td></tr>`).join(""))
      : R.emptyState(kind === "pickup" ? "🔑" : "↩",
          kind === "pickup" ? "Aucun départ aujourd'hui" : "Aucun retour aujourd'hui");
    box.innerHTML = `
      <div class="card"><h2>Départs du jour (${data.pickups.length})</h2>${block(data.pickups, "pickup")}</div>
      <div class="card"><h2>Retours du jour (${data.returns.length})</h2>${block(data.returns, "return")}</div>`;
    box.querySelectorAll("[data-act]").forEach(btn =>
      btn.onclick = () => act(btn.dataset.id, btn.dataset.act, today));
  }

  async function revenue() {
    box.innerHTML = R.skeleton(3);
    const [data, dash] = await Promise.all([
      R.api("/api/v1/fleet/analytics"), R.api("/api/v1/fleet/dashboard"),
    ]);
    const max = Math.max(1, ...data.revenue_by_month.map(r => r.revenue));
    box.innerHTML = `
      <div class="grid grid--stats">
        <div class="stat stat--accent"><div class="stat__label">Revenu du mois</div>
          <div class="stat__value">${R.money(dash.metrics.revenue_month)}</div></div>
        <div class="stat"><div class="stat__label">Revenu total</div>
          <div class="stat__value">${R.money(dash.metrics.revenue_total)}</div></div>
        <div class="stat"><div class="stat__label">Réservations en cours</div>
          <div class="stat__value">${dash.metrics.bookings_active}</div></div>
        <div class="stat"><div class="stat__label">Commission plateforme</div>
          <div class="stat__value">${company.commission_rate != null ? company.commission_rate : "—"}%</div>
          <div class="stat__hint">${company.commission_rate == null ? "taux par défaut de la plateforme" : "taux négocié"}</div></div>
      </div>
      <div class="card"><h2>Revenu net par mois</h2>
        ${data.revenue_by_month.length ? `<div class="bars">${data.revenue_by_month.map(r => `
          <div class="bars__item" title="${R.esc(r.month)} · ${R.money(r.revenue)}">
            <div class="bars__bar" style="height:${Math.round(r.revenue / max * 100)}%"></div>
            <span class="bars__label">${R.esc(r.month.slice(5))}/${R.esc(r.month.slice(2,4))}</span>
          </div>`).join("")}</div>` : R.emptyState("📈", "Pas encore de revenus")}
      </div>
      <div class="card"><h2>Véhicules les plus loués</h2>${data.top_vehicles.length
        ? table(["Véhicule","Réservations","Chiffre d'affaires"], data.top_vehicles.map(v => `
            <tr><td data-label="Véhicule">${R.esc(v.brand)} ${R.esc(v.model)}</td>
              <td data-label="Réservations">${v.bookings}</td>
              <td data-label="CA">${R.money(v.revenue)}</td></tr>`).join(""))
        : R.emptyState("🚗", "Aucune donnée")}</div>`;
  }

  async function companyView() {
    const [c, wilayas] = await Promise.all([
      R.api("/api/v1/companies/mine"), R.api("/api/v1/wilayas"),
    ]);
    box.innerHTML = `
      <div class="banner banner--${c.status === "approved" ? "ok" : c.status === "pending" ? "warn" : "bad"}">
        Statut de la société : <strong>${R.esc((R.STATUS[c.status] || [c.status])[0])}</strong>
        ${c.reject_reason ? " · " + R.esc(c.reject_reason) : ""}</div>
      <div class="grid grid--stats">
        <div class="stat"><div class="stat__label">Véhicules</div>
          <div class="stat__value">${c.stats.vehicles}</div></div>
        <div class="stat"><div class="stat__label">Réservations</div>
          <div class="stat__value">${c.stats.bookings}</div></div>
        <div class="stat"><div class="stat__label">Note</div>
          <div class="stat__value">${c.rating_avg ? c.rating_avg.toFixed(1) + " ★" : "—"}</div></div>
      </div>
      <div class="card"><h2>Informations de la société</h2>
        <form class="form" data-companyform>
          <div class="formgrid">
            <div class="field"><label for="name">Nom commercial</label>
              <input id="name" name="name" value="${R.esc(c.name)}" required>
              <p class="field__error" data-error-for="name" hidden></p></div>
            <div class="field"><label for="legal_name">Raison sociale</label>
              <input id="legal_name" name="legal_name" value="${R.esc(c.legal_name || "")}"></div>
            <div class="field"><label for="rc_number">Registre de Commerce</label>
              <input id="rc_number" name="rc_number" value="${R.esc(c.rc_number || "")}"></div>
            <div class="field"><label for="nif">NIF</label>
              <input id="nif" name="nif" value="${R.esc(c.nif || "")}"></div>
            <div class="field"><label for="phone">Téléphone</label>
              <input id="phone" name="phone" value="${R.esc(c.phone)}" required>
              <p class="field__error" data-error-for="phone" hidden></p></div>
            <div class="field"><label for="email">E-mail</label>
              <input id="email" name="email" type="email" value="${R.esc(c.email || "")}">
              <p class="field__error" data-error-for="email" hidden></p></div>
            <div class="field"><label for="wilaya_id">Wilaya</label>
              <select id="wilaya_id" name="wilaya_id">${wilayas.map(w =>
                `<option value="${w.id}"${w.id === c.wilaya_id ? " selected" : ""}>
                  ${R.esc(w.name_fr)}</option>`).join("")}</select></div>
            <div class="field"><label for="address">Adresse</label>
              <input id="address" name="address" value="${R.esc(c.address || "")}"></div>
          </div>
          <div class="field"><label for="description">Présentation</label>
            <textarea id="description" name="description" rows="4">${R.esc(c.description || "")}</textarea></div>
          <p class="form__error" data-formerror hidden></p>
          <p class="form__ok" data-formok hidden></p>
          <button class="btn btn--primary" type="submit">Enregistrer</button>
        </form></div>`;
    const form = box.querySelector("[data-companyform]");
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      R.clearErrors(form);
      const btn = form.querySelector('button[type="submit"]');
      R.busy(btn, true);
      try {
        const body = R.formData(form);
        body.wilaya_id = Number(body.wilaya_id);
        await R.api(`/api/v1/companies/${c.id}`, { method: "PUT", body });
        const ok = form.querySelector("[data-formok]");
        ok.textContent = "Informations enregistrées."; ok.hidden = false;
        R.toast("Société mise à jour.", "ok");
      } catch (e) {
        if (e.fields) R.fieldErrors(form, e.fields);
        R.formError(form, e.message);
      } finally { R.busy(btn, false); }
    };
  }
});
