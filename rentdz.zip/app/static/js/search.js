/* Search bar validation + sort + filter auto-submit. */
document.addEventListener("DOMContentLoaded", () => {
  const R = window.RENTDZ;

  document.querySelectorAll("[data-searchform]").forEach(form => {
    const pickup = form.querySelector('[name="pickup_date"]');
    const ret = form.querySelector('[name="return_date"]');
    const err = form.querySelector("[data-search-error]");
    const show = (msg) => { if (err) { err.textContent = msg; err.hidden = !msg; } };

    if (pickup && ret) {
      pickup.addEventListener("change", () => {
        ret.min = pickup.value;
        if (ret.value && ret.value < pickup.value) ret.value = pickup.value;
        show("");
      });
    }
    form.addEventListener("submit", (ev) => {
      if (!pickup || !ret) return;
      if (!pickup.value || !ret.value) { ev.preventDefault(); show("Indiquez les dates de départ et de retour."); return; }
      if (ret.value < pickup.value) { ev.preventDefault(); show("La date de retour doit suivre la date de départ."); return; }
      const today = new Date().toISOString().slice(0, 10);
      if (pickup.value < today) { ev.preventDefault(); show("La date de départ ne peut pas être dans le passé."); return; }
      show("");
    });
  });

  const sort = document.querySelector("[data-sort]");
  if (sort) {
    sort.addEventListener("change", () => {
      const url = new URL(location.href);
      url.searchParams.set("sort", sort.value);
      url.searchParams.delete("offset");
      location.href = url.toString();
    });
  }

  const filterForm = document.querySelector("[data-filterform]");
  if (filterForm) {
    filterForm.addEventListener("change", (ev) => {
      if (ev.target.type === "checkbox" || ev.target.type === "radio") {
        if (window.matchMedia("(min-width: 961px)").matches) filterForm.requestSubmit();
      }
    });
  }
});
