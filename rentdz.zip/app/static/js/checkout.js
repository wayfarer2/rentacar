/* Booking wizard: 6 steps, server-priced summary, real submission. */
document.addEventListener("DOMContentLoaded", async () => {
  const R = window.RENTDZ;
  const root = document.querySelector("[data-checkout]");
  if (!root) return;
  const body = root.querySelector("[data-checkout-body]");
  const side = root.querySelector("[data-checkout-summary]");
  const steps = Array.from(root.querySelectorAll(".wizard__step"));
  const params = new URLSearchParams(location.search);

  const state = {
    step: 0,
    vehicle_id: Number(root.dataset.checkout),
    slug: root.dataset.vehicleSlug,
    pickup_at: params.get("pickup_at") || "",
    return_at: params.get("return_at") || "",
    pickup_location_id: params.get("pickup_location_id") || "",
    promo_code: params.get("promo_code") || "",
    services: (params.get("services") || "").split(",").filter(Boolean).map(Number),
    customer: {}, quote: null, methods: [], vehicle: null, config: null,
  };

  function setStep(n) {
    state.step = n;
    steps.forEach((el, i) => {
      el.classList.toggle("is-active", i === n);
      el.classList.toggle("is-done", i < n);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
    render();
  }

  async function quote() {
    const payload = {
      vehicle_id: state.vehicle_id, pickup_at: state.pickup_at, return_at: state.return_at,
      services: state.services.map(id => ({ id })),
    };
    if (state.pickup_location_id) payload.pickup_location_id = Number(state.pickup_location_id);
    if (state.promo_code) payload.promo_code = state.promo_code;
    state.quote = await R.api("/api/v1/quote", { method: "POST", body: payload });
    renderSummary();
  }

  function renderSummary() {
    const q = state.quote;
    if (!q) { side.innerHTML = R.skeleton(3); return; }
    const line = (k, v, cls = "") =>
      `<div class="quote__row ${cls}"><span>${R.esc(k)}</span><span>${v}</span></div>`;
    let html = line("Départ", R.humanDate(q.pickup_at, true), "quote__row--muted");
    html += line("Retour", R.humanDate(q.return_at, true), "quote__row--muted");
    html += line("Durée", `${q.days} ${q.days > 1 ? "jours" : "jour"}`, "quote__row--muted");
    html += `<hr style="border:0;border-top:1px solid var(--line);margin:8px 0">`;
    (q.lines.base || []).forEach(l => html += line(l.label, R.money(l.amount)));
    (q.lines.services || []).forEach(l => html += line(l.label, R.money(l.amount)));
    (q.lines.fees || []).forEach(l => html += line(l.label, R.money(l.amount)));
    (q.lines.discounts || []).forEach(l => html += line(l.label, R.money(l.amount), "quote__row--discount"));
    (q.lines.taxes || []).forEach(l => html += line(l.label, R.money(l.amount)));
    html += line("Total", R.money(q.total_amount), "quote__row--total");
    if (q.deposit_amount) html += line("Caution", R.money(q.deposit_amount), "quote__row--muted");
    if (!q.available) html += `<p class="banner banner--bad" style="margin-top:10px">
      Ce véhicule n'est plus disponible sur ces dates.</p>`;
    side.innerHTML = html;
  }

  function nav(backLabel, nextLabel, onNext, disabled) {
    return `<div class="actionsrow">
      ${state.step > 0 ? `<button class="btn btn--ghost" data-back>${R.esc(backLabel)}</button>` : "<span></span>"}
      <button class="btn btn--primary btn--lg" data-next ${disabled ? "disabled" : ""}>${R.esc(nextLabel)}</button>
    </div>`;
  }

  function render() {
    const v = state.vehicle, cfg = state.config;
    if (state.step === 0) {
      body.innerHTML = `<section class="card">
        <h2>Dates et heures de location</h2>
        <form class="formgrid" data-step-form>
          <div class="field"><label for="p_date">Date de départ</label>
            <input id="p_date" type="date" name="pickup_date" required
              value="${R.esc((state.pickup_at || "").slice(0,10))}"
              min="${new Date().toISOString().slice(0,10)}"></div>
          <div class="field"><label for="p_time">Heure de départ</label>
            <input id="p_time" type="time" name="pickup_time" step="1800"
              value="${R.esc((state.pickup_at || "").slice(11,16) || "10:00")}"></div>
          <div class="field"><label for="r_date">Date de retour</label>
            <input id="r_date" type="date" name="return_date" required
              value="${R.esc((state.return_at || "").slice(0,10))}"
              min="${new Date().toISOString().slice(0,10)}"></div>
          <div class="field"><label for="r_time">Heure de retour</label>
            <input id="r_time" type="time" name="return_time" step="1800"
              value="${R.esc((state.return_at || "").slice(11,16) || "10:00")}"></div>
        </form>
        <p class="field__hint">Durée : ${cfg?.booking?.min_days || 1} à ${cfg?.booking?.max_days || 90} jours.
          Prise en charge au moins ${cfg?.booking?.min_hours_before_pickup || 2} h à l'avance.</p>
        <p class="form__error" data-formerror hidden></p>
        ${nav("Retour", "Continuer")}
      </section>`;
      body.querySelector("[data-next]").onclick = async () => {
        const f = body.querySelector("[data-step-form]");
        const d = R.formData(f);
        if (!d.pickup_date || !d.return_date) return R.formError(f, "Renseignez les deux dates.");
        state.pickup_at = `${d.pickup_date} ${d.pickup_time || "10:00"}`;
        state.return_at = `${d.return_date} ${d.return_time || "10:00"}`;
        if (state.return_at <= state.pickup_at) return R.formError(f, "Le retour doit suivre le départ.");
        const btn = body.querySelector("[data-next]");
        R.busy(btn, true);
        try { await quote(); setStep(1); }
        catch (e) { R.formError(f, e.fields ? Object.values(e.fields)[0] : e.message); }
        finally { R.busy(btn, false); }
      };
    }

    if (state.step === 1) {
      const u = R.user || {};
      const p = (u.profile || {});
      body.innerHTML = `<section class="card">
        <h2>Vos informations</h2>
        <form class="formgrid" data-step-form>
          <div class="field"><label for="full_name">Nom complet</label>
            <input id="full_name" name="full_name" required minlength="3" value="${R.esc(u.full_name || "")}">
            <p class="field__error" data-error-for="full_name" hidden></p></div>
          <div class="field"><label for="phone">Téléphone</label>
            <input id="phone" name="phone" type="tel" placeholder="0555 12 34 56" required
              value="${R.esc(u.phone || "")}">
            <p class="field__error" data-error-for="phone" hidden></p></div>
          <div class="field"><label for="email">E-mail</label>
            <input id="email" name="email" type="email" required value="${R.esc(u.email || "")}">
            <p class="field__error" data-error-for="email" hidden></p></div>
          <div class="field"><label for="date_of_birth">Date de naissance</label>
            <input id="date_of_birth" name="date_of_birth" type="date" value="${R.esc(p.date_of_birth || "")}"
              ${cfg?.booking?.require_license_info ? "required" : ""}>
            <p class="field__hint">Âge minimum : ${cfg?.booking?.min_driver_age || 21} ans.</p>
            <p class="field__error" data-error-for="date_of_birth" hidden></p></div>
          <div class="field" style="grid-column:1/-1"><label for="address">Adresse</label>
            <input id="address" name="address" value="${R.esc(p.address || "")}"></div>
        </form>
        <p class="form__error" data-formerror hidden></p>
        ${nav("Retour", "Continuer")}
      </section>`;
      body.querySelector("[data-next]").onclick = () => {
        const f = body.querySelector("[data-step-form]");
        const d = R.formData(f);
        if (!d.full_name || d.full_name.length < 3) return R.fieldErrors(f, { full_name: "Nom complet requis." });
        if (!d.phone) return R.fieldErrors(f, { phone: "Téléphone requis." });
        Object.assign(state.customer, d);
        setStep(2);
      };
    }

    if (state.step === 2) {
      const p = (R.user && R.user.profile) || {};
      body.innerHTML = `<section class="card">
        <h2>Permis de conduire</h2>
        <p class="muted" style="margin-block-end:16px">Ces informations sont transmises uniquement au
          loueur du véhicule. Vous téléverserez la copie de votre permis après la réservation.</p>
        <form class="formgrid" data-step-form>
          <div class="field"><label for="license_number">Numéro de permis</label>
            <input id="license_number" name="license_number" required value="${R.esc(p.license_number || "")}">
            <p class="field__error" data-error-for="license_number" hidden></p></div>
          <div class="field"><label for="license_issued_at">Date de délivrance</label>
            <input id="license_issued_at" name="license_issued_at" type="date" value="${R.esc(p.license_issued_at || "")}"></div>
          <div class="field"><label for="license_expires_at">Date d'expiration</label>
            <input id="license_expires_at" name="license_expires_at" type="date" value="${R.esc(p.license_expires_at || "")}">
            <p class="field__error" data-error-for="license_expires_at" hidden></p></div>
        </form>
        <p class="form__error" data-formerror hidden></p>
        ${nav("Retour", "Continuer")}
      </section>`;
      body.querySelector("[data-next]").onclick = () => {
        const f = body.querySelector("[data-step-form]");
        const d = R.formData(f);
        if (cfg?.booking?.require_license_info && !d.license_number)
          return R.fieldErrors(f, { license_number: "Numéro de permis requis." });
        if (d.license_expires_at && d.license_expires_at < state.pickup_at.slice(0, 10))
          return R.fieldErrors(f, { license_expires_at: "Votre permis expire avant le départ." });
        Object.assign(state.customer, d);
        setStep(3);
      };
    }

    if (state.step === 3) {
      const svc = (v.services || []).map(s => `
        <label class="svc">
          <input type="checkbox" name="service" value="${s.id}"
            ${state.services.includes(s.id) ? "checked" : ""}>
          <span class="svc__name">${R.esc(s.name_fr)}</span>
          <span class="svc__price">${R.money(s.price)}${s.price_type === "per_day" ? "/jour" : ""}</span>
        </label>`).join("") || `<p class="muted">Ce loueur ne propose pas d'option supplémentaire.</p>`;
      body.innerHTML = `<section class="card">
        <h2>Options et services</h2>
        <form class="form" data-step-form>${svc}
          <div class="field"><label for="promo">Code promo</label>
            <input id="promo" name="promo_code" value="${R.esc(state.promo_code)}" placeholder="Optionnel">
            <p class="field__error" data-error-for="promo_code" hidden></p></div>
          <div class="field"><label for="notes">Remarques pour le loueur</label>
            <textarea id="notes" name="notes" rows="3" maxlength="1000">${R.esc(state.customer.notes || "")}</textarea></div>
        </form>
        <p class="form__error" data-formerror hidden></p>
        ${nav("Retour", "Continuer")}
      </section>`;
      body.querySelector("[data-next]").onclick = async () => {
        const f = body.querySelector("[data-step-form]");
        const d = R.formData(f);
        state.services = Array.from(f.querySelectorAll('[name="service"]:checked')).map(e => Number(e.value));
        state.promo_code = (d.promo_code || "").trim();
        state.customer.notes = d.notes || "";
        const btn = body.querySelector("[data-next]");
        R.busy(btn, true);
        try { await quote(); setStep(4); }
        catch (e) {
          if (e.fields) R.fieldErrors(f, e.fields);
          R.formError(f, e.message);
        } finally { R.busy(btn, false); }
      };
    }

    if (state.step === 4) {
      const q = state.quote;
      body.innerHTML = `<section class="card">
        <h2>Récapitulatif</h2>
        <dl class="kv">
          <div class="kv__item"><dt>Véhicule</dt><dd>${R.esc(v.brand)} ${R.esc(v.model)} ${v.year}</dd></div>
          <div class="kv__item"><dt>Loueur</dt><dd>${R.esc(v.company_name)}</dd></div>
          <div class="kv__item"><dt>Départ</dt><dd>${R.humanDate(q.pickup_at, true)}</dd></div>
          <div class="kv__item"><dt>Retour</dt><dd>${R.humanDate(q.return_at, true)}</dd></div>
          <div class="kv__item"><dt>Conducteur</dt><dd>${R.esc(state.customer.full_name || "")}</dd></div>
          <div class="kv__item"><dt>Téléphone</dt><dd>${R.esc(state.customer.phone || "")}</dd></div>
          <div class="kv__item"><dt>Total</dt><dd>${R.money(q.total_amount)}</dd></div>
          <div class="kv__item"><dt>Caution</dt><dd>${R.money(q.deposit_amount)}</dd></div>
        </dl>
        <div class="banner banner--info" style="margin-block-start:16px">
          Votre réservation sera transmise au loueur pour confirmation. Le véhicule est bloqué
          pendant ${state.config?.booking?.hold_minutes || 30} minutes le temps de finaliser.
        </div>
        ${nav("Retour", "Choisir le paiement")}
      </section>`;
      body.querySelector("[data-next]").onclick = () => setStep(5);
    }

    if (state.step === 5) {
      const methods = state.methods.filter(m => m.usable !== false);
      const unusable = state.methods.filter(m => m.usable === false);
      const opts = methods.map((m, i) => `
        <label class="svc">
          <input type="radio" name="payment_method" value="${R.esc(m.code)}" ${i === 0 ? "checked" : ""}>
          <span class="svc__name"><strong>${R.esc(m.name)}</strong><br>
            <small class="muted">${R.esc(m.instructions || "")}</small></span>
        </label>`).join("");
      body.innerHTML = `<section class="card">
        <h2>Moyen de paiement</h2>
        ${methods.length ? `<form class="form" data-step-form>${opts}</form>`
          : `<div class="banner banner--warn">Aucun moyen de paiement n'est activé.
             Votre réservation sera enregistrée et l'agence vous contactera.</div>`}
        ${unusable.length ? `<div class="banner banner--info" style="margin-block-start:12px">
          Bientôt disponible : ${unusable.map(m => R.esc(m.name)).join(", ")} —
          en attente de configuration par la plateforme.</div>` : ""}
        <p class="form__error" data-formerror hidden></p>
        ${nav("Retour", "Confirmer la réservation")}
      </section>`;
      body.querySelector("[data-next]").onclick = submit;
    }

    const back = body.querySelector("[data-back]");
    if (back) back.onclick = () => setStep(Math.max(0, state.step - 1));
  }

  async function submit() {
    const btn = body.querySelector("[data-next]");
    const f = body.querySelector("[data-step-form]");
    R.busy(btn, true);
    const payload = Object.assign({
      vehicle_id: state.vehicle_id,
      pickup_at: state.pickup_at, return_at: state.return_at,
      services: state.services.join(","),
      promo_code: state.promo_code || "",
      payment_method: f ? (R.formData(f).payment_method || "") : "",
    }, state.customer);
    if (state.pickup_location_id) payload.pickup_location_id = Number(state.pickup_location_id);
    try {
      const booking = await R.api("/api/v1/bookings", { method: "POST", body: payload });
      if (payload.payment_method) {
        try {
          await R.api("/api/v1/payments", { method: "POST", body: {
            booking_id: booking.id, provider_code: payload.payment_method, kind: "deposit" } });
        } catch (e) { R.toast(e.message, "warn"); }
      }
      location.href = `/reservation/${booking.id}?created=1`;
    } catch (e) {
      R.busy(btn, false);
      if (e.code === "dates_unavailable") {
        R.modal({
          title: "Ce véhicule vient d'être réservé",
          body: `<p>${R.esc(e.message)}</p>`,
          confirmLabel: "Choisir d'autres dates", cancelLabel: "Voir d'autres véhicules",
          onConfirm: () => setStep(0),
        }).root.querySelector("[data-cancel]").onclick = () => location.href = "/vehicules";
        return;
      }
      if (f && e.fields) R.fieldErrors(f, e.fields);
      if (f) R.formError(f, e.message); else R.toast(e.message, "bad");
    }
  }

  /* boot */
  try {
    await R.session();
    const [vehicle, config] = await Promise.all([
      R.api(`/api/v1/vehicles/${root.dataset.vehicleSlug}`),
      R.api("/api/v1/config"),
    ]);
    state.vehicle = vehicle;
    state.config = config;
    state.methods = config.payment_methods || [];
    if (!state.pickup_location_id && vehicle.location_id) state.pickup_location_id = vehicle.location_id;
    if (state.pickup_at && state.return_at) { await quote(); setStep(1); }
    else setStep(0);
  } catch (e) {
    body.innerHTML = `<div class="banner banner--bad">${R.esc(e.message)}</div>`;
  }
});
