"""
Development seed data. Everything created here is flagged is_demo = 1 and uses
invented names, so it can be identified and purged. Never run in production.
"""
from __future__ import annotations
import random
from datetime import timedelta
from .. import db
from ..config import Config
from ..security import hash_password, now, now_str, slugify, in_minutes
from ..services import auth_service as A
from ..services import availability as AV
from ..services import settings_service as S
from ..services.payment import seed_providers

random.seed(1789)

DEMO_PASSWORD = "RentDZ2026!"

COMPANIES = [
    ("Sahara Cars", "Alger", 16, "Agence Alger-Centre", "0555100001", 12.0,
     "Agence familiale basée à Alger-Centre depuis 2015. Flotte récente et entretenue."),
    ("Oran Auto Location", "Oran", 31, "Agence Oran Centre", "0555100002", 12.0,
     "Spécialiste de la location courte et longue durée dans l'Oranie."),
    ("Constantine Rent", "Constantine", 25, "Agence Constantine Centre", "0555100003", 10.0,
     "Véhicules citadins et berlines, livraison à l'aéroport Mohamed Boudiaf."),
    ("Kabylie Mobility", "Tizi Ouzou", 15, "Agence Tizi Ouzou", "0555100004", 12.0,
     "Location de 4x4 et SUV adaptés aux routes de montagne."),
    ("Sud Location Ghardaïa", "Ghardaïa", 47, "Agence Ghardaïa", "0555100005", 14.0,
     "Location de 4x4 pour missions dans le Sud algérien."),
]

# brand, model, year, category, transmission, fuel, seats, doors, daily, deposit, colour
FLEET = [
    ("Renault", "Clio 5", 2023, "compact", "manual", "petrol", 5, 5, 4200, 20000, "Blanc"),
    ("Renault", "Symbol", 2022, "sedan", "manual", "diesel", 5, 4, 4500, 20000, "Gris"),
    ("Dacia", "Logan", 2022, "sedan", "manual", "diesel", 5, 4, 4000, 18000, "Blanc"),
    ("Dacia", "Sandero Stepway", 2023, "compact", "manual", "petrol", 5, 5, 4600, 20000, "Bleu"),
    ("Dacia", "Duster", 2023, "suv", "manual", "diesel", 5, 5, 6500, 30000, "Beige"),
    ("Hyundai", "i10", 2022, "economy", "manual", "petrol", 4, 5, 3200, 15000, "Rouge"),
    ("Hyundai", "Accent", 2023, "sedan", "automatic", "petrol", 5, 4, 5200, 25000, "Noir"),
    ("Hyundai", "Tucson", 2024, "suv", "automatic", "diesel", 5, 5, 9500, 45000, "Gris"),
    ("Kia", "Picanto", 2022, "economy", "manual", "petrol", 4, 5, 3000, 15000, "Blanc"),
    ("Kia", "Rio", 2023, "compact", "automatic", "petrol", 5, 5, 5000, 22000, "Bleu"),
    ("Volkswagen", "Golf 8", 2023, "compact", "automatic", "petrol", 5, 5, 8500, 40000, "Noir"),
    ("Volkswagen", "Passat", 2022, "luxury", "automatic", "diesel", 5, 4, 11000, 60000, "Gris"),
    ("Peugeot", "208", 2023, "compact", "manual", "petrol", 5, 5, 4400, 20000, "Jaune"),
    ("Peugeot", "301", 2022, "sedan", "manual", "diesel", 5, 4, 4300, 20000, "Blanc"),
    ("Peugeot", "3008", 2024, "suv", "automatic", "diesel", 5, 5, 10500, 50000, "Bleu nuit"),
    ("Toyota", "Yaris", 2023, "compact", "automatic", "hybrid", 5, 5, 5800, 25000, "Argent"),
    ("Toyota", "Corolla", 2023, "sedan", "automatic", "hybrid", 5, 4, 7200, 32000, "Blanc nacré"),
    ("Toyota", "Land Cruiser", 2022, "4x4", "automatic", "diesel", 7, 5, 18000, 90000, "Blanc"),
    ("Toyota", "Hilux", 2023, "4x4", "manual", "diesel", 5, 4, 13000, 70000, "Gris"),
    ("Seat", "Ibiza", 2022, "compact", "manual", "petrol", 5, 5, 4300, 20000, "Rouge"),
    ("Skoda", "Octavia", 2023, "sedan", "automatic", "diesel", 5, 4, 8200, 38000, "Gris acier"),
    ("Fiat", "Doblo", 2022, "van", "manual", "diesel", 7, 5, 6000, 28000, "Blanc"),
    ("Renault", "Trafic", 2021, "van", "manual", "diesel", 9, 4, 8500, 40000, "Blanc"),
    ("Mercedes-Benz", "Classe C", 2023, "luxury", "automatic", "diesel", 5, 4, 16000, 90000, "Noir"),
    ("Chery", "Tiggo 4 Pro", 2024, "suv", "automatic", "petrol", 5, 5, 7000, 32000, "Blanc"),
    ("Suzuki", "Swift", 2022, "economy", "manual", "petrol", 5, 5, 3600, 16000, "Bleu"),
]

CUSTOMERS = [
    ("Amine Belkacem", "amine.demo@rentdz.test", "0661000101", 16),
    ("Yasmine Haddad", "yasmine.demo@rentdz.test", "0661000102", 16),
    ("Karim Bouzid", "karim.demo@rentdz.test", "0661000103", 31),
    ("Nadia Cherif", "nadia.demo@rentdz.test", "0661000104", 25),
    ("Sofiane Mansouri", "sofiane.demo@rentdz.test", "0661000105", 19),
    ("Lila Zerrouki", "lila.demo@rentdz.test", "0661000106", 15),
]

REVIEW_TEXTS = [
    "Véhicule propre et récent, agence très correcte. La remise des clés a pris cinq minutes.",
    "Bon rapport qualité-prix. La climatisation fonctionnait parfaitement malgré la chaleur.",
    "Prise en charge à l'aéroport impeccable, l'agent était là à l'heure.",
    "Voiture conforme à l'annonce. Caution restituée sans problème au retour.",
    "Bonne expérience dans l'ensemble, je relouerai pour mes déplacements professionnels.",
    "Le véhicule manquait un peu d'entretien intérieur mais rien de bloquant.",
]


def _user(name: str, email: str, phone: str, role: str, wilaya_id=None) -> int:
    existing = db.one("SELECT id FROM users WHERE lower(email) = lower(?)", (email,))
    if existing:
        return existing["id"]
    uid = db.insert("users", {
        "email": email.lower(), "phone": phone, "password_hash": hash_password(DEMO_PASSWORD),
        "full_name": name, "locale": "fr", "status": "active", "is_demo": 1,
        "email_verified_at": now_str(), "created_at": now_str(), "updated_at": now_str()})
    A.grant_role(uid, role)
    if role == "customer":
        db.insert("customer_profiles", {
            "user_id": uid, "date_of_birth": "1992-04-18",
            "address": "Cité des Palmiers, bâtiment B", "wilaya_id": wilaya_id,
            "license_number": f"DZ{random.randint(100000, 999999)}",
            "license_issued_at": "2016-06-12", "license_expires_at": "2032-06-12",
            "updated_at": now_str()})
    return uid


def seed(*, admin_email: str = "admin@rentdz.dz", admin_password: str | None = None) -> dict:
    if Config.APP_ENV == "production":
        raise RuntimeError("Les données de démonstration ne peuvent pas être créées en production.")
    from .geography import seed as seed_geo
    out = {}
    A.seed_roles()
    S.seed_defaults()
    seed_providers()
    out["geography"] = seed_geo()

    # ── platform staff ────────────────────────────────────────────────────────
    admin_pw = admin_password or DEMO_PASSWORD
    admin = db.one("SELECT id FROM users WHERE lower(email) = lower(?)", (admin_email,))
    if admin:
        admin_id = admin["id"]
    else:
        admin_id = db.insert("users", {
            "email": admin_email.lower(), "phone": "0555000000",
            "password_hash": hash_password(admin_pw), "full_name": "Administrateur RENTDZ",
            "locale": "fr", "status": "active", "is_demo": 1,
            "email_verified_at": now_str(), "created_at": now_str(), "updated_at": now_str()})
    A.grant_role(admin_id, "super_admin")
    A.grant_role(admin_id, "admin")
    out["admin"] = {"email": admin_email, "password": admin_pw}

    support_id = _user("Hakim Support", "support.demo@rentdz.test", "0555000010", "support_agent")
    finance_id = _user("Farida Finance", "finance.demo@rentdz.test", "0555000011", "finance_manager")
    out["staff"] = [{"email": "support.demo@rentdz.test", "role": "support_agent"},
                    {"email": "finance.demo@rentdz.test", "role": "finance_manager"}]

    # ── companies + fleets ────────────────────────────────────────────────────
    company_ids = []
    for idx, (name, city, wilaya_id, loc_name, phone, commission, description) in enumerate(COMPANIES):
        owner_email = f"loueur{idx + 1}.demo@rentdz.test"
        owner_id = _user(f"Propriétaire {name}", owner_email, phone, "fleet_owner", wilaya_id)
        existing = db.one("SELECT id FROM rental_companies WHERE slug = ?", (slugify(name),))
        if existing:
            company_ids.append(existing["id"])
            continue
        cid = db.insert("rental_companies", {
            "owner_user_id": owner_id, "name": name, "slug": slugify(name),
            "legal_name": f"{name} SARL", "rc_number": f"16/00-{1000 + idx}B{idx}",
            "nif": f"0016{random.randint(10000000, 99999999)}", "phone": phone,
            "email": owner_email, "wilaya_id": wilaya_id,
            "address": f"{loc_name}, {city}", "description": description,
            "status": "approved" if idx < 4 else "pending",
            "commission_rate": commission, "is_demo": 1,
            "approved_at": now_str() if idx < 4 else None,
            "approved_by": admin_id if idx < 4 else None,
            "created_at": now_str(), "updated_at": now_str()})
        db.execute("UPDATE user_roles SET company_id = ? WHERE user_id = ? AND company_id IS NULL",
                   (cid, owner_id))
        company_ids.append(cid)
    out["companies"] = len(company_ids)

    vehicle_ids = []
    for i, (brand, model, year, cat, trans, fuel, seats, doors, daily, deposit, colour) in enumerate(FLEET):
        company_id = company_ids[i % 4]                      # only approved companies get a fleet
        if cat in ("4x4",) and len(company_ids) >= 4:
            company_id = company_ids[3]
        slug = slugify(f"{brand} {model} {year}", extra=str(i + 1))
        if db.one("SELECT 1 FROM vehicles WHERE slug = ?", (slug,)):
            continue
        cat_id = db.scalar("SELECT id FROM vehicle_categories WHERE code = ?", (cat,))
        loc = db.one("""SELECT l.id FROM locations l
                          JOIN rental_companies c ON c.wilaya_id = l.wilaya_id
                         WHERE c.id = ? AND l.kind='office' LIMIT 1""", (company_id,))
        weekly = int(daily * 6.2)
        monthly = int(daily * 23)
        vid = db.insert("vehicles", {
            "company_id": company_id, "slug": slug, "brand": brand, "model": model, "year": year,
            "category_id": cat_id, "transmission": trans, "fuel": fuel, "seats": seats,
            "doors": doors, "color": colour, "mileage": random.randint(8000, 95000),
            "registration_number": f"{random.randint(10000,99999)}-116-{random.randint(10,58):02d}",
            "description": (f"{brand} {model} de {year}, entretenue et révisée. "
                            f"Idéale pour {'la ville' if cat in ('economy','compact') else 'les longs trajets'}. "
                            f"Véhicule non-fumeur, propreté garantie à chaque location."),
            "daily_price": daily, "weekly_price": weekly, "monthly_price": monthly,
            "weekend_price": int(daily * 1.15) if i % 3 == 0 else None,
            "deposit": deposit, "min_days": 1, "max_days": 60,
            "km_included_per_day": None if i % 4 == 0 else 250,
            "extra_km_price": 0 if i % 4 == 0 else 25,
            "primary_location_id": loc["id"] if loc else None,
            "status": "available",
            "approval_status": "approved" if i < len(FLEET) - 3 else "pending",
            "is_demo": 1, "created_at": now_str(), "updated_at": now_str()})
        feature_pool = ["air_conditioning", "airbags", "abs", "spare_wheel", "usb", "bluetooth",
                        "gps", "backup_camera", "cruise_control", "android_auto", "apple_carplay",
                        "parking_sensors", "child_seat", "first_aid"]
        picked = ["air_conditioning", "airbags", "abs"] + random.sample(feature_pool[4:], k=random.randint(3, 7))
        for code in set(picked):
            fid = db.scalar("SELECT id FROM features WHERE code = ?", (code,))
            if fid:
                db.execute("INSERT OR IGNORE INTO vehicle_features (vehicle_id, feature_id) VALUES (?,?)",
                           (vid, fid))
        vehicle_ids.append(vid)
    out["vehicles"] = len(vehicle_ids)

    # ── customers ─────────────────────────────────────────────────────────────
    customer_ids = [_user(n, e, p, "customer", w) for n, e, p, w in CUSTOMERS]
    out["customers"] = len(customer_ids)

    # ── promo codes ───────────────────────────────────────────────────────────
    promos = [
        ("BIENVENUE10", "percent", 10, 0, 5000, 200, 1),
        ("ETE2026", "percent", 15, 20000, 12000, 100, 1),
        ("SAHARA5000", "fixed", 5000, 40000, None, 50, 1),
    ]
    for code, kind, value, min_amount, max_disc, limit, per_user in promos:
        if db.one("SELECT 1 FROM promo_codes WHERE code = ?", (code,)):
            continue
        db.insert("promo_codes", {
            "code": code, "kind": kind, "value": value, "min_amount": min_amount,
            "max_discount": max_disc, "usage_limit": limit, "per_user_limit": per_user,
            "starts_at": (now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M"),
            "ends_at": (now() + timedelta(days=120)).strftime("%Y-%m-%d %H:%M"),
            "active": 1, "created_at": now_str()})
    out["promo_codes"] = len(promos)

    # ── pricing rules ─────────────────────────────────────────────────────────
    if not db.one("SELECT 1 FROM pricing_rules"):
        db.insert("pricing_rules", {
            "scope": "global", "kind": "seasonal", "label": "Haute saison estivale (+15 %)",
            "start_date": f"{now().year}-07-01", "end_date": f"{now().year}-08-31",
            "adjust_type": "percent", "adjust_value": 15, "priority": 10, "active": 1,
            "created_at": now_str()})
        db.insert("pricing_rules", {
            "scope": "global", "kind": "early_booking",
            "label": "Réservation anticipée (−5 % à 30 jours)",
            "min_days_ahead": 30, "adjust_type": "percent", "adjust_value": -5,
            "priority": 5, "active": 1, "created_at": now_str()})
        out["pricing_rules"] = 2

    # ── maintenance windows ───────────────────────────────────────────────────
    maint = 0
    for vid in vehicle_ids[:3]:
        start = (now().date() + timedelta(days=random.randint(20, 40))).isoformat()
        end = (now().date() + timedelta(days=random.randint(41, 45))).isoformat()
        days = AV.day_range(start, end)
        if any(AV.conflicting_days(vid, start, end)):
            continue
        mid = db.insert("vehicle_maintenance", {
            "vehicle_id": vid, "start_date": start, "end_date": end,
            "reason": random.choice(["Révision des 60 000 km", "Changement de pneumatiques",
                                     "Entretien climatisation"]),
            "cost": random.choice([12000, 18000, 25000]), "status": "planned",
            "created_by": admin_id, "created_at": now_str()})
        AV.lock_days(vid, days, "maintenance", maintenance_id=mid)
        maint += 1
    out["maintenance"] = maint

    # ── bookings across every meaningful state ────────────────────────────────
    from ..services import pricing as P
    plan = [
        ("completed", -40, -36), ("completed", -30, -27), ("completed", -20, -18),
        ("completed", -14, -10), ("active", -2, 3), ("confirmed", 6, 10),
        ("confirmed", 12, 15), ("pending", 20, 23), ("cancelled", -8, -5),
        ("expired", 25, 28), ("rejected", 30, 33),
    ]
    made = {}
    for i, (status, start_off, end_off) in enumerate(plan):
        vid = vehicle_ids[i % max(1, len(vehicle_ids))]
        vehicle = db.one("SELECT * FROM vehicles WHERE id = ?", (vid,))
        if not vehicle or vehicle["approval_status"] != "approved":
            continue
        customer_id = customer_ids[i % len(customer_ids)]
        pickup = (now() + timedelta(days=start_off)).replace(hour=10, minute=0)
        ret = (now() + timedelta(days=end_off)).replace(hour=10, minute=0)
        pickup_s, ret_s = pickup.strftime("%Y-%m-%d %H:%M"), ret.strftime("%Y-%m-%d %H:%M")
        try:
            q = P.quote(dict(vehicle), pickup_s, ret_s)
        except Exception:
            continue
        occupies = status in AV.BLOCKING_BOOKING_STATUSES
        days = AV.day_range(pickup_s[:10], ret_s[:10])
        if occupies and AV.conflicting_days(vid, pickup_s[:10], ret_s[:10]):
            continue
        ref = f"RDZ-{pickup.strftime('%y%m')}-D{i:03d}"
        if db.one("SELECT 1 FROM bookings WHERE reference = ?", (ref,)):
            continue
        loc_id = vehicle["primary_location_id"]
        paid = q["total_amount"] if status in ("completed", "active") else 0
        bid = db.insert("bookings", {
            "reference": ref, "customer_user_id": customer_id, "vehicle_id": vid,
            "company_id": vehicle["company_id"], "pickup_location_id": loc_id,
            "dropoff_location_id": loc_id, "pickup_at": pickup_s, "return_at": ret_s,
            "pickup_date": pickup_s[:10], "return_date": ret_s[:10], "days": q["days"],
            "status": status, "base_amount": q["base_amount"],
            "services_amount": 0, "fees_amount": q["fees_amount"],
            "discount_amount": q["discount_amount"], "tax_amount": q["tax_amount"],
            "total_amount": q["total_amount"], "deposit_amount": q["deposit_amount"],
            "commission_amount": q["commission_amount"], "paid_amount": paid,
            "payment_status": "paid" if paid else ("cancelled" if status in ("cancelled", "expired", "rejected") else "pending"),
            "payment_method": "cash_on_pickup",
            "price_breakdown": db.jdump(q), "customer_snapshot": db.jdump({}),
            "confirmed_at": now_str() if status in ("confirmed", "active", "completed") else None,
            "started_at": now_str() if status in ("active", "completed") else None,
            "completed_at": now_str() if status == "completed" else None,
            "cancelled_at": now_str() if status in ("cancelled", "expired", "rejected") else None,
            "cancel_reason": {"cancelled": "Changement de programme du client",
                              "expired": "Délai de confirmation dépassé",
                              "rejected": "Véhicule immobilisé pour réparation"}.get(status),
            "hold_expires_at": in_minutes(30) if status == "pending" else None,
            "is_demo": 1, "created_at": now_str(), "updated_at": now_str()})
        db.insert("booking_status_history", {
            "booking_id": bid, "from_status": None, "to_status": status,
            "actor_user_id": customer_id, "reason": "Donnée de démonstration",
            "created_at": now_str()})
        if occupies:
            AV.lock_days(vid, days, "booking", booking_id=bid)
        if paid:
            db.insert("payments", {
                "booking_id": bid, "user_id": customer_id, "provider_code": "cash_on_pickup",
                "kind": "full", "amount": paid, "status": "paid",
                "provider_txn_id": f"CASH-{ref}", "idempotency_key": f"{ref}:full:cash_on_pickup",
                "created_at": now_str(), "updated_at": now_str()})
        made[status] = made.get(status, 0) + 1
        if status == "completed":
            db.insert("reviews", {
                "booking_id": bid, "vehicle_id": vid, "company_id": vehicle["company_id"],
                "user_id": customer_id, "rating_overall": random.choice([5, 5, 4, 4, 3]),
                "rating_vehicle": random.choice([5, 4]), "rating_service": random.choice([5, 4]),
                "rating_cleanliness": random.choice([5, 4, 3]),
                "rating_communication": random.choice([5, 4]),
                "comment": REVIEW_TEXTS[i % len(REVIEW_TEXTS)],
                "status": "published", "created_at": now_str()})
    out["bookings"] = made

    # refresh aggregate ratings
    for vid in vehicle_ids:
        r = db.one("""SELECT COALESCE(AVG(rating_overall),0) AS a, COUNT(*) AS n FROM reviews
                       WHERE vehicle_id = ? AND status='published'""", (vid,))
        db.update("vehicles", vid, {"rating_avg": round(r["a"], 2), "rating_count": r["n"]})
    for cid in company_ids:
        r = db.one("""SELECT COALESCE(AVG(rating_overall),0) AS a, COUNT(*) AS n FROM reviews
                       WHERE company_id = ? AND status='published'""", (cid,))
        db.update("rental_companies", cid, {"rating_avg": round(r["a"], 2), "rating_count": r["n"]})

    # support ticket sample
    if not db.one("SELECT 1 FROM support_tickets"):
        tid = db.insert("support_tickets", {
            "reference": "SUP-DEMO01", "user_id": customer_ids[0], "category": "question",
            "subject": "Puis-je ajouter un second conducteur ?", "status": "open",
            "created_at": now_str(), "updated_at": now_str()})
        db.insert("support_messages", {
            "ticket_id": tid, "user_id": customer_ids[0], "is_staff": 0,
            "body": "Bonjour, je souhaite ajouter mon frère comme second conducteur. "
                    "Est-ce possible et à quel tarif ?", "created_at": now_str()})
    out["accounts"] = {
        "admin": {"email": admin_email, "password": admin_pw},
        "fleet_owner": {"email": "loueur1.demo@rentdz.test", "password": DEMO_PASSWORD},
        "customer": {"email": "amine.demo@rentdz.test", "password": DEMO_PASSWORD},
        "support": {"email": "support.demo@rentdz.test", "password": DEMO_PASSWORD},
        "finance": {"email": "finance.demo@rentdz.test", "password": DEMO_PASSWORD},
    }
    return out


def purge() -> dict:
    """Remove every demo row. Used to prove demo data cannot leak into production."""
    counts = {}
    counts["bookings"] = db.scalar("SELECT COUNT(*) FROM bookings WHERE is_demo = 1", (), 0)
    db.execute("""DELETE FROM vehicle_day_locks WHERE booking_id IN
                  (SELECT id FROM bookings WHERE is_demo = 1)""")
    db.execute("DELETE FROM bookings WHERE is_demo = 1")
    counts["vehicles"] = db.scalar("SELECT COUNT(*) FROM vehicles WHERE is_demo = 1", (), 0)
    db.execute("DELETE FROM vehicles WHERE is_demo = 1")
    counts["companies"] = db.scalar("SELECT COUNT(*) FROM rental_companies WHERE is_demo = 1", (), 0)
    db.execute("DELETE FROM rental_companies WHERE is_demo = 1")
    counts["users"] = db.scalar("SELECT COUNT(*) FROM users WHERE is_demo = 1", (), 0)
    db.execute("DELETE FROM users WHERE is_demo = 1")
    return counts
