"""The 58 Algerian wilayas, sample communes, agency and airport locations."""
from __future__ import annotations
from .. import db
from ..security import slugify, now_str

# (code, name_fr, name_ar, lat, lng)
WILAYAS = [
    (1,"Adrar","أدرار",27.8743,-0.2939),(2,"Chlef","الشلف",36.1647,1.3317),
    (3,"Laghouat","الأغواط",33.8000,2.8650),(4,"Oum El Bouaghi","أم البواقي",35.8776,7.1135),
    (5,"Batna","باتنة",35.5560,6.1741),(6,"Béjaïa","بجاية",36.7509,5.0567),
    (7,"Biskra","بسكرة",34.8515,5.7280),(8,"Béchar","بشار",31.6167,-2.2167),
    (9,"Blida","البليدة",36.4703,2.8277),(10,"Bouira","البويرة",36.3739,3.9020),
    (11,"Tamanrasset","تمنراست",22.7850,5.5228),(12,"Tébessa","تبسة",35.4042,8.1242),
    (13,"Tlemcen","تلمسان",34.8783,-1.3150),(14,"Tiaret","تيارت",35.3711,1.3170),
    (15,"Tizi Ouzou","تيزي وزو",36.7169,4.0497),(16,"Alger","الجزائر",36.7538,3.0588),
    (17,"Djelfa","الجلفة",34.6703,3.2630),(18,"Jijel","جيجل",36.8210,5.7667),
    (19,"Sétif","سطيف",36.1898,5.4108),(20,"Saïda","سعيدة",34.8303,0.1517),
    (21,"Skikda","سكيكدة",36.8762,6.9095),(22,"Sidi Bel Abbès","سيدي بلعباس",35.1875,-0.6417),
    (23,"Annaba","عنابة",36.9000,7.7667),(24,"Guelma","قالمة",36.4620,7.4260),
    (25,"Constantine","قسنطينة",36.3650,6.6147),(26,"Médéa","المدية",36.2675,2.7539),
    (27,"Mostaganem","مستغانم",35.9315,0.0892),(28,"M'Sila","المسيلة",35.7050,4.5419),
    (29,"Mascara","معسكر",35.3960,0.1400),(30,"Ouargla","ورقلة",31.9527,5.3335),
    (31,"Oran","وهران",35.6969,-0.6331),(32,"El Bayadh","البيض",33.6800,1.0200),
    (33,"Illizi","إليزي",26.4833,8.4667),(34,"Bordj Bou Arreridj","برج بوعريريج",36.0731,4.7614),
    (35,"Boumerdès","بومرداس",36.7660,3.4770),(36,"El Tarf","الطارف",36.7672,8.3136),
    (37,"Tindouf","تندوف",27.6742,-8.1478),(38,"Tissemsilt","تيسمسيلت",35.6072,1.8111),
    (39,"El Oued","الوادي",33.3683,6.8675),(40,"Khenchela","خنشلة",35.4361,7.1436),
    (41,"Souk Ahras","سوق أهراس",36.2864,7.9511),(42,"Tipaza","تيبازة",36.5892,2.4472),
    (43,"Mila","ميلة",36.4503,6.2644),(44,"Aïn Defla","عين الدفلى",36.2639,1.9681),
    (45,"Naâma","النعامة",33.2667,-0.3000),(46,"Aïn Témouchent","عين تموشنت",35.2981,-1.1400),
    (47,"Ghardaïa","غرداية",32.4909,3.6733),(48,"Relizane","غليزان",35.7372,0.5556),
    (49,"Timimoun","تيميمون",29.2639,0.2306),(50,"Bordj Badji Mokhtar","برج باجي مختار",21.3256,0.9556),
    (51,"Ouled Djellal","أولاد جلال",34.4167,5.0667),(52,"Béni Abbès","بني عباس",30.1300,-2.1700),
    (53,"In Salah","عين صالح",27.1936,2.4608),(54,"In Guezzam","عين قزام",19.5686,5.7722),
    (55,"Touggourt","تقرت",33.1000,6.0667),(56,"Djanet","جانت",24.5542,9.4842),
    (57,"El M'Ghair","المغير",33.9500,5.9167),(58,"El Meniaa","المنيعة",30.5833,2.8833),
]

# wilaya_id -> communes
COMMUNES = {
    16: ["Alger-Centre","Bab El Oued","Hydra","Bir Mourad Raïs","El Harrach","Bab Ezzouar",
         "Dar El Beïda","Chéraga","Draria","Birtouta","Kouba","Hussein Dey"],
    31: ["Oran","Es Sénia","Bir El Djir","Aïn El Turck","Arzew","Gdyel","Mers El Kébir"],
    25: ["Constantine","El Khroub","Aïn Smara","Hamma Bouziane","Didouche Mourad"],
    23: ["Annaba","El Bouni","Sidi Amar","El Hadjar","Seraïdi"],
    9:  ["Blida","Boufarik","Ouled Yaïch","Bougara","Larbaâ"],
    19: ["Sétif","El Eulma","Aïn Oulmene","Bougaa","Aïn Arnat"],
    13: ["Tlemcen","Mansourah","Chetouane","Remchi","Ghazaouet"],
    6:  ["Béjaïa","Akbou","Tichy","Aokas","El Kseur"],
    5:  ["Batna","Barika","Merouana","Tazoult","N'Gaous"],
    15: ["Tizi Ouzou","Azazga","Draâ Ben Khedda","Boghni","Tigzirt"],
    18: ["Jijel","Taher","El Milia","Ziama Mansouriah"],
    42: ["Tipaza","Cherchell","Kolea","Hadjout","Bou Ismaïl"],
    35: ["Boumerdès","Boudouaou","Bordj Menaïel","Dellys","Reghaïa"],
    2:  ["Chlef","Ténès","Ouled Farès","Boukadir"],
    27: ["Mostaganem","Aïn Tédelès","Hassi Mameche","Mazagran"],
    21: ["Skikda","Azzaba","Collo","El Harrouch"],
    47: ["Ghardaïa","Metlili","Berriane","El Guerrara"],
    7:  ["Biskra","Tolga","Sidi Okba","Ouled Djellal"],
    30: ["Ouargla","Hassi Messaoud","Rouissat","N'Goussa"],
    1:  ["Adrar","Reggane","Aoulef","Timimoun"],
}

# (wilaya_id, name_fr, name_ar, kind, iata, extra_fee, address)
LOCATIONS = [
    (16,"Aéroport d'Alger Houari Boumediene","مطار الجزائر هواري بومدين","airport","ALG",1500,"Dar El Beïda, Alger"),
    (31,"Aéroport d'Oran Ahmed Ben Bella","مطار وهران أحمد بن بلة","airport","ORN",1200,"Es Sénia, Oran"),
    (25,"Aéroport de Constantine Mohamed Boudiaf","مطار قسنطينة محمد بوضياف","airport","CZL",1200,"Aïn El Bey, Constantine"),
    (23,"Aéroport d'Annaba Rabah Bitat","مطار عنابة رابح بيطاط","airport","AAE",1000,"El Bouni, Annaba"),
    (13,"Aéroport de Tlemcen Zenata","مطار تلمسان زناتة","airport","TLM",1000,"Zenata, Tlemcen"),
    (19,"Aéroport de Sétif 8 Mai 1945","مطار سطيف 8 ماي 1945","airport","QSF",1000,"Aïn Arnat, Sétif"),
    (6,"Aéroport de Béjaïa Soummam","مطار بجاية الصومام","airport","BJA",1000,"Béjaïa"),
    (47,"Aéroport de Ghardaïa Noumérat","مطار غرداية نوميرات","airport","GHA",1200,"Ghardaïa"),
    (30,"Aéroport de Ouargla Aïn Beïda","مطار ورقلة عين البيضاء","airport","OGX",1200,"Ouargla"),
    (16,"Agence Alger-Centre","وكالة الجزائر الوسطى","office",None,0,"Rue Didouche Mourad, Alger-Centre"),
    (16,"Agence Bab Ezzouar","وكالة باب الزوار","office",None,0,"Bab Ezzouar, Alger"),
    (16,"Gare routière du Caroubier","محطة القروبي","station",None,500,"Hussein Dey, Alger"),
    (31,"Agence Oran Centre","وكالة وهران المركز","office",None,0,"Boulevard de la Soummam, Oran"),
    (25,"Agence Constantine Centre","وكالة قسنطينة المركز","office",None,0,"Rue Larbi Ben M'hidi, Constantine"),
    (23,"Agence Annaba Cours de la Révolution","وكالة عنابة","office",None,0,"Cours de la Révolution, Annaba"),
    (9,"Agence Blida","وكالة البليدة","office",None,0,"Boulevard Larbi Tebessi, Blida"),
    (19,"Agence Sétif","وكالة سطيف","office",None,0,"Avenue du 8 Mai 1945, Sétif"),
    (6,"Agence Béjaïa Port","وكالة بجاية الميناء","office",None,0,"Quartier du port, Béjaïa"),
    (15,"Agence Tizi Ouzou","وكالة تيزي وزو","office",None,0,"Nouvelle ville, Tizi Ouzou"),
    (5,"Agence Batna","وكالة باتنة","office",None,0,"Avenue de l'Indépendance, Batna"),
    (13,"Agence Tlemcen","وكالة تلمسان","office",None,0,"Place des Martyrs, Tlemcen"),
    (42,"Agence Tipaza","وكالة تيبازة","office",None,0,"Centre-ville, Tipaza"),
    (35,"Agence Boumerdès","وكالة بومرداس","office",None,0,"Centre-ville, Boumerdès"),
    (18,"Agence Jijel","وكالة جيجل","office",None,0,"Centre-ville, Jijel"),
    (27,"Agence Mostaganem","وكالة مستغانم","office",None,0,"Centre-ville, Mostaganem"),
    (21,"Agence Skikda","وكالة سكيكدة","office",None,0,"Centre-ville, Skikda"),
    (47,"Agence Ghardaïa","وكالة غرداية","office",None,0,"Centre-ville, Ghardaïa"),
    (7,"Agence Biskra","وكالة بسكرة","office",None,0,"Centre-ville, Biskra"),
    (30,"Agence Hassi Messaoud","وكالة حاسي مسعود","office",None,0,"Hassi Messaoud, Ouargla"),
    (1,"Agence Adrar","وكالة أدرار","office",None,0,"Centre-ville, Adrar"),
]

CATEGORIES = [
    ("economy","Économique","اقتصادية","Economy",1),
    ("compact","Compacte","مدمجة","Compact",2),
    ("sedan","Berline","سيدان","Sedan",3),
    ("suv","SUV","دفع رباعي حضري","SUV",4),
    ("family","Familiale","عائلية","Family",5),
    ("luxury","Luxe","فخمة","Luxury",6),
    ("van","Utilitaire / Van","شاحنة صغيرة","Van",7),
    ("4x4","4x4","دفع رباعي","4x4",8),
]

FEATURES = [
    ("air_conditioning","Climatisation","تكييف الهواء","Air conditioning","❄"),
    ("bluetooth","Bluetooth","بلوتوث","Bluetooth","📶"),
    ("gps","GPS","نظام تحديد المواقع","GPS","🧭"),
    ("usb","Port USB","منفذ USB","USB port","🔌"),
    ("cruise_control","Régulateur de vitesse","مثبت السرعة","Cruise control","⏱"),
    ("child_seat","Siège enfant","مقعد أطفال","Child seat","🧒"),
    ("backup_camera","Caméra de recul","كاميرا خلفية","Backup camera","📷"),
    ("android_auto","Android Auto","أندرويد أوتو","Android Auto","🤖"),
    ("apple_carplay","Apple CarPlay","آبل كار بلاي","Apple CarPlay","🍎"),
    ("parking_sensors","Radar de recul","حساسات الركن","Parking sensors","📡"),
    ("abs","ABS","نظام ABS","ABS","🛞"),
    ("airbags","Airbags","أكياس هوائية","Airbags","🎈"),
    ("spare_wheel","Roue de secours","عجلة احتياطية","Spare wheel","🛞"),
    ("first_aid","Trousse de secours","حقيبة إسعاف","First-aid kit","🩹"),
]

SERVICES = [
    ("additional_driver","Conducteur additionnel","سائق إضافي","Additional driver","per_booking",2500,2),
    ("child_seat","Siège enfant","مقعد أطفال","Child seat","per_day",500,3),
    ("gps_device","GPS portable","جهاز GPS","Portable GPS","per_day",400,1),
    ("delivery","Livraison du véhicule","توصيل السيارة","Vehicle delivery","per_booking",3000,1),
    ("airport_pickup","Prise en charge à l'aéroport","الاستلام من المطار","Airport pickup","per_booking",1500,1),
    ("extra_insurance","Assurance tous risques","تأمين شامل","Full insurance","per_day",1200,1),
    ("wifi","Modem Wi-Fi 4G","مودم واي فاي","4G Wi-Fi modem","per_day",600,1),
]


def seed() -> dict:
    counts = {"wilayas": 0, "communes": 0, "locations": 0, "categories": 0,
              "features": 0, "services": 0}
    for wid, fr, ar, lat, lng in WILAYAS:
        db.execute("""INSERT INTO wilayas (id, code, slug, name_fr, name_ar, name_en, lat, lng, active)
                      VALUES (?,?,?,?,?,?,?,?,1)
                      ON CONFLICT(id) DO UPDATE SET name_fr=excluded.name_fr, name_ar=excluded.name_ar""",
                   (wid, f"{wid:02d}", slugify(fr), fr, ar, fr, lat, lng))
        counts["wilayas"] += 1
    for wid, names in COMMUNES.items():
        for name in names:
            try:
                db.insert("communes", {"wilaya_id": wid, "slug": slugify(name),
                                       "name_fr": name, "name_ar": name})
                counts["communes"] += 1
            except Exception:
                pass
    for wid, fr, ar, kind, iata, fee, address in LOCATIONS:
        slug = slugify(fr)
        if db.one("SELECT 1 FROM locations WHERE slug = ?", (slug,)):
            continue
        wl = db.one("SELECT lat, lng FROM wilayas WHERE id = ?", (wid,))
        db.insert("locations", {"wilaya_id": wid, "kind": kind, "slug": slug,
                                "name_fr": fr, "name_ar": ar, "name_en": fr,
                                "address": address, "iata_code": iata, "extra_fee": fee,
                                "lat": wl["lat"], "lng": wl["lng"], "active": 1,
                                "created_at": now_str()})
        counts["locations"] += 1
    for code, fr, ar, en, sort in CATEGORIES:
        db.execute("""INSERT INTO vehicle_categories (code, slug, name_fr, name_ar, name_en, sort, active)
                      VALUES (?,?,?,?,?,?,1) ON CONFLICT(code) DO UPDATE SET name_fr=excluded.name_fr""",
                   (code, slugify(code), fr, ar, en, sort))
        counts["categories"] += 1
    for code, fr, ar, en, icon in FEATURES:
        db.execute("""INSERT INTO features (code, name_fr, name_ar, name_en, icon) VALUES (?,?,?,?,?)
                      ON CONFLICT(code) DO UPDATE SET name_fr=excluded.name_fr""",
                   (code, fr, ar, en, icon))
        counts["features"] += 1
    for code, fr, ar, en, ptype, price, maxq in SERVICES:
        if db.one("SELECT 1 FROM services WHERE company_id IS NULL AND code = ?", (code,)):
            continue
        db.insert("services", {"company_id": None, "code": code, "name_fr": fr, "name_ar": ar,
                               "name_en": en, "price_type": ptype, "price": price,
                               "max_qty": maxq, "active": 1})
        counts["services"] += 1
    return counts
