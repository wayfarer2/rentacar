"""
Private documents. Files live outside any served directory, with random names.
Download requires a session, a permission check, AND a short-lived signed token.
Every access attempt (allowed or denied) is logged.
"""
from __future__ import annotations
from pathlib import Path
from .. import db
from ..config import Config, DOCS_DIR
from ..http import Forbidden, NotFound, BadRequest
from ..security import (safe_upload, sha256_hex, sign, unsign, now_str, ValidationError,
                        clean_text, now)
from . import settings_service as S
from .audit import record as audit
from .notification_service import notify

KINDS = ("driver_license", "id_card", "passport", "company_registry",
         "vehicle_registration", "other")


def upload(*, user: dict, kind: str, filename: str, data: bytes,
           booking_id: int | None = None, expires_at: str | None = None,
           ip: str = None) -> dict:
    if kind not in KINDS:
        raise ValidationError({"kind": "Type de document non autorisé."})
    mime, safe_name = safe_upload(data, filename, Config.ALLOWED_DOC_MIMES, Config.MAX_UPLOAD_MB)
    if booking_id:
        owner = db.scalar("SELECT customer_user_id FROM bookings WHERE id = ?", (booking_id,))
        if owner != user["id"]:
            raise Forbidden("Vous ne pouvez joindre un document qu'à vos propres réservations.")
    user_dir = DOCS_DIR / str(user["id"])
    user_dir.mkdir(parents=True, exist_ok=True)
    target = user_dir / safe_name
    target.write_bytes(data)
    try:
        target.chmod(0o600)
    except Exception:
        pass
    retention = int(S.get("document_retention_days", 1095) or 1095)
    doc_id = db.insert("documents", {
        "owner_user_id": user["id"], "booking_id": booking_id, "kind": kind,
        "status": "pending", "storage_path": f"{user['id']}/{safe_name}",
        "original_name": clean_text(filename, 120), "mime": mime,
        "size_bytes": len(data), "sha256": sha256_hex(data),
        "expires_at": expires_at,
        "retention_delete_at": (now().date().fromordinal(now().date().toordinal() + retention)).isoformat(),
        "created_at": now_str()})
    log_access(doc_id, user["id"], "upload", True, ip)
    audit("document.uploaded", actor=user, target_type="document", target_id=doc_id, ip=ip,
          metadata={"kind": kind, "size": len(data), "mime": mime})
    return get(doc_id, requester=user, ip=ip)


def log_access(document_id: int, user_id, action: str, allowed: bool, ip: str = None) -> None:
    db.insert("document_access_log", {"document_id": document_id, "user_id": user_id,
                                      "action": action, "allowed": 1 if allowed else 0,
                                      "ip": ip, "created_at": now_str()})


def _can_access(doc: dict, requester: dict) -> bool:
    if not requester:
        return False
    if doc["owner_user_id"] == requester["id"]:
        return True
    perms = requester.get("permissions", set())
    if "document.view.all" in perms or "document.review" in perms:
        return True
    # Fleet side may see documents attached to a booking on their own vehicle
    if doc.get("booking_id") and "booking.view.company" in perms:
        company_id = db.scalar("SELECT company_id FROM bookings WHERE id = ?", (doc["booking_id"],))
        return company_id in requester.get("company_ids", [])
    return False


def get(document_id: int, *, requester: dict, ip: str = None) -> dict:
    row = db.one("SELECT * FROM documents WHERE id = ? AND deleted_at IS NULL", (document_id,))
    if not row:
        raise NotFound("Document introuvable.")
    doc = dict(row)
    if not _can_access(doc, requester):
        log_access(document_id, requester["id"] if requester else None, "view_metadata", False, ip)
        raise NotFound("Document introuvable.")      # never confirm existence
    log_access(document_id, requester["id"], "view_metadata", True, ip)
    return public(doc, requester)


def public(doc: dict, requester: dict | None = None) -> dict:
    ttl = int(S.get("document_url_ttl_seconds", 300) or 300)
    out = {k: doc[k] for k in ("id", "kind", "status", "original_name", "mime", "size_bytes",
                               "created_at", "reviewed_at", "reject_reason", "expires_at",
                               "booking_id", "owner_user_id")}
    out["download_token"] = sign(f"doc:{doc['id']}:{requester['id']}", ttl) if requester else None
    out["download_url"] = (f"/api/v1/documents/{doc['id']}/download?token={out['download_token']}"
                           if out["download_token"] else None)
    out["expires_in"] = ttl
    return out


def read_file(document_id: int, token: str, requester: dict, ip: str = None) -> tuple[bytes, str, str]:
    payload = unsign(token or "")
    expected = f"doc:{document_id}:{requester['id'] if requester else 0}"
    if payload != expected:
        log_access(document_id, requester["id"] if requester else None, "download", False, ip)
        raise Forbidden("Lien de téléchargement invalide ou expiré.")
    row = db.one("SELECT * FROM documents WHERE id = ? AND deleted_at IS NULL", (document_id,))
    if not row:
        raise NotFound("Document introuvable.")
    doc = dict(row)
    if not _can_access(doc, requester):
        log_access(document_id, requester["id"], "download", False, ip)
        raise NotFound("Document introuvable.")
    path = (DOCS_DIR / doc["storage_path"]).resolve()
    if not str(path).startswith(str(DOCS_DIR.resolve())) or not path.is_file():
        raise NotFound("Fichier introuvable.")
    log_access(document_id, requester["id"], "download", True, ip)
    audit("document.downloaded", actor=requester, target_type="document", target_id=document_id, ip=ip)
    return path.read_bytes(), doc["mime"], doc["original_name"]


def review(document_id: int, *, decision: str, reviewer: dict, reason: str = "",
           ip: str = None) -> dict:
    if decision not in ("approved", "rejected"):
        raise BadRequest("Décision invalide.")
    row = db.one("SELECT * FROM documents WHERE id = ? AND deleted_at IS NULL", (document_id,))
    if not row:
        raise NotFound("Document introuvable.")
    if decision == "rejected" and not reason.strip():
        raise ValidationError({"reason": "Indiquez le motif du refus."})
    db.update("documents", document_id, {
        "status": decision, "reviewed_by": reviewer["id"], "reviewed_at": now_str(),
        "reject_reason": clean_text(reason, 300) if decision == "rejected" else None})
    audit(f"document.{decision}", actor=reviewer, target_type="document", target_id=document_id,
          ip=ip, metadata={"reason": reason})
    notify(row["owner_user_id"],
           "document_approved" if decision == "approved" else "document_rejected",
           {"kind": row["kind"], "reason": reason or "-"})
    return get(document_id, requester=reviewer, ip=ip)


def list_for_user(user_id: int, requester: dict) -> list[dict]:
    if user_id != requester["id"] and not ({"document.view.all", "document.review"}
                                           & requester.get("permissions", set())):
        raise Forbidden()
    rows = db.query("""SELECT * FROM documents WHERE owner_user_id = ? AND deleted_at IS NULL
                        ORDER BY created_at DESC""", (user_id,))
    return [public(dict(r), requester) for r in rows]


def pending_queue(limit: int = 50, offset: int = 0) -> dict:
    total = db.scalar("SELECT COUNT(*) FROM documents WHERE status='pending' AND deleted_at IS NULL", (), 0)
    rows = db.query(
        """SELECT d.id, d.kind, d.status, d.original_name, d.mime, d.size_bytes, d.created_at,
                  d.booking_id, u.full_name AS owner_name, u.email AS owner_email, d.owner_user_id
             FROM documents d JOIN users u ON u.id = d.owner_user_id
            WHERE d.status='pending' AND d.deleted_at IS NULL
            ORDER BY d.created_at LIMIT ? OFFSET ?""", (limit, offset))
    return {"items": db.rows_to_dicts(rows), "total": total}


def purge_expired(dry_run: bool = False) -> int:
    """Retention enforcement: shred files past their retention date."""
    rows = db.query("""SELECT id, storage_path FROM documents
                        WHERE deleted_at IS NULL AND retention_delete_at IS NOT NULL
                          AND retention_delete_at < date('now')""")
    n = 0
    for r in rows:
        if dry_run:
            n += 1
            continue
        p = DOCS_DIR / r["storage_path"]
        try:
            p.unlink(missing_ok=True)
        except Exception:
            pass
        db.update("documents", r["id"], {"deleted_at": now_str(), "status": "expired"})
        audit("document.purged", target_type="document", target_id=r["id"],
              metadata={"reason": "retention"})
        n += 1
    return n
