"""Vehicle catalogue: search (availability-aware, paginated), CRUD, photos, approval."""
from __future__ import annotations
from datetime import timedelta
from pathlib import Path
from .. import db
from ..config import Config, UPLOAD_DIR
from ..http import Forbidden, NotFound, Conflict, BadRequest
from ..security import (ValidationError, as_int, as_choice, clean_text, slugify, safe_upload,
                        now_str, now)
from . import availability as A
from . import settings_service as S
from .audit import record as audit
from .notification_service import notify, notify_admins

CATEGORIES = ("economy", "compact", "sedan", "suv", "luxury", "family", "van", "4x4")
TRANSMISSIONS = ("manual", "automatic")
FUELS = ("petrol", "diesel", "hybrid", "electric", "gpl")
SORTS = {
    "recommended": "v.rating_avg DESC, v.bookings_count DESC, v.daily_price ASC",
    "price_asc": "v.daily_price ASC",
    "price_desc": "v.daily_price DESC",
    "rating": "v.rating_avg DESC, v.rating_count DESC",
    "newest": "v.created_at DESC",
}

PUBLIC_COLUMNS = """v.id, v.slug, v.brand, v.model, v.year, v.transmission, v.fuel, v.seats,
    v.doors, v.color, v.daily_price, v.weekly_price, v.monthly_price, v.weekend_price,
    v.deposit, v.min_days, v.max_days, v.km_included_per_day, v.extra_km_price, v.fuel_policy,
    v.description, v.status, v.rating_avg, v.rating_count, v.bookings_count, v.created_at,
    cat.code AS category, cat.name_fr AS category_label,
    c.id AS company_id, c.name AS company_name, c.slug AS company_slug,
    c.rating_avg AS company_rating,
    w.id AS wilaya_id, w.name_fr AS wilaya, w.slug AS wilaya_slug,
    l.id AS location_id, l.name_fr AS location_name, l.kind AS location_kind"""
# NOTE: registration_number is deliberately absent from public projections.


def search(*, pickup_date=None, return_date=None, wilaya=None, location_id=None,
           category=None, transmission=None, fuel=None, seats=None,
           price_min=None, price_max=None, features=None, sort="recommended",
           limit=12, offset=0, company_id=None) -> dict:
    A.release_expired_holds()
    limit = max(1, min(int(limit or 12), 48))
    offset = max(0, int(offset or 0))
    where = ["v.deleted_at IS NULL", "v.approval_status = 'approved'",
             "v.status NOT IN ('inactive','unavailable')", "c.status = 'approved'",
             "c.deleted_at IS NULL"]
    params: list = []

    if company_id:
        where.append("v.company_id = ?"); params.append(company_id)
    if wilaya:
        where.append("(w.slug = ? OR w.id = ?)"); params += [str(wilaya), wilaya if str(wilaya).isdigit() else -1]
    if location_id:
        where.append("l.id = ?"); params.append(location_id)
    if category:
        cats = [c for c in (category if isinstance(category, list) else [category]) if c in CATEGORIES]
        if cats:
            where.append(f"cat.code IN ({','.join('?' * len(cats))})"); params += cats
    if transmission in TRANSMISSIONS:
        where.append("v.transmission = ?"); params.append(transmission)
    if fuel:
        fs = [f for f in (fuel if isinstance(fuel, list) else [fuel]) if f in FUELS]
        if fs:
            where.append(f"v.fuel IN ({','.join('?' * len(fs))})"); params += fs
    if seats:
        s = int(seats)
        where.append("v.seats >= ?" if s >= 7 else "v.seats = ?"); params.append(s)
    if price_min is not None:
        where.append("v.daily_price >= ?"); params.append(int(price_min))
    if price_max is not None:
        where.append("v.daily_price <= ?"); params.append(int(price_max))

    feature_codes = [f for f in (features or []) if f]
    if feature_codes:
        where.append(f"""(SELECT COUNT(*) FROM vehicle_features vf
                            JOIN features f ON f.id = vf.feature_id
                           WHERE vf.vehicle_id = v.id
                             AND f.code IN ({','.join('?' * len(feature_codes))})) = ?""")
        params += feature_codes + [len(feature_codes)]

    # availability: never show a vehicle that cannot be rented for these dates
    if pickup_date and return_date:
        days = A.day_range(pickup_date, return_date)
        if days:
            frag, extra = A.unavailable_sql_fragment(days)
            where.append(frag.replace(" AND ", "", 1).strip())
            params += extra

    base_from = """FROM vehicles v
        JOIN rental_companies c ON c.id = v.company_id
        JOIN vehicle_categories cat ON cat.id = v.category_id
        LEFT JOIN locations l ON l.id = v.primary_location_id
        LEFT JOIN wilayas w ON w.id = COALESCE(l.wilaya_id, c.wilaya_id)"""
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) {base_from}{where_sql}", tuple(params), 0)
    order = SORTS.get(sort, SORTS["recommended"])
    rows = db.query(f"""SELECT {PUBLIC_COLUMNS},
            (SELECT path FROM vehicle_images WHERE vehicle_id = v.id
              ORDER BY is_primary DESC, sort LIMIT 1) AS image
        {base_from}{where_sql} ORDER BY {order} LIMIT ? OFFSET ?""",
        tuple(params + [limit, offset]))
    items = db.rows_to_dicts(rows)
    if pickup_date and return_date:
        days_count = A.rental_days(f"{pickup_date} 10:00", f"{return_date} 10:00")
        for it in items:
            it["estimated_total"] = it["daily_price"] * max(1, days_count)
            it["estimated_days"] = max(1, days_count)
    return {"items": items, "total": total, "limit": limit, "offset": offset,
            "has_more": offset + len(items) < total}


def get_public(id_or_slug) -> dict | None:
    row = db.one(f"""SELECT {PUBLIC_COLUMNS}, c.phone AS company_phone, c.description AS company_description,
                            l.address AS location_address, l.lat, l.lng
        FROM vehicles v
        JOIN rental_companies c ON c.id = v.company_id
        JOIN vehicle_categories cat ON cat.id = v.category_id
        LEFT JOIN locations l ON l.id = v.primary_location_id
        LEFT JOIN wilayas w ON w.id = COALESCE(l.wilaya_id, c.wilaya_id)
       WHERE (v.slug = ? OR v.id = ?) AND v.deleted_at IS NULL""",
        (str(id_or_slug), id_or_slug if str(id_or_slug).isdigit() else -1))
    if not row:
        return None
    v = dict(row)
    if v["status"] == "inactive":
        return None
    v["images"] = [dict(r) for r in db.query(
        "SELECT path, alt, is_primary FROM vehicle_images WHERE vehicle_id = ? ORDER BY is_primary DESC, sort",
        (v["id"],))]
    v["features"] = [dict(r) for r in db.query(
        """SELECT f.code, f.name_fr, f.name_ar, f.name_en, f.icon FROM vehicle_features vf
             JOIN features f ON f.id = vf.feature_id WHERE vf.vehicle_id = ? ORDER BY f.id""",
        (v["id"],))]
    v["services"] = db.rows_to_dicts(db.query(
        """SELECT id, code, name_fr, name_ar, name_en, price, price_type, max_qty FROM services
            WHERE active = 1 AND (company_id IS NULL OR company_id = ?) ORDER BY price""",
        (v["company_id"],)))
    v["reviews"] = db.rows_to_dicts(db.query(
        """SELECT r.rating_overall, r.comment, r.created_at, u.full_name AS author
             FROM reviews r JOIN users u ON u.id = r.user_id
            WHERE r.vehicle_id = ? AND r.status='published' ORDER BY r.created_at DESC LIMIT 10""",
        (v["id"],)))
    v["locations"] = db.rows_to_dicts(db.query(
        """SELECT id, name_fr, kind, extra_fee, address FROM locations
            WHERE active = 1 AND (company_id = ? OR company_id IS NULL) ORDER BY kind, name_fr""",
        (v["company_id"],)))
    v["unavailable_days"] = [r["day"] for r in db.query(
        """SELECT day FROM vehicle_day_locks WHERE vehicle_id = ? AND day >= date('now')
            AND day <= date('now','+180 days') ORDER BY day""", (v["id"],))]
    return v


def assert_can_manage(vehicle_id: int, req) -> dict:
    row = db.one("SELECT * FROM vehicles WHERE id = ? AND deleted_at IS NULL", (vehicle_id,))
    if not row:
        raise NotFound("Véhicule introuvable.")
    v = dict(row)
    if req.has_perm("vehicle.view.all") and req.has_perm("booking.manage.all"):
        return v
    if not req.has_perm("vehicle.manage.company") or v["company_id"] not in req.company_ids():
        raise NotFound("Véhicule introuvable.")     # no existence leak across tenants
    return v


def _validate_payload(data: dict, *, partial=False) -> dict:
    out: dict = {}
    def need(key):
        return (not partial) or key in data

    if need("brand"):
        out["brand"] = clean_text(data.get("brand"), 60)
        if len(out["brand"]) < 2:
            raise ValidationError({"brand": "Marque obligatoire."})
    if need("model"):
        out["model"] = clean_text(data.get("model"), 60)
        if len(out["model"]) < 1:
            raise ValidationError({"model": "Modèle obligatoire."})
    if need("year"):
        out["year"] = as_int(data.get("year"), "year", minimum=1990, maximum=now().year + 1)
    if need("category"):
        code = as_choice(data.get("category"), "category", CATEGORIES)
        cid = db.scalar("SELECT id FROM vehicle_categories WHERE code = ?", (code,))
        if not cid:
            raise ValidationError({"category": "Catégorie inconnue."})
        out["category_id"] = cid
    if need("transmission"):
        out["transmission"] = as_choice(data.get("transmission"), "transmission", TRANSMISSIONS)
    if need("fuel"):
        out["fuel"] = as_choice(data.get("fuel"), "fuel", FUELS)
    if need("seats"):
        out["seats"] = as_int(data.get("seats"), "seats", minimum=1, maximum=20)
    if need("doors"):
        out["doors"] = as_int(data.get("doors"), "doors", minimum=2, maximum=6, required=False, default=5)
    if "color" in data:
        out["color"] = clean_text(data.get("color"), 30)
    if "mileage" in data:
        out["mileage"] = as_int(data.get("mileage"), "mileage", minimum=0, maximum=2_000_000,
                                required=False, default=0)
    if "registration_number" in data:
        out["registration_number"] = clean_text(data.get("registration_number"), 30)
    if "description" in data:
        out["description"] = clean_text(data.get("description"), 3000)
    if need("daily_price"):
        out["daily_price"] = as_int(data.get("daily_price"), "daily_price", minimum=500, maximum=2_000_000)
    for key in ("weekly_price", "monthly_price", "weekend_price"):
        if key in data:
            out[key] = as_int(data.get(key), key, minimum=0, maximum=50_000_000,
                              required=False, default=None) or None
    if "deposit" in data:
        out["deposit"] = as_int(data.get("deposit"), "deposit", minimum=0, maximum=5_000_000,
                                required=False, default=0)
    if "min_days" in data:
        out["min_days"] = as_int(data.get("min_days"), "min_days", minimum=1, maximum=90,
                                 required=False, default=1)
    if "max_days" in data:
        out["max_days"] = as_int(data.get("max_days"), "max_days", minimum=1, maximum=365,
                                 required=False, default=90)
    if out.get("min_days") and out.get("max_days") and out["min_days"] > out["max_days"]:
        raise ValidationError({"min_days": "La durée minimale dépasse la durée maximale."})
    if "km_included_per_day" in data:
        out["km_included_per_day"] = as_int(data.get("km_included_per_day"), "km_included_per_day",
                                            minimum=0, maximum=2000, required=False, default=None)
    if "extra_km_price" in data:
        out["extra_km_price"] = as_int(data.get("extra_km_price"), "extra_km_price", minimum=0,
                                       maximum=100000, required=False, default=0)
    if "primary_location_id" in data and data.get("primary_location_id"):
        out["primary_location_id"] = as_int(data.get("primary_location_id"), "primary_location_id",
                                            minimum=1)
    if "status" in data:
        out["status"] = as_choice(data.get("status"), "status",
                                 ("available", "maintenance", "unavailable", "inactive"))
    return out


def create(*, req, company_id: int, data: dict) -> dict:
    if company_id not in req.company_ids() and not req.has_perm("company.manage.all"):
        raise Forbidden("Vous ne pouvez ajouter un véhicule qu'à votre propre société.")
    company = db.one("SELECT * FROM rental_companies WHERE id = ? AND deleted_at IS NULL", (company_id,))
    if not company:
        raise NotFound("Société introuvable.")
    if company["status"] != "approved" and not req.has_perm("company.manage.all"):
        raise Conflict("Votre société doit être validée avant de publier des véhicules.",
                       code="company_not_approved")
    payload = _validate_payload(data)
    if payload.get("primary_location_id"):
        loc_company = db.scalar("SELECT company_id FROM locations WHERE id = ?",
                                (payload["primary_location_id"],))
        if loc_company not in (None, company_id):
            raise ValidationError({"primary_location_id": "Cette agence n'appartient pas à votre société."})
    if not payload.get("primary_location_id"):
        default_loc = db.one(
            """SELECT id FROM locations
                WHERE active = 1 AND wilaya_id = (SELECT wilaya_id FROM rental_companies WHERE id = ?)
                ORDER BY (company_id = ?) DESC, (company_id IS NULL) DESC, kind='office' DESC, id
                LIMIT 1""", (company_id, company_id))
        if default_loc:
            payload["primary_location_id"] = default_loc["id"]
    payload.update({
        "company_id": company_id,
        "slug": slugify(f"{payload['brand']} {payload['model']} {payload['year']}",
                        extra=str(db.scalar("SELECT COALESCE(MAX(id),0)+1 FROM vehicles", (), 1))),
        "approval_status": "approved" if req.has_perm("vehicle.approve") else "pending",
        "status": payload.get("status", "available"),
        "is_demo": 1 if req.user.get("is_demo") else 0,
        "created_at": now_str(), "updated_at": now_str()})
    with db.transaction():
        vehicle_id = db.insert("vehicles", payload)
        _sync_features(vehicle_id, data.get("features") or [])
    audit("vehicle.created", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"company_id": company_id, "brand": payload["brand"]})
    notify_admins("vehicle_approved" if payload["approval_status"] == "approved" else "booking_received_vendor",
                  {"vehicle": f"{payload['brand']} {payload['model']}"})
    return get_admin(vehicle_id)


def update(*, req, vehicle_id: int, data: dict) -> dict:
    vehicle = assert_can_manage(vehicle_id, req)
    payload = _validate_payload(data, partial=True)
    if not payload and "features" not in data:
        raise BadRequest("Aucune modification fournie.")
    price_changed = ("daily_price" in payload and payload["daily_price"] != vehicle["daily_price"])
    payload["updated_at"] = now_str()
    # A vendor edit re-enters moderation unless the editor can approve directly.
    if not req.has_perm("vehicle.approve") and any(
            k in payload for k in ("brand", "model", "year", "category_id", "description")):
        payload["approval_status"] = "pending"
    with db.transaction():
        db.update("vehicles", vehicle_id, payload)
        if "features" in data:
            _sync_features(vehicle_id, data.get("features") or [])
    audit("vehicle.updated", actor=req.user, target_type="vehicle", target_id=vehicle_id, ip=req.ip,
          metadata={"changed": sorted(payload.keys())})
    if price_changed:
        audit("vehicle.price_changed", actor=req.user, target_type="vehicle", target_id=vehicle_id,
              ip=req.ip, metadata={"from": vehicle["daily_price"], "to": payload["daily_price"]})
    return get_admin(vehicle_id)


def _sync_features(vehicle_id: int, codes: list[str]) -> None:
    db.execute("DELETE FROM vehicle_features WHERE vehicle_id = ?", (vehicle_id,))
    for code in codes[:40]:
        fid = db.scalar("SELECT id FROM features WHERE code = ?", (str(code),))
        if fid:
            db.execute("INSERT OR IGNORE INTO vehicle_features (vehicle_id, feature_id) VALUES (?,?)",
                       (vehicle_id, fid))


def soft_delete(*, req, vehicle_id: int) -> None:
    assert_can_manage(vehicle_id, req)
    active = db.scalar(
        """SELECT COUNT(*) FROM bookings WHERE vehicle_id = ?
            AND status IN ('pending','awaiting_payment','confirmed','active')""", (vehicle_id,), 0)
    if active:
        raise Conflict(f"{active} réservation(s) en cours sur ce véhicule. "
                       "Traitez-les avant de le retirer.", code="vehicle_has_bookings")
    with db.transaction():
        db.update("vehicles", vehicle_id, {"deleted_at": now_str(), "status": "inactive",
                                           "updated_at": now_str()})
        db.execute("DELETE FROM vehicle_day_locks WHERE vehicle_id = ? AND booking_id IS NULL",
                   (vehicle_id,))
    audit("vehicle.deleted", actor=req.user, target_type="vehicle", target_id=vehicle_id, ip=req.ip)


def add_photo(*, req, vehicle_id: int, filename: str, data: bytes, alt: str = "") -> dict:
    assert_can_manage(vehicle_id, req)
    mime, safe_name = safe_upload(data, filename, Config.ALLOWED_IMAGE_MIMES, Config.MAX_UPLOAD_MB)
    count = db.scalar("SELECT COUNT(*) FROM vehicle_images WHERE vehicle_id = ?", (vehicle_id,), 0)
    if count >= 12:
        raise Conflict("Maximum 12 photos par véhicule.", code="photo_limit")
    folder = UPLOAD_DIR / "vehicles" / str(vehicle_id)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / safe_name).write_bytes(data)
    image_id = db.insert("vehicle_images", {
        "vehicle_id": vehicle_id, "path": f"vehicles/{vehicle_id}/{safe_name}",
        "alt": clean_text(alt, 120), "sort": count,
        "is_primary": 1 if count == 0 else 0, "size_bytes": len(data),
        "created_at": now_str()})
    audit("vehicle.photo_added", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"image_id": image_id, "bytes": len(data)})
    return {"id": image_id, "path": f"vehicles/{vehicle_id}/{safe_name}",
            "url": f"/media/vehicles/{vehicle_id}/{safe_name}", "is_primary": count == 0}


def delete_photo(*, req, vehicle_id: int, image_id: int) -> None:
    assert_can_manage(vehicle_id, req)
    row = db.one("SELECT * FROM vehicle_images WHERE id = ? AND vehicle_id = ?", (image_id, vehicle_id))
    if not row:
        raise NotFound("Photo introuvable.")
    try:
        (UPLOAD_DIR / row["path"]).unlink(missing_ok=True)
    except Exception:
        pass
    db.execute("DELETE FROM vehicle_images WHERE id = ?", (image_id,))
    if row["is_primary"]:
        nxt = db.one("SELECT id FROM vehicle_images WHERE vehicle_id = ? ORDER BY sort LIMIT 1",
                     (vehicle_id,))
        if nxt:
            db.update("vehicle_images", nxt["id"], {"is_primary": 1})
    audit("vehicle.photo_deleted", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"image_id": image_id})


def set_approval(*, req, vehicle_id: int, decision: str, reason: str = "") -> dict:
    if decision not in ("approved", "rejected"):
        raise BadRequest("Décision invalide.")
    row = db.one("SELECT * FROM vehicles WHERE id = ? AND deleted_at IS NULL", (vehicle_id,))
    if not row:
        raise NotFound("Véhicule introuvable.")
    if decision == "rejected" and not reason.strip():
        raise ValidationError({"reason": "Indiquez le motif du refus."})
    db.update("vehicles", vehicle_id, {"approval_status": decision,
                                       "reject_reason": clean_text(reason, 300) or None,
                                       "updated_at": now_str()})
    audit(f"vehicle.{decision}", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"reason": reason})
    owner = db.scalar("SELECT owner_user_id FROM rental_companies WHERE id = ?", (row["company_id"],))
    if owner:
        notify(owner, "vehicle_approved" if decision == "approved" else "vehicle_rejected",
               {"vehicle": f"{row['brand']} {row['model']}", "reason": reason or "-"})
    return get_admin(vehicle_id)


def get_admin(vehicle_id: int) -> dict | None:
    row = db.one(f"""SELECT v.*, cat.code AS category, c.name AS company_name
                       FROM vehicles v
                       JOIN vehicle_categories cat ON cat.id = v.category_id
                       JOIN rental_companies c ON c.id = v.company_id
                      WHERE v.id = ?""", (vehicle_id,))
    if not row:
        return None
    v = dict(row)
    v["images"] = db.rows_to_dicts(db.query(
        "SELECT id, path, alt, is_primary, sort FROM vehicle_images WHERE vehicle_id = ? ORDER BY sort",
        (vehicle_id,)))
    v["features"] = [r["code"] for r in db.query(
        """SELECT f.code FROM vehicle_features vf JOIN features f ON f.id = vf.feature_id
            WHERE vf.vehicle_id = ?""", (vehicle_id,))]
    return v


def company_fleet(company_id: int, *, limit=50, offset=0, status=None) -> dict:
    where = ["v.company_id = ?", "v.deleted_at IS NULL"]
    params: list = [company_id]
    if status:
        where.append("v.status = ?"); params.append(status)
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM vehicles v{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT v.id, v.slug, v.brand, v.model, v.year, v.status, v.approval_status,
                               v.daily_price, v.deposit, v.rating_avg, v.bookings_count, cat.code AS category,
                               (SELECT path FROM vehicle_images WHERE vehicle_id = v.id
                                 ORDER BY is_primary DESC, sort LIMIT 1) AS image,
                               (SELECT COUNT(*) FROM bookings b WHERE b.vehicle_id = v.id
                                 AND b.status IN ('pending','awaiting_payment','confirmed','active')) AS active_bookings
                          FROM vehicles v JOIN vehicle_categories cat ON cat.id = v.category_id
                          {where_sql} ORDER BY v.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return {"items": db.rows_to_dicts(rows), "total": total}


def block_dates(*, req, vehicle_id: int, start_date: str, end_date: str, reason: str = "",
                kind: str = "blocked") -> dict:
    """Blocked/maintenance periods use the same day-lock table as bookings."""
    import sqlite3
    assert_can_manage(vehicle_id, req)
    days = A.day_range(start_date, end_date)
    if not days:
        raise ValidationError({"end_date": "Période invalide."})
    if len(days) > 400:
        raise ValidationError({"end_date": "Période trop longue (400 jours maximum)."})
    try:
        with db.transaction():
            if kind == "maintenance":
                rec_id = db.insert("vehicle_maintenance", {
                    "vehicle_id": vehicle_id, "start_date": start_date, "end_date": end_date,
                    "reason": clean_text(reason, 300) or "Maintenance", "status": "planned",
                    "created_by": req.user["id"], "created_at": now_str()})
                A.lock_days(vehicle_id, days, "maintenance", maintenance_id=rec_id)
            else:
                rec_id = db.insert("vehicle_blocks", {
                    "vehicle_id": vehicle_id, "start_date": start_date, "end_date": end_date,
                    "reason": clean_text(reason, 300), "created_by": req.user["id"],
                    "created_at": now_str()})
                A.lock_days(vehicle_id, days, "blocked", block_id=rec_id)
    except sqlite3.IntegrityError:
        conflicts = A.conflicting_days(vehicle_id, start_date, end_date)
        raise Conflict("Cette période chevauche une réservation ou un blocage existant.",
                       code="period_conflict",
                       extra={"conflicts": conflicts[:10]})
    audit(f"vehicle.{kind}_added", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"start": start_date, "end": end_date, "reason": reason})
    return {"id": rec_id, "kind": kind, "days": len(days)}


def unblock(*, req, vehicle_id: int, kind: str, record_id: int) -> None:
    assert_can_manage(vehicle_id, req)
    table = "vehicle_maintenance" if kind == "maintenance" else "vehicle_blocks"
    col = "maintenance_id" if kind == "maintenance" else "block_id"
    row = db.one(f"SELECT * FROM {table} WHERE id = ? AND vehicle_id = ?", (record_id, vehicle_id))
    if not row:
        raise NotFound("Période introuvable.")
    with db.transaction():
        db.execute(f"DELETE FROM vehicle_day_locks WHERE {col} = ?", (record_id,))
        db.execute(f"DELETE FROM {table} WHERE id = ?", (record_id,))
    audit(f"vehicle.{kind}_removed", actor=req.user, target_type="vehicle", target_id=vehicle_id,
          ip=req.ip, metadata={"record_id": record_id})
