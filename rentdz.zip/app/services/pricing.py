"""
Pricing engine. Returns a fully itemised, transparent breakdown.
No tax rate, commission or discount is hardcoded: everything comes from
platform settings or pricing_rules, both admin-editable.
"""
from __future__ import annotations
from datetime import datetime, timedelta
from .. import db
from ..security import now, ValidationError
from . import settings_service as S
from .availability import d, rental_days, day_range

WEEKEND_WEEKDAYS = (3, 4)  # Thursday=3, Friday=4 -> Algerian weekend is Fri/Sat
# python weekday(): Mon0 Tue1 Wed2 Thu3 Fri4 Sat5 Sun6 -> Algerian weekend = Fri(4), Sat(5)
WEEKEND_WEEKDAYS = (4, 5)


def _r(x) -> int:
    return int(round(x))


def _tier_base(vehicle: dict, days: int, billable_days: list[str]) -> tuple[int, list[dict]]:
    """Monthly > weekly > daily, with weekend rate applied to leftover single days."""
    daily = int(vehicle["daily_price"])
    weekly = int(vehicle["weekly_price"] or daily * 7)
    monthly = int(vehicle["monthly_price"] or daily * 30)
    weekend = int(vehicle["weekend_price"] or 0)

    lines: list[dict] = []
    remaining = days
    total = 0

    months = remaining // 30
    if months and vehicle["monthly_price"]:
        total += months * monthly
        remaining -= months * 30
        lines.append({"label": f"{months} mois × {monthly}", "code": "monthly",
                      "qty": months, "unit": monthly, "amount": months * monthly})
    weeks = remaining // 7
    if weeks and vehicle["weekly_price"]:
        total += weeks * weekly
        remaining -= weeks * 7
        lines.append({"label": f"{weeks} semaine(s) × {weekly}", "code": "weekly",
                      "qty": weeks, "unit": weekly, "amount": weeks * weekly})

    if remaining > 0:
        # Which calendar days are left over -> weekend rate where configured
        tail = billable_days[len(billable_days) - remaining:] if len(billable_days) >= remaining else billable_days
        wk_days = [x for x in tail if d(x).weekday() in WEEKEND_WEEKDAYS] if weekend else []
        normal = remaining - len(wk_days)
        if normal > 0:
            total += normal * daily
            lines.append({"label": f"{normal} jour(s) × {daily}", "code": "daily",
                          "qty": normal, "unit": daily, "amount": normal * daily})
        if wk_days:
            total += len(wk_days) * weekend
            lines.append({"label": f"{len(wk_days)} jour(s) week-end × {weekend}",
                          "code": "weekend", "qty": len(wk_days), "unit": weekend,
                          "amount": len(wk_days) * weekend})
    return total, lines


def _applicable_rules(vehicle: dict, pickup_date: str, days: int) -> list[dict]:
    rows = db.query(
        """SELECT * FROM pricing_rules
            WHERE active = 1
              AND (scope='global'
                   OR (scope='company'  AND company_id  = ?)
                   OR (scope='category' AND category_id = ?)
                   OR (scope='vehicle'  AND vehicle_id  = ?))
            ORDER BY priority DESC, id ASC""",
        (vehicle["company_id"], vehicle["category_id"], vehicle["id"]))
    out = []
    pd = d(pickup_date)
    days_ahead = (pd - now().date()).days
    for r in rows:
        rule = dict(r)
        if rule["start_date"] and pd < d(rule["start_date"]):
            continue
        if rule["end_date"] and pd > d(rule["end_date"]):
            continue
        if rule["min_days"] and days < rule["min_days"]:
            continue
        if rule["min_days_ahead"] and days_ahead < rule["min_days_ahead"]:
            continue
        if rule["weekday_mask"]:
            allowed = {int(x) for x in str(rule["weekday_mask"]).split(",") if x.strip().isdigit()}
            if pd.weekday() not in allowed:
                continue
        out.append(rule)
    return out


def _apply_rule(amount: int, rule: dict, days: int) -> int:
    kind, val = rule["adjust_type"], float(rule["adjust_value"])
    if kind == "percent":
        return _r(amount * val / 100.0)
    if kind == "fixed":
        return _r(val * days)
    return _r(val - amount)  # absolute: force total to val


def validate_promo(code: str, *, user_id: int | None, amount: int, vehicle: dict) -> dict:
    row = db.one("SELECT * FROM promo_codes WHERE code = ? COLLATE NOCASE", (code.strip(),))
    if not row or not row["active"]:
        raise ValidationError({"promo_code": "Code promo invalide."})
    promo = dict(row)
    today = now().strftime("%Y-%m-%d %H:%M")
    if promo["starts_at"] and today < promo["starts_at"]:
        raise ValidationError({"promo_code": "Ce code n'est pas encore actif."})
    if promo["ends_at"] and today > promo["ends_at"]:
        raise ValidationError({"promo_code": "Ce code promo a expiré."})
    if promo["min_amount"] and amount < promo["min_amount"]:
        raise ValidationError({"promo_code": f"Montant minimum requis : {promo['min_amount']} DA."})
    if promo["usage_limit"] is not None and promo["used_count"] >= promo["usage_limit"]:
        raise ValidationError({"promo_code": "Ce code a atteint sa limite d'utilisation."})
    if promo["category_id"] and promo["category_id"] != vehicle["category_id"]:
        raise ValidationError({"promo_code": "Ce code ne s'applique pas à cette catégorie."})
    if promo["company_id"] and promo["company_id"] != vehicle["company_id"]:
        raise ValidationError({"promo_code": "Ce code ne s'applique pas à ce loueur."})
    if user_id and promo["per_user_limit"]:
        used = db.scalar("SELECT COUNT(*) FROM promo_redemptions WHERE promo_id = ? AND user_id = ?",
                         (promo["id"], user_id), 0)
        if used >= promo["per_user_limit"]:
            raise ValidationError({"promo_code": "Vous avez déjà utilisé ce code."})
    return promo


def promo_discount(promo: dict, amount: int) -> int:
    if promo["kind"] == "percent":
        disc = _r(amount * float(promo["value"]) / 100.0)
    else:
        disc = _r(float(promo["value"]))
    if promo["max_discount"]:
        disc = min(disc, int(promo["max_discount"]))
    return max(0, min(disc, amount))


def quote(vehicle: dict, pickup_at: str, return_at: str, *,
          services: list[dict] | None = None,
          pickup_location: dict | None = None,
          dropoff_location: dict | None = None,
          promo_code: str | None = None,
          user_id: int | None = None) -> dict:
    """
    services: [{"id": int, "qty": int}]
    Returns a dict safe to show the customer and to snapshot on the booking.
    """
    days = rental_days(pickup_at, return_at)
    if days < 1:
        raise ValidationError({"return_at": "La date de retour doit suivre la date de départ."})

    min_days = max(int(vehicle["min_days"] or 1), int(S.get("min_rental_days", 1)))
    max_days = min(int(vehicle["max_days"] or 90), int(S.get("max_rental_days", 90)))
    if days < min_days:
        raise ValidationError({"return_at": f"Durée minimale de location : {min_days} jour(s)."})
    if days > max_days:
        raise ValidationError({"return_at": f"Durée maximale de location : {max_days} jour(s)."})

    billable = day_range(pickup_at[:10], (d(pickup_at[:10]) + timedelta(days=days - 1)).isoformat())
    base, base_lines = _tier_base(vehicle, days, billable)

    # pricing rules (seasonal / holiday / weekend / long rental / early booking)
    adjustments: list[dict] = []
    for rule in _applicable_rules(vehicle, pickup_at[:10], days):
        delta = _apply_rule(base, rule, days)
        if rule["adjust_type"] == "absolute":
            adjustments.append({"label": rule["label"], "code": rule["kind"], "amount": delta})
            base = base + delta
        elif delta:
            adjustments.append({"label": rule["label"], "code": rule["kind"], "amount": delta})
            base += delta
    base = max(0, base)

    # optional services
    service_lines: list[dict] = []
    services_total = 0
    for item in (services or []):
        row = db.one("SELECT * FROM services WHERE id = ? AND active = 1", (item["id"],))
        if not row:
            raise ValidationError({"services": "Service optionnel indisponible."})
        svc = dict(row)
        if svc["company_id"] not in (None, vehicle["company_id"]):
            raise ValidationError({"services": "Service non proposé par ce loueur."})
        qty = max(1, min(int(item.get("qty", 1)), int(svc["max_qty"] or 1)))
        unit = int(svc["price"])
        amount = unit * qty * (days if svc["price_type"] == "per_day" else 1)
        services_total += amount
        service_lines.append({"service_id": svc["id"], "code": svc["code"],
                              "label": svc["name_fr"], "qty": qty, "unit": unit,
                              "price_type": svc["price_type"], "amount": amount})

    # location fees
    fee_lines: list[dict] = []
    fees_total = 0
    for loc, lbl in ((pickup_location, "Prise en charge"), (dropoff_location, "Restitution")):
        if loc and int(loc.get("extra_fee") or 0) > 0:
            fee = int(loc["extra_fee"])
            fees_total += fee
            fee_lines.append({"label": f"{lbl} — {loc.get('name_fr') or ''}".strip(),
                              "code": "location_fee", "amount": fee})
    svc_fee_pct = float(S.get("service_fee_percent", 0) or 0)
    if svc_fee_pct > 0:
        fee = _r((base + services_total) * svc_fee_pct / 100.0)
        if fee:
            fees_total += fee
            fee_lines.append({"label": f"Frais de service ({svc_fee_pct:g} %)",
                              "code": "service_fee", "amount": fee})

    # discounts: configured long-rental tiers, then promo code
    discount_lines: list[dict] = []
    discount_total = 0
    tiers = sorted([t for t in (S.get("long_rental_discount") or [])
                    if days >= int(t.get("min_days", 0))],
                   key=lambda t: int(t.get("min_days", 0)))
    if tiers:
        best = tiers[-1]
        disc = _r(base * float(best.get("percent", 0)) / 100.0)
        if disc > 0:
            discount_total += disc
            discount_lines.append({"label": f"Remise longue durée ({best.get('percent')} % dès "
                                            f"{best.get('min_days')} jours)",
                                   "code": "long_rental", "amount": -disc})

    promo = None
    if promo_code:
        promo = validate_promo(promo_code, user_id=user_id,
                               amount=base + services_total - discount_total, vehicle=vehicle)
        disc = promo_discount(promo, base + services_total - discount_total)
        if disc > 0:
            discount_total += disc
            discount_lines.append({"label": f"Code promo {promo['code']}",
                                   "code": "promo", "amount": -disc})

    subtotal = max(0, base + services_total + fees_total - discount_total)

    # tax (rate is a setting, never a constant)
    tax_total = 0
    tax_lines: list[dict] = []
    if S.get("vat_enabled"):
        rate = float(S.get("vat_rate_percent", 0) or 0)
        if rate > 0:
            tax_total = _r(subtotal * rate / 100.0)
            tax_lines.append({"label": f"TVA ({rate:g} %)", "code": "vat", "amount": tax_total})

    total = subtotal + tax_total

    deposit = int(vehicle["deposit"] or 0)
    if deposit == 0:
        pct = float(S.get("deposit_default_percent", 0) or 0)
        deposit = _r(base * pct / 100.0)

    commission_pct = float(S.get("platform_commission_percent", 0) or 0)
    company_rate = db.scalar("SELECT commission_rate FROM rental_companies WHERE id = ?",
                             (vehicle["company_id"],))
    if company_rate is not None:
        commission_pct = float(company_rate)
    commission = _r(total * commission_pct / 100.0)

    return {
        "currency": "DZD",
        "days": days,
        "pickup_at": pickup_at, "return_at": return_at,
        "daily_price": int(vehicle["daily_price"]),
        "base_amount": base,
        "services_amount": services_total,
        "fees_amount": fees_total,
        "discount_amount": discount_total,
        "tax_amount": tax_total,
        "total_amount": total,
        "deposit_amount": deposit,
        "commission_amount": commission,
        "payable_now": 0,
        "lines": {"base": base_lines, "adjustments": adjustments, "services": service_lines,
                  "fees": fee_lines, "discounts": discount_lines, "taxes": tax_lines},
        "services_selected": service_lines,
        "promo": {"id": promo["id"], "code": promo["code"]} if promo else None,
        "cancellation_policy": S.get("cancellation_policy"),
    }


def refund_for_cancellation(booking: dict, at=None) -> dict:
    """Apply the admin-configured cancellation ladder. First matching rule wins."""
    at = at or now()
    pickup = datetime.strptime(booking["pickup_at"][:16], "%Y-%m-%d %H:%M")
    hours_before = (pickup - at.replace(tzinfo=None)).total_seconds() / 3600.0
    policy = sorted(S.get("cancellation_policy") or [],
                    key=lambda p: -int(p.get("hours_before", 0)))
    chosen = {"hours_before": 0, "refund_percent": 0, "label": "Aucun remboursement"}
    for rule in policy:
        if hours_before >= int(rule.get("hours_before", 0)):
            chosen = rule
            break
    paid = int(booking.get("paid_amount") or 0)
    percent = float(chosen.get("refund_percent", 0))
    return {
        "hours_before_pickup": round(hours_before, 1),
        "refund_percent": percent,
        "refund_amount": _r(paid * percent / 100.0),
        "paid_amount": paid,
        "policy_label": chosen.get("label", ""),
        "free": percent >= 100,
    }
