"""Rental company onboarding, approval and profile management."""
from __future__ import annotations
from .. import db
from ..http import Conflict, NotFound, Forbidden
from ..security import ValidationError, clean_text, slugify, normalise_phone, now_str, valid_email
from .audit import record as audit
from .notification_service import notify, notify_admins
from .auth_service import grant_role


def create(*, req, data: dict) -> dict:
    user = req.require_user()
    existing = db.one("SELECT id FROM rental_companies WHERE owner_user_id = ? AND deleted_at IS NULL",
                      (user["id"],))
    if existing:
        raise Conflict("Vous avez déjà une société enregistrée.", code="company_exists")
    name = clean_text(data.get("name"), 120)
    phone = normalise_phone(data.get("phone") or "")
    errors = {}
    if len(name) < 2:
        errors["name"] = "Nom de la société obligatoire."
    if not phone:
        errors["phone"] = "Numéro de téléphone algérien invalide."
    email = clean_text(data.get("email"), 190)
    if email and not valid_email(email):
        errors["email"] = "Adresse e-mail invalide."
    wilaya_id = data.get("wilaya_id")
    if wilaya_id and not db.one("SELECT 1 FROM wilayas WHERE id = ?", (wilaya_id,)):
        errors["wilaya_id"] = "Wilaya inconnue."
    if errors:
        raise ValidationError(errors)
    with db.transaction():
        company_id = db.insert("rental_companies", {
            "owner_user_id": user["id"], "name": name,
            "slug": slugify(name, extra=str(db.scalar("SELECT COALESCE(MAX(id),0)+1 FROM rental_companies", (), 1))),
            "legal_name": clean_text(data.get("legal_name"), 160),
            "rc_number": clean_text(data.get("rc_number"), 40),
            "nif": clean_text(data.get("nif"), 40),
            "phone": phone, "email": email or None,
            "wilaya_id": wilaya_id, "commune_id": data.get("commune_id"),
            "address": clean_text(data.get("address"), 250),
            "description": clean_text(data.get("description"), 2000),
            "status": "pending", "is_demo": 1 if user.get("is_demo") else 0,
            "created_at": now_str(), "updated_at": now_str()})
        grant_role(user["id"], "fleet_owner", company_id)
    audit("company.created", actor=user, target_type="company", target_id=company_id, ip=req.ip,
          metadata={"name": name})
    notify_admins("company_approved", {"company": name})
    return get(company_id)


def get(company_id: int) -> dict | None:
    row = db.one("""SELECT c.*, w.name_fr AS wilaya, u.full_name AS owner_name, u.email AS owner_email
                      FROM rental_companies c
                      LEFT JOIN wilayas w ON w.id = c.wilaya_id
                      JOIN users u ON u.id = c.owner_user_id
                     WHERE c.id = ? AND c.deleted_at IS NULL""", (company_id,))
    if not row:
        return None
    c = dict(row)
    c["stats"] = {
        "vehicles": db.scalar("SELECT COUNT(*) FROM vehicles WHERE company_id=? AND deleted_at IS NULL",
                              (company_id,), 0),
        "bookings": db.scalar("SELECT COUNT(*) FROM bookings WHERE company_id=?", (company_id,), 0),
    }
    return c


def update(*, req, company_id: int, data: dict) -> dict:
    if company_id not in req.company_ids() and not req.has_perm("company.manage.all"):
        raise NotFound("Société introuvable.")
    patch = {}
    if "name" in data:
        patch["name"] = clean_text(data["name"], 120)
    for key, ln in (("legal_name", 160), ("rc_number", 40), ("nif", 40),
                    ("address", 250), ("description", 2000)):
        if key in data:
            patch[key] = clean_text(data[key], ln)
    if "phone" in data:
        p = normalise_phone(data["phone"] or "")
        if not p:
            raise ValidationError({"phone": "Numéro algérien invalide."})
        patch["phone"] = p
    if "email" in data:
        if data["email"] and not valid_email(data["email"]):
            raise ValidationError({"email": "Adresse e-mail invalide."})
        patch["email"] = clean_text(data["email"], 190) or None
    if "wilaya_id" in data:
        patch["wilaya_id"] = data["wilaya_id"]
    if "commune_id" in data:
        patch["commune_id"] = data["commune_id"]
    # commission_rate is admin-only: a vendor must never set their own commission
    if "commission_rate" in data and req.has_perm("company.manage.all"):
        raw = data["commission_rate"]
        if raw in (None, "", "null", "default"):
            patch["commission_rate"] = None          # fall back to the platform rate
        else:
            try:
                rate = float(raw)
            except (TypeError, ValueError):
                raise ValidationError({"commission_rate": "Taux de commission invalide."})
            if not 0 <= rate <= 60:
                raise ValidationError({"commission_rate": "Le taux doit être entre 0 et 60 %."})
            patch["commission_rate"] = rate
    if not patch and "commission_rate" not in data:
        raise ValidationError({"name": "Aucune modification fournie."})
    patch["updated_at"] = now_str()
    db.update("rental_companies", company_id, patch)
    audit("company.updated", actor=req.user, target_type="company", target_id=company_id, ip=req.ip,
          metadata={"changed": sorted(patch.keys())})
    return get(company_id)


def set_status(*, req, company_id: int, status: str, reason: str = "") -> dict:
    if status not in ("approved", "rejected", "suspended", "pending"):
        raise ValidationError({"status": "Statut invalide."})
    row = db.one("SELECT * FROM rental_companies WHERE id = ? AND deleted_at IS NULL", (company_id,))
    if not row:
        raise NotFound("Société introuvable.")
    if status in ("rejected", "suspended") and not reason.strip():
        raise ValidationError({"reason": "Indiquez le motif."})
    patch = {"status": status, "updated_at": now_str(),
             "reject_reason": clean_text(reason, 300) if status in ("rejected", "suspended") else None}
    if status == "approved":
        patch.update({"approved_at": now_str(), "approved_by": req.user["id"]})
    db.update("rental_companies", company_id, patch)
    if status in ("suspended", "rejected"):
        # pull their fleet out of public search immediately
        db.execute("""UPDATE vehicles SET status='unavailable', updated_at=?
                       WHERE company_id = ? AND deleted_at IS NULL""", (now_str(), company_id))
    audit(f"company.{status}", actor=req.user, target_type="company", target_id=company_id,
          ip=req.ip, metadata={"reason": reason})
    notify(row["owner_user_id"],
           "company_approved" if status == "approved" else "company_rejected",
           {"company": row["name"], "reason": reason or "-"})
    return get(company_id)


def dashboard(company_id: int) -> dict:
    today = db.scalar("SELECT date('now')")
    def s(sql, params=()):
        return db.scalar(sql, params, 0)
    return {
        "vehicles_total": s("SELECT COUNT(*) FROM vehicles WHERE company_id=? AND deleted_at IS NULL", (company_id,)),
        "vehicles_available": s("""SELECT COUNT(*) FROM vehicles WHERE company_id=? AND deleted_at IS NULL
                                    AND status='available' AND approval_status='approved'""", (company_id,)),
        "vehicles_rented": s("SELECT COUNT(*) FROM vehicles WHERE company_id=? AND status='rented' AND deleted_at IS NULL", (company_id,)),
        "vehicles_maintenance": s("SELECT COUNT(*) FROM vehicles WHERE company_id=? AND status='maintenance' AND deleted_at IS NULL", (company_id,)),
        "vehicles_pending_approval": s("""SELECT COUNT(*) FROM vehicles WHERE company_id=?
                                           AND approval_status='pending' AND deleted_at IS NULL""", (company_id,)),
        "bookings_pending": s("SELECT COUNT(*) FROM bookings WHERE company_id=? AND status='pending'", (company_id,)),
        "bookings_upcoming": s("""SELECT COUNT(*) FROM bookings WHERE company_id=? AND status='confirmed'
                                   AND pickup_date >= date('now')""", (company_id,)),
        "bookings_active": s("SELECT COUNT(*) FROM bookings WHERE company_id=? AND status='active'", (company_id,)),
        "pickups_today": s("""SELECT COUNT(*) FROM bookings WHERE company_id=? AND pickup_date = date('now')
                               AND status IN ('confirmed','active')""", (company_id,)),
        "returns_today": s("""SELECT COUNT(*) FROM bookings WHERE company_id=? AND return_date = date('now')
                               AND status IN ('active','confirmed')""", (company_id,)),
        "revenue_month": s("""SELECT COALESCE(SUM(total_amount - commission_amount),0) FROM bookings
                               WHERE company_id=? AND status IN ('confirmed','active','completed')
                                 AND pickup_date >= date('now','start of month')""", (company_id,)),
        "revenue_total": s("""SELECT COALESCE(SUM(total_amount - commission_amount),0) FROM bookings
                               WHERE company_id=? AND status IN ('active','completed')""", (company_id,)),
        "pending_documents": s("""SELECT COUNT(*) FROM documents d JOIN bookings b ON b.id = d.booking_id
                                   WHERE b.company_id=? AND d.status='pending'""", (company_id,)),
        "rating": db.scalar("SELECT rating_avg FROM rental_companies WHERE id=?", (company_id,), 0),
    }
