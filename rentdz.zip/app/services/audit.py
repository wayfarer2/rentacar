"""Append-only audit trail. Writable by services, readable only with audit.view."""
from __future__ import annotations
from .. import db
from ..security import now_str


def record(action: str, *, actor=None, target_type: str = None, target_id=None,
           ip: str = None, user_agent: str = None, metadata: dict = None) -> int:
    actor_id = actor.get("id") if isinstance(actor, dict) else actor
    actor_email = actor.get("email") if isinstance(actor, dict) else None
    return db.insert("audit_logs", {
        "actor_user_id": actor_id, "actor_email": actor_email, "action": action,
        "target_type": target_type, "target_id": str(target_id) if target_id is not None else None,
        "ip": ip, "user_agent": (user_agent or "")[:255] or None,
        "metadata": db.jdump(metadata) if metadata else None,
        "created_at": now_str(),
    })


def from_request(req, action: str, **kwargs) -> int:
    return record(action, actor=req.user, ip=req.ip, user_agent=req.user_agent, **kwargs)
