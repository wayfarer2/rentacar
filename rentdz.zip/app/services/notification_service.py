"""
Notifications. In-app is always real. Email/SMS/WhatsApp go through an outbox:
if the provider has no credentials the row is marked 'unconfigured' and the UI
says so. Nothing is ever reported as sent when it was not.
"""
from __future__ import annotations
import smtplib, logging
from email.message import EmailMessage
from .. import db
from ..config import Config, env_present
from ..security import now_str
from . import settings_service as S

log = logging.getLogger("rentdz.notify")

TEMPLATES = {
    "welcome": {"subject": "Bienvenue sur RENTDZ", "title": "Bienvenue sur RENTDZ",
                "body": "Votre compte a été créé. Bonne route avec RENTDZ."},
    "verify_email": {"subject": "Confirmez votre adresse e-mail", "title": "Confirmez votre e-mail",
                     "body": "Cliquez sur le lien pour confirmer votre adresse : {link}"},
    "password_reset": {"subject": "Réinitialisation de votre mot de passe",
                       "title": "Réinitialisation du mot de passe",
                       "body": "Utilisez ce lien pour définir un nouveau mot de passe : {link}"},
    "booking_created": {"subject": "Votre demande de réservation {reference}",
                        "title": "Réservation {reference} enregistrée",
                        "body": "Votre réservation {reference} pour {vehicle} du {pickup} au {ret} "
                                "est enregistrée. Montant : {total}."},
    "booking_confirmed": {"subject": "Réservation {reference} confirmée",
                          "title": "Réservation {reference} confirmée",
                          "body": "Bonne nouvelle : votre réservation {reference} est confirmée."},
    "booking_rejected": {"subject": "Réservation {reference} refusée",
                         "title": "Réservation {reference} refusée",
                         "body": "Votre demande {reference} a été refusée. Motif : {reason}"},
    "booking_cancelled": {"subject": "Réservation {reference} annulée",
                          "title": "Réservation {reference} annulée",
                          "body": "La réservation {reference} a été annulée. Remboursement prévu : {refund}."},
    "booking_expired": {"subject": "Réservation {reference} expirée",
                        "title": "Réservation {reference} expirée",
                        "body": "Faute de confirmation, la réservation {reference} a expiré et le véhicule a été libéré."},
    "booking_received_vendor": {"subject": "Nouvelle réservation {reference}",
                                "title": "Nouvelle réservation {reference}",
                                "body": "{customer} a réservé {vehicle} du {pickup} au {ret}."},
    "payment_recorded": {"subject": "Paiement enregistré — {reference}",
                         "title": "Paiement enregistré",
                         "body": "Un paiement de {amount} a été enregistré pour la réservation {reference}."},
    "payment_failed": {"subject": "Paiement échoué — {reference}",
                       "title": "Paiement échoué",
                       "body": "Le paiement de la réservation {reference} a échoué. Vous pouvez réessayer."},
    "refund_processed": {"subject": "Remboursement — {reference}",
                         "title": "Remboursement traité",
                         "body": "Un remboursement de {amount} a été traité pour {reference}."},
    "pickup_reminder": {"subject": "Départ demain — {reference}",
                        "title": "Rappel de départ",
                        "body": "Votre location {reference} commence le {pickup}."},
    "return_reminder": {"subject": "Retour prévu — {reference}",
                        "title": "Rappel de retour",
                        "body": "Le retour du véhicule est prévu le {ret}."},
    "document_approved": {"subject": "Document approuvé", "title": "Document approuvé",
                          "body": "Votre document ({kind}) a été approuvé."},
    "document_rejected": {"subject": "Document refusé", "title": "Document refusé",
                          "body": "Votre document ({kind}) a été refusé. Motif : {reason}"},
    "company_approved": {"subject": "Votre société est approuvée", "title": "Société approuvée",
                         "body": "Votre société {company} est approuvée. Vous pouvez publier vos véhicules."},
    "company_rejected": {"subject": "Inscription société refusée", "title": "Société refusée",
                         "body": "Votre demande a été refusée. Motif : {reason}"},
    "vehicle_approved": {"subject": "Véhicule publié", "title": "Véhicule publié",
                         "body": "Votre véhicule {vehicle} est publié et visible des clients."},
    "vehicle_rejected": {"subject": "Véhicule refusé", "title": "Véhicule refusé",
                         "body": "Votre véhicule {vehicle} a été refusé. Motif : {reason}"},
    "account_suspended": {"subject": "Compte suspendu", "title": "Compte suspendu",
                          "body": "Votre compte a été suspendu. Motif : {reason}"},
    "support_message": {"subject": "Nouveau message — ticket {reference}",
                        "title": "Nouveau message de support",
                        "body": "Vous avez un nouveau message sur le ticket {reference}."},
    "review_request": {"subject": "Votre avis compte", "title": "Donnez votre avis",
                       "body": "Votre location {reference} est terminée. Partagez votre expérience."},
}


def _fmt(text: str, ctx: dict) -> str:
    try:
        return text.format(**ctx)
    except Exception:
        return text


def email_status() -> str:
    if Config.EMAIL_PROVIDER == "smtp" and env_present("SMTP_HOST"):
        return "configured"
    if Config.EMAIL_PROVIDER == "api" and env_present("EMAIL_API_KEY"):
        return "configured"
    return "unconfigured"


def sms_status() -> str:
    return "configured" if env_present("SMS_API_KEY") else "unconfigured"


def _prefs(user_id: int, kind: str) -> dict:
    row = db.one("SELECT in_app, email, sms FROM notification_preferences WHERE user_id=? AND kind=?",
                 (user_id, kind))
    if row:
        return {"in_app": bool(row["in_app"]), "email": bool(row["email"]), "sms": bool(row["sms"])}
    return {"in_app": True, "email": True, "sms": False}


def _queue(user_id, channel: str, recipient: str, template: str, subject: str, payload: dict) -> None:
    status = {"email": email_status(), "sms": sms_status()}.get(channel, "unconfigured")
    provider = {"email": Config.EMAIL_PROVIDER, "sms": Config.SMS_PROVIDER}.get(channel, "none")
    if not recipient:
        status = "skipped"
    db.insert("notification_outbox", {
        "user_id": user_id, "channel": channel, "recipient": recipient or "",
        "template": template, "subject": subject, "payload": db.jdump(payload),
        "status": "queued" if status == "configured" else status,
        "provider": provider, "created_at": now_str(),
    })


def notify(user_id: int | None, template: str, ctx: dict | None = None, *,
           channels=("in_app", "email"), recipient_email: str = None,
           recipient_phone: str = None) -> None:
    ctx = ctx or {}
    tpl = TEMPLATES.get(template, {"subject": template, "title": template, "body": ""})
    title = _fmt(tpl["title"], ctx)
    body = _fmt(tpl["body"], ctx)
    subject = _fmt(tpl["subject"], ctx)

    prefs = _prefs(user_id, template) if user_id else {"in_app": False, "email": True, "sms": False}
    if user_id and "in_app" in channels and prefs["in_app"]:
        db.insert("notifications", {"user_id": user_id, "kind": template, "title": title,
                                    "body": body, "data": db.jdump(ctx), "created_at": now_str()})
    if "email" in channels and prefs.get("email", True):
        to = recipient_email or (db.scalar("SELECT email FROM users WHERE id = ?", (user_id,)) if user_id else None)
        _queue(user_id, "email", to, template, subject, ctx)
    if "sms" in channels and prefs.get("sms", False):
        to = recipient_phone or (db.scalar("SELECT phone FROM users WHERE id = ?", (user_id,)) if user_id else None)
        _queue(user_id, "sms", to, template, subject, ctx)


def notify_admins(template: str, ctx: dict | None = None) -> None:
    rows = db.query(
        """SELECT DISTINCT u.id FROM users u
             JOIN user_roles ur ON ur.user_id = u.id
             JOIN roles r ON r.id = ur.role_id
            WHERE r.code IN ('admin','super_admin') AND u.status='active' AND u.deleted_at IS NULL""")
    for r in rows:
        notify(r["id"], template, ctx, channels=("in_app",))


def flush_outbox(limit: int = 50) -> dict:
    """Attempt real delivery of queued messages. Only SMTP is wired locally."""
    sent = failed = skipped = 0
    rows = db.query("SELECT * FROM notification_outbox WHERE status='queued' ORDER BY id LIMIT ?", (limit,))
    for row in rows:
        if row["channel"] == "email" and Config.EMAIL_PROVIDER == "smtp" and env_present("SMTP_HOST"):
            try:
                msg = EmailMessage()
                msg["From"] = f"{Config.EMAIL_FROM_NAME} <{Config.EMAIL_FROM}>"
                msg["To"] = row["recipient"]
                msg["Subject"] = row["subject"] or "RENTDZ"
                ctx = db.jload(row["payload"], {}) or {}
                tpl = TEMPLATES.get(row["template"], {"body": ""})
                msg.set_content(_fmt(tpl.get("body", ""), ctx))
                with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=15) as s:
                    s.starttls()
                    if Config.SMTP_USER:
                        s.login(Config.SMTP_USER, Config.SMTP_PASSWORD or "")
                    s.send_message(msg)
                db.update("notification_outbox", row["id"],
                          {"status": "sent", "sent_at": now_str(), "attempts": row["attempts"] + 1})
                sent += 1
            except Exception as e:
                db.update("notification_outbox", row["id"],
                          {"status": "failed", "error": str(e)[:250], "attempts": row["attempts"] + 1})
                failed += 1
        else:
            db.update("notification_outbox", row["id"], {"status": "unconfigured",
                      "error": "Aucun fournisseur configuré pour ce canal."})
            skipped += 1
    return {"sent": sent, "failed": failed, "unconfigured": skipped}


def unread_count(user_id: int) -> int:
    return db.scalar("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL",
                     (user_id,), 0)
