"""Admin analytics. Every figure comes from a real aggregate query."""
from __future__ import annotations
from .. import db

RANGES = {
    "today": "date('now')",
    "7d": "date('now','-7 days')",
    "30d": "date('now','-30 days')",
    "90d": "date('now','-90 days')",
    "year": "date('now','start of year')",
    "all": "date('1970-01-01')",
}
COUNTED = ("confirmed", "active", "completed")


def _bounds(range_key: str, date_from: str = None, date_to: str = None) -> tuple[str, str]:
    if date_from and date_to:
        return date_from, date_to
    start = db.scalar(f"SELECT {RANGES.get(range_key, RANGES['30d'])}")
    return start, db.scalar("SELECT date('now')")


def overview(range_key: str = "30d", date_from=None, date_to=None) -> dict:
    start, end = _bounds(range_key, date_from, date_to)
    p = (start, end)
    counted = ",".join(f"'{s}'" for s in COUNTED)
    def s(sql, params=p, default=0):
        return db.scalar(sql, params, default)

    bookings_total = s("SELECT COUNT(*) FROM bookings WHERE date(created_at) BETWEEN ? AND ?")
    confirmed = s(f"SELECT COUNT(*) FROM bookings WHERE status IN ({counted}) AND date(created_at) BETWEEN ? AND ?")
    cancelled = s("SELECT COUNT(*) FROM bookings WHERE status IN ('cancelled','rejected') AND date(created_at) BETWEEN ? AND ?")
    expired = s("SELECT COUNT(*) FROM bookings WHERE status='expired' AND date(created_at) BETWEEN ? AND ?")
    gross = s(f"SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE status IN ({counted}) AND date(created_at) BETWEEN ? AND ?")
    commission = s(f"SELECT COALESCE(SUM(commission_amount),0) FROM bookings WHERE status IN ({counted}) AND date(created_at) BETWEEN ? AND ?")
    collected = s("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='paid' AND date(created_at) BETWEEN ? AND ?")
    refunded = s("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE status='refunded' AND date(created_at) BETWEEN ? AND ?")

    vehicles_total = s("SELECT COUNT(*) FROM vehicles WHERE deleted_at IS NULL", ())
    rented_days = s(f"""SELECT COALESCE(SUM(days),0) FROM bookings
                         WHERE status IN ({counted}) AND date(pickup_date) BETWEEN ? AND ?""")
    span_days = max(1, int(s("SELECT julianday(?) - julianday(?) + 1", (end, start), 1)))
    utilisation = round(100.0 * rented_days / max(1, vehicles_total * span_days), 1)

    return {
        "range": {"from": start, "to": end, "key": range_key},
        "revenue_gross": gross,
        "revenue_platform": commission,
        "revenue_companies": gross - commission,
        "payments_collected": collected,
        "refunds_total": refunded,
        "bookings_total": bookings_total,
        "bookings_confirmed": confirmed,
        "bookings_cancelled": cancelled,
        "bookings_expired": expired,
        "average_booking_value": int(round(gross / confirmed)) if confirmed else 0,
        "cancellation_rate": round(100.0 * cancelled / bookings_total, 1) if bookings_total else 0.0,
        "conversion_rate": round(100.0 * confirmed / bookings_total, 1) if bookings_total else 0.0,
        "vehicle_utilisation_percent": utilisation,
        "customers_total": s("""SELECT COUNT(DISTINCT u.id) FROM users u JOIN user_roles ur ON ur.user_id=u.id
                                 JOIN roles r ON r.id=ur.role_id WHERE r.code='customer' AND u.deleted_at IS NULL""", ()),
        "customers_new": s("""SELECT COUNT(*) FROM users WHERE deleted_at IS NULL
                               AND date(created_at) BETWEEN ? AND ?"""),
        "companies_total": s("SELECT COUNT(*) FROM rental_companies WHERE deleted_at IS NULL", ()),
        "companies_pending": s("SELECT COUNT(*) FROM rental_companies WHERE status='pending' AND deleted_at IS NULL", ()),
        "vehicles_total": vehicles_total,
        "vehicles_pending": s("SELECT COUNT(*) FROM vehicles WHERE approval_status='pending' AND deleted_at IS NULL", ()),
        "documents_pending": s("SELECT COUNT(*) FROM documents WHERE status='pending' AND deleted_at IS NULL", ()),
        "tickets_open": s("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open','in_progress')", ()),
        "outbox_unconfigured": s("SELECT COUNT(*) FROM notification_outbox WHERE status='unconfigured'", ()),
    }


def revenue_by_month(months: int = 12) -> list[dict]:
    counted = ",".join(f"'{s}'" for s in COUNTED)
    rows = db.query(f"""SELECT strftime('%Y-%m', pickup_date) AS month,
                               COUNT(*) AS bookings,
                               COALESCE(SUM(total_amount),0) AS revenue,
                               COALESCE(SUM(commission_amount),0) AS platform
                          FROM bookings
                         WHERE status IN ({counted})
                           AND pickup_date >= date('now', ?)
                         GROUP BY month ORDER BY month""", (f"-{months} months",))
    return db.rows_to_dicts(rows)


def top_vehicles(limit: int = 10) -> list[dict]:
    counted = ",".join(f"'{s}'" for s in COUNTED)
    return db.rows_to_dicts(db.query(f"""
        SELECT v.id, v.brand, v.model, v.slug, c.name AS company,
               COUNT(b.id) AS bookings, COALESCE(SUM(b.total_amount),0) AS revenue,
               v.rating_avg
          FROM vehicles v
          JOIN rental_companies c ON c.id = v.company_id
          LEFT JOIN bookings b ON b.vehicle_id = v.id AND b.status IN ({counted})
         WHERE v.deleted_at IS NULL
         GROUP BY v.id ORDER BY bookings DESC, revenue DESC LIMIT ?""", (limit,)))


def top_locations(limit: int = 10) -> list[dict]:
    counted = ",".join(f"'{s}'" for s in COUNTED)
    return db.rows_to_dicts(db.query(f"""
        SELECT w.name_fr AS wilaya, w.slug, COUNT(b.id) AS bookings,
               COALESCE(SUM(b.total_amount),0) AS revenue
          FROM bookings b
          JOIN locations l ON l.id = b.pickup_location_id
          JOIN wilayas w ON w.id = l.wilaya_id
         WHERE b.status IN ({counted})
         GROUP BY w.id ORDER BY bookings DESC LIMIT ?""", (limit,)))


def bookings_by_status() -> list[dict]:
    return db.rows_to_dicts(db.query(
        "SELECT status, COUNT(*) AS n, COALESCE(SUM(total_amount),0) AS amount FROM bookings GROUP BY status ORDER BY n DESC"))


def customer_growth(months: int = 12) -> list[dict]:
    return db.rows_to_dicts(db.query("""
        SELECT strftime('%Y-%m', created_at) AS month, COUNT(*) AS customers
          FROM users WHERE deleted_at IS NULL AND created_at >= date('now', ?)
         GROUP BY month ORDER BY month""", (f"-{months} months",)))


def company_analytics(company_id: int) -> dict:
    counted = ",".join(f"'{s}'" for s in COUNTED)
    return {
        "revenue_by_month": db.rows_to_dicts(db.query(f"""
            SELECT strftime('%Y-%m', pickup_date) AS month, COUNT(*) AS bookings,
                   COALESCE(SUM(total_amount - commission_amount),0) AS revenue
              FROM bookings WHERE company_id = ? AND status IN ({counted})
               AND pickup_date >= date('now','-12 months')
             GROUP BY month ORDER BY month""", (company_id,))),
        "top_vehicles": db.rows_to_dicts(db.query(f"""
            SELECT v.brand, v.model, COUNT(b.id) AS bookings,
                   COALESCE(SUM(b.total_amount),0) AS revenue
              FROM vehicles v LEFT JOIN bookings b ON b.vehicle_id = v.id AND b.status IN ({counted})
             WHERE v.company_id = ? AND v.deleted_at IS NULL
             GROUP BY v.id ORDER BY bookings DESC LIMIT 10""", (company_id,))),
        "by_status": db.rows_to_dicts(db.query(
            "SELECT status, COUNT(*) AS n FROM bookings WHERE company_id = ? GROUP BY status",
            (company_id,))),
    }
