"""
Booking engine.

Guarantees:
  * every booking is created inside ONE BEGIN IMMEDIATE transaction;
  * occupancy is written to vehicle_day_locks, which has UNIQUE(vehicle_id, day),
    so a concurrent request loses on the database constraint, not on a race;
  * a lost race raises Conflict (409) and rolls back cleanly -- no orphan rows;
  * every state change is recorded in booking_status_history.
"""
from __future__ import annotations
import sqlite3, secrets
from datetime import datetime, timedelta
from .. import db
from ..http import Conflict, NotFound, Forbidden, BadRequest
from ..security import ValidationError, now, now_str, in_minutes, utc_str, clean_text
from . import settings_service as S
from . import pricing as P
from . import availability as A
from .audit import record as audit
from .notification_service import notify, notify_admins
from ..i18n import money

ACTIVE_STATUSES = ("pending", "awaiting_payment", "confirmed", "active")
CLOSED_STATUSES = ("completed", "cancelled", "rejected", "expired", "no_show")

TRANSITIONS = {
    "pending":          ("awaiting_payment", "confirmed", "rejected", "cancelled", "expired"),
    "awaiting_payment": ("confirmed", "cancelled", "expired", "rejected"),
    "confirmed":        ("active", "cancelled", "no_show"),
    "active":           ("completed",),
    "completed":        (),
    "cancelled":        (),
    "rejected":         (),
    "expired":          (),
    "no_show":          ("completed", "cancelled"),
}


def new_reference() -> str:
    """Human-friendly, non-sequential: RDZ-YYMM-XXXXX (no enumeration leak)."""
    stamp = now().strftime("%y%m")
    for _ in range(12):
        ref = f"RDZ-{stamp}-{secrets.token_hex(3).upper()}"
        if not db.one("SELECT 1 FROM bookings WHERE reference = ?", (ref,)):
            return ref
    raise RuntimeError("Impossible de générer une référence unique.")


def get_vehicle_for_booking(vehicle_id: int) -> dict:
    row = db.one(
        """SELECT v.*, c.status AS company_status, c.name AS company_name
             FROM vehicles v JOIN rental_companies c ON c.id = v.company_id
            WHERE v.id = ? AND v.deleted_at IS NULL""", (vehicle_id,))
    if not row:
        raise NotFound("Ce véhicule n'existe pas ou n'est plus proposé.")
    v = dict(row)
    if v["approval_status"] != "approved":
        raise Conflict("Ce véhicule n'est pas encore validé par la plateforme.",
                       code="vehicle_not_approved")
    if v["company_status"] != "approved":
        raise Conflict("Le loueur de ce véhicule n'est pas actif.", code="company_not_active")
    if v["status"] in ("inactive", "unavailable"):
        raise Conflict("Ce véhicule n'est pas disponible à la location.", code="vehicle_inactive")
    return v


def _parse_dt(value: str, field: str) -> datetime:
    try:
        return datetime.strptime(str(value).replace("T", " ")[:16], "%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        raise ValidationError({field: "Format de date et heure invalide (AAAA-MM-JJ HH:MM)."})


def validate_window(pickup_at: str, return_at: str) -> None:
    p = _parse_dt(pickup_at, "pickup_at")
    r = _parse_dt(return_at, "return_at")
    if r <= p:
        raise ValidationError({"return_at": "La date de retour doit être postérieure au départ."})
    lead = float(S.get("min_hours_before_pickup", 0) or 0)
    if p < now().replace(tzinfo=None) + timedelta(hours=lead):
        raise ValidationError({"pickup_at": f"La prise en charge doit être au moins {lead:g} h à l'avance."})
    ahead = int(S.get("max_days_ahead", 365) or 365)
    if p > now().replace(tzinfo=None) + timedelta(days=ahead):
        raise ValidationError({"pickup_at": f"Réservation possible jusqu'à {ahead} jours à l'avance."})


def _fraud_checks(user_id: int) -> None:
    max_pending = int(S.get("max_pending_bookings_per_user", 99) or 99)
    pending = db.scalar(
        """SELECT COUNT(*) FROM bookings
            WHERE customer_user_id = ? AND status IN ('pending','awaiting_payment')""",
        (user_id,), 0)
    if pending >= max_pending:
        raise Conflict(f"Vous avez déjà {pending} réservation(s) en attente. "
                       "Finalisez-les avant d'en créer une nouvelle.", code="too_many_pending")
    max_day = int(S.get("max_bookings_per_day_per_user", 99) or 99)
    today = db.scalar("SELECT COUNT(*) FROM bookings WHERE customer_user_id = ? AND date(created_at) = date('now')",
                      (user_id,), 0)
    if today >= max_day:
        raise Conflict("Limite de réservations quotidiennes atteinte.", code="daily_limit")


def _location(loc_id, company_id: int, field: str) -> dict | None:
    if not loc_id:
        return None
    row = db.one("SELECT * FROM locations WHERE id = ? AND active = 1", (loc_id,))
    if not row:
        raise ValidationError({field: "Agence ou lieu introuvable."})
    loc = dict(row)
    if loc["company_id"] not in (None, company_id):
        raise ValidationError({field: "Ce lieu n'appartient pas à ce loueur."})
    return loc


def quote_for(vehicle_id: int, pickup_at: str, return_at: str, *, services=None,
              pickup_location_id=None, dropoff_location_id=None,
              promo_code=None, user_id=None) -> dict:
    vehicle = get_vehicle_for_booking(vehicle_id)
    validate_window(pickup_at, return_at)
    q = P.quote(vehicle, pickup_at, return_at,
                services=services,
                pickup_location=_location(pickup_location_id, vehicle["company_id"], "pickup_location_id"),
                dropoff_location=_location(dropoff_location_id, vehicle["company_id"], "dropoff_location_id"),
                promo_code=promo_code, user_id=user_id)
    A.release_expired_holds()
    return_date = (A.d(pickup_at[:10]) + timedelta(days=q["days"] - 1)).isoformat()
    return_date = max(return_date, return_at[:10])
    q["available"] = A.is_available(vehicle_id, pickup_at[:10], return_date)
    q["vehicle"] = {"id": vehicle["id"], "brand": vehicle["brand"], "model": vehicle["model"],
                    "slug": vehicle["slug"], "company_name": vehicle["company_name"]}
    return q


def create_booking(*, user: dict, vehicle_id: int, pickup_at: str, return_at: str,
                   pickup_location_id=None, dropoff_location_id=None,
                   services: list[dict] | None = None, promo_code: str | None = None,
                   customer: dict | None = None, notes: str = "",
                   payment_method: str | None = None,
                   actor: dict | None = None, ip: str = None) -> dict:
    actor = actor or user
    A.release_expired_holds()
    vehicle = get_vehicle_for_booking(vehicle_id)
    validate_window(pickup_at, return_at)
    _fraud_checks(user["id"])

    pickup_loc = _location(pickup_location_id, vehicle["company_id"], "pickup_location_id")
    drop_loc = _location(dropoff_location_id, vehicle["company_id"], "dropoff_location_id")

    q = P.quote(vehicle, pickup_at, return_at, services=services,
                pickup_location=pickup_loc, dropoff_location=drop_loc,
                promo_code=promo_code, user_id=user["id"])

    # Occupancy window: pickup day .. return day inclusive
    return_date = max(return_at[:10], (A.d(pickup_at[:10]) + timedelta(days=q["days"] - 1)).isoformat())
    days_to_lock = A.day_range(pickup_at[:10], return_date)

    if S.get("require_license_info") and customer:
        if not customer.get("license_number"):
            raise ValidationError({"license_number": "Numéro de permis obligatoire."})
        exp = customer.get("license_expires_at")
        if exp and exp < pickup_at[:10]:
            raise ValidationError({"license_expires_at":
                                   "Votre permis expire avant la date de prise en charge."})
    if S.get("require_date_of_birth") and customer and customer.get("date_of_birth"):
        min_age = int(S.get("min_driver_age", 21) or 21)
        dob = A.d(customer["date_of_birth"])
        age = (now().date() - dob).days // 365
        if age < min_age:
            raise ValidationError({"date_of_birth": f"Âge minimum requis : {min_age} ans."})

    reference = new_reference()
    hold_minutes = int(S.get("hold_minutes", 30) or 30)
    auto_confirm = bool(S.get("auto_confirm_bookings"))
    status = "confirmed" if auto_confirm else "pending"

    try:
        with db.transaction():                      # BEGIN IMMEDIATE: serialised writer
            # re-read inside the lock: state may have changed since the quote
            fresh = db.one("SELECT status, approval_status FROM vehicles WHERE id = ? AND deleted_at IS NULL",
                           (vehicle_id,))
            if not fresh or fresh["approval_status"] != "approved" or fresh["status"] in ("inactive", "unavailable"):
                raise Conflict("Ce véhicule vient de devenir indisponible.", code="vehicle_unavailable")

            booking_id = db.insert("bookings", {
                "reference": reference,
                "customer_user_id": user["id"],
                "vehicle_id": vehicle_id,
                "company_id": vehicle["company_id"],
                "pickup_location_id": pickup_loc["id"] if pickup_loc else None,
                "dropoff_location_id": drop_loc["id"] if drop_loc else None,
                "pickup_at": pickup_at, "return_at": return_at,
                "pickup_date": pickup_at[:10], "return_date": return_date,
                "days": q["days"], "status": status, "currency": "DZD",
                "base_amount": q["base_amount"], "services_amount": q["services_amount"],
                "fees_amount": q["fees_amount"], "discount_amount": q["discount_amount"],
                "tax_amount": q["tax_amount"], "total_amount": q["total_amount"],
                "deposit_amount": q["deposit_amount"], "commission_amount": q["commission_amount"],
                "payment_status": "pending", "payment_method": payment_method,
                "promo_code_id": q["promo"]["id"] if q["promo"] else None,
                "price_breakdown": db.jdump(q),
                "customer_snapshot": db.jdump(customer or {}),
                "customer_notes": clean_text(notes, 1000),
                "hold_expires_at": in_minutes(hold_minutes) if status == "pending" else None,
                "confirmed_at": now_str() if status == "confirmed" else None,
                "is_demo": 1 if user.get("is_demo") else 0,
                "created_at": now_str(), "updated_at": now_str(),
            })

            # THE integrity step. UNIQUE(vehicle_id, day) turns a race into an error.
            A.lock_days(vehicle_id, days_to_lock, "booking", booking_id=booking_id)

            for line in q["services_selected"]:
                db.insert("booking_services", {
                    "booking_id": booking_id, "service_id": line["service_id"],
                    "code": line["code"], "name_snapshot": line["label"], "qty": line["qty"],
                    "unit_price": line["unit"], "price_type": line["price_type"],
                    "amount": line["amount"]})

            if q["promo"]:
                db.insert("promo_redemptions", {
                    "promo_id": q["promo"]["id"], "user_id": user["id"],
                    "booking_id": booking_id, "amount": q["discount_amount"],
                    "created_at": now_str()})
                db.execute("UPDATE promo_codes SET used_count = used_count + 1 WHERE id = ?",
                           (q["promo"]["id"],))

            db.insert("booking_status_history", {
                "booking_id": booking_id, "from_status": None, "to_status": status,
                "actor_user_id": actor["id"], "reason": "Création de la réservation",
                "created_at": now_str()})

            if customer:
                _upsert_customer_profile(user["id"], customer)

    except sqlite3.IntegrityError as e:
        if "vehicle_day_locks" in str(e) or "UNIQUE" in str(e).upper():
            raise Conflict(
                "Ce véhicule vient d'être réservé pour ces dates. Choisissez d'autres dates "
                "ou un autre véhicule.", code="dates_unavailable",
                extra={"vehicle_id": vehicle_id, "pickup_date": pickup_at[:10],
                       "return_date": return_date})
        raise

    booking = get_booking(booking_id)
    ctx = {"reference": reference,
           "vehicle": f"{vehicle['brand']} {vehicle['model']}",
           "pickup": pickup_at, "ret": return_at,
           "total": money(q["total_amount"]), "customer": user.get("full_name", "")}
    notify(user["id"], "booking_created", ctx)
    owner_id = db.scalar("SELECT owner_user_id FROM rental_companies WHERE id = ?", (vehicle["company_id"],))
    if owner_id:
        notify(owner_id, "booking_received_vendor", ctx)
    notify_admins("booking_received_vendor", ctx)
    audit("booking.created", actor=actor, target_type="booking", target_id=booking_id, ip=ip,
          metadata={"reference": reference, "vehicle_id": vehicle_id,
                    "total": q["total_amount"], "days": q["days"]})
    return booking


def _upsert_customer_profile(user_id: int, c: dict) -> None:
    db.execute(
        """INSERT INTO customer_profiles (user_id, date_of_birth, address, wilaya_id, commune_id,
                                          license_number, license_issued_at, license_expires_at, updated_at)
           VALUES (:user_id,:dob,:address,:wilaya_id,:commune_id,:lic,:iss,:exp,:updated)
           ON CONFLICT(user_id) DO UPDATE SET
             date_of_birth=COALESCE(excluded.date_of_birth, date_of_birth),
             address=COALESCE(excluded.address, address),
             wilaya_id=COALESCE(excluded.wilaya_id, wilaya_id),
             commune_id=COALESCE(excluded.commune_id, commune_id),
             license_number=COALESCE(excluded.license_number, license_number),
             license_issued_at=COALESCE(excluded.license_issued_at, license_issued_at),
             license_expires_at=COALESCE(excluded.license_expires_at, license_expires_at),
             updated_at=excluded.updated_at""",
        {"user_id": user_id, "dob": c.get("date_of_birth"), "address": c.get("address"),
         "wilaya_id": c.get("wilaya_id"), "commune_id": c.get("commune_id"),
         "lic": c.get("license_number"), "iss": c.get("license_issued_at"),
         "exp": c.get("license_expires_at"), "updated": now_str()})


def get_booking(booking_id: int) -> dict | None:
    row = db.one(
        """SELECT b.*, v.brand, v.model, v.year, v.slug AS vehicle_slug, v.transmission, v.fuel,
                  v.seats, c.name AS company_name, c.phone AS company_phone, c.slug AS company_slug,
                  u.full_name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
                  pl.name_fr AS pickup_location, dl.name_fr AS dropoff_location,
                  (SELECT path FROM vehicle_images WHERE vehicle_id = v.id
                    ORDER BY is_primary DESC, sort LIMIT 1) AS image
             FROM bookings b
             JOIN vehicles v ON v.id = b.vehicle_id
             JOIN rental_companies c ON c.id = b.company_id
             JOIN users u ON u.id = b.customer_user_id
             LEFT JOIN locations pl ON pl.id = b.pickup_location_id
             LEFT JOIN locations dl ON dl.id = b.dropoff_location_id
            WHERE b.id = ?""", (booking_id,))
    if not row:
        return None
    b = dict(row)
    b["breakdown"] = db.jload(b.pop("price_breakdown"), {})
    b["customer_snapshot"] = db.jload(b.get("customer_snapshot"), {})
    b["services"] = db.rows_to_dicts(db.query(
        "SELECT code, name_snapshot, qty, unit_price, amount FROM booking_services WHERE booking_id = ?",
        (booking_id,)))
    b["history"] = db.rows_to_dicts(db.query(
        """SELECT h.from_status, h.to_status, h.reason, h.created_at, u.full_name AS actor
             FROM booking_status_history h LEFT JOIN users u ON u.id = h.actor_user_id
            WHERE h.booking_id = ? ORDER BY h.id""", (booking_id,)))
    b["payments"] = db.rows_to_dicts(db.query(
        """SELECT id, provider_code, kind, amount, status, provider_txn_id, created_at
             FROM payments WHERE booking_id = ? ORDER BY id""", (booking_id,)))
    return b


def by_reference(reference: str) -> dict | None:
    row = db.one("SELECT id FROM bookings WHERE reference = ?", (reference,))
    return get_booking(row["id"]) if row else None


def can_view(booking: dict, req) -> bool:
    if not req.user:
        return False
    if req.has_perm("booking.view.all"):
        return True
    if booking["customer_user_id"] == req.user["id"]:
        return True
    if (req.has_perm("booking.view.company") and booking["company_id"] in req.company_ids()):
        return True
    return False


def assert_can_view(booking: dict, req) -> None:
    if not can_view(booking, req):
        # 404, not 403: never confirm the existence of someone else's booking
        raise NotFound("Réservation introuvable.")


def can_manage(booking: dict, req) -> bool:
    if req.has_perm("booking.manage.all"):
        return True
    return (req.has_perm("booking.manage.company") and booking["company_id"] in req.company_ids())


def transition(booking_id: int, to_status: str, *, actor: dict, reason: str = "",
               ip: str = None, release_days: bool | None = None) -> dict:
    with db.transaction():
        row = db.one("SELECT * FROM bookings WHERE id = ?", (booking_id,))
        if not row:
            raise NotFound("Réservation introuvable.")
        current = row["status"]
        if to_status == current:
            return get_booking(booking_id)
        if to_status not in TRANSITIONS.get(current, ()):
            raise Conflict(f"Transition impossible : {current} → {to_status}.",
                           code="invalid_transition")
        patch = {"status": to_status, "updated_at": now_str()}
        if to_status == "confirmed":
            patch.update({"confirmed_at": now_str(), "hold_expires_at": None})
        if to_status == "active":
            patch["started_at"] = now_str()
            db.execute("UPDATE vehicles SET status='rented' WHERE id = ?", (row["vehicle_id"],))
        if to_status == "completed":
            patch["completed_at"] = now_str()
            db.execute("UPDATE vehicles SET status='available' WHERE id = ?", (row["vehicle_id"],))
            db.execute("UPDATE vehicles SET bookings_count = bookings_count + 1 WHERE id = ?",
                       (row["vehicle_id"],))
        if to_status in ("cancelled", "rejected", "expired"):
            patch.update({"cancelled_at": now_str(), "cancelled_by": actor["id"],
                          "cancel_reason": clean_text(reason, 300) or None})
        should_release = release_days if release_days is not None else to_status in (
            "cancelled", "rejected", "expired", "completed", "no_show")
        if should_release:
            db.execute("DELETE FROM vehicle_day_locks WHERE booking_id = ?", (booking_id,))
        db.update("bookings", booking_id, patch)
        db.insert("booking_status_history", {
            "booking_id": booking_id, "from_status": current, "to_status": to_status,
            "actor_user_id": actor["id"], "reason": clean_text(reason, 300) or None,
            "created_at": now_str()})
    audit(f"booking.{to_status}", actor=actor, target_type="booking", target_id=booking_id,
          ip=ip, metadata={"from": current, "to": to_status, "reason": reason})
    booking = get_booking(booking_id)
    ctx = {"reference": booking["reference"], "reason": reason or "-",
           "vehicle": f"{booking['brand']} {booking['model']}",
           "pickup": booking["pickup_at"], "ret": booking["return_at"],
           "refund": money(booking.get("refund_amount") or 0)}
    tpl = {"confirmed": "booking_confirmed", "rejected": "booking_rejected",
           "cancelled": "booking_cancelled", "expired": "booking_expired",
           "completed": "review_request"}.get(to_status)
    if tpl:
        notify(booking["customer_user_id"], tpl, ctx)
    return booking


def cancel_booking(booking_id: int, *, actor: dict, reason: str = "", ip: str = None) -> dict:
    row = db.one("SELECT * FROM bookings WHERE id = ?", (booking_id,))
    if not row:
        raise NotFound("Réservation introuvable.")
    booking = dict(row)
    if booking["status"] in CLOSED_STATUSES:
        raise Conflict("Cette réservation est déjà clôturée.", code="already_closed")
    if booking["status"] == "active":
        raise Conflict("Une location en cours ne peut pas être annulée. Contactez l'agence.",
                       code="rental_in_progress")

    refund = P.refund_for_cancellation(booking)
    monthly = db.scalar(
        """SELECT COUNT(*) FROM bookings
            WHERE customer_user_id = ? AND status='cancelled'
              AND cancelled_at >= date('now','-30 days')""", (booking["customer_user_id"],), 0)
    if monthly >= int(S.get("max_cancellations_per_month", 99) or 99) and actor["id"] == booking["customer_user_id"]:
        raise Conflict("Trop d'annulations sur les 30 derniers jours. Contactez le support.",
                       code="cancellation_limit")

    result = transition(booking_id, "cancelled", actor=actor, reason=reason, ip=ip)
    patch = {"refund_amount": refund["refund_amount"]}
    if refund["refund_amount"] > 0:
        patch["payment_status"] = ("refunded" if refund["refund_amount"] >= int(booking["paid_amount"] or 0)
                                   else "partially_refunded")
    elif int(booking["paid_amount"] or 0) == 0:
        patch["payment_status"] = "cancelled"
    db.update("bookings", booking_id, patch)

    if refund["refund_amount"] > 0:
        pay = db.one("SELECT id FROM payments WHERE booking_id = ? AND status='paid' ORDER BY id LIMIT 1",
                     (booking_id,))
        if pay:
            db.insert("refunds", {"payment_id": pay["id"], "booking_id": booking_id,
                                  "amount": refund["refund_amount"], "status": "pending",
                                  "reason": reason or "Annulation client",
                                  "created_by": actor["id"], "created_at": now_str()})
    result = get_booking(booking_id)
    result["refund"] = refund
    return result


def customer_bookings(user_id: int, scope: str = "all", limit: int = 20, offset: int = 0) -> dict:
    where = "b.customer_user_id = ?"
    params: list = [user_id]
    today = now().strftime("%Y-%m-%d")
    if scope == "upcoming":
        where += " AND b.status IN ('pending','awaiting_payment','confirmed') AND b.return_date >= ?"
        params.append(today)
    elif scope == "past":
        where += " AND (b.status IN ('completed','no_show') OR (b.return_date < ? AND b.status='active'))"
        params.append(today)
    elif scope == "cancelled":
        where += " AND b.status IN ('cancelled','rejected','expired')"
    elif scope == "active":
        where += " AND b.status = 'active'"
    total = db.scalar(f"SELECT COUNT(*) FROM bookings b WHERE {where}", tuple(params), 0)
    rows = db.query(
        f"""SELECT b.id, b.reference, b.status, b.payment_status, b.pickup_at, b.return_at,
                   b.days, b.total_amount, b.deposit_amount, b.currency, b.created_at,
                   v.brand, v.model, v.year, v.slug AS vehicle_slug,
                   c.name AS company_name,
                   (SELECT path FROM vehicle_images WHERE vehicle_id = v.id
                     ORDER BY is_primary DESC, sort LIMIT 1) AS image,
                   (SELECT 1 FROM reviews r WHERE r.booking_id = b.id) AS has_review
              FROM bookings b
              JOIN vehicles v ON v.id = b.vehicle_id
              JOIN rental_companies c ON c.id = b.company_id
             WHERE {where}
             ORDER BY b.pickup_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [limit, offset]))
    return {"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset}
