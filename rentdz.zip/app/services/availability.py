"""
Availability. Truth lives in vehicle_day_locks (UNIQUE per vehicle+day), so two
overlapping blocking periods are impossible at the database level.
Convention: a rental occupies every calendar day from pickup date to return date
inclusive (the return day is needed for cleaning/handover).
"""
from __future__ import annotations
from datetime import datetime, date, timedelta
from .. import db
from ..security import now, utc_str

BLOCKING_BOOKING_STATUSES = ("pending", "awaiting_payment", "confirmed", "active")


def d(value: str | date) -> date:
    if isinstance(value, date):
        return value
    return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()


def day_range(start, end) -> list[str]:
    """Inclusive list of 'YYYY-MM-DD' between start and end."""
    s, e = d(start), d(end)
    if e < s:
        return []
    return [(s + timedelta(days=i)).isoformat() for i in range((e - s).days + 1)]


def rental_days(pickup_at: str, return_at: str) -> int:
    """Billable days: every started 24 h period, minimum 1."""
    p = datetime.strptime(pickup_at[:16], "%Y-%m-%d %H:%M")
    r = datetime.strptime(return_at[:16], "%Y-%m-%d %H:%M")
    hours = (r - p).total_seconds() / 3600.0
    if hours <= 0:
        return 0
    return max(1, int(-(-hours // 24)))


def release_expired_holds() -> int:
    """Pending bookings past their hold expiry are expired and their days freed."""
    stale = db.query(
        """SELECT id FROM bookings
            WHERE status IN ('pending','awaiting_payment')
              AND hold_expires_at IS NOT NULL AND hold_expires_at < ?""",
        (utc_str(),))
    freed = 0
    for row in stale:
        with db.transaction():
            cur = db.one("SELECT status FROM bookings WHERE id = ?", (row["id"],))
            if not cur or cur["status"] not in ("pending", "awaiting_payment"):
                continue
            db.execute("DELETE FROM vehicle_day_locks WHERE booking_id = ?", (row["id"],))
            db.execute("UPDATE bookings SET status='expired', updated_at=? WHERE id = ?",
                       (now().strftime("%Y-%m-%d %H:%M"), row["id"]))
            db.insert("booking_status_history", {
                "booking_id": row["id"], "from_status": cur["status"], "to_status": "expired",
                "reason": "Délai de confirmation dépassé (libération automatique du véhicule)"})
            freed += 1
    db.execute("DELETE FROM vehicle_day_locks WHERE kind='hold' AND expires_at IS NOT NULL AND expires_at < ?",
               (utc_str(),))
    return freed


def conflicting_days(vehicle_id: int, pickup_date: str, return_date: str,
                     exclude_booking_id: int | None = None) -> list[dict]:
    days = day_range(pickup_date, return_date)
    if not days:
        return []
    marks = ",".join("?" * len(days))
    sql = f"""SELECT day, kind, booking_id, maintenance_id, block_id
                FROM vehicle_day_locks
               WHERE vehicle_id = ? AND day IN ({marks})"""
    params: list = [vehicle_id, *days]
    if exclude_booking_id:
        sql += " AND (booking_id IS NULL OR booking_id != ?)"
        params.append(exclude_booking_id)
    return db.rows_to_dicts(db.query(sql + " ORDER BY day", tuple(params)))


def is_available(vehicle_id: int, pickup_date: str, return_date: str,
                 exclude_booking_id: int | None = None) -> bool:
    return not conflicting_days(vehicle_id, pickup_date, return_date, exclude_booking_id)


def available_vehicle_ids(pickup_date: str, return_date: str) -> set[int]:
    """Vehicles with at least one lock inside the window are excluded."""
    days = day_range(pickup_date, return_date)
    if not days:
        return set()
    marks = ",".join("?" * len(days))
    busy = db.query(f"SELECT DISTINCT vehicle_id FROM vehicle_day_locks WHERE day IN ({marks})",
                    tuple(days))
    return {r["vehicle_id"] for r in busy}


def unavailable_sql_fragment(days: list[str]) -> tuple[str, list]:
    """NOT EXISTS fragment so search filters unavailable vehicles inside SQL."""
    marks = ",".join("?" * len(days))
    return (f""" AND NOT EXISTS (SELECT 1 FROM vehicle_day_locks l
                                  WHERE l.vehicle_id = v.id AND l.day IN ({marks}))""",
            list(days))


def lock_days(vehicle_id: int, days: list[str], kind: str, *, booking_id=None,
              maintenance_id=None, block_id=None, expires_at=None) -> None:
    """
    Insert one row per day. Relies on UNIQUE(vehicle_id, day): a competing writer
    triggers IntegrityError instead of silently double-booking.
    """
    for day in days:
        db.insert("vehicle_day_locks", {
            "vehicle_id": vehicle_id, "day": day, "kind": kind,
            "booking_id": booking_id, "maintenance_id": maintenance_id,
            "block_id": block_id, "expires_at": expires_at,
        })


def calendar(vehicle_id: int, start: str, end: str) -> list[dict]:
    """Day-by-day state for the fleet calendar UI."""
    locks = {r["day"]: r for r in db.query(
        """SELECT l.day, l.kind, l.booking_id, l.maintenance_id, l.block_id,
                  b.reference, b.status AS booking_status, u.full_name AS customer
             FROM vehicle_day_locks l
             LEFT JOIN bookings b ON b.id = l.booking_id
             LEFT JOIN users u ON u.id = b.customer_user_id
            WHERE l.vehicle_id = ? AND l.day BETWEEN ? AAND2 ?""".replace("AAND2", "ND"),
        (vehicle_id, start, end))}
    out = []
    for day in day_range(start, end):
        row = locks.get(day)
        if row is None:
            out.append({"day": day, "state": "available"})
        else:
            out.append({"day": day,
                        "state": row["kind"],
                        "booking_id": row["booking_id"],
                        "reference": row["reference"],
                        "booking_status": row["booking_status"],
                        "customer": row["customer"]})
    return out
