"""Payments: idempotent creation, offline confirmation, refunds, webhook intake."""
from __future__ import annotations
import secrets
from .. import db
from ..http import NotFound, Conflict, Forbidden, BadRequest
from ..security import now_str, ValidationError, clean_text
from .payment import get_provider, available_providers
from .audit import record as audit
from .notification_service import notify
from ..i18n import money


def _booking(booking_id: int) -> dict:
    row = db.one("SELECT * FROM bookings WHERE id = ?", (booking_id,))
    if not row:
        raise NotFound("Réservation introuvable.")
    return dict(row)


def initiate(*, booking_id: int, provider_code: str, kind: str, actor: dict,
             ip: str = None, return_url: str = "") -> dict:
    booking = _booking(booking_id)
    if booking["customer_user_id"] != actor["id"] and "payment.manage" not in actor.get("permissions", set()):
        raise NotFound("Réservation introuvable.")
    if booking["status"] in ("cancelled", "rejected", "expired", "completed"):
        raise Conflict("Cette réservation n'accepte plus de paiement.", code="booking_closed")
    enabled = {p["code"] for p in available_providers()}
    if provider_code not in enabled:
        raise ValidationError({"provider_code": "Moyen de paiement indisponible."})
    provider = get_provider(provider_code)
    if kind not in ("deposit", "full", "balance"):
        raise ValidationError({"kind": "Type de paiement invalide."})
    amount = (booking["deposit_amount"] if kind == "deposit"
              else booking["total_amount"] - int(booking["paid_amount"] or 0))
    if amount <= 0:
        raise Conflict("Aucun montant à payer.", code="nothing_due")

    # Idempotency: same booking+kind+provider never creates two live payments.
    key = f"{booking['reference']}:{kind}:{provider_code}"
    existing = db.one("SELECT * FROM payments WHERE idempotency_key = ?", (key,))
    if existing and existing["status"] in ("pending", "processing", "paid"):
        return {"payment": dict(existing), "idempotent": True,
                "message": "Un paiement est déjà en cours pour cette réservation."}

    result = provider.create_payment(booking, amount, kind=kind, idempotency_key=key,
                                     return_url=return_url)
    if result.requires_configuration:
        raise Conflict(result.message, code="provider_not_configured",
                       extra={"provider": provider_code, "configuration_required": True})
    if existing:
        key = f"{key}:{secrets.token_hex(3)}"
    payment_id = db.insert("payments", {
        "booking_id": booking_id, "user_id": booking["customer_user_id"],
        "provider_code": provider_code, "kind": kind, "amount": amount, "currency": "DZD",
        "status": result.status, "provider_txn_id": result.provider_txn_id,
        "idempotency_key": key, "payload": db.jdump(result.raw or {}),
        "created_at": now_str(), "updated_at": now_str()})
    patch = {"payment_method": provider_code, "updated_at": now_str()}
    if result.status == "processing":
        patch["payment_status"] = "processing"
    if booking["status"] == "pending" and get_provider(provider_code).kind == "online":
        patch["status"] = "awaiting_payment"
        db.insert("booking_status_history", {"booking_id": booking_id, "from_status": "pending",
                                            "to_status": "awaiting_payment",
                                            "actor_user_id": actor["id"],
                                            "reason": "Paiement en ligne initié",
                                            "created_at": now_str()})
    db.update("bookings", booking_id, patch)
    audit("payment.initiated", actor=actor, target_type="payment", target_id=payment_id, ip=ip,
          metadata={"booking": booking["reference"], "provider": provider_code, "amount": amount})
    return {"payment": dict(db.one("SELECT * FROM payments WHERE id = ?", (payment_id,))),
            "redirect_url": result.redirect_url, "message": result.message,
            "instructions": provider.instructions_fr}


def mark_paid(*, payment_id: int, actor: dict, provider_txn_id: str = None,
              ip: str = None, amount: int = None) -> dict:
    """Used by staff/admin for offline money and by verified webhooks for online."""
    row = db.one("SELECT * FROM payments WHERE id = ?", (payment_id,))
    if not row:
        raise NotFound("Paiement introuvable.")
    payment = dict(row)
    if payment["status"] == "paid":
        return payment                                    # idempotent
    if payment["status"] in ("refunded", "cancelled"):
        raise Conflict("Ce paiement est clôturé.", code="payment_closed")
    booking = _booking(payment["booking_id"])
    paid = int(amount or payment["amount"])
    with db.transaction():
        db.update("payments", payment_id, {"status": "paid", "updated_at": now_str(),
                                           "provider_txn_id": provider_txn_id or payment["provider_txn_id"]})
        total_paid = db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE booking_id=? AND status='paid'",
                              (payment["booking_id"],), 0)
        pstatus = ("paid" if total_paid >= booking["total_amount"]
                   else "partially_paid" if total_paid > 0 else "pending")
        db.update("bookings", payment["booking_id"],
                  {"paid_amount": total_paid, "payment_status": pstatus, "updated_at": now_str()})
    audit("payment.paid", actor=actor, target_type="payment", target_id=payment_id, ip=ip,
          metadata={"booking": booking["reference"], "amount": paid})
    notify(booking["customer_user_id"], "payment_recorded",
           {"reference": booking["reference"], "amount": money(paid)})
    return dict(db.one("SELECT * FROM payments WHERE id = ?", (payment_id,)))


def mark_failed(*, payment_id: int, reason: str, actor: dict = None, ip: str = None) -> dict:
    row = db.one("SELECT * FROM payments WHERE id = ?", (payment_id,))
    if not row:
        raise NotFound("Paiement introuvable.")
    db.update("payments", payment_id, {"status": "failed", "failure_reason": clean_text(reason, 250),
                                       "updated_at": now_str()})
    booking = _booking(row["booking_id"])
    db.update("bookings", row["booking_id"], {"payment_status": "failed", "updated_at": now_str()})
    audit("payment.failed", actor=actor, target_type="payment", target_id=payment_id, ip=ip,
          metadata={"reason": reason})
    notify(booking["customer_user_id"], "payment_failed", {"reference": booking["reference"]})
    return dict(db.one("SELECT * FROM payments WHERE id = ?", (payment_id,)))


def refund(*, payment_id: int, amount: int, actor: dict, reason: str = "", ip: str = None) -> dict:
    row = db.one("SELECT * FROM payments WHERE id = ?", (payment_id,))
    if not row:
        raise NotFound("Paiement introuvable.")
    payment = dict(row)
    if payment["status"] not in ("paid", "partially_refunded"):
        raise Conflict("Seul un paiement encaissé peut être remboursé.", code="not_refundable")
    already = db.scalar("""SELECT COALESCE(SUM(amount),0) FROM refunds
                            WHERE payment_id = ? AND status IN ('refunded','processing','pending')""",
                        (payment_id,), 0)
    if amount <= 0 or already + amount > payment["amount"]:
        raise ValidationError({"amount": "Montant de remboursement supérieur au paiement."})
    provider = get_provider(payment["provider_code"])
    result = provider.refund(payment, amount)
    with db.transaction():
        refund_id = db.insert("refunds", {
            "payment_id": payment_id, "booking_id": payment["booking_id"], "amount": amount,
            "status": result.status if result.status in ("pending", "processing", "refunded") else "pending",
            "reason": clean_text(reason, 300), "provider_txn_id": result.provider_txn_id,
            "created_by": actor["id"], "created_at": now_str()})
        total_ref = already + amount
        db.update("payments", payment_id,
                  {"status": "refunded" if total_ref >= payment["amount"] else "partially_refunded",
                   "updated_at": now_str()})
        booking = _booking(payment["booking_id"])
        db.update("bookings", payment["booking_id"], {
            "refund_amount": int(booking["refund_amount"] or 0) + amount,
            "payment_status": "refunded" if total_ref >= int(booking["paid_amount"] or 0) else "partially_refunded",
            "updated_at": now_str()})
    audit("payment.refunded", actor=actor, target_type="payment", target_id=payment_id, ip=ip,
          metadata={"amount": amount, "reason": reason, "refund_id": refund_id})
    notify(payment["user_id"], "refund_processed",
           {"reference": db.scalar("SELECT reference FROM bookings WHERE id = ?", (payment["booking_id"],)),
            "amount": money(amount)})
    return dict(db.one("SELECT * FROM refunds WHERE id = ?", (refund_id,)))


def handle_webhook(provider_code: str, headers: dict, body: bytes) -> dict:
    """Signature-verified and idempotent: a replayed event changes nothing."""
    provider = get_provider(provider_code)
    if not provider:
        raise NotFound("Fournisseur inconnu.")
    if not provider.verify_webhook(headers, body):
        audit("payment.webhook_rejected", metadata={"provider": provider_code,
                                                   "reason": "signature invalide ou secret absent"})
        raise Forbidden("Signature de webhook invalide.")
    event = provider.parse_webhook(headers, body)
    event_id = event.get("event_id") or ""
    if not event_id:
        raise BadRequest("Événement sans identifiant.")
    try:
        db.insert("payment_webhook_events", {"provider_code": provider_code, "event_id": event_id,
                                             "payload": body.decode("utf-8", "replace")[:20000]})
    except Exception:
        return {"status": "duplicate_ignored", "event_id": event_id}
    txn = event.get("provider_txn_id")
    payment = db.one("""SELECT * FROM payments WHERE provider_code = ?
                          AND (provider_txn_id = ? OR idempotency_key = ?)""",
                     (provider_code, txn, event.get("booking_reference") or ""))
    if not payment:
        return {"status": "unmatched", "event_id": event_id}
    system = {"id": None, "email": f"webhook:{provider_code}", "permissions": {"payment.manage"}}
    if event.get("status") == "paid":
        mark_paid(payment_id=payment["id"], actor=system, provider_txn_id=txn)
    elif event.get("status") == "failed":
        mark_failed(payment_id=payment["id"], reason="Échec signalé par le fournisseur", actor=system)
    db.execute("UPDATE payment_webhook_events SET processed_at = ? WHERE provider_code = ? AND event_id = ?",
               (now_str(), provider_code, event_id))
    return {"status": "processed", "event_id": event_id}
