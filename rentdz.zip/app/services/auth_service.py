"""Registration, login, verification, password reset. Enumeration-safe by design."""
from __future__ import annotations
from .. import db
from ..config import Config
from ..http import BadRequest, Conflict, Unauthorized, Forbidden, TooMany
from ..security import (hash_password, verify_password, password_problem, valid_email,
                        normalise_phone, clean_text, ValidationError, now_str, utc_str,
                        in_hours, new_token, token_hash, rate_limited, ROLES, PERMISSIONS,
                        ROLE_PERMISSIONS, now)
from .audit import record as audit
from .notification_service import notify

GENERIC_LOGIN_ERROR = "E-mail ou mot de passe incorrect."


def seed_roles() -> None:
    for code, (fr, ar, en, rank) in ROLES.items():
        db.execute("""INSERT INTO roles (code, name_fr, name_ar, name_en, rank) VALUES (?,?,?,?,?)
                      ON CONFLICT(code) DO UPDATE SET name_fr=excluded.name_fr, rank=excluded.rank""",
                   (code, fr, ar, en, rank))
    for code, desc in PERMISSIONS.items():
        db.execute("""INSERT INTO permissions (code, description) VALUES (?,?)
                      ON CONFLICT(code) DO UPDATE SET description=excluded.description""", (code, desc))
    for role_code, perms in ROLE_PERMISSIONS.items():
        rid = db.scalar("SELECT id FROM roles WHERE code = ?", (role_code,))
        db.execute("DELETE FROM role_permissions WHERE role_id = ?", (rid,))
        for p in perms:
            db.execute("INSERT OR IGNORE INTO role_permissions (role_id, permission_code) VALUES (?,?)",
                       (rid, p))


def grant_role(user_id: int, role_code: str, company_id: int | None = None) -> None:
    rid = db.scalar("SELECT id FROM roles WHERE code = ?", (role_code,))
    if not rid:
        raise BadRequest("Rôle inconnu.")
    db.execute("INSERT OR IGNORE INTO user_roles (user_id, role_id, company_id, created_at) VALUES (?,?,?,?)",
               (user_id, rid, company_id, now_str()))


def revoke_role(user_id: int, role_code: str) -> None:
    rid = db.scalar("SELECT id FROM roles WHERE code = ?", (role_code,))
    db.execute("DELETE FROM user_roles WHERE user_id = ? AND role_id = ?", (user_id, rid))


def find_by_email(email: str):
    return db.one("SELECT * FROM users WHERE lower(email) = lower(?) AND deleted_at IS NULL",
                  (email.strip(),))


def register(*, email: str, password: str, full_name: str, phone: str = "",
             locale: str = "fr", role: str = "customer", is_demo: bool = False,
             ip: str = None, user_agent: str = None) -> dict:
    errors = {}
    email = (email or "").strip().lower()
    full_name = clean_text(full_name, 120)
    if not valid_email(email):
        errors["email"] = "Adresse e-mail invalide."
    if len(full_name) < 3:
        errors["full_name"] = "Indiquez votre nom complet."
    pw = password_problem(password or "")
    if pw:
        errors["password"] = pw
    phone_n = normalise_phone(phone) if phone else None
    if phone and not phone_n:
        errors["phone"] = "Numéro algérien invalide (ex. 0555 12 34 56)."
    if role not in ("customer", "fleet_owner"):
        errors["role"] = "Type de compte invalide."
    if errors:
        raise ValidationError(errors)

    with db.transaction():
        if find_by_email(email):
            # Do not leak account existence through a distinct error.
            raise Conflict("Impossible de créer ce compte. Essayez de vous connecter ou "
                           "utilisez « mot de passe oublié ».", code="registration_blocked")
        user_id = db.insert("users", {
            "email": email, "phone": phone_n, "password_hash": hash_password(password),
            "full_name": full_name, "locale": locale if locale in Config.LOCALES else "fr",
            "status": "active", "is_demo": 1 if is_demo else 0,
            "created_at": now_str(), "updated_at": now_str()})
        grant_role(user_id, role)
        token = new_token()
        db.insert("auth_tokens", {"user_id": user_id, "kind": "verify_email",
                                  "token_hash": token_hash(token), "expires_at": in_hours(48),
                                  "created_at": utc_str()})
    notify(user_id, "welcome", {}, channels=("in_app", "email"), recipient_email=email)
    notify(user_id, "verify_email",
           {"link": f"{Config.APP_URL}/verifier-email?token={token}"},
           channels=("email",), recipient_email=email)
    audit("user.registered", actor={"id": user_id, "email": email}, target_type="user",
          target_id=user_id, ip=ip, user_agent=user_agent, metadata={"role": role})
    return {"id": user_id, "email": email, "full_name": full_name,
            "verification_token": token if Config.DEBUG else None}


def login(*, email: str, password: str, ip: str = "", user_agent: str = "") -> dict:
    email = (email or "").strip().lower()
    if rate_limited(f"login:ip:{ip}", 20, 300) or rate_limited(f"login:email:{email}", 8, 300):
        raise TooMany("Trop de tentatives de connexion. Réessayez dans quelques minutes.")
    row = find_by_email(email)
    if not row:
        # constant-ish work regardless of existence, and identical message
        verify_password(password or "", "pbkdf2_sha256$1$AAAA$AAAA")
        raise Unauthorized(GENERIC_LOGIN_ERROR)
    user = dict(row)
    if user["locked_until"] and user["locked_until"] > utc_str():
        raise TooMany("Compte temporairement bloqué après plusieurs échecs. Réessayez plus tard.")
    if not verify_password(password or "", user["password_hash"]):
        fails = int(user["failed_logins"] or 0) + 1
        patch = {"failed_logins": fails, "updated_at": now_str()}
        if fails >= Config.MAX_LOGIN_ATTEMPTS:
            patch["locked_until"] = in_hours(Config.LOCKOUT_MINUTES / 60.0)
            patch["failed_logins"] = 0
            audit("user.login_locked", actor=user, target_type="user", target_id=user["id"], ip=ip)
        db.update("users", user["id"], patch)
        raise Unauthorized(GENERIC_LOGIN_ERROR)
    if user["status"] == "suspended":
        raise Forbidden("Votre compte est suspendu. Contactez le support RENTDZ.")
    if user["status"] == "deleted":
        raise Unauthorized(GENERIC_LOGIN_ERROR)
    db.update("users", user["id"], {"failed_logins": 0, "locked_until": None,
                                    "last_login_at": now_str(), "updated_at": now_str()})
    audit("user.login", actor=user, target_type="user", target_id=user["id"], ip=ip,
          user_agent=user_agent)
    return user


def verify_email(token: str) -> bool:
    row = db.one("""SELECT * FROM auth_tokens WHERE kind='verify_email' AND token_hash = ?
                      AND used_at IS NULL AND expires_at > ?""", (token_hash(token), utc_str()))
    if not row:
        return False
    with db.transaction():
        db.update("auth_tokens", row["id"], {"used_at": utc_str()})
        db.update("users", row["user_id"], {"email_verified_at": now_str(), "updated_at": now_str()})
    audit("user.email_verified", actor=row["user_id"], target_type="user", target_id=row["user_id"])
    return True


def request_password_reset(email: str, ip: str = "") -> str | None:
    """Always behaves identically whether or not the account exists."""
    if rate_limited(f"pwreset:ip:{ip}", 10, 900):
        raise TooMany("Trop de demandes. Réessayez plus tard.")
    row = find_by_email(email or "")
    if not row:
        return None
    token = new_token()
    db.insert("auth_tokens", {"user_id": row["id"], "kind": "reset_password",
                              "token_hash": token_hash(token), "expires_at": in_hours(2),
                              "created_at": utc_str()})
    notify(row["id"], "password_reset",
           {"link": f"{Config.APP_URL}/nouveau-mot-de-passe?token={token}"},
           channels=("email",), recipient_email=row["email"])
    audit("user.password_reset_requested", actor=dict(row), target_type="user",
          target_id=row["id"], ip=ip)
    return token


def reset_password(token: str, new_password: str) -> bool:
    problem = password_problem(new_password or "")
    if problem:
        raise ValidationError({"password": problem})
    row = db.one("""SELECT * FROM auth_tokens WHERE kind='reset_password' AND token_hash = ?
                      AND used_at IS NULL AND expires_at > ?""", (token_hash(token), utc_str()))
    if not row:
        raise BadRequest("Lien de réinitialisation invalide ou expiré.")
    with db.transaction():
        db.update("auth_tokens", row["id"], {"used_at": utc_str()})
        db.update("users", row["user_id"], {"password_hash": hash_password(new_password),
                                            "failed_logins": 0, "locked_until": None,
                                            "updated_at": now_str()})
        # password change kills every other session
        db.execute("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL",
                   (utc_str(), row["user_id"]))
    audit("user.password_reset", actor=row["user_id"], target_type="user", target_id=row["user_id"])
    return True


def change_password(user_id: int, current: str, new_password: str) -> bool:
    row = db.one("SELECT password_hash FROM users WHERE id = ?", (user_id,))
    if not row or not verify_password(current or "", row["password_hash"]):
        raise ValidationError({"current_password": "Mot de passe actuel incorrect."})
    problem = password_problem(new_password or "")
    if problem:
        raise ValidationError({"password": problem})
    db.update("users", user_id, {"password_hash": hash_password(new_password), "updated_at": now_str()})
    db.execute("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL",
               (utc_str(), user_id))
    audit("user.password_changed", actor=user_id, target_type="user", target_id=user_id)
    return True


def public_user(user_id: int) -> dict | None:
    row = db.one("""SELECT id, email, full_name, phone, locale, status, email_verified_at, created_at
                      FROM users WHERE id = ? AND deleted_at IS NULL""", (user_id,))
    if not row:
        return None
    u = dict(row)
    u["roles"] = [r["code"] for r in db.query(
        "SELECT r.code FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id = ?", (user_id,))]
    prof = db.one("SELECT * FROM customer_profiles WHERE user_id = ?", (user_id,))
    u["profile"] = dict(prof) if prof else {}
    u["companies"] = db.rows_to_dicts(db.query(
        "SELECT id, name, slug, status FROM rental_companies WHERE owner_user_id = ? AND deleted_at IS NULL",
        (user_id,)))
    return u
