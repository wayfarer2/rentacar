"""Provider-agnostic payment contract. No provider-specific logic leaks upward."""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class PaymentResult:
    status: str                    # pending|processing|paid|failed
    provider_txn_id: str | None = None
    redirect_url: str | None = None
    message: str = ""
    requires_configuration: bool = False
    raw: dict = field(default_factory=dict)


class PaymentProvider:
    code = "base"
    name = "Base"
    kind = "offline"                # offline | online
    supports_refund = False
    instructions_fr = ""

    def is_configured(self) -> bool:
        return True

    def config_status(self) -> str:
        return "configured" if self.is_configured() else "configuration_required"

    # -- lifecycle
    def create_payment(self, booking: dict, amount: int, *, kind: str,
                       idempotency_key: str, return_url: str = "") -> PaymentResult:
        raise NotImplementedError

    def verify_webhook(self, headers: dict, body: bytes) -> bool:
        return False

    def parse_webhook(self, headers: dict, body: bytes) -> dict:
        return {}

    def refund(self, payment: dict, amount: int) -> PaymentResult:
        return PaymentResult("failed", message="Remboursement non pris en charge par ce moyen de paiement.")

    def to_public(self) -> dict:
        return {"code": self.code, "name": self.name, "kind": self.kind,
                "status": self.config_status(), "supports_refund": self.supports_refund,
                "instructions": self.instructions_fr}
