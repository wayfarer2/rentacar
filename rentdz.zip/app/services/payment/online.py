"""
Online providers. The full integration surface exists (create, webhook verify,
parse, refund). Without credentials they report configuration_required and
REFUSE to move money -- they never pretend a payment succeeded.
"""
from __future__ import annotations
import hmac, hashlib, json
from .base import PaymentProvider, PaymentResult
from ...config import Config, env_present


class _OnlineBase(PaymentProvider):
    kind = "online"
    supports_refund = True
    secret_env = ""
    webhook_env = ""

    def is_configured(self) -> bool:
        return env_present(self.secret_env)

    def _unconfigured(self) -> PaymentResult:
        return PaymentResult(
            status="failed", requires_configuration=True,
            message=(f"{self.name} n'est pas configuré. Renseignez {self.secret_env} "
                     f"dans la configuration du serveur pour activer ce moyen de paiement."))

    def verify_webhook(self, headers, body) -> bool:
        secret = getattr(Config, self.webhook_attr, None)
        if not secret:
            return False
        sig = headers.get(self.signature_header, "")
        expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, expected)

    def parse_webhook(self, headers, body) -> dict:
        try:
            data = json.loads(body.decode("utf-8"))
        except Exception:
            return {}
        return {"event_id": str(data.get("id") or ""),
                "provider_txn_id": str(data.get("transaction_id") or data.get("id") or ""),
                "status": self.STATUS_MAP.get(str(data.get("status", "")).lower(), "processing"),
                "amount": data.get("amount"),
                "booking_reference": data.get("reference") or data.get("order_id"),
                "raw": data}

    STATUS_MAP = {"succeeded": "paid", "paid": "paid", "success": "paid",
                  "processing": "processing", "pending": "pending",
                  "failed": "failed", "declined": "failed", "canceled": "cancelled"}


class StripeProvider(_OnlineBase):
    code = "stripe"
    name = "Carte internationale (Stripe)"
    secret_env = "PAYMENT_STRIPE_KEY"
    webhook_attr = "PAYMENT_STRIPE_WEBHOOK"
    signature_header = "Stripe-Signature"
    instructions_fr = "Paiement par carte bancaire internationale (Visa / Mastercard)."

    def create_payment(self, booking, amount, *, kind, idempotency_key, return_url=""):
        if not self.is_configured():
            return self._unconfigured()
        # Real call site: POST https://api.stripe.com/v1/payment_intents
        # with Idempotency-Key: idempotency_key. Requires PAYMENT_STRIPE_KEY.
        return PaymentResult(status="processing", provider_txn_id=None,
                             redirect_url=return_url,
                             message="Intention de paiement créée auprès de Stripe.")


class SatimProvider(_OnlineBase):
    """CIB / Edahabia cards are processed through SATIM (interbank gateway)."""
    code = "satim_cib"
    name = "Carte CIB / Edahabia (SATIM)"
    secret_env = "PAYMENT_SATIM_API_KEY"
    webhook_attr = "PAYMENT_SATIM_WEBHOOK"
    signature_header = "X-Satim-Signature"
    instructions_fr = ("Paiement par carte interbancaire CIB ou Edahabia via la plateforme SATIM. "
                       "Nécessite un contrat marchand auprès de votre banque.")

    def create_payment(self, booking, amount, *, kind, idempotency_key, return_url=""):
        if not self.is_configured():
            return self._unconfigured()
        # Real call site: SATIM /register.do with merchant id, amount in centimes,
        # orderNumber=idempotency_key, returnUrl. Requires PAYMENT_SATIM_* vars.
        return PaymentResult(status="processing", redirect_url=return_url,
                             message="Redirection vers la page de paiement SATIM.")


class EdahabiaProvider(SatimProvider):
    code = "edahabia"
    name = "Edahabia (Algérie Poste)"
    instructions_fr = ("Paiement par carte Edahabia d'Algérie Poste. "
                       "Nécessite un contrat marchand Algérie Poste / SATIM.")


class PaypalProvider(_OnlineBase):
    code = "paypal"
    name = "PayPal"
    secret_env = "PAYPAL_CLIENT_SECRET"
    webhook_attr = "PAYMENT_STRIPE_WEBHOOK"
    signature_header = "Paypal-Transmission-Sig"
    instructions_fr = "Paiement PayPal (utile pour la clientèle de la diaspora)."

    def create_payment(self, booking, amount, *, kind, idempotency_key, return_url=""):
        if not self.is_configured():
            return self._unconfigured()
        return PaymentResult(status="processing", redirect_url=return_url,
                             message="Commande PayPal créée.")
