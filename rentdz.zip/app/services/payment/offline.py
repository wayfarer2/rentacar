"""Offline methods: real in Algeria today (cash on pickup, bank transfer)."""
from __future__ import annotations
from .base import PaymentProvider, PaymentResult


class CashOnPickupProvider(PaymentProvider):
    code = "cash_on_pickup"
    name = "Espèces à la prise en charge"
    kind = "offline"
    supports_refund = True
    instructions_fr = ("Vous réglerez en espèces à l'agence lors de la prise en charge du véhicule. "
                       "Une caution peut être demandée sur place.")

    def create_payment(self, booking, amount, *, kind, idempotency_key, return_url=""):
        return PaymentResult(
            status="pending",
            provider_txn_id=f"CASH-{booking['reference']}",
            message="Paiement à effectuer à l'agence. Rien n'est débité en ligne.",
        )

    def refund(self, payment, amount):
        return PaymentResult("refunded", provider_txn_id=payment.get("provider_txn_id"),
                             message="Remboursement à effectuer par l'agence (suivi manuel).")


class BankTransferProvider(PaymentProvider):
    code = "bank_transfer"
    name = "Virement bancaire / versement"
    kind = "offline"
    supports_refund = True
    instructions_fr = ("Effectuez un virement ou un versement sur le compte de l'agence, puis "
                       "transmettez le reçu. L'agence validera le paiement manuellement.")

    def create_payment(self, booking, amount, *, kind, idempotency_key, return_url=""):
        return PaymentResult(
            status="pending",
            provider_txn_id=f"TRF-{booking['reference']}",
            message="En attente de réception du virement et de validation par l'agence.",
        )

    def refund(self, payment, amount):
        return PaymentResult("pending", message="Remboursement par virement à traiter par l'agence.")
