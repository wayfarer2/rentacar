from __future__ import annotations
from ... import db
from .base import PaymentProvider, PaymentResult
from .offline import CashOnPickupProvider, BankTransferProvider
from .online import StripeProvider, SatimProvider, EdahabiaProvider, PaypalProvider

_PROVIDERS: dict[str, PaymentProvider] = {
    p.code: p for p in (CashOnPickupProvider(), BankTransferProvider(),
                        SatimProvider(), EdahabiaProvider(),
                        StripeProvider(), PaypalProvider())
}


def get_provider(code: str) -> PaymentProvider | None:
    return _PROVIDERS.get(code)


def provider_catalogue() -> list[dict]:
    return [p.to_public() for p in _PROVIDERS.values()]


def available_providers() -> list[dict]:
    """Only methods an admin enabled AND that are actually usable."""
    from .. import settings_service as S
    enabled = set(S.get("payment_methods_enabled") or [])
    out = []
    for p in _PROVIDERS.values():
        if p.code not in enabled:
            continue
        pub = p.to_public()
        pub["usable"] = p.is_configured()
        out.append(pub)
    return out


def seed_providers() -> None:
    for p in _PROVIDERS.values():
        db.execute(
            """INSERT INTO payment_providers (code, name, kind, enabled, config_status, supports_refund, sort)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(code) DO UPDATE SET name=excluded.name, kind=excluded.kind,
                    config_status=excluded.config_status, supports_refund=excluded.supports_refund""",
            (p.code, p.name, p.kind, 1 if p.kind == "offline" else 0,
             p.config_status(), 1 if p.supports_refund else 0, 0))
