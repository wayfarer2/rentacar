"""Platform settings: every business/legal number is configurable, never hardcoded."""
from __future__ import annotations
import json
from .. import db
from ..security import now_str

DEFAULTS: dict[str, tuple] = {
    # (value, group)
    "company_name":          ("RENTDZ", "brand"),
    "company_tagline":       ("Votre route commence ici.", "brand"),
    "support_email":         ("support@rentdz.dz", "brand"),
    "support_phone":         ("0555000000", "brand"),
    "logo_path":             ("", "brand"),
    "default_locale":        ("fr", "localisation"),
    "enabled_locales":       (["fr", "ar", "en"], "localisation"),
    "currency":              ("DZD", "localisation"),
    "timezone":              ("Africa/Algiers", "localisation"),

    # Booking rules
    "min_rental_days":       (1, "booking"),
    "max_rental_days":       (90, "booking"),
    "min_hours_before_pickup": (2, "booking"),
    "max_days_ahead":        (365, "booking"),
    "min_driver_age":        (21, "booking"),
    "require_date_of_birth": (True, "booking"),
    "require_license_info":  (True, "booking"),
    "require_documents_before_confirm": (True, "booking"),
    "hold_minutes":          (30, "booking"),
    "auto_confirm_bookings": (False, "booking"),
    "turnaround_note":       ("Le jour de restitution reste bloqué pour la préparation du véhicule.", "booking"),

    # Money (admin-editable: no Algerian tax rate is hardcoded in code)
    "vat_enabled":           (False, "finance"),
    "vat_rate_percent":      (0.0, "finance"),
    "service_fee_percent":   (0.0, "finance"),
    "platform_commission_percent": (12.0, "finance"),
    "deposit_default_percent": (20.0, "finance"),
    "long_rental_discount":  ([{"min_days": 7, "percent": 5}, {"min_days": 30, "percent": 12}], "finance"),

    # Cancellation policy (evaluated top-down, first match wins)
    "cancellation_policy":   ([
        {"hours_before": 48, "refund_percent": 100, "label": "Annulation gratuite jusqu'à 48 h avant le départ"},
        {"hours_before": 24, "refund_percent": 50,  "label": "Remboursement de 50 % entre 48 h et 24 h"},
        {"hours_before": 0,  "refund_percent": 0,   "label": "Aucun remboursement moins de 24 h avant le départ"},
    ], "cancellation"),

    # Documents
    "document_retention_days": (1095, "documents"),
    "document_url_ttl_seconds": (300, "documents"),
    "required_customer_documents": (["driver_license"], "documents"),

    # Providers
    "payment_methods_enabled": (["cash_on_pickup", "bank_transfer"], "payments"),
    "map_provider":          ("osm", "integrations"),

    # Fraud / abuse
    "max_pending_bookings_per_user": (3, "fraud"),
    "max_bookings_per_day_per_user": (5, "fraud"),
    "max_cancellations_per_month": (5, "fraud"),

    # Legal
    "terms_url":             ("/legal/conditions", "legal"),
    "privacy_url":           ("/legal/confidentialite", "legal"),
    "rental_agreement_intro": ("Le présent contrat est conclu entre le loueur et le locataire "
                               "désignés ci-dessous, conformément à la législation algérienne en vigueur.", "legal"),
}

_cache: dict | None = None


def _load() -> dict:
    global _cache
    if _cache is None:
        _cache = {}
        try:
            for row in db.query("SELECT key, value FROM settings"):
                _cache[row["key"]] = db.jload(row["value"])
        except Exception:
            _cache = {}
    return _cache


def invalidate() -> None:
    global _cache
    _cache = None


def get(key: str, default=None):
    data = _load()
    if key in data:
        return data[key]
    if key in DEFAULTS:
        return DEFAULTS[key][0]
    return default


def set_value(key: str, value, user_id: int | None = None) -> None:
    grp = DEFAULTS.get(key, (None, "general"))[1]
    db.execute(
        """INSERT INTO settings (key, value, grp, updated_at, updated_by)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(key) DO UPDATE SET value = excluded.value,
                                          updated_at = excluded.updated_at,
                                          updated_by = excluded.updated_by""",
        (key, db.jdump(value), grp, now_str(), user_id))
    invalidate()


def all_settings() -> dict:
    out = {}
    for key, (val, grp) in DEFAULTS.items():
        out[key] = {"value": get(key, val), "group": grp, "default": val}
    return out


def seed_defaults() -> None:
    existing = {r["key"] for r in db.query("SELECT key FROM settings")}
    for key, (val, grp) in DEFAULTS.items():
        if key not in existing:
            db.insert("settings", {"key": key, "value": db.jdump(val), "grp": grp,
                                   "updated_at": now_str()})
    invalidate()
