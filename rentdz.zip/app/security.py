"""Password hashing, tokens, CSRF, rate limiting, input validation, RBAC."""
from __future__ import annotations
import hashlib, hmac, base64, secrets, re, time, unicodedata
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .config import Config
from . import db

TZ = ZoneInfo(Config.TIMEZONE)

# ── time helpers (single source of truth: Africa/Algiers) ────────────────────
def now() -> datetime:
    return datetime.now(TZ).replace(microsecond=0)

def now_str() -> str:
    return now().strftime("%Y-%m-%d %H:%M")

def utc_str(dt: datetime | None = None) -> str:
    return (dt or datetime.now(timezone.utc)).strftime("%Y-%m-%d %H:%M:%S")

def in_hours(h: float) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=h)).strftime("%Y-%m-%d %H:%M:%S")

def in_minutes(m: float) -> str:
    return (datetime.now(timezone.utc) + timedelta(minutes=m)).strftime("%Y-%m-%d %H:%M:%S")


# ── passwords ────────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    it = Config.PBKDF2_ITERATIONS
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, it)
    return f"pbkdf2_sha256${it}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, it, salt_b64, hash_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(),
                                 base64.b64decode(salt_b64), int(it))
        return hmac.compare_digest(dk, base64.b64decode(hash_b64))
    except Exception:
        return False


PASSWORD_RULES_FR = ("Le mot de passe doit contenir au moins %d caractères, "
                     "dont une lettre et un chiffre.")

def password_problem(password: str) -> str | None:
    if not password or len(password) < Config.PASSWORD_MIN_LEN:
        return PASSWORD_RULES_FR % Config.PASSWORD_MIN_LEN
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return PASSWORD_RULES_FR % Config.PASSWORD_MIN_LEN
    if password.lower() in ("motdepasse", "password", "azertyuiop", "1234567890"):
        return "Ce mot de passe est trop courant."
    return None


# ── tokens ───────────────────────────────────────────────────────────────────
def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)

def token_hash(token: str) -> str:
    return hashlib.sha256((Config.secret() + token).encode()).hexdigest()

def sign(value: str, ttl_seconds: int | None = None) -> str:
    """Signed, optionally expiring value: used for private document URLs."""
    exp = str(int(time.time()) + ttl_seconds) if ttl_seconds else "0"
    payload = f"{value}.{exp}"
    mac = hmac.new(Config.secret().encode(), payload.encode(), hashlib.sha256).hexdigest()[:32]
    return f"{payload}.{mac}"

def unsign(token: str) -> str | None:
    try:
        value, exp, mac = token.rsplit(".", 2)
    except ValueError:
        return None
    expected = hmac.new(Config.secret().encode(), f"{value}.{exp}".encode(),
                        hashlib.sha256).hexdigest()[:32]
    if not hmac.compare_digest(mac, expected):
        return None
    if exp != "0" and int(exp) < int(time.time()):
        return None
    return value


# ── rate limiting (DB-backed sliding window) ─────────────────────────────────
def rate_limited(bucket: str, limit: int, per_seconds: int) -> bool:
    if not Config.RATE_LIMIT_ENABLED:
        return False
    cutoff = (datetime.now(timezone.utc) - timedelta(seconds=per_seconds)).strftime("%Y-%m-%d %H:%M:%S")
    db.execute("DELETE FROM rate_events WHERE created_at < ?",
               ((datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),))
    n = db.scalar("SELECT COUNT(*) FROM rate_events WHERE bucket = ? AND created_at >= ?",
                  (bucket, cutoff), 0)
    if n >= limit:
        return True
    db.execute("INSERT INTO rate_events (bucket, created_at) VALUES (?, ?)", (bucket, utc_str()))
    return False


# ── validation ───────────────────────────────────────────────────────────────
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,}$")
# Algerian numbers: 0[5-7]XXXXXXXX, +2135XXXXXXXX, 0[1-4]XXXXXXX (landline)
PHONE_RE = re.compile(r"^(?:\+213|00213|0)(?:[5-7]\d{8}|[1-4]\d{7})$")

class ValidationError(Exception):
    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__("validation_error")


def normalise_phone(raw: str) -> str | None:
    if not raw:
        return None
    p = re.sub(r"[\s.\-()]", "", raw.strip())
    if not PHONE_RE.match(p):
        return None
    if p.startswith("00213"):
        p = "0" + p[5:]
    elif p.startswith("+213"):
        p = "0" + p[4:]
    return p


def valid_email(raw: str) -> bool:
    return bool(raw and EMAIL_RE.match(raw.strip()) and len(raw.strip()) <= 254)


def slugify(text: str, extra: str = "") -> str:
    base = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-zA-Z0-9]+", "-", base).strip("-").lower()
    base = re.sub(r"-{2,}", "-", base) or "item"
    return f"{base}-{extra}" if extra else base


def clean_text(raw, max_len: int = 500) -> str:
    """Strip control chars and trim. Output is HTML-escaped at render time."""
    if raw is None:
        return ""
    s = str(raw).replace("\x00", "")
    s = "".join(ch for ch in s if ch == "\n" or ch == "\t" or unicodedata.category(ch)[0] != "C")
    return s.strip()[:max_len]


def as_int(raw, field: str, *, minimum=None, maximum=None, required=True, default=None):
    if raw in (None, ""):
        if required:
            raise ValidationError({field: "Ce champ est obligatoire."})
        return default
    try:
        v = int(str(raw).strip())
    except (TypeError, ValueError):
        raise ValidationError({field: "Valeur numérique invalide."})
    if minimum is not None and v < minimum:
        raise ValidationError({field: f"La valeur minimale est {minimum}."})
    if maximum is not None and v > maximum:
        raise ValidationError({field: f"La valeur maximale est {maximum}."})
    return v


MAX_SQLITE_INT = 2 ** 63 - 1


def as_id(raw, field: str = "id", *, required=True, default=None):
    """Row identifier: positive and inside SQLite's INTEGER range."""
    if raw in (None, ""):
        if required:
            raise ValidationError({field: "Identifiant manquant."})
        return default
    try:
        v = int(str(raw).strip())
    except (TypeError, ValueError):
        raise ValidationError({field: "Identifiant invalide."})
    if v < 1 or v > MAX_SQLITE_INT:
        raise ValidationError({field: "Identifiant invalide."})
    return v


def as_choice(raw, field: str, choices: tuple | list, required=True, default=None):
    if raw in (None, ""):
        if required:
            raise ValidationError({field: "Ce champ est obligatoire."})
        return default
    v = str(raw).strip()
    if v not in choices:
        raise ValidationError({field: "Valeur non autorisée."})
    return v


DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")


def as_date(raw, field: str, required=True):
    if raw in (None, ""):
        if required:
            raise ValidationError({field: "Date obligatoire."})
        return None
    s = str(raw).strip()
    if not DATE_RE.match(s):
        raise ValidationError({field: "Format de date invalide (AAAA-MM-JJ)."})
    try:
        datetime.strptime(s, "%Y-%m-%d")
    except ValueError:
        raise ValidationError({field: "Date invalide."})
    return s


def as_datetime(raw, field: str, required=True):
    if raw in (None, ""):
        if required:
            raise ValidationError({field: "Date et heure obligatoires."})
        return None
    s = str(raw).strip().replace("T", " ")
    if not DATETIME_RE.match(s):
        raise ValidationError({field: "Format invalide (AAAA-MM-JJ HH:MM)."})
    try:
        dt = datetime.strptime(s[:16], "%Y-%m-%d %H:%M")
    except ValueError:
        raise ValidationError({field: "Date et heure invalides."})
    return dt.strftime("%Y-%m-%d %H:%M")


# ── file upload safety ───────────────────────────────────────────────────────
_MAGIC = {
    b"\xff\xd8\xff": "image/jpeg",
    b"\x89PNG\r\n\x1a\n": "image/png",
    b"%PDF-": "application/pdf",
}

def sniff_mime(data: bytes) -> str | None:
    for magic, mime in _MAGIC.items():
        if data.startswith(magic):
            return mime
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def safe_upload(data: bytes, filename: str, allowed: tuple, max_mb: int) -> tuple[str, str]:
    """Validate by magic bytes (never by extension). Returns (mime, safe_name)."""
    if not data:
        raise ValidationError({"file": "Fichier vide."})
    if len(data) > max_mb * 1024 * 1024:
        raise ValidationError({"file": f"Fichier trop volumineux (max {max_mb} Mo)."})
    mime = sniff_mime(data)
    if mime is None or mime not in allowed:
        raise ValidationError({"file": "Type de fichier non autorisé (JPEG, PNG, WEBP ou PDF)."})
    ext = {"image/jpeg": ".jpg", "image/png": ".png",
           "image/webp": ".webp", "application/pdf": ".pdf"}[mime]
    return mime, f"{secrets.token_hex(16)}{ext}"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ── RBAC ─────────────────────────────────────────────────────────────────────
ROLES = {
    "customer":        ("Client", "عميل", "Customer", 10),
    "fleet_owner":     ("Propriétaire de flotte", "مالك الأسطول", "Fleet owner", 40),
    "fleet_manager":   ("Gestionnaire de flotte", "مدير الأسطول", "Fleet manager", 35),
    "staff":           ("Agent d'agence", "موظف", "Agency staff", 30),
    "support_agent":   ("Agent support", "وكيل الدعم", "Support agent", 50),
    "finance_manager": ("Responsable financier", "المدير المالي", "Finance manager", 60),
    "admin":           ("Administrateur", "مدير", "Administrator", 90),
    "super_admin":     ("Super administrateur", "مدير عام", "Super administrator", 100),
}

PERMISSIONS = {
    "booking.create":      "Créer une réservation",
    "booking.view.own":    "Voir ses réservations",
    "booking.cancel.own":  "Annuler ses réservations",
    "booking.view.company": "Voir les réservations de sa société",
    "booking.manage.company": "Gérer les réservations de sa société",
    "booking.view.all":    "Voir toutes les réservations",
    "booking.manage.all":  "Gérer toutes les réservations",
    "vehicle.manage.company": "Gérer les véhicules de sa société",
    "vehicle.view.all":    "Voir tous les véhicules",
    "vehicle.approve":     "Approuver les véhicules",
    "company.manage.own":  "Gérer sa société",
    "company.manage.all":  "Gérer toutes les sociétés",
    "company.approve":     "Approuver les sociétés",
    "document.upload":     "Téléverser des documents",
    "document.view.own":   "Voir ses documents",
    "document.review":     "Approuver / rejeter les documents",
    "document.view.all":   "Voir tous les documents",
    "payment.view.own":    "Voir ses paiements",
    "payment.view.company": "Voir les paiements de sa société",
    "payment.view.all":    "Voir tous les paiements",
    "payment.manage":      "Gérer paiements et remboursements",
    "user.view.all":       "Voir tous les utilisateurs",
    "user.manage":         "Gérer les utilisateurs",
    "user.suspend":        "Suspendre un compte",
    "review.moderate":     "Modérer les avis",
    "promo.manage":        "Gérer les codes promo",
    "settings.manage":     "Modifier les paramètres",
    "analytics.view":      "Voir les analyses",
    "analytics.view.company": "Voir les analyses de sa société",
    "audit.view":          "Consulter les journaux d'audit",
    "support.manage":      "Gérer les tickets de support",
    "maintenance.manage":  "Gérer la maintenance",
}

ROLE_PERMISSIONS = {
    "customer": ["booking.create", "booking.view.own", "booking.cancel.own",
                 "document.upload", "document.view.own", "payment.view.own"],
    "fleet_owner": ["vehicle.manage.company", "booking.view.company", "booking.manage.company",
                    "company.manage.own", "payment.view.company", "analytics.view.company",
                    "maintenance.manage", "document.upload", "document.view.own"],
    "fleet_manager": ["vehicle.manage.company", "booking.view.company", "booking.manage.company",
                      "analytics.view.company", "maintenance.manage"],
    "staff": ["booking.view.company", "booking.manage.company"],
    "support_agent": ["booking.view.all", "user.view.all", "support.manage", "document.view.all"],
    "finance_manager": ["payment.view.all", "payment.manage", "booking.view.all", "analytics.view"],
    "admin": ["booking.view.all", "booking.manage.all", "vehicle.view.all", "vehicle.approve",
              "company.manage.all", "company.approve", "document.review", "document.view.all",
              "payment.view.all", "payment.manage", "user.view.all", "user.manage", "user.suspend",
              "review.moderate", "promo.manage", "settings.manage", "analytics.view",
              "audit.view", "support.manage", "maintenance.manage"],
    "super_admin": list(PERMISSIONS.keys()),
}

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(self), camera=(self), microphone=()",
    "Content-Security-Policy": (
        "default-src 'self'; img-src 'self' data: blob:; "
        "style-src 'self' 'unsafe-inline'; script-src 'self'; "
        "connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    ),
    "Cross-Origin-Opener-Policy": "same-origin",
}
