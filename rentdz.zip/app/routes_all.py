"""Single import point that registers every route (API + server-rendered pages)."""
from .api import (auth_routes, catalog_routes, booking_routes, document_routes,
                  payment_routes, fleet_routes, admin_routes, misc_routes)  # noqa: F401
from .web import views  # noqa: F401
