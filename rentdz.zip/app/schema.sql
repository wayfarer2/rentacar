-- RENTDZ schema. SQLite (WAL, FK enforced). All money = INTEGER Algerian Dinar (DZD).
-- All datetimes = TEXT 'YYYY-MM-DD HH:MM' in Africa/Algiers (single-market platform).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);

-- ── Settings ─────────────────────────────────────────────────────────────────
CREATE TABLE settings (
  key         TEXT PRIMARY KEY,
  value       TEXT NOT NULL,            -- JSON encoded
  grp         TEXT NOT NULL DEFAULT 'general',
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by  INTEGER
);

-- ── Identity / RBAC ──────────────────────────────────────────────────────────
CREATE TABLE users (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  email            TEXT NOT NULL,
  phone            TEXT,
  password_hash    TEXT NOT NULL,
  full_name        TEXT NOT NULL,
  locale           TEXT NOT NULL DEFAULT 'fr',
  status           TEXT NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','pending','suspended','deleted')),
  email_verified_at TEXT,
  phone_verified_at TEXT,
  is_demo          INTEGER NOT NULL DEFAULT 0,
  failed_logins    INTEGER NOT NULL DEFAULT 0,
  locked_until     TEXT,
  last_login_at    TEXT,
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at       TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at       TEXT
);
CREATE UNIQUE INDEX ux_users_email ON users(lower(email)) WHERE deleted_at IS NULL;
CREATE INDEX ix_users_status ON users(status);
CREATE INDEX ix_users_created ON users(created_at);

CREATE TABLE roles (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  code    TEXT NOT NULL UNIQUE,
  name_fr TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  rank    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE permissions (
  code        TEXT PRIMARY KEY,
  description TEXT NOT NULL
);
CREATE TABLE role_permissions (
  role_id         INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_code TEXT NOT NULL REFERENCES permissions(code) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_code)
);
CREATE TABLE user_roles (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id    INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  company_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, role_id)
);
CREATE INDEX ix_user_roles_user ON user_roles(user_id);

CREATE TABLE sessions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash    TEXT NOT NULL UNIQUE,     -- sha256 of session token; raw token never stored
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_token    TEXT NOT NULL,
  ip            TEXT,
  user_agent    TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at  TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at    TEXT NOT NULL,
  revoked_at    TEXT
);
CREATE INDEX ix_sessions_user ON sessions(user_id);
CREATE INDEX ix_sessions_expires ON sessions(expires_at);

CREATE TABLE auth_tokens (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL CHECK (kind IN ('verify_email','reset_password','otp_phone')),
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_auth_tokens_lookup ON auth_tokens(kind, token_hash);

CREATE TABLE rate_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  bucket     TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_rate_events ON rate_events(bucket, created_at);

CREATE TABLE customer_profiles (
  user_id        INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  date_of_birth  TEXT,
  address        TEXT,
  wilaya_id      INTEGER REFERENCES wilayas(id),
  commune_id     INTEGER REFERENCES communes(id),
  license_number TEXT,
  license_issued_at TEXT,
  license_expires_at TEXT,
  updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Geography ────────────────────────────────────────────────────────────────
CREATE TABLE wilayas (
  id      INTEGER PRIMARY KEY,           -- official wilaya code 1..58
  code    TEXT NOT NULL UNIQUE,
  slug    TEXT NOT NULL UNIQUE,
  name_fr TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  name_en TEXT NOT NULL,
  lat     REAL, lng REAL,
  active  INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE communes (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  wilaya_id INTEGER NOT NULL REFERENCES wilayas(id) ON DELETE CASCADE,
  slug      TEXT NOT NULL,
  name_fr   TEXT NOT NULL,
  name_ar   TEXT NOT NULL,
  lat REAL, lng REAL,
  UNIQUE (wilaya_id, slug)
);
CREATE INDEX ix_communes_wilaya ON communes(wilaya_id);

CREATE TABLE locations (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id  INTEGER REFERENCES rental_companies(id) ON DELETE CASCADE,
  wilaya_id   INTEGER NOT NULL REFERENCES wilayas(id),
  commune_id  INTEGER REFERENCES communes(id),
  kind        TEXT NOT NULL DEFAULT 'office'
              CHECK (kind IN ('office','airport','station','city','delivery')),
  slug        TEXT NOT NULL UNIQUE,
  name_fr     TEXT NOT NULL,
  name_ar     TEXT NOT NULL,
  name_en     TEXT NOT NULL,
  address     TEXT,
  lat REAL, lng REAL,
  iata_code   TEXT,
  extra_fee   INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_locations_wilaya ON locations(wilaya_id, active);
CREATE INDEX ix_locations_company ON locations(company_id);

-- ── Companies ────────────────────────────────────────────────────────────────
CREATE TABLE rental_companies (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  name          TEXT NOT NULL,
  slug          TEXT NOT NULL UNIQUE,
  legal_name    TEXT,
  rc_number     TEXT,                    -- Registre de Commerce
  nif           TEXT,                    -- Numéro d'Identification Fiscale
  phone         TEXT NOT NULL,
  email         TEXT,
  wilaya_id     INTEGER REFERENCES wilayas(id),
  commune_id    INTEGER REFERENCES communes(id),
  address       TEXT,
  logo_path     TEXT,
  description   TEXT,
  status        TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','approved','rejected','suspended')),
  commission_rate REAL,                  -- NULL = use platform default
  rating_avg    REAL NOT NULL DEFAULT 0,
  rating_count  INTEGER NOT NULL DEFAULT 0,
  is_demo       INTEGER NOT NULL DEFAULT 0,
  approved_at   TEXT, approved_by INTEGER,
  reject_reason TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at    TEXT
);
CREATE INDEX ix_companies_status ON rental_companies(status);
CREATE INDEX ix_companies_owner ON rental_companies(owner_user_id);

CREATE TABLE company_staff (
  company_id INTEGER NOT NULL REFERENCES rental_companies(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role       TEXT NOT NULL DEFAULT 'fleet_manager',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (company_id, user_id)
);

-- ── Fleet ────────────────────────────────────────────────────────────────────
CREATE TABLE vehicle_categories (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  code    TEXT NOT NULL UNIQUE,
  slug    TEXT NOT NULL UNIQUE,
  name_fr TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  sort    INTEGER NOT NULL DEFAULT 0,
  active  INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE features (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  code    TEXT NOT NULL UNIQUE,
  name_fr TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  icon    TEXT
);
CREATE TABLE vehicles (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id    INTEGER NOT NULL REFERENCES rental_companies(id) ON DELETE CASCADE,
  slug          TEXT NOT NULL UNIQUE,
  brand         TEXT NOT NULL,
  model         TEXT NOT NULL,
  year          INTEGER NOT NULL,
  category_id   INTEGER NOT NULL REFERENCES vehicle_categories(id),
  transmission  TEXT NOT NULL CHECK (transmission IN ('manual','automatic')),
  fuel          TEXT NOT NULL CHECK (fuel IN ('petrol','diesel','hybrid','electric','gpl')),
  seats         INTEGER NOT NULL CHECK (seats BETWEEN 1 AND 20),
  doors         INTEGER NOT NULL DEFAULT 5,
  color         TEXT,
  mileage       INTEGER NOT NULL DEFAULT 0,
  registration_number TEXT,              -- private: never exposed publicly
  description   TEXT,
  daily_price   INTEGER NOT NULL CHECK (daily_price > 0),
  weekly_price  INTEGER,
  monthly_price INTEGER,
  weekend_price INTEGER,
  deposit       INTEGER NOT NULL DEFAULT 0 CHECK (deposit >= 0),
  min_days      INTEGER NOT NULL DEFAULT 1 CHECK (min_days >= 1),
  max_days      INTEGER NOT NULL DEFAULT 90,
  km_included_per_day INTEGER,           -- NULL = unlimited
  extra_km_price INTEGER NOT NULL DEFAULT 0,
  fuel_policy   TEXT NOT NULL DEFAULT 'same_to_same',
  primary_location_id INTEGER REFERENCES locations(id),
  status        TEXT NOT NULL DEFAULT 'available'
                CHECK (status IN ('available','reserved','rented','maintenance','unavailable','inactive')),
  approval_status TEXT NOT NULL DEFAULT 'pending'
                CHECK (approval_status IN ('pending','approved','rejected')),
  reject_reason TEXT,
  rating_avg    REAL NOT NULL DEFAULT 0,
  rating_count  INTEGER NOT NULL DEFAULT 0,
  bookings_count INTEGER NOT NULL DEFAULT 0,
  is_demo       INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at    TEXT
);
CREATE INDEX ix_vehicles_search ON vehicles(approval_status, status, deleted_at, daily_price);
CREATE INDEX ix_vehicles_company ON vehicles(company_id, deleted_at);
CREATE INDEX ix_vehicles_category ON vehicles(category_id);
CREATE INDEX ix_vehicles_location ON vehicles(primary_location_id);
CREATE INDEX ix_vehicles_rating ON vehicles(rating_avg DESC);

CREATE TABLE vehicle_features (
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  feature_id INTEGER NOT NULL REFERENCES features(id) ON DELETE CASCADE,
  PRIMARY KEY (vehicle_id, feature_id)
);
CREATE TABLE vehicle_images (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  path       TEXT NOT NULL,
  alt        TEXT,
  sort       INTEGER NOT NULL DEFAULT 0,
  is_primary INTEGER NOT NULL DEFAULT 0,
  size_bytes INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_vehicle_images ON vehicle_images(vehicle_id, sort);

CREATE TABLE vehicle_maintenance (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date   TEXT NOT NULL,
  reason     TEXT NOT NULL,
  cost       INTEGER NOT NULL DEFAULT 0,
  status     TEXT NOT NULL DEFAULT 'planned'
             CHECK (status IN ('planned','in_progress','done','cancelled')),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (end_date >= start_date)
);
CREATE INDEX ix_maint_vehicle ON vehicle_maintenance(vehicle_id, start_date, end_date);

CREATE TABLE vehicle_blocks (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date   TEXT NOT NULL,
  reason     TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (end_date >= start_date)
);
CREATE INDEX ix_blocks_vehicle ON vehicle_blocks(vehicle_id, start_date, end_date);

-- ── THE integrity guard: one row per occupied vehicle-day ────────────────────
-- A vehicle can never hold two overlapping blocking periods because of the
-- UNIQUE(vehicle_id, day) constraint. Enforced by the database, not the app.
CREATE TABLE vehicle_day_locks (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id     INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  day            TEXT NOT NULL,                       -- 'YYYY-MM-DD'
  kind           TEXT NOT NULL CHECK (kind IN ('booking','hold','maintenance','blocked')),
  booking_id     INTEGER REFERENCES bookings(id) ON DELETE CASCADE,
  maintenance_id INTEGER REFERENCES vehicle_maintenance(id) ON DELETE CASCADE,
  block_id       INTEGER REFERENCES vehicle_blocks(id) ON DELETE CASCADE,
  expires_at     TEXT,                                -- holds only
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (vehicle_id, day)
);
CREATE INDEX ix_day_locks_lookup ON vehicle_day_locks(vehicle_id, day);
CREATE INDEX ix_day_locks_booking ON vehicle_day_locks(booking_id);
CREATE INDEX ix_day_locks_expiry ON vehicle_day_locks(kind, expires_at);

-- ── Bookings ─────────────────────────────────────────────────────────────────
CREATE TABLE services (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER REFERENCES rental_companies(id) ON DELETE CASCADE,
  code       TEXT NOT NULL,
  name_fr TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  price_type TEXT NOT NULL DEFAULT 'per_booking'
             CHECK (price_type IN ('per_day','per_booking')),
  price      INTEGER NOT NULL DEFAULT 0,
  max_qty    INTEGER NOT NULL DEFAULT 1,
  active     INTEGER NOT NULL DEFAULT 1,
  UNIQUE (company_id, code)
);

CREATE TABLE bookings (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  reference         TEXT NOT NULL UNIQUE,
  customer_user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  vehicle_id        INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE RESTRICT,
  company_id        INTEGER NOT NULL REFERENCES rental_companies(id) ON DELETE RESTRICT,
  pickup_location_id  INTEGER REFERENCES locations(id),
  dropoff_location_id INTEGER REFERENCES locations(id),
  pickup_at   TEXT NOT NULL,
  return_at   TEXT NOT NULL,
  pickup_date TEXT NOT NULL,
  return_date TEXT NOT NULL,
  days        INTEGER NOT NULL CHECK (days >= 1),
  status      TEXT NOT NULL DEFAULT 'pending'
              CHECK (status IN ('pending','awaiting_payment','confirmed','active',
                                'completed','cancelled','rejected','expired','no_show')),
  currency    TEXT NOT NULL DEFAULT 'DZD',
  base_amount     INTEGER NOT NULL DEFAULT 0,
  services_amount INTEGER NOT NULL DEFAULT 0,
  fees_amount     INTEGER NOT NULL DEFAULT 0,
  discount_amount INTEGER NOT NULL DEFAULT 0,
  tax_amount      INTEGER NOT NULL DEFAULT 0,
  total_amount    INTEGER NOT NULL DEFAULT 0,
  deposit_amount  INTEGER NOT NULL DEFAULT 0,
  commission_amount INTEGER NOT NULL DEFAULT 0,
  paid_amount     INTEGER NOT NULL DEFAULT 0,
  refund_amount   INTEGER NOT NULL DEFAULT 0,
  payment_status  TEXT NOT NULL DEFAULT 'pending'
              CHECK (payment_status IN ('pending','processing','paid','partially_paid',
                                        'failed','refunded','partially_refunded','cancelled')),
  payment_method  TEXT,
  promo_code_id   INTEGER REFERENCES promo_codes(id),
  price_breakdown TEXT,                  -- JSON snapshot
  customer_snapshot TEXT,                -- JSON snapshot (name/phone/licence at booking time)
  customer_notes  TEXT,
  internal_notes  TEXT,
  hold_expires_at TEXT,
  confirmed_at TEXT,
  started_at   TEXT,
  completed_at TEXT,
  cancelled_at TEXT,
  cancelled_by INTEGER REFERENCES users(id),
  cancel_reason TEXT,
  is_demo     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (return_at > pickup_at),
  CHECK (total_amount >= 0)
);
CREATE INDEX ix_bookings_customer ON bookings(customer_user_id, created_at DESC);
CREATE INDEX ix_bookings_vehicle ON bookings(vehicle_id, status, pickup_date, return_date);
CREATE INDEX ix_bookings_company ON bookings(company_id, status, pickup_date);
CREATE INDEX ix_bookings_status ON bookings(status, hold_expires_at);
CREATE INDEX ix_bookings_dates ON bookings(pickup_date, return_date);

CREATE TABLE booking_services (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id  INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  service_id  INTEGER REFERENCES services(id),
  code        TEXT NOT NULL,
  name_snapshot TEXT NOT NULL,
  qty         INTEGER NOT NULL DEFAULT 1,
  unit_price  INTEGER NOT NULL,
  price_type  TEXT NOT NULL,
  amount      INTEGER NOT NULL
);
CREATE INDEX ix_booking_services ON booking_services(booking_id);

CREATE TABLE booking_status_history (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id  INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  from_status TEXT,
  to_status   TEXT NOT NULL,
  actor_user_id INTEGER REFERENCES users(id),
  reason      TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_bsh_booking ON booking_status_history(booking_id, created_at);

-- ── Documents (private storage + access audit) ────────────────────────────────
CREATE TABLE documents (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  booking_id    INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
  kind          TEXT NOT NULL CHECK (kind IN ('driver_license','id_card','passport',
                                              'company_registry','vehicle_registration','other')),
  status        TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','approved','rejected','expired')),
  storage_path  TEXT NOT NULL,           -- outside web root, random filename
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size_bytes    INTEGER NOT NULL,
  sha256        TEXT NOT NULL,
  expires_at    TEXT,
  retention_delete_at TEXT,
  reviewed_by   INTEGER REFERENCES users(id),
  reviewed_at   TEXT,
  reject_reason TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at    TEXT
);
CREATE INDEX ix_documents_owner ON documents(owner_user_id, status);
CREATE INDEX ix_documents_status ON documents(status, created_at);
CREATE INDEX ix_documents_booking ON documents(booking_id);

CREATE TABLE document_access_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id     INTEGER REFERENCES users(id),
  action      TEXT NOT NULL,
  allowed     INTEGER NOT NULL,
  ip          TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_doc_access ON document_access_log(document_id, created_at);

-- ── Payments ─────────────────────────────────────────────────────────────────
CREATE TABLE payment_providers (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  kind        TEXT NOT NULL CHECK (kind IN ('offline','online')),
  enabled     INTEGER NOT NULL DEFAULT 0,
  config_status TEXT NOT NULL DEFAULT 'configuration_required',
  supports_refund INTEGER NOT NULL DEFAULT 0,
  sort        INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE payments (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id      INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  provider_code   TEXT NOT NULL REFERENCES payment_providers(code),
  kind            TEXT NOT NULL DEFAULT 'deposit'
                  CHECK (kind IN ('deposit','full','balance','extra_charges')),
  amount          INTEGER NOT NULL CHECK (amount > 0),
  currency        TEXT NOT NULL DEFAULT 'DZD',
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','processing','paid','partially_paid',
                                    'failed','refunded','partially_refunded','cancelled')),
  provider_txn_id TEXT,
  idempotency_key TEXT NOT NULL UNIQUE,
  failure_reason  TEXT,
  payload         TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_payments_booking ON payments(booking_id, status);
CREATE INDEX ix_payments_user ON payments(user_id, created_at DESC);
CREATE INDEX ix_payments_provider ON payments(provider_code, provider_txn_id);

CREATE TABLE refunds (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id INTEGER NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  amount     INTEGER NOT NULL CHECK (amount > 0),
  status     TEXT NOT NULL DEFAULT 'pending'
             CHECK (status IN ('pending','processing','refunded','failed','cancelled')),
  reason     TEXT,
  provider_txn_id TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_refunds_booking ON refunds(booking_id);

CREATE TABLE payment_webhook_events (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  provider_code TEXT NOT NULL,
  event_id      TEXT NOT NULL,
  payload       TEXT,
  received_at   TEXT NOT NULL DEFAULT (datetime('now')),
  processed_at  TEXT,
  UNIQUE (provider_code, event_id)       -- idempotency
);

-- ── Pricing ──────────────────────────────────────────────────────────────────
CREATE TABLE pricing_rules (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  scope       TEXT NOT NULL CHECK (scope IN ('global','company','category','vehicle')),
  company_id  INTEGER REFERENCES rental_companies(id) ON DELETE CASCADE,
  category_id INTEGER REFERENCES vehicle_categories(id) ON DELETE CASCADE,
  vehicle_id  INTEGER REFERENCES vehicles(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK (kind IN ('seasonal','weekend','holiday','long_rental','early_booking')),
  label       TEXT NOT NULL,
  start_date  TEXT, end_date TEXT,
  weekday_mask TEXT,                     -- e.g. '4,5' (Fri,Sat) python weekday()
  min_days    INTEGER,
  min_days_ahead INTEGER,
  adjust_type TEXT NOT NULL CHECK (adjust_type IN ('percent','fixed','absolute')),
  adjust_value REAL NOT NULL,
  priority    INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_pricing_lookup ON pricing_rules(active, scope, kind, priority);

CREATE TABLE promo_codes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT NOT NULL UNIQUE,
  kind          TEXT NOT NULL CHECK (kind IN ('percent','fixed')),
  value         REAL NOT NULL CHECK (value > 0),
  min_amount    INTEGER NOT NULL DEFAULT 0,
  max_discount  INTEGER,
  starts_at     TEXT, ends_at TEXT,
  usage_limit   INTEGER, per_user_limit INTEGER NOT NULL DEFAULT 1,
  used_count    INTEGER NOT NULL DEFAULT 0,
  category_id   INTEGER REFERENCES vehicle_categories(id),
  wilaya_id     INTEGER REFERENCES wilayas(id),
  company_id    INTEGER REFERENCES rental_companies(id),
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE promo_redemptions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  promo_id   INTEGER NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  amount     INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (promo_id, booking_id)
);
CREATE INDEX ix_promo_redemptions_user ON promo_redemptions(promo_id, user_id);

-- ── Reviews / favourites ─────────────────────────────────────────────────────
CREATE TABLE reviews (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL UNIQUE REFERENCES bookings(id) ON DELETE CASCADE,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL REFERENCES rental_companies(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating_overall  INTEGER NOT NULL CHECK (rating_overall BETWEEN 1 AND 5),
  rating_vehicle  INTEGER CHECK (rating_vehicle BETWEEN 1 AND 5),
  rating_service  INTEGER CHECK (rating_service BETWEEN 1 AND 5),
  rating_cleanliness INTEGER CHECK (rating_cleanliness BETWEEN 1 AND 5),
  rating_communication INTEGER CHECK (rating_communication BETWEEN 1 AND 5),
  comment    TEXT,
  status     TEXT NOT NULL DEFAULT 'published'
             CHECK (status IN ('pending','published','rejected')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_reviews_vehicle ON reviews(vehicle_id, status);
CREATE TABLE favourites (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, vehicle_id)
);

-- ── Notifications ────────────────────────────────────────────────────────────
CREATE TABLE notifications (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind     TEXT NOT NULL,
  title    TEXT NOT NULL,
  body     TEXT NOT NULL,
  data     TEXT,
  read_at  TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_notifications_user ON notifications(user_id, read_at, created_at DESC);

CREATE TABLE notification_outbox (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  channel  TEXT NOT NULL CHECK (channel IN ('email','sms','whatsapp','push')),
  recipient TEXT NOT NULL,
  template TEXT NOT NULL,
  subject  TEXT,
  payload  TEXT,
  status   TEXT NOT NULL DEFAULT 'queued'
           CHECK (status IN ('queued','sent','failed','unconfigured','skipped')),
  provider TEXT,
  error    TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  sent_at  TEXT
);
CREATE INDEX ix_outbox_status ON notification_outbox(status, created_at);

CREATE TABLE notification_preferences (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind    TEXT NOT NULL,
  in_app  INTEGER NOT NULL DEFAULT 1,
  email   INTEGER NOT NULL DEFAULT 1,
  sms     INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, kind)
);

-- ── Support ──────────────────────────────────────────────────────────────────
CREATE TABLE support_tickets (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  reference  TEXT NOT NULL UNIQUE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  booking_id INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
  category   TEXT NOT NULL CHECK (category IN ('question','booking_problem','payment_problem',
                                               'vehicle_problem','refund_request','complaint','other')),
  subject    TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'open'
             CHECK (status IN ('open','in_progress','waiting_customer','resolved','closed')),
  priority   TEXT NOT NULL DEFAULT 'normal',
  assigned_to INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_tickets_user ON support_tickets(user_id, status);
CREATE TABLE support_messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id  INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body       TEXT NOT NULL,
  is_staff   INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_ticket_messages ON support_messages(ticket_id, created_at);

-- ── Inspections & damage (schema ready, V2 workflows) ─────────────────────────
CREATE TABLE rental_inspections (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  phase      TEXT NOT NULL CHECK (phase IN ('checkout','checkin')),
  mileage    INTEGER, fuel_level INTEGER,
  exterior_condition TEXT, interior_condition TEXT,
  existing_damage TEXT, notes TEXT,
  extra_charges INTEGER NOT NULL DEFAULT 0,
  deposit_status TEXT,
  staff_user_id INTEGER REFERENCES users(id),
  performed_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (booking_id, phase)
);
CREATE TABLE inspection_photos (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  inspection_id INTEGER NOT NULL REFERENCES rental_inspections(id) ON DELETE CASCADE,
  path TEXT NOT NULL, label TEXT
);
CREATE TABLE vehicle_damage (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  booking_id INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
  location_on_vehicle TEXT NOT NULL,
  description TEXT NOT NULL,
  estimated_cost INTEGER NOT NULL DEFAULT 0,
  final_cost  INTEGER,
  status     TEXT NOT NULL DEFAULT 'reported'
             CHECK (status IN ('reported','under_review','approved','charged','disputed','resolved')),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_damage_vehicle ON vehicle_damage(vehicle_id, status);

-- ── Audit ────────────────────────────────────────────────────────────────────
CREATE TABLE audit_logs (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_email  TEXT,
  action       TEXT NOT NULL,
  target_type  TEXT,
  target_id    TEXT,
  ip           TEXT,
  user_agent   TEXT,
  metadata     TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ix_audit_actor ON audit_logs(actor_user_id, created_at DESC);
CREATE INDEX ix_audit_action ON audit_logs(action, created_at DESC);
CREATE INDEX ix_audit_target ON audit_logs(target_type, target_id);
