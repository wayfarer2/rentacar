"""SQLite access layer: WAL, enforced FKs, busy timeout, transaction helpers."""
from __future__ import annotations
import sqlite3, threading, json
from contextlib import contextmanager
from pathlib import Path
from .config import Config

_local = threading.local()


def _connect() -> sqlite3.Connection:
    path = Config.db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=15.0, isolation_level=None,
                           check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def get_conn() -> sqlite3.Connection:
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = _local.conn = _connect()
    return conn


def close_conn() -> None:
    conn = getattr(_local, "conn", None)
    if conn is not None:
        conn.close()
        _local.conn = None


@contextmanager
def transaction(immediate: bool = True):
    """
    Serialised write transaction. BEGIN IMMEDIATE takes the write lock up-front,
    which is what makes concurrent booking attempts safe rather than hopeful.
    """
    conn = get_conn()
    depth = getattr(_local, "depth", 0)
    if depth == 0:
        conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
    _local.depth = depth + 1
    try:
        yield conn
    except Exception:
        if _local.depth == 1:
            conn.execute("ROLLBACK")
        _local.depth -= 1
        raise
    else:
        if _local.depth == 1:
            conn.execute("COMMIT")
        _local.depth -= 1


def query(sql: str, params: tuple | dict = ()) -> list[sqlite3.Row]:
    return get_conn().execute(sql, params).fetchall()


def one(sql: str, params: tuple | dict = ()):
    return get_conn().execute(sql, params).fetchone()


def scalar(sql: str, params: tuple | dict = (), default=None):
    row = one(sql, params)
    if row is None:
        return default
    v = row[0]
    return default if v is None else v


def execute(sql: str, params: tuple | dict = ()) -> sqlite3.Cursor:
    return get_conn().execute(sql, params)


def insert(table: str, data: dict) -> int:
    cols = ", ".join(data)
    marks = ", ".join(f":{k}" for k in data)
    cur = get_conn().execute(f"INSERT INTO {table} ({cols}) VALUES ({marks})", data)
    return int(cur.lastrowid)


def update(table: str, pk_value, data: dict, pk: str = "id") -> None:
    if not data:
        return
    sets = ", ".join(f"{k} = :{k}" for k in data)
    params = dict(data); params["__pk"] = pk_value
    get_conn().execute(f"UPDATE {table} SET {sets} WHERE {pk} = :__pk", params)


def rows_to_dicts(rows) -> list[dict]:
    return [dict(r) for r in rows]


def migrate(fresh: bool = False) -> None:
    path = Config.db_path()
    if fresh and path.exists():
        close_conn()
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(path) + suffix)
            p.unlink(missing_ok=True)
    conn = get_conn()
    have = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'"
    ).fetchone()
    if have:
        return
    sql = (Path(__file__).parent / "schema.sql").read_text(encoding="utf-8")
    conn.executescript(sql)
    conn.execute("INSERT INTO schema_version (version) VALUES (1)")


def jdump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def jload(text, default=None):
    if not text:
        return default
    try:
        return json.loads(text)
    except Exception:
        return default
