"""Admin API. Every handler demands an explicit permission -- no UI-only gating."""
from __future__ import annotations
from ..http import get, post, put, ok, json_response, Request, NotFound, BadRequest, Forbidden, Conflict
from .. import db
from ..config import Config
from ..services import analytics as AN
from ..services import company_service as C
from ..services import vehicle_service as V
from ..services import document_service as D
from ..services import settings_service as S
from ..services import booking_service as B
from ..services.audit import from_request as audit_req
from ..services.notification_service import notify, flush_outbox, email_status, sms_status
from ..security import as_id, clean_text, as_int, as_choice, now_str, utc_str, ROLES


def _page(req: Request, default=25, cap=100):
    return min(int(req.q("limit", default)), cap), int(req.q("offset", 0))


@get("/api/v1/admin/dashboard")
def dashboard(req: Request):
    req.require_perm("analytics.view")
    rng = req.q("range", "30d")
    return ok({
        "overview": AN.overview(rng, req.q("from"), req.q("to")),
        "revenue_by_month": AN.revenue_by_month(),
        "top_vehicles": AN.top_vehicles(),
        "top_locations": AN.top_locations(),
        "bookings_by_status": AN.bookings_by_status(),
        "customer_growth": AN.customer_growth(),
        "integrations": Config.integration_status(),
    })


@get("/api/v1/admin/users")
def users(req: Request):
    req.require_perm("user.view.all")
    limit, offset = _page(req)
    where, params = ["u.deleted_at IS NULL"], []
    if req.q("role"):
        where.append("""EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id
                                 WHERE ur.user_id=u.id AND r.code = ?)""")
        params.append(req.q("role"))
    if req.q("status"):
        where.append("u.status = ?"); params.append(req.q("status"))
    if req.q("q"):
        where.append("(u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)")
        term = f"%{clean_text(req.q('q'), 60)}%"
        params += [term, term, term]
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM users u{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT u.id, u.email, u.full_name, u.phone, u.status, u.locale, u.is_demo,
                               u.email_verified_at, u.last_login_at, u.created_at,
                               (SELECT GROUP_CONCAT(r.code) FROM user_roles ur JOIN roles r ON r.id=ur.role_id
                                 WHERE ur.user_id=u.id) AS roles,
                               (SELECT COUNT(*) FROM bookings b WHERE b.customer_user_id=u.id) AS bookings
                          FROM users u{where_sql} ORDER BY u.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset})


@get("/api/v1/admin/users/<user_id>")
def user_detail(req: Request):
    req.require_perm("user.view.all")
    from ..services.auth_service import public_user
    u = public_user(as_id(req.params["user_id"], "user_id"))
    if not u:
        raise NotFound("Utilisateur introuvable.")
    u["bookings"] = db.rows_to_dicts(db.query(
        """SELECT id, reference, status, pickup_at, total_amount FROM bookings
            WHERE customer_user_id = ? ORDER BY id DESC LIMIT 20""", (u["id"],)))
    u["documents"] = D.list_for_user(u["id"], req.user)
    return ok(u)


@post("/api/v1/admin/users/<user_id>/suspend")
def suspend(req: Request):
    actor = req.require_perm("user.suspend")
    uid = as_id(req.params["user_id"], "user_id")
    d = req.form()
    action = as_choice(d.get("action", "suspend"), "action", ("suspend", "reactivate"))
    reason = clean_text(d.get("reason"), 300)
    target = db.one("SELECT * FROM users WHERE id = ? AND deleted_at IS NULL", (uid,))
    if not target:
        raise NotFound("Utilisateur introuvable.")
    if uid == actor["id"]:
        raise Conflict("Vous ne pouvez pas suspendre votre propre compte.", code="self_suspend")
    is_super = db.one("""SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id
                          WHERE ur.user_id=? AND r.code='super_admin'""", (uid,))
    if is_super and "super_admin" not in req.user["roles"]:
        raise Forbidden("Seul un super administrateur peut suspendre un super administrateur.")
    if action == "suspend" and not reason:
        raise BadRequest("Indiquez le motif de la suspension.")
    with db.transaction():
        db.update("users", uid, {"status": "suspended" if action == "suspend" else "active",
                                 "updated_at": now_str()})
        if action == "suspend":
            db.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",
                       (utc_str(), uid))
    audit_req(req, f"user.{action}", target_type="user", target_id=uid, metadata={"reason": reason})
    if action == "suspend":
        notify(uid, "account_suspended", {"reason": reason or "-"}, channels=("email",))
    return ok({"id": uid, "status": "suspended" if action == "suspend" else "active"})


@post("/api/v1/admin/users/<user_id>/roles")
def set_roles(req: Request):
    req.require_perm("user.manage")
    from ..services.auth_service import grant_role, revoke_role, public_user
    uid = as_id(req.params["user_id"], "user_id")
    d = req.form()
    role = as_choice(d.get("role"), "role", tuple(ROLES.keys()))
    action = as_choice(d.get("action", "grant"), "action", ("grant", "revoke"))
    if role in ("admin", "super_admin") and "super_admin" not in req.user["roles"]:
        raise Forbidden("Seul un super administrateur peut attribuer un rôle d'administration.")
    if action == "grant":
        grant_role(uid, role)
    else:
        if uid == req.user["id"] and role in ("admin", "super_admin"):
            raise Conflict("Vous ne pouvez pas retirer votre propre rôle d'administration.",
                           code="self_demote")
        revoke_role(uid, role)
    audit_req(req, f"user.role_{action}ed", target_type="user", target_id=uid,
              metadata={"role": role})
    return ok(public_user(uid))


@get("/api/v1/admin/companies")
def companies(req: Request):
    req.require_perm("company.manage.all")
    limit, offset = _page(req)
    where, params = ["c.deleted_at IS NULL"], []
    if req.q("status"):
        where.append("c.status = ?"); params.append(req.q("status"))
    if req.q("q"):
        where.append("(c.name LIKE ? OR c.phone LIKE ?)")
        term = f"%{clean_text(req.q('q'), 60)}%"; params += [term, term]
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM rental_companies c{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT c.id, c.name, c.slug, c.status, c.phone, c.email, c.rc_number, c.nif,
                               c.commission_rate, c.rating_avg, c.created_at, c.is_demo,
                               w.name_fr AS wilaya, u.full_name AS owner_name, u.email AS owner_email,
                               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id=c.id AND v.deleted_at IS NULL) AS vehicles,
                               (SELECT COUNT(*) FROM bookings b WHERE b.company_id=c.id) AS bookings
                          FROM rental_companies c
                          LEFT JOIN wilayas w ON w.id=c.wilaya_id
                          JOIN users u ON u.id=c.owner_user_id
                          {where_sql} ORDER BY c.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset})


@post("/api/v1/admin/companies/<company_id>/status")
def company_status(req: Request):
    req.require_perm("company.approve")
    d = req.form()
    return ok(C.set_status(req=req, company_id=as_id(req.params["company_id"], "company_id"),
                           status=d.get("status", ""), reason=d.get("reason", "")))


@put("/api/v1/admin/companies/<company_id>")
def admin_update_company(req: Request):
    req.require_perm("company.manage.all")
    return ok(C.update(req=req, company_id=as_id(req.params["company_id"], "company_id"), data=req.form()))


@get("/api/v1/admin/vehicles")
def admin_vehicles(req: Request):
    req.require_perm("vehicle.view.all")
    limit, offset = _page(req)
    where, params = ["v.deleted_at IS NULL"], []
    if req.q("approval_status"):
        where.append("v.approval_status = ?"); params.append(req.q("approval_status"))
    if req.q("status"):
        where.append("v.status = ?"); params.append(req.q("status"))
    if req.q("company_id"):
        where.append("v.company_id = ?"); params.append(int(req.q("company_id")))
    if req.q("q"):
        where.append("(v.brand LIKE ? OR v.model LIKE ?)")
        term = f"%{clean_text(req.q('q'), 40)}%"; params += [term, term]
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM vehicles v{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT v.id, v.slug, v.brand, v.model, v.year, v.status, v.approval_status,
                               v.daily_price, v.deposit, v.rating_avg, v.bookings_count, v.created_at,
                               cat.code AS category, c.name AS company_name, c.id AS company_id,
                               (SELECT path FROM vehicle_images WHERE vehicle_id=v.id
                                 ORDER BY is_primary DESC, sort LIMIT 1) AS image
                          FROM vehicles v
                          JOIN vehicle_categories cat ON cat.id=v.category_id
                          JOIN rental_companies c ON c.id=v.company_id
                          {where_sql} ORDER BY v.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset})


@post("/api/v1/admin/vehicles/<vehicle_id>/approval")
def approve_vehicle(req: Request):
    req.require_perm("vehicle.approve")
    d = req.form()
    return ok(V.set_approval(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"),
                             decision=d.get("decision", ""), reason=d.get("reason", "")))


@get("/api/v1/admin/bookings")
def admin_bookings(req: Request):
    req.require_perm("booking.view.all")
    limit, offset = _page(req)
    where, params = ["1=1"], []
    if req.q("status"):
        where.append("b.status = ?"); params.append(req.q("status"))
    if req.q("company_id"):
        where.append("b.company_id = ?"); params.append(int(req.q("company_id")))
    if req.q("q"):
        where.append("(b.reference LIKE ? OR u.email LIKE ? OR u.full_name LIKE ?)")
        term = f"%{clean_text(req.q('q'), 60)}%"; params += [term, term, term]
    if req.q("from") and req.q("to"):
        where.append("date(b.pickup_date) BETWEEN ? AND ?"); params += [req.q("from"), req.q("to")]
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"""SELECT COUNT(*) FROM bookings b JOIN users u ON u.id=b.customer_user_id{where_sql}""",
                      tuple(params), 0)
    rows = db.query(f"""SELECT b.id, b.reference, b.status, b.payment_status, b.pickup_at, b.return_at,
                               b.days, b.total_amount, b.paid_amount, b.commission_amount, b.created_at,
                               v.brand, v.model, c.name AS company_name,
                               u.full_name AS customer_name, u.email AS customer_email
                          FROM bookings b
                          JOIN vehicles v ON v.id=b.vehicle_id
                          JOIN rental_companies c ON c.id=b.company_id
                          JOIN users u ON u.id=b.customer_user_id
                          {where_sql} ORDER BY b.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset})


@get("/api/v1/admin/payments")
def admin_payments(req: Request):
    req.require_perm("payment.view.all")
    limit, offset = _page(req)
    where, params = ["1=1"], []
    if req.q("status"):
        where.append("p.status = ?"); params.append(req.q("status"))
    if req.q("provider"):
        where.append("p.provider_code = ?"); params.append(req.q("provider"))
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM payments p{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT p.*, b.reference, u.full_name AS customer_name
                          FROM payments p JOIN bookings b ON b.id=p.booking_id
                          JOIN users u ON u.id=p.user_id
                          {where_sql} ORDER BY p.created_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    refunds = db.rows_to_dicts(db.query(
        """SELECT r.*, b.reference FROM refunds r JOIN bookings b ON b.id=r.booking_id
            ORDER BY r.created_at DESC LIMIT 50"""))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "refunds": refunds,
               "totals": {
                   "collected": db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='paid'", (), 0),
                   "pending": db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status IN ('pending','processing')", (), 0),
                   "refunded": db.scalar("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE status='refunded'", (), 0)}})


@get("/api/v1/admin/documents")
def admin_documents(req: Request):
    req.require_perm("document.review")
    limit, offset = _page(req)
    if req.q("status", "pending") == "pending":
        return ok(D.pending_queue(limit, offset))
    rows = db.query("""SELECT d.id, d.kind, d.status, d.original_name, d.mime, d.size_bytes,
                              d.created_at, d.reviewed_at, d.owner_user_id, u.full_name AS owner_name
                         FROM documents d JOIN users u ON u.id=d.owner_user_id
                        WHERE d.status = ? AND d.deleted_at IS NULL
                        ORDER BY d.created_at DESC LIMIT ? OFFSET ?""",
                    (req.q("status"), limit, offset))
    return ok({"items": db.rows_to_dicts(rows),
               "total": db.scalar("SELECT COUNT(*) FROM documents WHERE status=? AND deleted_at IS NULL",
                                  (req.q("status"),), 0)})


@get("/api/v1/admin/audit")
def audit_logs(req: Request):
    req.require_perm("audit.view")
    limit, offset = _page(req, 50, 200)
    where, params = ["1=1"], []
    if req.q("action"):
        where.append("a.action LIKE ?"); params.append(f"{clean_text(req.q('action'), 40)}%")
    if req.q("actor_id"):
        where.append("a.actor_user_id = ?"); params.append(int(req.q("actor_id")))
    if req.q("target_type"):
        where.append("a.target_type = ?"); params.append(req.q("target_type"))
    where_sql = " WHERE " + " AND ".join(where)
    total = db.scalar(f"SELECT COUNT(*) FROM audit_logs a{where_sql}", tuple(params), 0)
    rows = db.query(f"""SELECT a.*, u.full_name AS actor_name FROM audit_logs a
                          LEFT JOIN users u ON u.id=a.actor_user_id
                          {where_sql} ORDER BY a.id DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total})


@get("/api/v1/admin/settings")
def get_settings(req: Request):
    req.require_perm("settings.manage")
    return ok({"settings": S.all_settings(),
               "integrations": Config.integration_status(),
               "readiness": Config.production_readiness(),
               "channels": {"email": email_status(), "sms": sms_status()}})


@put("/api/v1/admin/settings")
def update_settings(req: Request):
    user = req.require_perm("settings.manage")
    payload = req.form()
    updates = payload.get("settings") if isinstance(payload.get("settings"), dict) else payload
    changed = {}
    for key, value in updates.items():
        if key not in S.DEFAULTS:
            continue
        default = S.DEFAULTS[key][0]
        try:
            if isinstance(default, bool):
                value = str(value).lower() in ("1", "true", "yes", "on") if not isinstance(value, bool) else value
            elif isinstance(default, int) and not isinstance(default, bool):
                value = int(value)
            elif isinstance(default, float):
                value = float(value)
        except (TypeError, ValueError):
            raise BadRequest(f"Valeur invalide pour « {key} ».")
        S.set_value(key, value, user["id"])
        changed[key] = value
    if not changed:
        raise BadRequest("Aucun paramètre reconnu à modifier.")
    audit_req(req, "settings.changed", target_type="settings",
              metadata={"keys": sorted(changed.keys())})
    return ok({"updated": changed})


@get("/api/v1/admin/promo-codes")
def promos(req: Request):
    req.require_perm("promo.manage")
    rows = db.query("""SELECT p.*, (SELECT COUNT(*) FROM promo_redemptions r WHERE r.promo_id=p.id) AS redemptions
                         FROM promo_codes p ORDER BY p.created_at DESC LIMIT 100""")
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/admin/promo-codes")
def create_promo(req: Request):
    req.require_perm("promo.manage")
    d = req.form()
    code = clean_text(d.get("code"), 30).upper()
    if len(code) < 3:
        raise BadRequest("Code promo trop court.")
    if db.one("SELECT 1 FROM promo_codes WHERE code = ? COLLATE NOCASE", (code,)):
        raise Conflict("Ce code existe déjà.", code="promo_exists")
    pid = db.insert("promo_codes", {
        "code": code, "kind": as_choice(d.get("kind"), "kind", ("percent", "fixed")),
        "value": float(d.get("value") or 0),
        "min_amount": as_int(d.get("min_amount"), "min_amount", minimum=0, required=False, default=0),
        "max_discount": as_int(d.get("max_discount"), "max_discount", minimum=0, required=False, default=None),
        "starts_at": d.get("starts_at") or None, "ends_at": d.get("ends_at") or None,
        "usage_limit": as_int(d.get("usage_limit"), "usage_limit", minimum=1, required=False, default=None),
        "per_user_limit": as_int(d.get("per_user_limit"), "per_user_limit", minimum=1, required=False, default=1),
        "active": 1, "created_at": now_str()})
    audit_req(req, "promo.created", target_type="promo_code", target_id=pid, metadata={"code": code})
    return json_response({"ok": True, "data": {"id": pid, "code": code}}, 201)


@post("/api/v1/admin/notifications/flush")
def flush(req: Request):
    req.require_perm("settings.manage")
    return ok(flush_outbox())


@get("/api/v1/admin/outbox")
def outbox(req: Request):
    req.require_perm("settings.manage")
    rows = db.query("""SELECT id, channel, recipient, template, subject, status, provider, error,
                              created_at, sent_at FROM notification_outbox
                        ORDER BY id DESC LIMIT 100""")
    return ok({"items": db.rows_to_dicts(rows),
               "summary": db.rows_to_dicts(db.query(
                   "SELECT status, COUNT(*) AS n FROM notification_outbox GROUP BY status"))})


@get("/api/v1/admin/reviews")
def admin_reviews(req: Request):
    req.require_perm("review.moderate")
    rows = db.query("""SELECT r.*, u.full_name AS author, v.brand, v.model
                         FROM reviews r JOIN users u ON u.id=r.user_id
                         JOIN vehicles v ON v.id=r.vehicle_id
                        ORDER BY r.created_at DESC LIMIT 100""")
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/admin/reviews/<review_id>/moderate")
def moderate_review(req: Request):
    req.require_perm("review.moderate")
    rid = as_id(req.params["review_id"], "review_id")
    status = as_choice(req.form().get("status"), "status", ("published", "rejected", "pending"))
    row = db.one("SELECT * FROM reviews WHERE id = ?", (rid,))
    if not row:
        raise NotFound("Avis introuvable.")
    db.update("reviews", rid, {"status": status})
    _recompute_ratings(row["vehicle_id"], row["company_id"])
    audit_req(req, "review.moderated", target_type="review", target_id=rid, metadata={"status": status})
    return ok({"id": rid, "status": status})


def _recompute_ratings(vehicle_id: int, company_id: int) -> None:
    v = db.one("""SELECT COALESCE(AVG(rating_overall),0) AS avg, COUNT(*) AS n FROM reviews
                   WHERE vehicle_id=? AND status='published'""", (vehicle_id,))
    db.update("vehicles", vehicle_id, {"rating_avg": round(v["avg"], 2), "rating_count": v["n"]})
    c = db.one("""SELECT COALESCE(AVG(rating_overall),0) AS avg, COUNT(*) AS n FROM reviews
                   WHERE company_id=? AND status='published'""", (company_id,))
    db.update("rental_companies", company_id, {"rating_avg": round(c["avg"], 2), "rating_count": c["n"]})
