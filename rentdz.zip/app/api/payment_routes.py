from __future__ import annotations
from ..http import get, post, ok, Request, BadRequest, Forbidden, NotFound
from .. import db
from ..services import payment_service as PS
from ..services.payment import available_providers, provider_catalogue
from ..security import as_id, as_int, clean_text


@get("/api/v1/payments/methods")
def methods(req: Request):
    return ok({"methods": available_providers(), "catalogue": provider_catalogue()})


@post("/api/v1/payments")
def initiate(req: Request):
    user = req.require_user()
    d = req.form()
    if not str(d.get("booking_id", "")).isdigit():
        raise BadRequest("Réservation manquante.")
    result = PS.initiate(booking_id=int(d["booking_id"]), provider_code=d.get("provider_code", ""),
                         kind=d.get("kind", "deposit"), actor=user, ip=req.ip,
                         return_url=f"/reservation/{d['booking_id']}")
    return ok(result)


@get("/api/v1/payments")
def my_payments(req: Request):
    user = req.require_user()
    if req.has_perm("payment.view.all") and req.q("all") == "1":
        rows = db.query("""SELECT p.*, b.reference FROM payments p JOIN bookings b ON b.id = p.booking_id
                            ORDER BY p.id DESC LIMIT 100""")
    else:
        rows = db.query("""SELECT p.*, b.reference FROM payments p JOIN bookings b ON b.id = p.booking_id
                            WHERE p.user_id = ? ORDER BY p.id DESC LIMIT 100""", (user["id"],))
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/payments/<payment_id>/confirm")
def confirm(req: Request):
    """Offline money confirmed by the agency or an admin. Never by the customer."""
    user = req.require_user()
    pid = as_id(req.params["payment_id"], "payment_id")
    row = db.one("""SELECT p.*, b.company_id FROM payments p JOIN bookings b ON b.id = p.booking_id
                     WHERE p.id = ?""", (pid,))
    if not row:
        raise NotFound("Paiement introuvable.")
    allowed = (req.has_perm("payment.manage")
               or (req.has_perm("booking.manage.company") and row["company_id"] in req.company_ids()))
    if not allowed:
        raise Forbidden("Seule l'agence ou un administrateur peut valider un paiement.")
    return ok(PS.mark_paid(payment_id=pid, actor=user,
                           provider_txn_id=clean_text(req.form().get("provider_txn_id"), 80) or None,
                           ip=req.ip))


@post("/api/v1/payments/<payment_id>/fail")
def fail(req: Request):
    user = req.require_perm("payment.manage")
    return ok(PS.mark_failed(payment_id=as_id(req.params["payment_id"], "payment_id"),
                             reason=req.form().get("reason", "Échec manuel"), actor=user, ip=req.ip))


@post("/api/v1/payments/<payment_id>/refund")
def refund(req: Request):
    user = req.require_perm("payment.manage")
    amount = as_int(req.form().get("amount"), "amount", minimum=1)
    return ok(PS.refund(payment_id=as_id(req.params["payment_id"], "payment_id"), amount=amount, actor=user,
                        reason=req.form().get("reason", ""), ip=req.ip))


@post("/api/v1/payments/webhook/<provider>")
def webhook(req: Request):
    """Unauthenticated by design, but signature-verified and idempotent."""
    headers = {k: v for k, v in req.headers.items()}
    return ok(PS.handle_webhook(req.params["provider"], headers, req.body))
