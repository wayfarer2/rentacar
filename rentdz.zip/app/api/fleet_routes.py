"""Fleet-owner portal API. Every handler is scoped to the caller's own company."""
from __future__ import annotations
from ..http import get, post, put, delete, ok, json_response, Request, NotFound, BadRequest, Forbidden
from .. import db
from ..services import company_service as C
from ..services import vehicle_service as V
from ..services import availability as A
from ..services import analytics as AN
from ..services import booking_service as B
from ..security import as_id, as_date, as_int, clean_text, now_str


def _company(req: Request) -> int:
    """Resolve which company the caller is acting for, and verify membership."""
    ids = req.company_ids()
    asked = req.q("company_id") or (req.form().get("company_id") if req.method != "GET" else None)
    if asked and str(asked).isdigit():
        cid = int(asked)
        if cid not in ids and not req.has_perm("company.manage.all"):
            raise NotFound("Société introuvable.")
        return cid
    if not ids:
        raise Forbidden("Aucune société rattachée à votre compte.")
    return ids[0]


@post("/api/v1/companies")
def create_company(req: Request):
    return json_response({"ok": True, "data": C.create(req=req, data=req.form())}, 201)


@get("/api/v1/companies/mine")
def my_company(req: Request):
    req.require_user()
    ids = req.company_ids()
    if not ids:
        return ok(None)
    return ok(C.get(ids[0]))


@put("/api/v1/companies/<company_id>")
def update_company(req: Request):
    return ok(C.update(req=req, company_id=as_id(req.params["company_id"], "company_id"), data=req.form()))


@get("/api/v1/fleet/dashboard")
def dashboard(req: Request):
    req.require_perm("booking.view.company", "vehicle.manage.company")
    cid = _company(req)
    return ok({"company": C.get(cid), "metrics": C.dashboard(cid)})


@get("/api/v1/fleet/vehicles")
def fleet_vehicles(req: Request):
    req.require_perm("vehicle.manage.company")
    cid = _company(req)
    return ok(V.company_fleet(cid, limit=min(int(req.q("limit", 50)), 100),
                              offset=int(req.q("offset", 0)), status=req.q("status")))


@post("/api/v1/fleet/vehicles")
def create_vehicle(req: Request):
    req.require_perm("vehicle.manage.company")
    cid = _company(req)
    data = dict(req.form())
    feats = data.get("features")
    if isinstance(feats, str):
        data["features"] = [f for f in feats.split(",") if f.strip()]
    return json_response({"ok": True, "data": V.create(req=req, company_id=cid, data=data)}, 201)


@get("/api/v1/fleet/vehicles/<vehicle_id>")
def get_vehicle(req: Request):
    req.require_perm("vehicle.manage.company")
    V.assert_can_manage(as_id(req.params["vehicle_id"], "vehicle_id"), req)
    return ok(V.get_admin(as_id(req.params["vehicle_id"], "vehicle_id")))


@put("/api/v1/fleet/vehicles/<vehicle_id>")
def update_vehicle(req: Request):
    req.require_perm("vehicle.manage.company")
    data = dict(req.form())
    feats = data.get("features")
    if isinstance(feats, str):
        data["features"] = [f for f in feats.split(",") if f.strip()]
    return ok(V.update(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"), data=data))


@delete("/api/v1/fleet/vehicles/<vehicle_id>")
def delete_vehicle(req: Request):
    req.require_perm("vehicle.manage.company")
    V.soft_delete(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"))
    return ok({"deleted": True})


@post("/api/v1/fleet/vehicles/<vehicle_id>/photos")
def add_photo(req: Request):
    req.require_perm("vehicle.manage.company")
    f = req.files().get("photo") or req.files().get("file")
    if not f:
        raise BadRequest("Aucune image reçue.")
    return ok(V.add_photo(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"),
                          filename=f["filename"], data=f["data"],
                          alt=req.form().get("alt", "")))


@delete("/api/v1/fleet/vehicles/<vehicle_id>/photos/<image_id>")
def remove_photo(req: Request):
    req.require_perm("vehicle.manage.company")
    V.delete_photo(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"),
                   image_id=as_id(req.params["image_id"], "image_id"))
    return ok({"deleted": True})


@get("/api/v1/fleet/vehicles/<vehicle_id>/calendar")
def calendar(req: Request):
    req.require_perm("vehicle.manage.company")
    vid = as_id(req.params["vehicle_id"], "vehicle_id")
    V.assert_can_manage(vid, req)
    start = req.q("start") or db.scalar("SELECT date('now')")
    end = req.q("end") or db.scalar("SELECT date('now','+60 days')")
    A.release_expired_holds()
    days = A.day_range(start, end)
    if not days or len(days) > 400:
        raise BadRequest("Plage de dates invalide.")
    locks = {r["day"]: dict(r) for r in db.query(
        f"""SELECT l.day, l.kind, l.booking_id, l.maintenance_id, l.block_id,
                   b.reference, b.status AS booking_status, b.pickup_at, b.return_at,
                   u.full_name AS customer, m.reason AS maintenance_reason, vb.reason AS block_reason
              FROM vehicle_day_locks l
              LEFT JOIN bookings b ON b.id = l.booking_id
              LEFT JOIN users u ON u.id = b.customer_user_id
              LEFT JOIN vehicle_maintenance m ON m.id = l.maintenance_id
              LEFT JOIN vehicle_blocks vb ON vb.id = l.block_id
             WHERE l.vehicle_id = ? AND l.day IN ({','.join('?' * len(days))})""",
        tuple([vid, *days]))}
    return ok({"vehicle_id": vid, "start": start, "end": end,
               "days": [locks.get(day, {"day": day, "kind": "available"}) | {"day": day}
                        for day in days]})


@post("/api/v1/fleet/vehicles/<vehicle_id>/block")
def block(req: Request):
    req.require_perm("vehicle.manage.company")
    d = req.form()
    kind = d.get("kind", "blocked")
    if kind not in ("blocked", "maintenance"):
        raise BadRequest("Type de blocage invalide.")
    return ok(V.block_dates(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"),
                            start_date=as_date(d.get("start_date"), "start_date"),
                            end_date=as_date(d.get("end_date"), "end_date"),
                            reason=d.get("reason", ""), kind=kind))


@delete("/api/v1/fleet/vehicles/<vehicle_id>/block/<kind>/<record_id>")
def unblock(req: Request):
    req.require_perm("vehicle.manage.company")
    V.unblock(req=req, vehicle_id=as_id(req.params["vehicle_id"], "vehicle_id"),
              kind=req.params["kind"], record_id=as_id(req.params["record_id"], "record_id"))
    return ok({"removed": True})


@get("/api/v1/fleet/bookings")
def fleet_bookings(req: Request):
    req.require_perm("booking.view.company")
    cid = _company(req)
    status = req.q("status")
    where, params = ["b.company_id = ?"], [cid]
    if status:
        where.append("b.status = ?"); params.append(status)
    if req.q("day"):
        where.append("(b.pickup_date = ? OR b.return_date = ?)")
        params += [req.q("day"), req.q("day")]
    limit, offset = min(int(req.q("limit", 25)), 100), int(req.q("offset", 0))
    total = db.scalar(f"SELECT COUNT(*) FROM bookings b WHERE {' AND '.join(where)}", tuple(params), 0)
    rows = db.query(f"""SELECT b.id, b.reference, b.status, b.payment_status, b.pickup_at, b.return_at,
                               b.days, b.total_amount, b.deposit_amount, b.paid_amount, b.created_at,
                               v.brand, v.model, v.id AS vehicle_id,
                               u.full_name AS customer_name, u.phone AS customer_phone,
                               u.email AS customer_email
                          FROM bookings b
                          JOIN vehicles v ON v.id = b.vehicle_id
                          JOIN users u ON u.id = b.customer_user_id
                         WHERE {' AND '.join(where)}
                         ORDER BY b.pickup_at DESC LIMIT ? OFFSET ?""",
                    tuple(params + [limit, offset]))
    return ok({"items": db.rows_to_dicts(rows), "total": total, "limit": limit, "offset": offset})


@get("/api/v1/fleet/today")
def today(req: Request):
    req.require_perm("booking.view.company")
    cid = _company(req)
    pickups = db.query("""SELECT b.id, b.reference, b.pickup_at, b.status, v.brand, v.model,
                                 u.full_name AS customer, u.phone
                            FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id
                            JOIN users u ON u.id=b.customer_user_id
                           WHERE b.company_id=? AND b.pickup_date=date('now')
                             AND b.status IN ('confirmed','active') ORDER BY b.pickup_at""", (cid,))
    returns = db.query("""SELECT b.id, b.reference, b.return_at, b.status, v.brand, v.model,
                                 u.full_name AS customer, u.phone
                            FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id
                            JOIN users u ON u.id=b.customer_user_id
                           WHERE b.company_id=? AND b.return_date=date('now')
                             AND b.status IN ('active','confirmed') ORDER BY b.return_at""", (cid,))
    return ok({"pickups": db.rows_to_dicts(pickups), "returns": db.rows_to_dicts(returns)})


@get("/api/v1/fleet/analytics")
def fleet_analytics(req: Request):
    req.require_perm("analytics.view.company")
    return ok(AN.company_analytics(_company(req)))


@get("/api/v1/fleet/locations")
def fleet_locations(req: Request):
    req.require_perm("vehicle.manage.company")
    cid = _company(req)
    rows = db.query("""SELECT l.*, w.name_fr AS wilaya FROM locations l
                        JOIN wilayas w ON w.id = l.wilaya_id
                       WHERE l.company_id = ? OR l.company_id IS NULL ORDER BY l.company_id, l.name_fr""",
                    (cid,))
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/fleet/locations")
def create_location(req: Request):
    req.require_perm("vehicle.manage.company")
    cid = _company(req)
    d = req.form()
    name = clean_text(d.get("name_fr"), 120)
    wilaya_id = as_int(d.get("wilaya_id"), "wilaya_id", minimum=1)
    if len(name) < 2:
        raise BadRequest("Nom de l'agence obligatoire.")
    if not db.one("SELECT 1 FROM wilayas WHERE id = ?", (wilaya_id,)):
        raise BadRequest("Wilaya inconnue.")
    from ..security import slugify
    lid = db.insert("locations", {
        "company_id": cid, "wilaya_id": wilaya_id,
        "commune_id": int(d["commune_id"]) if str(d.get("commune_id", "")).isdigit() else None,
        "kind": d.get("kind", "office") if d.get("kind") in ("office", "airport", "station", "city", "delivery") else "office",
        "slug": slugify(name, extra=str(db.scalar("SELECT COALESCE(MAX(id),0)+1 FROM locations", (), 1))),
        "name_fr": name, "name_ar": clean_text(d.get("name_ar"), 120) or name,
        "name_en": clean_text(d.get("name_en"), 120) or name,
        "address": clean_text(d.get("address"), 250),
        "extra_fee": as_int(d.get("extra_fee"), "extra_fee", minimum=0, maximum=100000,
                            required=False, default=0),
        "active": 1, "created_at": now_str()})
    return json_response({"ok": True, "data": {"id": lid}}, 201)
