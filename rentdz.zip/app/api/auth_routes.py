from __future__ import annotations
from ..http import (get, post, ok, json_response, Request, SESSION_COOKIE, create_session,
                    revoke_session, BadRequest, Unauthorized, TooMany, redirect)
from ..config import Config
from .. import db
from ..services import auth_service as A
from ..services.audit import from_request as audit_req
from ..security import rate_limited, clean_text, normalise_phone, valid_email, now_str


def _session_payload(user_id: int, csrf: str) -> dict:
    u = A.public_user(user_id)
    return {"user": u, "csrf_token": csrf}


@post("/api/v1/auth/register")
def register(req: Request):
    if rate_limited(f"register:{req.ip}", 10, 3600):
        raise TooMany("Trop d'inscriptions depuis cette connexion. Réessayez plus tard.")
    d = req.form()
    result = A.register(email=d.get("email", ""), password=d.get("password", ""),
                        full_name=d.get("full_name", ""), phone=d.get("phone", ""),
                        locale=d.get("locale", req.locale),
                        role="fleet_owner" if d.get("account_type") == "fleet_owner" else "customer",
                        ip=req.ip, user_agent=req.user_agent)
    user = A.login(email=result["email"], password=d.get("password"), ip=req.ip,
                   user_agent=req.user_agent)
    token, csrf = create_session(user["id"], req)
    resp = json_response({"ok": True, "data": _session_payload(user["id"], csrf),
                          "verification_token": result.get("verification_token")}, 201)
    return resp.set_cookie(SESSION_COOKIE, token, max_age=Config.SESSION_TTL_HOURS * 3600)


@post("/api/v1/auth/login")
def login(req: Request):
    d = req.form()
    user = A.login(email=d.get("email", ""), password=d.get("password", ""),
                   ip=req.ip, user_agent=req.user_agent)
    token, csrf = create_session(user["id"], req)
    resp = json_response({"ok": True, "data": _session_payload(user["id"], csrf)})
    return resp.set_cookie(SESSION_COOKIE, token, max_age=Config.SESSION_TTL_HOURS * 3600)


@post("/api/v1/auth/logout")
def logout(req: Request):
    if req.session:
        revoke_session(req.session["id"])
        audit_req(req, "user.logout", target_type="user", target_id=req.user["id"])
    resp = ok({"logged_out": True})
    return resp.set_cookie(SESSION_COOKIE, "", delete=True)


@get("/api/v1/auth/me")
def me(req: Request):
    if not req.user:
        return json_response({"ok": True, "data": {"user": None}})
    return ok({"user": A.public_user(req.user["id"]),
               "csrf_token": req.session["csrf_token"],
               "roles": req.user["roles"],
               "permissions": sorted(req.user["permissions"]),
               "company_ids": req.user["company_ids"]})


@post("/api/v1/auth/verify-email")
def verify_email(req: Request):
    token = req.form().get("token") or req.q("token") or ""
    if not A.verify_email(token):
        raise BadRequest("Lien de confirmation invalide ou expiré.")
    return ok({"verified": True})


@post("/api/v1/auth/password/forgot")
def forgot(req: Request):
    email = req.form().get("email", "")
    token = A.request_password_reset(email, ip=req.ip)
    # Always the same answer: no account enumeration.
    payload = {"message": "Si un compte existe pour cette adresse, un e-mail de "
                          "réinitialisation vient d'être envoyé."}
    if Config.DEBUG and token:
        payload["debug_token"] = token
    return ok(payload)


@post("/api/v1/auth/password/reset")
def reset(req: Request):
    d = req.form()
    A.reset_password(d.get("token", ""), d.get("password", ""))
    return ok({"message": "Mot de passe mis à jour. Vous pouvez vous connecter."})


@post("/api/v1/auth/password/change")
def change(req: Request):
    user = req.require_user()
    d = req.form()
    A.change_password(user["id"], d.get("current_password", ""), d.get("password", ""))
    resp = ok({"message": "Mot de passe modifié. Reconnectez-vous."})
    return resp.set_cookie(SESSION_COOKIE, "", delete=True)


@get("/api/v1/profile")
def profile(req: Request):
    user = req.require_user()
    return ok(A.public_user(user["id"]))


@post("/api/v1/profile")
def update_profile(req: Request):
    user = req.require_user()
    d = req.form()
    patch = {}
    if "full_name" in d:
        name = clean_text(d["full_name"], 120)
        if len(name) < 3:
            raise BadRequest("Nom complet invalide.")
        patch["full_name"] = name
    if "phone" in d:
        p = normalise_phone(d["phone"] or "")
        if d["phone"] and not p:
            raise BadRequest("Numéro algérien invalide (ex. 0555 12 34 56).")
        patch["phone"] = p
    if "locale" in d and d["locale"] in Config.LOCALES:
        patch["locale"] = d["locale"]
    if "email" in d and d["email"].strip().lower() != user["email"]:
        new_email = d["email"].strip().lower()
        if not valid_email(new_email):
            raise BadRequest("Adresse e-mail invalide.")
        if A.find_by_email(new_email):
            raise BadRequest("Cette adresse ne peut pas être utilisée.")
        patch.update({"email": new_email, "email_verified_at": None})
    if patch:
        patch["updated_at"] = now_str()
        db.update("users", user["id"], patch)
        audit_req(req, "user.profile_updated", target_type="user", target_id=user["id"],
                  metadata={"changed": sorted(patch.keys())})
    prof = {k: d[k] for k in ("date_of_birth", "address", "wilaya_id", "commune_id",
                              "license_number", "license_issued_at", "license_expires_at") if k in d}
    if prof:
        from ..services.booking_service import _upsert_customer_profile
        _upsert_customer_profile(user["id"], prof)
    return ok(A.public_user(user["id"]))
