from __future__ import annotations
from ..http import get, post, ok, Response, Request, BadRequest, Forbidden, NotFound
from ..services import document_service as D
from ..security import as_id, as_date


@post("/api/v1/documents")
def upload(req: Request):
    user = req.require_perm("document.upload")
    files = req.files()
    f = files.get("file") or files.get("document")
    if not f:
        raise BadRequest("Aucun fichier reçu.")
    d = req.form()
    doc = D.upload(user=user, kind=d.get("kind", "other"), filename=f["filename"],
                   data=f["data"], booking_id=int(d["booking_id"]) if str(d.get("booking_id", "")).isdigit() else None,
                   expires_at=as_date(d.get("expires_at"), "expires_at", required=False), ip=req.ip)
    return ok(doc)


@get("/api/v1/documents")
def my_documents(req: Request):
    user = req.require_user()
    target = req.q("user_id")
    user_id = int(target) if target and str(target).isdigit() else user["id"]
    return ok(D.list_for_user(user_id, user))


@get("/api/v1/documents/<doc_id>")
def detail(req: Request):
    user = req.require_user()
    return ok(D.get(as_id(req.params["doc_id"], "doc_id"), requester=user, ip=req.ip))


@get("/api/v1/documents/<doc_id>/download")
def download(req: Request):
    """Private: session + permission + short-lived signed token, all three required."""
    user = req.require_user()
    data, mime, name = D.read_file(as_id(req.params["doc_id"], "doc_id"), req.q("token", ""), user, ip=req.ip)
    safe_name = name.replace('"', "").replace("\r", "").replace("\n", "")
    return Response(200, data, {
        "Content-Type": mime,
        "Content-Disposition": f'attachment; filename="{safe_name}"',
        "Cache-Control": "no-store, private",
        "X-Robots-Tag": "noindex, nofollow",
    })


@post("/api/v1/documents/<doc_id>/review")
def review(req: Request):
    reviewer = req.require_perm("document.review")
    d = req.form()
    return ok(D.review(as_id(req.params["doc_id"], "doc_id"), decision=d.get("decision", ""),
                       reviewer=reviewer, reason=d.get("reason", ""), ip=req.ip))
