"""Notifications, favourites, reviews, support tickets, health."""
from __future__ import annotations
from ..http import get, post, ok, json_response, Request, NotFound, BadRequest, Conflict, Forbidden
from .. import db
from ..config import Config
from ..security import as_id, clean_text, as_int, as_choice, now_str
from ..services.audit import from_request as audit_req
from ..services.notification_service import notify, unread_count
from ..services import settings_service as S


@get("/api/v1/health")
def health(req: Request):
    try:
        db.scalar("SELECT 1")
        healthy = True
    except Exception:
        healthy = False
    return ok({"status": "ok" if healthy else "degraded", "env": Config.APP_ENV,
               "version": "1.0.0", "database": healthy})


@get("/api/v1/notifications")
def notifications(req: Request):
    user = req.require_user()
    rows = db.query("""SELECT id, kind, title, body, read_at, created_at FROM notifications
                        WHERE user_id = ? ORDER BY id DESC LIMIT 50""", (user["id"],))
    return ok({"items": db.rows_to_dicts(rows), "unread": unread_count(user["id"])})


@post("/api/v1/notifications/read")
def mark_read(req: Request):
    user = req.require_user()
    nid = req.form().get("id")
    if nid and str(nid).isdigit():
        db.execute("UPDATE notifications SET read_at=? WHERE id=? AND user_id=?",
                   (now_str(), int(nid), user["id"]))
    else:
        db.execute("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL",
                   (now_str(), user["id"]))
    return ok({"unread": unread_count(user["id"])})


@get("/api/v1/notifications/preferences")
def get_prefs(req: Request):
    user = req.require_user()
    rows = db.query("SELECT kind, in_app, email, sms FROM notification_preferences WHERE user_id=?",
                    (user["id"],))
    return ok({"preferences": db.rows_to_dicts(rows)})


@post("/api/v1/notifications/preferences")
def set_prefs(req: Request):
    user = req.require_user()
    d = req.form()
    kind = clean_text(d.get("kind"), 60)
    if not kind:
        raise BadRequest("Type de notification manquant.")
    db.execute("""INSERT INTO notification_preferences (user_id, kind, in_app, email, sms)
                  VALUES (?,?,?,?,?)
                  ON CONFLICT(user_id, kind) DO UPDATE SET in_app=excluded.in_app,
                        email=excluded.email, sms=excluded.sms""",
               (user["id"], kind,
                1 if str(d.get("in_app", "1")).lower() in ("1", "true", "on", "yes") else 0,
                1 if str(d.get("email", "1")).lower() in ("1", "true", "on", "yes") else 0,
                1 if str(d.get("sms", "0")).lower() in ("1", "true", "on", "yes") else 0))
    return ok({"saved": True})


@get("/api/v1/favourites")
def favourites(req: Request):
    user = req.require_user()
    rows = db.query("""SELECT v.id, v.slug, v.brand, v.model, v.year, v.daily_price, v.rating_avg,
                              (SELECT path FROM vehicle_images WHERE vehicle_id=v.id
                                ORDER BY is_primary DESC, sort LIMIT 1) AS image
                         FROM favourites f JOIN vehicles v ON v.id=f.vehicle_id
                        WHERE f.user_id=? AND v.deleted_at IS NULL ORDER BY f.created_at DESC""",
                    (user["id"],))
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/favourites")
def toggle_favourite(req: Request):
    user = req.require_user()
    vid = as_int(req.form().get("vehicle_id"), "vehicle_id", minimum=1)
    if not db.one("SELECT 1 FROM vehicles WHERE id=? AND deleted_at IS NULL", (vid,)):
        raise NotFound("Véhicule introuvable.")
    existing = db.one("SELECT 1 FROM favourites WHERE user_id=? AND vehicle_id=?", (user["id"], vid))
    if existing:
        db.execute("DELETE FROM favourites WHERE user_id=? AND vehicle_id=?", (user["id"], vid))
        return ok({"favourite": False})
    db.execute("INSERT INTO favourites (user_id, vehicle_id, created_at) VALUES (?,?,?)",
               (user["id"], vid, now_str()))
    return ok({"favourite": True})


@post("/api/v1/reviews")
def create_review(req: Request):
    """Only the customer of a completed booking may review it, exactly once."""
    user = req.require_user()
    d = req.form()
    booking_id = as_int(d.get("booking_id"), "booking_id", minimum=1)
    booking = db.one("SELECT * FROM bookings WHERE id = ?", (booking_id,))
    if not booking:
        raise NotFound("Réservation introuvable.")
    if booking["customer_user_id"] != user["id"]:
        raise NotFound("Réservation introuvable.")
    if booking["status"] != "completed":
        raise Conflict("Vous pourrez laisser un avis une fois la location terminée.",
                       code="rental_not_completed")
    if db.one("SELECT 1 FROM reviews WHERE booking_id = ?", (booking_id,)):
        raise Conflict("Vous avez déjà laissé un avis pour cette location.", code="review_exists")
    ratings = {}
    for key in ("rating_overall", "rating_vehicle", "rating_service",
                "rating_cleanliness", "rating_communication"):
        val = d.get(key)
        ratings[key] = as_int(val, key, minimum=1, maximum=5,
                              required=(key == "rating_overall"), default=None)
    rid = db.insert("reviews", {
        "booking_id": booking_id, "vehicle_id": booking["vehicle_id"],
        "company_id": booking["company_id"], "user_id": user["id"],
        "comment": clean_text(d.get("comment"), 2000),
        "status": "published", "created_at": now_str(), **ratings})
    from .admin_routes import _recompute_ratings
    _recompute_ratings(booking["vehicle_id"], booking["company_id"])
    audit_req(req, "review.created", target_type="review", target_id=rid,
              metadata={"booking": booking["reference"]})
    return json_response({"ok": True, "data": {"id": rid}}, 201)


@get("/api/v1/support/tickets")
def tickets(req: Request):
    user = req.require_user()
    if req.has_perm("support.manage") and req.q("all") == "1":
        rows = db.query("""SELECT t.*, u.full_name AS customer FROM support_tickets t
                            JOIN users u ON u.id=t.user_id ORDER BY t.updated_at DESC LIMIT 100""")
    else:
        rows = db.query("SELECT * FROM support_tickets WHERE user_id=? ORDER BY updated_at DESC",
                        (user["id"],))
    return ok(db.rows_to_dicts(rows))


@post("/api/v1/support/tickets")
def create_ticket(req: Request):
    user = req.require_user()
    d = req.form()
    subject = clean_text(d.get("subject"), 160)
    body = clean_text(d.get("message"), 4000)
    if len(subject) < 4 or len(body) < 10:
        raise BadRequest("Indiquez un objet et un message détaillé.")
    category = as_choice(d.get("category", "question"), "category",
                         ("question", "booking_problem", "payment_problem", "vehicle_problem",
                          "refund_request", "complaint", "other"))
    booking_id = int(d["booking_id"]) if str(d.get("booking_id", "")).isdigit() else None
    if booking_id:
        owner = db.scalar("SELECT customer_user_id FROM bookings WHERE id=?", (booking_id,))
        if owner != user["id"]:
            raise Forbidden("Cette réservation ne vous appartient pas.")
    import secrets
    ref = f"SUP-{secrets.token_hex(3).upper()}"
    with db.transaction():
        tid = db.insert("support_tickets", {
            "reference": ref, "user_id": user["id"], "booking_id": booking_id,
            "category": category, "subject": subject, "status": "open",
            "created_at": now_str(), "updated_at": now_str()})
        db.insert("support_messages", {"ticket_id": tid, "user_id": user["id"], "body": body,
                                       "is_staff": 0, "created_at": now_str()})
    return json_response({"ok": True, "data": {"id": tid, "reference": ref}}, 201)


@get("/api/v1/support/tickets/<ticket_id>")
def ticket_detail(req: Request):
    user = req.require_user()
    tid = as_id(req.params["ticket_id"], "ticket_id")
    t = db.one("SELECT * FROM support_tickets WHERE id=?", (tid,))
    if not t or (t["user_id"] != user["id"] and not req.has_perm("support.manage")):
        raise NotFound("Ticket introuvable.")
    msgs = db.query("""SELECT m.body, m.is_staff, m.created_at, u.full_name AS author
                         FROM support_messages m JOIN users u ON u.id=m.user_id
                        WHERE m.ticket_id=? ORDER BY m.id""", (tid,))
    return ok({"ticket": dict(t), "messages": db.rows_to_dicts(msgs)})


@post("/api/v1/support/tickets/<ticket_id>/messages")
def reply_ticket(req: Request):
    user = req.require_user()
    tid = as_id(req.params["ticket_id"], "ticket_id")
    t = db.one("SELECT * FROM support_tickets WHERE id=?", (tid,))
    is_staff = req.has_perm("support.manage")
    if not t or (t["user_id"] != user["id"] and not is_staff):
        raise NotFound("Ticket introuvable.")
    body = clean_text(req.form().get("message"), 4000)
    if len(body) < 2:
        raise BadRequest("Message vide.")
    db.insert("support_messages", {"ticket_id": tid, "user_id": user["id"], "body": body,
                                   "is_staff": 1 if is_staff else 0, "created_at": now_str()})
    new_status = req.form().get("status")
    patch = {"updated_at": now_str()}
    if is_staff and new_status in ("open", "in_progress", "waiting_customer", "resolved", "closed"):
        patch["status"] = new_status
    elif is_staff:
        patch["status"] = "in_progress"
    db.update("support_tickets", tid, patch)
    target = t["user_id"] if is_staff else None
    if target:
        notify(target, "support_message", {"reference": t["reference"]})
    return ok({"sent": True})
