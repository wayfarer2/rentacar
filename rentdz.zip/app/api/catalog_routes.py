"""Public catalogue: geography, categories, features, vehicles, availability, quotes."""
from __future__ import annotations
from ..http import get, post, ok, Request, NotFound, BadRequest
from .. import db
from ..services import vehicle_service as V
from ..services import booking_service as B
from ..services import availability as A
from ..services import settings_service as S
from ..services.payment import available_providers
from ..config import Config
from ..security import as_datetime, as_int


@get("/api/v1/config")
def public_config(req: Request):
    return ok({
        "app_name": S.get("company_name"),
        "tagline": S.get("company_tagline"),
        "locales": S.get("enabled_locales"),
        "default_locale": S.get("default_locale"),
        "currency": S.get("currency"),
        "timezone": S.get("timezone"),
        "locale": req.locale,
        "direction": "rtl" if req.locale in Config.RTL_LOCALES else "ltr",
        "booking": {
            "min_days": S.get("min_rental_days"), "max_days": S.get("max_rental_days"),
            "min_hours_before_pickup": S.get("min_hours_before_pickup"),
            "hold_minutes": S.get("hold_minutes"),
            "min_driver_age": S.get("min_driver_age"),
            "require_license_info": S.get("require_license_info"),
        },
        "cancellation_policy": S.get("cancellation_policy"),
        "payment_methods": available_providers(),
        "support": {"email": S.get("support_email"), "phone": S.get("support_phone")},
    })


@get("/api/v1/wilayas")
def wilayas(req: Request):
    rows = db.query("""SELECT w.id, w.code, w.slug, w.name_fr, w.name_ar, w.name_en, w.lat, w.lng,
                              (SELECT COUNT(*) FROM locations l WHERE l.wilaya_id = w.id AND l.active=1) AS locations,
                              (SELECT COUNT(*) FROM vehicles v JOIN locations l2 ON l2.id = v.primary_location_id
                                WHERE l2.wilaya_id = w.id AND v.deleted_at IS NULL
                                  AND v.approval_status='approved') AS vehicles
                         FROM wilayas w WHERE w.active = 1 ORDER BY w.id""")
    return ok(db.rows_to_dicts(rows))


@get("/api/v1/wilayas/<wilaya_id>/communes")
def communes(req: Request):
    rows = db.query("SELECT id, slug, name_fr, name_ar FROM communes WHERE wilaya_id = ? ORDER BY name_fr",
                    (req.params["wilaya_id"],))
    return ok(db.rows_to_dicts(rows))


@get("/api/v1/locations")
def locations(req: Request):
    where, params = ["active = 1"], []
    if req.q("wilaya"):
        where.append("wilaya_id IN (SELECT id FROM wilayas WHERE slug = ? OR id = ?)")
        params += [req.q("wilaya"), req.q("wilaya") if req.q("wilaya").isdigit() else -1]
    if req.q("kind"):
        where.append("kind = ?"); params.append(req.q("kind"))
    rows = db.query(f"""SELECT l.id, l.slug, l.kind, l.name_fr, l.name_ar, l.name_en, l.address,
                               l.lat, l.lng, l.iata_code, l.extra_fee, w.name_fr AS wilaya, w.slug AS wilaya_slug
                          FROM locations l JOIN wilayas w ON w.id = l.wilaya_id
                         WHERE {' AND '.join(where)} ORDER BY l.kind, l.name_fr""", tuple(params))
    return ok(db.rows_to_dicts(rows))


@get("/api/v1/categories")
def categories(req: Request):
    rows = db.query("""SELECT c.code, c.slug, c.name_fr, c.name_ar, c.name_en,
                              (SELECT COUNT(*) FROM vehicles v WHERE v.category_id = c.id
                                AND v.deleted_at IS NULL AND v.approval_status='approved') AS vehicles
                         FROM vehicle_categories c WHERE c.active = 1 ORDER BY c.sort, c.id""")
    return ok(db.rows_to_dicts(rows))


@get("/api/v1/features")
def features(req: Request):
    return ok(db.rows_to_dicts(db.query(
        "SELECT code, name_fr, name_ar, name_en, icon FROM features ORDER BY id")))


@get("/api/v1/services")
def services(req: Request):
    return ok(db.rows_to_dicts(db.query(
        """SELECT id, code, name_fr, name_ar, name_en, price, price_type, max_qty
             FROM services WHERE active = 1 AND company_id IS NULL ORDER BY price""")))


@get("/api/v1/vehicles")
def search_vehicles(req: Request):
    def multi(name):
        return [v for v in req.query.get(name, []) if v] or None
    result = V.search(
        pickup_date=req.q("pickup_date"), return_date=req.q("return_date"),
        wilaya=req.q("wilaya"), location_id=req.q("location_id"),
        category=multi("category"), transmission=req.q("transmission"),
        fuel=multi("fuel"), seats=req.q("seats"),
        price_min=req.q("price_min"), price_max=req.q("price_max"),
        features=multi("features"), sort=req.q("sort", "recommended"),
        limit=req.q("limit", 12), offset=req.q("offset", 0))
    return ok(result)


@get("/api/v1/vehicles/<slug>")
def vehicle_detail(req: Request):
    v = V.get_public(req.params["slug"])
    if not v:
        raise NotFound("Ce véhicule n'existe pas ou n'est plus proposé.")
    return ok(v)


@get("/api/v1/vehicles/<vehicle_id>/availability")
def vehicle_availability(req: Request):
    start = req.q("start") or db.scalar("SELECT date('now')")
    end = req.q("end") or db.scalar("SELECT date('now','+90 days')")
    A.release_expired_holds()
    vid = req.params["vehicle_id"]
    row = db.one("""SELECT v.id FROM vehicles v JOIN rental_companies c ON c.id = v.company_id
                     WHERE (v.id = ? OR v.slug = ?) AND v.deleted_at IS NULL
                       AND v.approval_status='approved' AND c.status='approved'""",
                 (vid if str(vid).isdigit() else -1, str(vid)))
    if not row:
        raise NotFound("Véhicule introuvable.")
    days = A.day_range(start, end)
    if len(days) > 400:
        raise BadRequest("Plage de dates trop large (400 jours maximum).")
    busy = {r["day"] for r in db.query(
        f"""SELECT day FROM vehicle_day_locks WHERE vehicle_id = ?
             AND day IN ({','.join('?' * len(days))})""", tuple([row["id"], *days]))}
    return ok({"vehicle_id": row["id"], "start": start, "end": end,
               "unavailable_days": sorted(busy),
               "note": S.get("turnaround_note")})


@post("/api/v1/quote")
def quote(req: Request):
    d = req.form()
    if not d.get("vehicle_id"):
        raise BadRequest("Véhicule manquant.")
    services_in = d.get("services") or []
    if isinstance(services_in, str):
        services_in = [{"id": int(x)} for x in services_in.split(",") if x.strip().isdigit()]
    q = B.quote_for(as_int(d.get("vehicle_id"), "vehicle_id", minimum=1),
                    as_datetime(d.get("pickup_at"), "pickup_at"),
                    as_datetime(d.get("return_at"), "return_at"),
                    services=services_in,
                    pickup_location_id=d.get("pickup_location_id") or None,
                    dropoff_location_id=d.get("dropoff_location_id") or None,
                    promo_code=d.get("promo_code") or None,
                    user_id=req.user["id"] if req.user else None)
    return ok(q)
