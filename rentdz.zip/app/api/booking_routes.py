from __future__ import annotations
from ..http import (get, post, ok, json_response, Request, NotFound, BadRequest,
                    Forbidden, Conflict)
from .. import db
from ..services import booking_service as B
from ..services import availability as A
from ..services import pricing as P
from ..services import settings_service as S
from ..security import (rate_limited, as_date, as_datetime, as_int, as_id,
                        clean_text, MAX_SQLITE_INT)


def _resolve(req: Request) -> dict:
    """Accepts a numeric id or a human reference. Anything else is a 404."""
    ident = str(req.params["id"]).strip()
    booking = None
    if ident.upper().startswith("RDZ-"):
        booking = B.by_reference(ident[:24])
    elif ident.isdigit():
        value = int(ident)
        if 1 <= value <= MAX_SQLITE_INT:
            booking = B.get_booking(value)
    if not booking:
        raise NotFound("Réservation introuvable.")
    B.assert_can_view(booking, req)
    return booking


@post("/api/v1/bookings")
def create(req: Request):
    user = req.require_perm("booking.create")
    if rate_limited(f"booking:{user['id']}", 12, 3600) or rate_limited(f"booking:ip:{req.ip}", 30, 3600):
        raise Conflict("Trop de tentatives de réservation. Réessayez plus tard.", code="rate_limited")
    d = req.form()
    if not d.get("vehicle_id"):
        raise BadRequest("Véhicule manquant.")
    services = d.get("services") or []
    if isinstance(services, str):
        services = [{"id": int(x)} for x in services.split(",") if x.strip().isdigit()]
    customer = {
        "full_name": clean_text(d.get("full_name") or user["full_name"], 120),
        "phone": clean_text(d.get("phone"), 20),
        "email": clean_text(d.get("email") or user["email"], 190),
        "date_of_birth": as_date(d.get("date_of_birth"), "date_of_birth", required=False),
        "address": clean_text(d.get("address"), 250),
        "wilaya_id": int(d["wilaya_id"]) if str(d.get("wilaya_id", "")).isdigit() else None,
        "commune_id": int(d["commune_id"]) if str(d.get("commune_id", "")).isdigit() else None,
        "license_number": clean_text(d.get("license_number"), 40),
        "license_issued_at": as_date(d.get("license_issued_at"), "license_issued_at", required=False),
        "license_expires_at": as_date(d.get("license_expires_at"), "license_expires_at", required=False),
    }
    booking = B.create_booking(
        user=user, vehicle_id=as_int(d.get("vehicle_id"), "vehicle_id", minimum=1),
        pickup_at=as_datetime(d.get("pickup_at"), "pickup_at"),
        return_at=as_datetime(d.get("return_at"), "return_at"),
        pickup_location_id=d.get("pickup_location_id") or None,
        dropoff_location_id=d.get("dropoff_location_id") or None,
        services=services, promo_code=d.get("promo_code") or None,
        customer=customer, notes=d.get("notes", ""),
        payment_method=d.get("payment_method") or None, ip=req.ip)
    return json_response({"ok": True, "data": booking}, 201)


@get("/api/v1/bookings")
def my_bookings(req: Request):
    user = req.require_user()
    scope = req.q("scope", "all")
    if scope not in ("all", "upcoming", "past", "cancelled", "active"):
        raise BadRequest("Filtre inconnu.")
    return ok(B.customer_bookings(user["id"], scope,
                                  limit=min(int(req.q("limit", 20)), 50),
                                  offset=int(req.q("offset", 0))))


@get("/api/v1/bookings/<id>")
def detail(req: Request):
    booking = _resolve(req)
    booking["cancellation_preview"] = P.refund_for_cancellation(booking)
    booking["can_cancel"] = booking["status"] in ("pending", "awaiting_payment", "confirmed")
    booking["can_manage"] = B.can_manage(booking, req)
    return ok(booking)


@post("/api/v1/bookings/<id>/cancel")
def cancel(req: Request):
    booking = _resolve(req)
    user = req.require_user()
    is_owner = booking["customer_user_id"] == user["id"]
    if not is_owner and not B.can_manage(booking, req):
        raise Forbidden("Vous ne pouvez pas annuler cette réservation.")
    if is_owner and not req.has_perm("booking.cancel.own") and not B.can_manage(booking, req):
        raise Forbidden("Vous ne pouvez pas annuler cette réservation.")
    reason = clean_text(req.form().get("reason"), 300)
    result = B.cancel_booking(booking["id"], actor=user, reason=reason, ip=req.ip)
    return ok(result)


@get("/api/v1/bookings/<id>/cancellation-preview")
def cancel_preview(req: Request):
    booking = _resolve(req)
    return ok(P.refund_for_cancellation(booking))


@post("/api/v1/bookings/<id>/status")
def set_status(req: Request):
    """Vendor/admin state machine: confirm, reject, start, complete, no-show."""
    booking = _resolve(req)
    user = req.require_user()
    if not B.can_manage(booking, req):
        raise Forbidden("Réservé aux gestionnaires de la société ou aux administrateurs.")
    to = req.form().get("status", "")
    if to not in ("confirmed", "rejected", "active", "completed", "no_show", "awaiting_payment"):
        raise BadRequest("Statut cible invalide.")
    reason = clean_text(req.form().get("reason"), 300)
    if to == "rejected" and not reason:
        raise BadRequest("Indiquez le motif du refus.")
    if to == "confirmed" and S.get("require_documents_before_confirm"):
        approved = db.scalar(
            """SELECT COUNT(*) FROM documents
                WHERE owner_user_id = ? AND kind='driver_license' AND status='approved'
                  AND deleted_at IS NULL""", (booking["customer_user_id"],), 0)
        if not approved and not req.has_perm("booking.manage.all"):
            raise Conflict("Le permis de conduire du client doit être approuvé avant confirmation.",
                           code="documents_required")
    return ok(B.transition(booking["id"], to, actor=user, reason=reason, ip=req.ip))


@get("/api/v1/bookings/<id>/agreement")
def agreement(req: Request):
    """Rental agreement data (rendered as a printable page / PDF by the client)."""
    booking = _resolve(req)
    if booking["status"] not in ("confirmed", "active", "completed"):
        raise Conflict("Le contrat est disponible après confirmation de la réservation.",
                       code="not_confirmed")
    company = db.one("SELECT * FROM rental_companies WHERE id = ?", (booking["company_id"],))
    vehicle = db.one("SELECT * FROM vehicles WHERE id = ?", (booking["vehicle_id"],))
    profile = db.one("SELECT * FROM customer_profiles WHERE user_id = ?", (booking["customer_user_id"],))
    return ok({
        "booking": booking,
        "company": {k: company[k] for k in ("name", "legal_name", "rc_number", "nif", "phone",
                                            "email", "address")},
        "vehicle": {k: vehicle[k] for k in ("brand", "model", "year", "color", "seats",
                                            "transmission", "fuel", "mileage",
                                            "km_included_per_day", "extra_km_price", "fuel_policy",
                                            "registration_number")},
        "customer": {"full_name": booking["customer_name"], "email": booking["customer_email"],
                     "phone": booking["customer_phone"],
                     "licence": (profile["license_number"] if profile else None),
                     "address": (profile["address"] if profile else None)},
        "clauses": {
            "intro": S.get("rental_agreement_intro"),
            "mileage": ("Kilométrage illimité" if not vehicle["km_included_per_day"]
                        else f"{vehicle['km_included_per_day']} km/jour inclus, "
                             f"puis {vehicle['extra_km_price']} DA/km"),
            "fuel": "Le véhicule est restitué avec le même niveau de carburant qu'au départ.",
            "damage": "Tout dommage constaté au retour est facturé selon le barème de l'agence.",
            "cancellation": S.get("cancellation_policy"),
            "deposit": f"Caution : {booking['deposit_amount']} DA",
        },
        "signatures": {"customer": None, "company": None, "signed_at": None},
    })


@get("/api/v1/bookings/<id>/receipt")
def receipt(req: Request):
    booking = _resolve(req)
    return ok({"reference": booking["reference"], "issued_at": booking["created_at"],
               "breakdown": booking["breakdown"], "payments": booking["payments"],
               "total": booking["total_amount"], "paid": booking["paid_amount"],
               "refunded": booking["refund_amount"], "currency": booking["currency"]})


@post("/api/v1/maintenance/release-holds")
def release_holds(req: Request):
    """Cron-able endpoint: expire stale holds and free inventory. Admin only."""
    req.require_perm("booking.manage.all")
    freed = A.release_expired_holds()
    return ok({"expired_bookings": freed})
