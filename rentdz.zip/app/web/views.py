"""Server-rendered pages. Public pages carry real content for SEO; the
authenticated areas render an app shell hydrated by the JSON API."""
from __future__ import annotations
import json
from datetime import timedelta
from ..http import get, html_response, Request, redirect, NotFound
from ..config import Config
from .. import db
from ..i18n import t, money, human_date, label, CATEGORY_LABELS, STATUS_LABELS, is_rtl
from ..services import vehicle_service as V
from ..services import settings_service as S
from ..services import availability as A
from ..security import now
from .templates import (layout, e, attr, safe_json, vehicle_card, empty_state,
                        status_pill, skeleton, breadcrumbs)

FUEL_LABELS = {"petrol": "Essence", "diesel": "Diesel", "hybrid": "Hybride",
               "electric": "Électrique", "gpl": "GPL"}


def _default_dates() -> tuple[str, str]:
    d1 = (now() + timedelta(days=2)).strftime("%Y-%m-%d")
    d2 = (now() + timedelta(days=5)).strftime("%Y-%m-%d")
    return d1, d2


def search_form(req, *, compact=False, values: dict | None = None) -> str:
    loc = req.locale
    v = values or {}
    d1, d2 = _default_dates()
    wilayas = db.query("""SELECT w.slug, w.name_fr, w.name_ar, w.name_en FROM wilayas w
                           WHERE w.active=1 AND EXISTS (SELECT 1 FROM locations l WHERE l.wilaya_id=w.id AND l.active=1)
                           ORDER BY w.name_fr""")
    options = "".join(
        f'<option value="{attr(w["slug"])}"{" selected" if v.get("wilaya") == w["slug"] else ""}>'
        f'{e(w[f"name_{loc}"] if f"name_{loc}" in w.keys() else w["name_fr"])}</option>'
        for w in wilayas)
    return f"""
<form class="searchbar{' searchbar--compact' if compact else ''}" action="/vehicules" method="get"
      data-searchform aria-label="{attr(t('search.submit', loc))}">
  <div class="searchbar__field">
    <label for="s-wilaya">{e(t('search.pickup_location', loc))}</label>
    <select id="s-wilaya" name="wilaya" required>
      <option value="">Choisir une ville…</option>{options}
    </select>
  </div>
  <div class="searchbar__field">
    <label for="s-pickup">{e(t('search.pickup_date', loc))}</label>
    <input id="s-pickup" type="date" name="pickup_date" value="{attr(v.get('pickup_date') or d1)}"
           min="{attr(now().strftime('%Y-%m-%d'))}" required>
  </div>
  <div class="searchbar__field searchbar__field--time">
    <label for="s-ptime">{e(t('search.pickup_time', loc))}</label>
    <input id="s-ptime" type="time" name="pickup_time" value="{attr(v.get('pickup_time') or '10:00')}" step="1800">
  </div>
  <div class="searchbar__field">
    <label for="s-return">{e(t('search.return_date', loc))}</label>
    <input id="s-return" type="date" name="return_date" value="{attr(v.get('return_date') or d2)}"
           min="{attr(now().strftime('%Y-%m-%d'))}" required>
  </div>
  <div class="searchbar__field searchbar__field--time">
    <label for="s-rtime">{e(t('search.return_time', loc))}</label>
    <input id="s-rtime" type="time" name="return_time" value="{attr(v.get('return_time') or '10:00')}" step="1800">
  </div>
  <button class="btn btn--primary btn--lg searchbar__submit" type="submit">
    {e(t('search.submit', loc))}
  </button>
  <p class="searchbar__error" data-search-error role="alert" hidden></p>
</form>"""


@get("/")
def home(req: Request):
    loc = req.locale
    popular = V.search(sort="recommended", limit=6)["items"]
    wilayas = db.query("""SELECT w.slug, w.name_fr, w.name_ar,
                                 (SELECT COUNT(*) FROM vehicles v
                                    JOIN locations l ON l.id=v.primary_location_id
                                   WHERE l.wilaya_id=w.id AND v.deleted_at IS NULL
                                     AND v.approval_status='approved') AS vehicles
                            FROM wilayas w WHERE w.active=1
                            ORDER BY vehicles DESC, w.name_fr LIMIT 8""")
    reviews = db.query("""SELECT r.rating_overall, r.comment, u.full_name, v.brand, v.model
                            FROM reviews r JOIN users u ON u.id=r.user_id
                            JOIN vehicles v ON v.id=r.vehicle_id
                           WHERE r.status='published' AND r.comment IS NOT NULL AND r.comment != ''
                           ORDER BY r.created_at DESC LIMIT 3""")
    stats = {
        "vehicles": db.scalar("""SELECT COUNT(*) FROM vehicles WHERE deleted_at IS NULL
                                  AND approval_status='approved'""", (), 0),
        "companies": db.scalar("SELECT COUNT(*) FROM rental_companies WHERE status='approved'", (), 0),
        "wilayas": db.scalar("""SELECT COUNT(DISTINCT l.wilaya_id) FROM locations l WHERE l.active=1""", (), 0),
    }

    cards = "".join(vehicle_card(v, loc) for v in popular) or empty_state(
        "🚘", t("empty.no_fleet", loc), "Les premiers véhicules arrivent bientôt.")
    dest = "".join(f"""
      <a class="dest" href="/location/{attr(w['slug'])}">
        <span class="dest__name">{e(w['name_ar'] if loc == 'ar' else w['name_fr'])}</span>
        <span class="dest__count">{e(w['vehicles'])} véhicule(s)</span>
      </a>""" for w in wilayas)
    testimonials = "".join(f"""
      <figure class="quote">
        <div class="quote__stars" aria-label="{r['rating_overall']} sur 5">{'★' * r['rating_overall']}{'☆' * (5 - r['rating_overall'])}</div>
        <blockquote>{e(r['comment'])}</blockquote>
        <figcaption>{e(r['full_name'])} · {e(r['brand'])} {e(r['model'])}</figcaption>
      </figure>""" for r in reviews)

    faq = [
        ("Quels documents faut-il pour louer une voiture en Algérie ?",
         "Un permis de conduire en cours de validité et une pièce d'identité. "
         "Vous téléversez votre permis dans votre espace client, l'agence le valide avant la remise des clés."),
        ("Comment se passe le paiement ?",
         "Selon le loueur : espèces à l'agence, virement bancaire, ou carte CIB/Edahabia lorsque "
         "le loueur a activé le paiement en ligne. Le détail du prix est affiché avant toute confirmation."),
        ("Une caution est-elle demandée ?",
         "Oui, la plupart des loueurs demandent une caution restituée au retour du véhicule si "
         "aucun dommage n'est constaté. Le montant est indiqué sur la fiche du véhicule."),
        ("Puis-je annuler ma réservation ?",
         "Oui. L'annulation est gratuite jusqu'à 48 h avant le départ, puis partiellement "
         "remboursée jusqu'à 24 h. Le détail s'affiche avant confirmation d'annulation."),
        ("Le kilométrage est-il limité ?",
         "Cela dépend du véhicule : chaque fiche précise le kilométrage inclus par jour et le "
         "tarif du kilomètre supplémentaire."),
    ]
    faq_html = "".join(f"""
      <details class="faq__item">
        <summary>{e(q)}</summary><p>{e(a)}</p>
      </details>""" for q, a in faq)

    json_ld = {
        "@context": "https://schema.org", "@type": "WebSite",
        "name": "RENTDZ", "url": Config.APP_URL,
        "inLanguage": ["fr-DZ", "ar-DZ"],
        "potentialAction": {"@type": "SearchAction",
                            "target": f"{Config.APP_URL}/vehicules?wilaya={{search_term_string}}",
                            "query-input": "required name=search_term_string"},
        "publisher": {"@type": "Organization", "name": "RENTDZ",
                      "areaServed": {"@type": "Country", "name": "Algérie"}},
    }

    body = f"""
<section class="hero">
  <div class="hero__bg" aria-hidden="true"></div>
  <div class="container hero__inner">
    <p class="hero__eyebrow">{e(S.get('company_tagline'))}</p>
    <h1 class="hero__title">{e(t('hero.title', loc))}</h1>
    <p class="hero__sub">{e(t('hero.subtitle', loc))}</p>
    {search_form(req)}
    <ul class="hero__stats">
      <li><strong>{e(stats['vehicles'])}</strong><span>véhicules disponibles</span></li>
      <li><strong>{e(stats['companies'])}</strong><span>loueurs partenaires</span></li>
      <li><strong>{e(stats['wilayas'])}</strong><span>wilayas couvertes</span></li>
    </ul>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section__head">
      <h2>Véhicules populaires</h2>
      <a class="link" href="/vehicules">Voir tout le catalogue →</a>
    </div>
    <div class="grid grid--cards">{cards}</div>
  </div>
</section>

<section class="section section--alt">
  <div class="container">
    <div class="section__head"><h2>Destinations populaires</h2></div>
    <div class="grid grid--dest">{dest}</div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section__head"><h2>Comment ça marche</h2></div>
    <ol class="steps">
      <li><span class="steps__num">1</span><h3>Choisissez vos dates</h3>
          <p>Indiquez la ville, les dates et les heures. Nous n'affichons que les véhicules réellement disponibles.</p></li>
      <li><span class="steps__num">2</span><h3>Comparez en toute transparence</h3>
          <p>Prix par jour, caution, kilométrage, options : tout est affiché avant de réserver.</p></li>
      <li><span class="steps__num">3</span><h3>Réservez et téléversez votre permis</h3>
          <p>Vos documents restent privés et ne sont visibles que par l'agence et nos équipes de contrôle.</p></li>
      <li><span class="steps__num">4</span><h3>Récupérez le véhicule</h3>
          <p>Paiement à l'agence ou en ligne selon le loueur. Vous recevez votre contrat de location.</p></li>
    </ol>
  </div>
</section>

<section class="section section--alt">
  <div class="container">
    <div class="section__head"><h2>Pourquoi RENTDZ</h2></div>
    <div class="grid grid--why">
      <div class="why"><h3>Disponibilité réelle</h3><p>Notre moteur bloque les dates au niveau de la base de données : pas de double réservation, jamais.</p></div>
      <div class="why"><h3>Prix en dinars, sans surprise</h3><p>Le détail complet (location, options, frais, caution) est calculé côté serveur et affiché avant paiement.</p></div>
      <div class="why"><h3>Loueurs vérifiés</h3><p>Chaque société est validée par notre équipe avant de publier des véhicules.</p></div>
      <div class="why"><h3>Documents protégés</h3><p>Permis et pièces d'identité sont stockés en privé, avec accès tracé et liens temporaires.</p></div>
    </div>
  </div>
</section>

{f'''<section class="section"><div class="container">
  <div class="section__head"><h2>Ils ont loué avec RENTDZ</h2></div>
  <div class="grid grid--quotes">{testimonials}</div></div></section>''' if testimonials else ''}

<section class="section section--alt">
  <div class="container container--narrow">
    <div class="section__head"><h2>Questions fréquentes</h2></div>
    <div class="faq">{faq_html}</div>
  </div>
</section>

<section class="cta">
  <div class="container cta__inner">
    <div>
      <h2>Vous gérez une flotte de véhicules ?</h2>
      <p>Publiez vos véhicules, gérez votre calendrier et vos réservations depuis un seul espace.</p>
    </div>
    <a class="btn btn--light btn--lg" href="/devenir-loueur">Devenir loueur partenaire</a>
  </div>
</section>"""
    return html_response(layout(req, title="Location de voiture en Algérie",
                                description=t("hero.subtitle", loc), canonical="/",
                                body=body, json_ld=json_ld, page_class="page-home",
                                scripts=("search.js",)))


@get("/vehicules")
def vehicles_page(req: Request):
    loc = req.locale
    filters = {k: req.q(k) for k in ("wilaya", "pickup_date", "return_date", "pickup_time",
                                     "return_time", "category", "transmission", "fuel",
                                     "seats", "price_min", "price_max", "sort")}
    result = V.search(pickup_date=filters["pickup_date"], return_date=filters["return_date"],
                      wilaya=filters["wilaya"], category=req.query.get("category"),
                      transmission=filters["transmission"], fuel=req.query.get("fuel"),
                      seats=filters["seats"], price_min=filters["price_min"],
                      price_max=filters["price_max"], features=req.query.get("features"),
                      sort=filters["sort"] or "recommended",
                      limit=req.q("limit", 12), offset=req.q("offset", 0))
    categories = db.query("SELECT code, name_fr, name_ar, name_en FROM vehicle_categories WHERE active=1 ORDER BY sort")
    features = db.query("SELECT code, name_fr, name_ar, name_en FROM features ORDER BY id")
    price_max = db.scalar("""SELECT COALESCE(MAX(daily_price), 30000) FROM vehicles
                              WHERE deleted_at IS NULL AND approval_status='approved'""", (), 30000)
    query = ""
    if filters["pickup_date"] and filters["return_date"]:
        query = f"?pickup_date={attr(filters['pickup_date'])}&return_date={attr(filters['return_date'])}"

    cards = "".join(vehicle_card(v, loc, query=query) for v in result["items"])
    if not result["items"]:
        cards = empty_state("🔍", t("empty.no_vehicles", loc),
                            "Essayez d'élargir vos dates, votre budget ou une autre ville.",
                            ("Réinitialiser les filtres", "/vehicules"))

    cat_boxes = "".join(f"""
      <label class="check"><input type="checkbox" name="category" value="{attr(c['code'])}"
        {'checked' if c['code'] in (req.query.get('category') or []) else ''}>
        <span>{e(c[f'name_{loc}'] if f'name_{loc}' in c.keys() else c['name_fr'])}</span></label>"""
      for c in categories)
    feat_boxes = "".join(f"""
      <label class="check"><input type="checkbox" name="features" value="{attr(f['code'])}"
        {'checked' if f['code'] in (req.query.get('features') or []) else ''}>
        <span>{e(f[f'name_{loc}'] if f'name_{loc}' in f.keys() else f['name_fr'])}</span></label>"""
      for f in features)
    fuel_boxes = "".join(f"""
      <label class="check"><input type="checkbox" name="fuel" value="{attr(code)}"
        {'checked' if code in (req.query.get('fuel') or []) else ''}>
        <span>{e(lbl)}</span></label>""" for code, lbl in FUEL_LABELS.items())
    sort_opts = "".join(
        f'<option value="{k}"{" selected" if (filters["sort"] or "recommended") == k else ""}>{e(t(f"sort.{k}", loc))}</option>'
        for k in ("recommended", "price_asc", "price_desc", "rating", "newest"))

    body = f"""
<div class="subhead">
  <div class="container">{search_form(req, compact=True, values=filters)}</div>
</div>
<div class="container results">
  <aside class="filters" data-filters>
    <form method="get" action="/vehicules" data-filterform>
      <input type="hidden" name="wilaya" value="{attr(filters['wilaya'] or '')}">
      <input type="hidden" name="pickup_date" value="{attr(filters['pickup_date'] or '')}">
      <input type="hidden" name="return_date" value="{attr(filters['return_date'] or '')}">
      <div class="filters__head">
        <h2>{e(t('filters.title', loc))}</h2>
        <a class="link link--sm" href="/vehicules">{e(t('filters.reset', loc))}</a>
      </div>
      <fieldset class="filters__group"><legend>{e(t('filters.category', loc))}</legend>{cat_boxes}</fieldset>
      <fieldset class="filters__group"><legend>{e(t('filters.transmission', loc))}</legend>
        <label class="check"><input type="radio" name="transmission" value=""
          {'checked' if not filters['transmission'] else ''}><span>Toutes</span></label>
        <label class="check"><input type="radio" name="transmission" value="manual"
          {'checked' if filters['transmission'] == 'manual' else ''}><span>Manuelle</span></label>
        <label class="check"><input type="radio" name="transmission" value="automatic"
          {'checked' if filters['transmission'] == 'automatic' else ''}><span>Automatique</span></label>
      </fieldset>
      <fieldset class="filters__group"><legend>{e(t('filters.fuel', loc))}</legend>{fuel_boxes}</fieldset>
      <fieldset class="filters__group"><legend>{e(t('filters.seats', loc))}</legend>
        <div class="seatrow">
          {''.join(f'''<label class="seatpill"><input type="radio" name="seats" value="{s}"
             {'checked' if filters['seats'] == str(s) else ''}><span>{s}{'+' if s == 7 else ''}</span></label>'''
             for s in (2, 4, 5, 7))}
        </div>
      </fieldset>
      <fieldset class="filters__group"><legend>{e(t('filters.price', loc))} (DA)</legend>
        <div class="pricerow">
          <input type="number" name="price_min" min="0" step="500" placeholder="Min"
                 value="{attr(filters['price_min'] or '')}" aria-label="Prix minimum">
          <span aria-hidden="true">—</span>
          <input type="number" name="price_max" min="0" step="500" placeholder="{attr(price_max)}"
                 value="{attr(filters['price_max'] or '')}" aria-label="Prix maximum">
        </div>
      </fieldset>
      <fieldset class="filters__group"><legend>{e(t('filters.features', loc))}</legend>{feat_boxes}</fieldset>
      <button class="btn btn--primary btn--full" type="submit">Appliquer les filtres</button>
    </form>
  </aside>
  <section class="results__main">
    <div class="results__head">
      <h1>{e(t('search.results_count', loc, result['total']))}</h1>
      <label class="sortsel">
        <span>Trier</span>
        <select data-sort>{sort_opts}</select>
      </label>
    </div>
    <button class="btn btn--ghost btn--full filters__toggle" type="button" data-filters-toggle>
      {e(t('filters.title', loc))}
    </button>
    <div class="grid grid--cards" data-results>{cards}</div>
    {f'''<nav class="pager" aria-label="Pagination">
      {f'<a class="btn btn--ghost" href="?{_page_query(req, max(0, int(result["offset"]) - int(result["limit"])))}">← Précédent</a>' if int(result['offset']) > 0 else ''}
      <span class="pager__info">{int(result['offset']) + len(result['items'])} / {result['total']}</span>
      {f'<a class="btn btn--ghost" href="?{_page_query(req, int(result["offset"]) + int(result["limit"]))}">Suivant →</a>' if result['has_more'] else ''}
    </nav>''' if result['total'] > int(result['limit']) else ''}
  </section>
</div>"""
    return html_response(layout(req, title="Véhicules disponibles en Algérie",
                                description="Comparez les voitures de location disponibles en Algérie : "
                                            "prix en dinars, caution, options et disponibilité réelle.",
                                canonical="/vehicules", body=body, page_class="page-results",
                                scripts=("search.js",)))


def _page_query(req: Request, offset: int) -> str:
    from urllib.parse import urlencode
    pairs = [(k, v) for k, values in req.query.items() if k != "offset" for v in values]
    pairs.append(("offset", str(max(0, offset))))
    return urlencode(pairs)


@get("/vehicules/<slug>")
def vehicle_page(req: Request):
    loc = req.locale
    v = V.get_public(req.params["slug"])
    if not v:
        return html_response(render_not_found(req), 404)
    gallery_main = (f'<img src="/media/{attr(v["images"][0]["path"])}" alt="{attr(v["brand"])} {attr(v["model"])}" '
                    f'width="960" height="640" decoding="async">' if v["images"]
                    else '<div class="gallery__placeholder" aria-hidden="true">🚗</div>')
    thumbs = "".join(f"""
      <button class="gallery__thumb{' is-active' if i == 0 else ''}" type="button"
              data-gallery-thumb="/media/{attr(img['path'])}" aria-label="Photo {i+1}">
        <img src="/media/{attr(img['path'])}" alt="" loading="lazy" width="120" height="80">
      </button>""" for i, img in enumerate(v["images"][:8]))

    feats = "".join(f'<li class="feat">{e(f[f"name_{loc}"] if f"name_{loc}" in f else f["name_fr"])}</li>'
                    for f in v["features"]) or '<li class="feat feat--none">Équipements non précisés</li>'
    specs = [
        ("Catégorie", label(CATEGORY_LABELS, v["category"], loc)),
        ("Boîte", "Automatique" if v["transmission"] == "automatic" else "Manuelle"),
        ("Carburant", FUEL_LABELS.get(v["fuel"], v["fuel"])),
        ("Places", f'{v["seats"]}'),
        ("Portes", f'{v["doors"]}'),
        ("Année", f'{v["year"]}'),
        ("Kilométrage", "Illimité" if not v["km_included_per_day"]
         else f'{v["km_included_per_day"]} km/jour inclus'),
        ("Carburant au retour", "Même niveau qu'au départ"),
    ]
    spec_html = "".join(f'<div class="spec"><dt>{e(k)}</dt><dd>{e(val)}</dd></div>' for k, val in specs)

    price_rows = [("Prix par jour", v["daily_price"])]
    if v["weekly_price"]:
        price_rows.append(("Prix par semaine", v["weekly_price"]))
    if v["monthly_price"]:
        price_rows.append(("Prix par mois", v["monthly_price"]))
    if v["weekend_price"]:
        price_rows.append(("Tarif week-end (par jour)", v["weekend_price"]))
    price_html = "".join(f'<li><span>{e(k)}</span><strong>{e(money(val, loc))}</strong></li>'
                         for k, val in price_rows)

    services_html = "".join(f"""
      <label class="svc">
        <input type="checkbox" name="service" value="{s['id']}" data-price="{s['price']}"
               data-type="{attr(s['price_type'])}">
        <span class="svc__name">{e(s[f'name_{loc}'] if f'name_{loc}' in s else s['name_fr'])}</span>
        <span class="svc__price">{e(money(s['price'], loc))}{'/jour' if s['price_type'] == 'per_day' else ''}</span>
      </label>""" for s in v["services"])

    locations_html = "".join(
        f'<option value="{s["id"]}">{e(s["name_fr"])}'
        + (f' (+{s["extra_fee"]} DA)' if s["extra_fee"] else '')
        + '</option>'
        for s in v["locations"])

    reviews_html = "".join(f"""
      <figure class="review">
        <div class="quote__stars" aria-label="{r['rating_overall']} sur 5">{'★' * r['rating_overall']}{'☆' * (5 - r['rating_overall'])}</div>
        <blockquote>{e(r['comment'] or '')}</blockquote>
        <figcaption>{e(r['author'])} · {e(human_date(r['created_at'], loc))}</figcaption>
      </figure>""" for r in v["reviews"]) or empty_state("💬", "Pas encore d'avis",
                                                          "Soyez le premier à louer ce véhicule.")

    d1, d2 = _default_dates()
    json_ld = {
        "@context": "https://schema.org", "@type": "Product",
        "name": f'{v["brand"]} {v["model"]} {v["year"]}',
        "description": (v["description"] or "")[:300],
        "brand": {"@type": "Brand", "name": v["brand"]},
        "offers": {"@type": "Offer", "price": v["daily_price"], "priceCurrency": "DZD",
                   "availability": "https://schema.org/InStock",
                   "url": f'{Config.APP_URL}/vehicules/{v["slug"]}',
                   "priceSpecification": {"@type": "UnitPriceSpecification",
                                          "price": v["daily_price"], "priceCurrency": "DZD",
                                          "unitCode": "DAY"}},
    }
    if v["rating_count"]:
        json_ld["aggregateRating"] = {"@type": "AggregateRating", "ratingValue": v["rating_avg"],
                                      "reviewCount": v["rating_count"]}

    body = f"""
<div class="container">
  {breadcrumbs([("Accueil", "/"), ("Véhicules", "/vehicules"),
                (f'{v["brand"]} {v["model"]}', f'/vehicules/{v["slug"]}')])}
</div>
<div class="container vdetail">
  <div class="vdetail__main">
    <section class="gallery" data-gallery>
      <div class="gallery__main" data-gallery-main>{gallery_main}</div>
      <div class="gallery__thumbs">{thumbs}</div>
    </section>

    <header class="vdetail__head">
      <div>
        <span class="chip chip--cat">{e(label(CATEGORY_LABELS, v['category'], loc))}</span>
        <h1>{e(v['brand'])} {e(v['model'])} <span class="muted">{e(v['year'])}</span></h1>
        <p class="vdetail__sub">
          {e(v.get('location_name') or '')}{' · ' if v.get('location_name') else ''}{e(v.get('wilaya') or '')}
          · Loué par <a href="#loueur">{e(v['company_name'])}</a>
          {f'· ★ {v["rating_avg"]:.1f} ({v["rating_count"]} avis)' if v['rating_count'] else '· Nouveau sur RENTDZ'}
        </p>
      </div>
      <button class="btn btn--ghost btn--icon" type="button" data-favourite="{v['id']}"
              aria-label="Ajouter aux favoris">♥</button>
    </header>

    <section class="card">
      <h2>Caractéristiques</h2>
      <dl class="specs">{spec_html}</dl>
    </section>

    <section class="card">
      <h2>Équipements</h2>
      <ul class="feats">{feats}</ul>
    </section>

    {f'<section class="card"><h2>Description</h2><p class="prose">{e(v["description"])}</p></section>' if v['description'] else ''}

    <section class="card" id="loueur">
      <h2>Le loueur</h2>
      <p class="prose"><strong>{e(v['company_name'])}</strong>
      {f'· ★ {v["company_rating"]:.1f}' if v.get('company_rating') else ''}</p>
      {f'<p class="prose">{e(v["company_description"])}</p>' if v.get('company_description') else ''}
      <p class="muted">Le numéro de téléphone de l'agence est communiqué après confirmation de la réservation.</p>
    </section>

    <section class="card">
      <h2>Tarifs</h2>
      <ul class="pricelist">{price_html}</ul>
      <p class="muted">Caution : <strong>{e(money(v['deposit'], loc))}</strong> · restituée au retour
        du véhicule si aucun dommage n'est constaté.</p>
    </section>

    <section class="card">
      <h2>Avis des clients</h2>
      <div class="reviews">{reviews_html}</div>
    </section>
  </div>

  <aside class="booker" data-booker
         data-vehicle="{v['id']}" data-slug="{attr(v['slug'])}" data-daily="{v['daily_price']}" data-deposit="{v['deposit']}"
         data-min-days="{v['min_days']}" data-max-days="{v['max_days']}"
         data-unavailable="{attr(safe_json(v['unavailable_days']))}">
    <div class="booker__price">
      <strong>{e(money(v['daily_price'], loc))}</strong><span>{e(t('vehicle.per_day', loc))}</span>
    </div>
    <form class="booker__form" data-quoteform>
      <div class="field">
        <label for="b-pickup">{e(t('search.pickup_date', loc))}</label>
        <div class="field__row">
          <input id="b-pickup" type="date" name="pickup_date" value="{attr(req.q('pickup_date') or d1)}"
                 min="{attr(now().strftime('%Y-%m-%d'))}" required>
          <input type="time" name="pickup_time" value="10:00" step="1800" aria-label="Heure de départ">
        </div>
      </div>
      <div class="field">
        <label for="b-return">{e(t('search.return_date', loc))}</label>
        <div class="field__row">
          <input id="b-return" type="date" name="return_date" value="{attr(req.q('return_date') or d2)}"
                 min="{attr(now().strftime('%Y-%m-%d'))}" required>
          <input type="time" name="return_time" value="10:00" step="1800" aria-label="Heure de retour">
        </div>
      </div>
      {f'''<div class="field">
        <label for="b-pickuploc">{e(t('search.pickup_location', loc))}</label>
        <select id="b-pickuploc" name="pickup_location_id">{locations_html}</select>
      </div>''' if locations_html else ''}
      {f'<fieldset class="field"><legend>{e(t("price.services", loc))}</legend>{services_html}</fieldset>' if services_html else ''}
      <div class="field">
        <label for="b-promo">Code promo</label>
        <input id="b-promo" type="text" name="promo_code" placeholder="Optionnel" autocomplete="off">
      </div>
      <div class="quote" data-quote aria-live="polite">
        <div class="skeleton skeleton__line"></div>
        <div class="skeleton skeleton__line skeleton__line--short"></div>
      </div>
      <p class="booker__error" data-quote-error role="alert" hidden></p>
      <button class="btn btn--primary btn--lg btn--full" type="submit" data-book>
        {e(t('vehicle.book', loc))}
      </button>
      <p class="booker__note">Vous ne payez rien maintenant. Le paiement se fait selon le moyen
        choisi à l'étape suivante.</p>
    </form>
  </aside>
</div>"""
    return html_response(layout(
        req, title=f'{v["brand"]} {v["model"]} {v["year"]} en location',
        description=(f'Louez une {v["brand"]} {v["model"]} {v["year"]} à '
                     f'{v.get("wilaya") or "en Algérie"} dès {v["daily_price"]} DA/jour. '
                     f'Disponibilité en temps réel, caution et options affichées.'),
        canonical=f'/vehicules/{v["slug"]}',
        og_image=f'{Config.APP_URL}/media/{v["images"][0]["path"]}' if v["images"] else "",
        body=body, json_ld=json_ld, page_class="page-vehicle", scripts=("vehicle.js",)))


@get("/location/<wilaya_slug>")
def location_page(req: Request):
    loc = req.locale
    w = db.one("SELECT * FROM wilayas WHERE slug = ? AND active = 1", (req.params["wilaya_slug"],))
    if not w:
        return html_response(render_not_found(req), 404)
    result = V.search(wilaya=w["slug"], limit=12)
    name = w[f"name_{loc}"] if f"name_{loc}" in w.keys() else w["name_fr"]
    cards = "".join(vehicle_card(v, loc) for v in result["items"]) or empty_state(
        "🚘", f"Aucun véhicule à {name} pour le moment",
        "De nouveaux loueurs rejoignent RENTDZ chaque semaine.",
        ("Voir tous les véhicules", "/vehicules"))
    offices = db.query("""SELECT name_fr, kind, address FROM locations
                           WHERE wilaya_id = ? AND active = 1 ORDER BY kind, name_fr""", (w["id"],))
    office_html = "".join(
        f'<li><strong>{e(o["name_fr"])}</strong> <span class="muted">'
        f'{"Aéroport" if o["kind"] == "airport" else "Agence"}'
        f'{(" · " + o["address"]) if o["address"] else ""}</span></li>' for o in offices)
    json_ld = {"@context": "https://schema.org", "@type": "CollectionPage",
               "name": f"Location de voiture à {name}",
               "url": f'{Config.APP_URL}/location/{w["slug"]}',
               "about": {"@type": "Place", "name": name,
                         "address": {"@type": "PostalAddress", "addressCountry": "DZ",
                                     "addressRegion": w["name_fr"]}}}
    body = f"""
<div class="container">{breadcrumbs([("Accueil", "/"), ("Destinations", "/destinations"), (name, f'/location/{w["slug"]}')])}</div>
<section class="pagehead">
  <div class="container">
    <h1>Location de voiture à {e(name)}</h1>
    <p class="pagehead__sub">{e(result['total'])} véhicule(s) proposé(s) par nos loueurs partenaires
      à {e(name)}. Prix en dinars, disponibilité vérifiée en temps réel.</p>
    {search_form(req, compact=True, values={"wilaya": w["slug"]})}
  </div>
</section>
<section class="section">
  <div class="container">
    <div class="grid grid--cards">{cards}</div>
  </div>
</section>
{f'''<section class="section section--alt"><div class="container container--narrow">
  <h2>Points de retrait à {e(name)}</h2><ul class="list">{office_html}</ul></div></section>''' if office_html else ''}"""
    return html_response(layout(req, title=f"Location de voiture à {name}",
                                description=f"Louez une voiture à {name} en Algérie. "
                                            f"{result['total']} véhicules disponibles, prix transparents en DA.",
                                canonical=f'/location/{w["slug"]}', body=body,
                                json_ld=json_ld, page_class="page-location",
                                scripts=("search.js",)))


@get("/destinations")
def destinations(req: Request):
    loc = req.locale
    rows = db.query("""SELECT w.slug, w.name_fr, w.name_ar, w.name_en,
                              (SELECT COUNT(*) FROM vehicles v JOIN locations l ON l.id=v.primary_location_id
                                WHERE l.wilaya_id=w.id AND v.deleted_at IS NULL
                                  AND v.approval_status='approved') AS vehicles,
                              (SELECT COALESCE(MIN(v.daily_price),0) FROM vehicles v
                                JOIN locations l ON l.id=v.primary_location_id
                               WHERE l.wilaya_id=w.id AND v.deleted_at IS NULL
                                 AND v.approval_status='approved') AS from_price
                         FROM wilayas w WHERE w.active=1 ORDER BY vehicles DESC, w.name_fr""")
    cards = "".join(f"""
      <a class="destcard" href="/location/{attr(r['slug'])}">
        <h2>{e(r[f'name_{loc}'] if f'name_{loc}' in r.keys() else r['name_fr'])}</h2>
        <p>{e(r['vehicles'])} véhicule(s)</p>
        {f'<p class="destcard__price">dès {e(money(r["from_price"], loc))}/jour</p>' if r['from_price'] else '<p class="muted">Bientôt disponible</p>'}
      </a>""" for r in rows)
    body = f"""
<section class="pagehead"><div class="container">
  <h1>Où louer une voiture en Algérie</h1>
  <p class="pagehead__sub">Nos loueurs partenaires couvrent les principales wilayas du pays.</p>
</div></section>
<section class="section"><div class="container"><div class="grid grid--destcards">{cards}</div></div></section>"""
    return html_response(layout(req, title="Destinations en Algérie",
                                description="Toutes les wilayas où louer une voiture avec RENTDZ.",
                                canonical="/destinations", body=body, page_class="page-destinations"))


@get("/comment-ca-marche")
def how_it_works(req: Request):
    body = """
<section class="pagehead"><div class="container">
  <h1>Comment ça marche</h1>
  <p class="pagehead__sub">De la recherche à la remise des clés, en quatre étapes.</p>
</div></section>
<section class="section"><div class="container container--narrow">
  <ol class="steps steps--vertical">
    <li><span class="steps__num">1</span><h3>Recherchez</h3>
      <p>Choisissez la ville, les dates et les heures. Le moteur écarte automatiquement tout véhicule
         déjà réservé, en maintenance ou bloqué par le loueur sur la période demandée.</p></li>
    <li><span class="steps__num">2</span><h3>Comparez</h3>
      <p>Filtrez par catégorie, boîte de vitesses, carburant, nombre de places, budget et équipements.
         Chaque fiche affiche le prix par jour, la caution et la politique kilométrique.</p></li>
    <li><span class="steps__num">3</span><h3>Réservez</h3>
      <p>Renseignez vos informations et votre permis, choisissez vos options, vérifiez le détail du
         prix calculé par nos serveurs, puis validez. Votre créneau est immédiatement bloqué.</p></li>
    <li><span class="steps__num">4</span><h3>Récupérez le véhicule</h3>
      <p>Le loueur confirme la réservation après vérification de votre permis. Vous recevez votre
         numéro de réservation et votre contrat de location.</p></li>
  </ol>
  <div class="card">
    <h2>Annulation</h2>
    <p class="prose">Annulation gratuite jusqu'à 48 h avant le départ, remboursement de 50 % entre
      48 h et 24 h, aucun remboursement au-delà. Le montant exact vous est affiché avant de confirmer
      l'annulation.</p>
  </div>
</div></section>"""
    return html_response(layout(req, title="Comment ça marche", body=body,
                                canonical="/comment-ca-marche",
                                description="Le fonctionnement de la location de voiture sur RENTDZ.",
                                page_class="page-static"))


@get("/aide")
def help_page(req: Request):
    body = """
<section class="pagehead"><div class="container">
  <h1>Centre d'aide</h1>
  <p class="pagehead__sub">Les réponses aux questions les plus fréquentes.</p>
</div></section>
<section class="section"><div class="container container--narrow">
  <div class="faq">
    <details class="faq__item" open><summary>Comment créer un compte ?</summary>
      <p>Cliquez sur « Créer un compte », renseignez votre nom, votre e-mail et un mot de passe de
         10 caractères minimum contenant lettres et chiffres.</p></details>
    <details class="faq__item"><summary>Mon permis est-il visible par d'autres clients ?</summary>
      <p>Non. Vos documents sont stockés en dehors de l'espace web public, accessibles uniquement
         par vous, l'agence concernée et notre équipe de vérification, via des liens temporaires.
         Chaque consultation est enregistrée.</p></details>
    <details class="faq__item"><summary>Puis-je modifier une réservation ?</summary>
      <p>Contactez l'agence via votre espace client. Selon la disponibilité, elle peut annuler et
         recréer la réservation aux nouvelles dates.</p></details>
    <details class="faq__item"><summary>Quand suis-je débité ?</summary>
      <p>Jamais sans action de votre part. Les paiements en ligne ne sont actifs que si le loueur a
         activé un fournisseur de paiement ; sinon vous réglez à l'agence.</p></details>
    <details class="faq__item"><summary>J'ai un litige sur des frais</summary>
      <p>Ouvrez un ticket depuis votre espace client, catégorie « Problème de paiement » ou
         « Réclamation ». Notre équipe support intervient.</p></details>
  </div>
  <div class="card">
    <h2>Nous contacter</h2>
    <p class="prose">Connectez-vous puis ouvrez un ticket depuis votre espace client pour un suivi
      complet de votre demande.</p>
    <a class="btn btn--primary" href="/mon-espace/support">Ouvrir un ticket</a>
  </div>
</div></section>"""
    return html_response(layout(req, title="Centre d'aide", body=body, canonical="/aide",
                                description="Aide et questions fréquentes RENTDZ.",
                                page_class="page-static"))


@get("/devenir-loueur")
def become_vendor(req: Request):
    body = """
<section class="pagehead pagehead--dark"><div class="container">
  <h1>Développez votre activité de location</h1>
  <p class="pagehead__sub">Publiez votre flotte sur RENTDZ, recevez des réservations et gérez
    votre calendrier depuis un seul espace.</p>
  <a class="btn btn--primary btn--lg" href="/inscription?type=loueur">Créer mon compte loueur</a>
</div></section>
<section class="section"><div class="container">
  <div class="grid grid--why">
    <div class="why"><h3>Calendrier unique</h3><p>Réservations, maintenance et dates bloquées sur une seule vue. Aucun conflit possible.</p></div>
    <div class="why"><h3>Vous gardez le contrôle</h3><p>Vous validez chaque réservation, définissez vos tarifs, votre caution et vos options.</p></div>
    <div class="why"><h3>Clients vérifiés</h3><p>Permis de conduire contrôlés avant la remise des clés.</p></div>
    <div class="why"><h3>Revenus suivis</h3><p>Chiffre d'affaires, taux d'utilisation et commission plateforme, en temps réel.</p></div>
  </div>
</div></section>
<section class="section section--alt"><div class="container container--narrow">
  <h2>Comment démarrer</h2>
  <ol class="steps steps--vertical">
    <li><span class="steps__num">1</span><h3>Créez votre compte loueur</h3><p>Renseignez votre société : RC, NIF, wilaya et coordonnées.</p></li>
    <li><span class="steps__num">2</span><h3>Validation par notre équipe</h3><p>Nous vérifions les informations légales avant publication.</p></li>
    <li><span class="steps__num">3</span><h3>Ajoutez vos véhicules</h3><p>Photos, tarifs, caution, disponibilité, options.</p></li>
    <li><span class="steps__num">4</span><h3>Recevez vos réservations</h3><p>Vous confirmez, encaissez et suivez vos départs et retours du jour.</p></li>
  </ol>
</div></section>"""
    return html_response(layout(req, title="Devenir loueur partenaire", body=body,
                                canonical="/devenir-loueur",
                                description="Inscrivez votre agence de location de voitures sur RENTDZ.",
                                page_class="page-static"))


# ── auth pages ───────────────────────────────────────────────────────────────
def _auth_page(req, *, title: str, heading: str, sub: str, form: str, footer: str = "") -> str:
    body = f"""
<section class="authwrap">
  <div class="authcard">
    <a class="brand brand--auth" href="/"><span class="brand__text">RENT<span class="brand__dz">DZ</span></span></a>
    <h1>{e(heading)}</h1>
    <p class="authcard__sub">{e(sub)}</p>
    {form}
    {footer}
  </div>
  <aside class="authaside" aria-hidden="true">
    <div class="authaside__inner">
      <p class="authaside__quote">« Des voitures fiables. Des prix transparents. Une réservation simple. »</p>
      <p class="authaside__meta">RENTDZ · Location de véhicules en Algérie</p>
    </div>
  </aside>
</section>"""
    return layout(req, title=title, body=body, page_class="page-auth", scripts=("auth.js",),
                  description=sub)


@get("/connexion")
def login_page(req: Request):
    if req.user:
        return redirect("/mon-espace")
    form = """
<form class="form" data-loginform novalidate>
  <div class="field">
    <label for="email">Adresse e-mail</label>
    <input id="email" name="email" type="email" autocomplete="email" required>
    <p class="field__error" data-error-for="email" hidden></p>
  </div>
  <div class="field">
    <label for="password">Mot de passe</label>
    <input id="password" name="password" type="password" autocomplete="current-password" required>
    <p class="field__error" data-error-for="password" hidden></p>
  </div>
  <p class="form__error" data-formerror role="alert" hidden></p>
  <button class="btn btn--primary btn--full btn--lg" type="submit">Se connecter</button>
</form>"""
    footer = """
<div class="authcard__foot">
  <a class="link" href="/mot-de-passe-oublie">Mot de passe oublié ?</a>
  <span>Pas encore de compte ? <a class="link" href="/inscription">Créer un compte</a></span>
</div>"""
    return html_response(_auth_page(req, title="Connexion", heading="Content de vous revoir",
                                    sub="Connectez-vous pour gérer vos réservations.",
                                    form=form, footer=footer))


@get("/inscription")
def register_page(req: Request):
    if req.user:
        return redirect("/mon-espace")
    is_vendor = req.q("type") == "loueur"
    form = f"""
<form class="form" data-registerform novalidate>
  <input type="hidden" name="account_type" value="{'fleet_owner' if is_vendor else 'customer'}">
  <div class="switchrow" role="tablist" aria-label="Type de compte">
    <a class="switchrow__opt{'' if is_vendor else ' is-active'}" href="/inscription" role="tab"
       aria-selected="{'false' if is_vendor else 'true'}">Je loue une voiture</a>
    <a class="switchrow__opt{' is-active' if is_vendor else ''}" href="/inscription?type=loueur" role="tab"
       aria-selected="{'true' if is_vendor else 'false'}">Je propose des véhicules</a>
  </div>
  <div class="field">
    <label for="full_name">Nom complet</label>
    <input id="full_name" name="full_name" type="text" autocomplete="name" required minlength="3">
    <p class="field__error" data-error-for="full_name" hidden></p>
  </div>
  <div class="field">
    <label for="email">Adresse e-mail</label>
    <input id="email" name="email" type="email" autocomplete="email" required>
    <p class="field__error" data-error-for="email" hidden></p>
  </div>
  <div class="field">
    <label for="phone">Téléphone</label>
    <input id="phone" name="phone" type="tel" inputmode="tel" placeholder="0555 12 34 56"
           autocomplete="tel">
    <p class="field__hint">Numéro algérien : 0555 12 34 56 ou +213 555 12 34 56</p>
    <p class="field__error" data-error-for="phone" hidden></p>
  </div>
  <div class="field">
    <label for="password">Mot de passe</label>
    <input id="password" name="password" type="password" autocomplete="new-password" required
           minlength="10">
    <p class="field__hint">10 caractères minimum, avec au moins une lettre et un chiffre.</p>
    <p class="field__error" data-error-for="password" hidden></p>
  </div>
  <p class="form__error" data-formerror role="alert" hidden></p>
  <button class="btn btn--primary btn--full btn--lg" type="submit">Créer mon compte</button>
  <p class="form__legal">En créant un compte, vous acceptez nos
    <a href="/legal/conditions">conditions générales</a> et notre
    <a href="/legal/confidentialite">politique de confidentialité</a>.</p>
</form>"""
    footer = '<div class="authcard__foot"><span>Déjà inscrit ? <a class="link" href="/connexion">Se connecter</a></span></div>'
    return html_response(_auth_page(
        req, title="Créer un compte",
        heading="Rejoignez RENTDZ" if not is_vendor else "Inscrivez votre agence",
        sub=("Réservez en quelques minutes et suivez vos locations." if not is_vendor
             else "Publiez votre flotte et recevez des réservations."),
        form=form, footer=footer))


@get("/mot-de-passe-oublie")
def forgot_page(req: Request):
    form = """
<form class="form" data-forgotform novalidate>
  <div class="field">
    <label for="email">Adresse e-mail</label>
    <input id="email" name="email" type="email" autocomplete="email" required>
  </div>
  <p class="form__ok" data-formok role="status" hidden></p>
  <p class="form__error" data-formerror role="alert" hidden></p>
  <button class="btn btn--primary btn--full btn--lg" type="submit">Envoyer le lien</button>
</form>"""
    footer = '<div class="authcard__foot"><a class="link" href="/connexion">Retour à la connexion</a></div>'
    return html_response(_auth_page(req, title="Mot de passe oublié",
                                    heading="Réinitialiser votre mot de passe",
                                    sub="Nous vous envoyons un lien valable 2 heures.",
                                    form=form, footer=footer))


@get("/nouveau-mot-de-passe")
def reset_page(req: Request):
    token = req.q("token", "")
    form = f"""
<form class="form" data-resetform novalidate>
  <input type="hidden" name="token" value="{attr(token)}">
  <div class="field">
    <label for="password">Nouveau mot de passe</label>
    <input id="password" name="password" type="password" autocomplete="new-password" required minlength="10">
    <p class="field__hint">10 caractères minimum, lettres et chiffres.</p>
    <p class="field__error" data-error-for="password" hidden></p>
  </div>
  <p class="form__ok" data-formok role="status" hidden></p>
  <p class="form__error" data-formerror role="alert" hidden></p>
  <button class="btn btn--primary btn--full btn--lg" type="submit">Définir le mot de passe</button>
</form>"""
    return html_response(_auth_page(req, title="Nouveau mot de passe",
                                    heading="Choisissez un nouveau mot de passe",
                                    sub="Toutes vos autres sessions seront déconnectées.",
                                    form=form))


@get("/verifier-email")
def verify_email_page(req: Request):
    token = req.q("token", "")
    body = f"""
<section class="authwrap authwrap--single">
  <div class="authcard" data-verify data-token="{attr(token)}">
    <h1>Confirmation de votre e-mail</h1>
    <p class="authcard__sub" data-verify-msg>Vérification en cours…</p>
    <a class="btn btn--primary" href="/mon-espace">Aller à mon espace</a>
  </div>
</section>"""
    return html_response(layout(req, title="Confirmation e-mail", body=body,
                                page_class="page-auth", scripts=("auth.js",)))


# ── app shells (hydrated by the API) ────────────────────────────────────────
def _shell(req, *, title: str, nav: list, active: str, heading: str, script: str,
           sub: str = "", page_class: str = "page-app") -> str:
    links = "".join(
        f'<a class="sidenav__link{" is-active" if key == active else ""}" href="{attr(href)}">'
        f'<span aria-hidden="true">{icon}</span>{e(lbl)}</a>'
        for key, href, lbl, icon in nav)
    body = f"""
<div class="appwrap">
  <aside class="sidenav" aria-label="Navigation de l'espace">
    <nav class="sidenav__inner">{links}</nav>
  </aside>
  <section class="appmain">
    <header class="appmain__head">
      <div>
        <h1>{e(heading)}</h1>
        {f'<p class="appmain__sub">{e(sub)}</p>' if sub else ''}
      </div>
      <div data-head-actions></div>
    </header>
    <div class="appmain__body" data-app aria-live="polite">
      {skeleton(3)}
    </div>
  </section>
</div>"""
    return layout(req, title=title, body=body, page_class=page_class, scripts=(script,))


CUSTOMER_NAV = [
    ("dashboard", "/mon-espace", "Tableau de bord", "▦"),
    ("bookings", "/mon-espace/reservations", "Mes réservations", "🗓"),
    ("documents", "/mon-espace/documents", "Mes documents", "📄"),
    ("favourites", "/mon-espace/favoris", "Véhicules sauvegardés", "♥"),
    ("payments", "/mon-espace/paiements", "Paiements", "₪"),
    ("notifications", "/mon-espace/notifications", "Notifications", "🔔"),
    ("support", "/mon-espace/support", "Support", "💬"),
    ("profile", "/mon-espace/profil", "Mon profil", "👤"),
]
FLEET_NAV = [
    ("dashboard", "/loueur", "Tableau de bord", "▦"),
    ("vehicles", "/loueur/vehicules", "Mes véhicules", "🚗"),
    ("calendar", "/loueur/calendrier", "Calendrier", "🗓"),
    ("bookings", "/loueur/reservations", "Réservations", "📋"),
    ("today", "/loueur/aujourdhui", "Départs & retours", "🔑"),
    ("analytics", "/loueur/revenus", "Revenus", "📈"),
    ("company", "/loueur/societe", "Ma société", "🏢"),
]
ADMIN_NAV = [
    ("dashboard", "/admin", "Tableau de bord", "▦"),
    ("bookings", "/admin/reservations", "Réservations", "📋"),
    ("vehicles", "/admin/vehicules", "Véhicules", "🚗"),
    ("companies", "/admin/loueurs", "Loueurs", "🏢"),
    ("users", "/admin/utilisateurs", "Utilisateurs", "👥"),
    ("documents", "/admin/documents", "Documents", "📄"),
    ("payments", "/admin/paiements", "Paiements", "₪"),
    ("reviews", "/admin/avis", "Avis", "★"),
    ("promos", "/admin/promos", "Codes promo", "🎟"),
    ("audit", "/admin/audit", "Journal d'audit", "🛡"),
    ("settings", "/admin/parametres", "Paramètres", "⚙"),
]


def _require_page_user(req):
    if not req.user:
        return redirect(f"/connexion?next={req.path}")
    return None


for key, path, heading, sub in [
        ("dashboard", "/mon-espace", "Mon espace", "Vos locations et documents en un coup d'œil."),
        ("bookings", "/mon-espace/reservations", "Mes réservations", ""),
        ("documents", "/mon-espace/documents", "Mes documents", "Permis et pièces justificatives."),
        ("favourites", "/mon-espace/favoris", "Véhicules sauvegardés", ""),
        ("payments", "/mon-espace/paiements", "Mes paiements", ""),
        ("notifications", "/mon-espace/notifications", "Notifications", ""),
        ("support", "/mon-espace/support", "Support", "Posez vos questions à notre équipe."),
        ("profile", "/mon-espace/profil", "Mon profil", "")]:
    def _make(key=key, heading=heading, sub=sub):
        def view(req: Request):
            guard = _require_page_user(req)
            if guard:
                return guard
            return html_response(_shell(req, title=heading, nav=CUSTOMER_NAV, active=key,
                                        heading=heading, sub=sub, script="dashboard.js"))
        return view
    get(path)(_make())


for key, path, heading, sub in [
        ("dashboard", "/loueur", "Espace loueur", "Votre flotte et vos réservations."),
        ("vehicles", "/loueur/vehicules", "Mes véhicules", ""),
        ("calendar", "/loueur/calendrier", "Calendrier de flotte", "Réservations, maintenance et dates bloquées."),
        ("bookings", "/loueur/reservations", "Réservations", ""),
        ("today", "/loueur/aujourdhui", "Départs et retours du jour", ""),
        ("analytics", "/loueur/revenus", "Revenus", ""),
        ("company", "/loueur/societe", "Ma société", "")]:
    def _make_fleet(key=key, heading=heading, sub=sub):
        def view(req: Request):
            guard = _require_page_user(req)
            if guard:
                return guard
            return html_response(_shell(req, title=heading, nav=FLEET_NAV, active=key,
                                        heading=heading, sub=sub, script="fleet.js",
                                        page_class="page-app page-fleet"))
        return view
    get(path)(_make_fleet())


for key, path, heading, sub in [
        ("dashboard", "/admin", "Administration", "Vue d'ensemble de la plateforme."),
        ("bookings", "/admin/reservations", "Réservations", ""),
        ("vehicles", "/admin/vehicules", "Véhicules", "Validation et supervision du catalogue."),
        ("companies", "/admin/loueurs", "Loueurs", "Validation des sociétés de location."),
        ("users", "/admin/utilisateurs", "Utilisateurs", ""),
        ("documents", "/admin/documents", "Documents", "File d'attente de vérification."),
        ("payments", "/admin/paiements", "Paiements", ""),
        ("reviews", "/admin/avis", "Avis clients", ""),
        ("promos", "/admin/promos", "Codes promo", ""),
        ("audit", "/admin/audit", "Journal d'audit", ""),
        ("settings", "/admin/parametres", "Paramètres", "Règles métier, finances et intégrations.")]:
    def _make_admin(key=key, heading=heading, sub=sub):
        def view(req: Request):
            guard = _require_page_user(req)
            if guard:
                return guard
            if not ({"admin", "super_admin", "support_agent", "finance_manager"} & set(req.user["roles"])):
                return html_response(render_error_page(req, 403,
                                                       "Cette section est réservée à l'administration."), 403)
            return html_response(_shell(req, title=heading, nav=ADMIN_NAV, active=key,
                                        heading=heading, sub=sub, script="admin.js",
                                        page_class="page-app page-admin"))
        return view
    get(path)(_make_admin())


@get("/reservation/<booking_id>")
def booking_page(req: Request):
    guard = _require_page_user(req)
    if guard:
        return guard
    body = f"""
<div class="container container--narrow bookingview" data-booking="{attr(req.params['booking_id'])}">
  {skeleton(4, 'line')}
</div>"""
    return html_response(layout(req, title="Ma réservation", body=body,
                                page_class="page-booking", scripts=("booking.js",)))


@get("/reserver/<slug>")
def checkout_page(req: Request):
    guard = _require_page_user(req)
    if guard:
        return guard
    v = V.get_public(req.params["slug"])
    if not v:
        return html_response(render_not_found(req), 404)
    loc = req.locale
    steps = ["booking.step_dates", "booking.step_customer", "booking.step_driver",
             "booking.step_services", "booking.step_summary", "booking.step_payment"]
    step_html = "".join(
        f'<li class="wizard__step{" is-active" if i == 0 else ""}" data-step="{i}">'
        f'<span class="wizard__num">{i+1}</span><span>{e(t(s, loc))}</span></li>'
        for i, s in enumerate(steps))
    body = f"""
<div class="container checkout" data-checkout="{v['id']}"
     data-vehicle-slug="{attr(v['slug'])}"
     data-pickup="{attr(req.q('pickup_at') or '')}" data-return="{attr(req.q('return_at') or '')}">
  <ol class="wizard">{step_html}</ol>
  <div class="checkout__grid">
    <div class="checkout__main" data-checkout-body>{skeleton(3, 'line')}</div>
    <aside class="checkout__side">
      <div class="card card--sticky">
        <h2>{e(v['brand'])} {e(v['model'])}</h2>
        <p class="muted">{e(v.get('wilaya') or '')} · {e(v['company_name'])}</p>
        <div data-checkout-summary>{skeleton(3, 'line')}</div>
      </div>
    </aside>
  </div>
</div>"""
    return html_response(layout(req, title=f"Réserver {v['brand']} {v['model']}", body=body,
                                page_class="page-checkout", scripts=("checkout.js",)))


@get("/legal/conditions")
def terms(req: Request):
    body = """
<section class="pagehead"><div class="container"><h1>Conditions générales d'utilisation</h1>
<p class="pagehead__sub">Version de démonstration — à faire valider par votre conseil juridique avant mise en production.</p></div></section>
<section class="section"><div class="container container--narrow prose prose--legal">
<h2>1. Objet</h2><p>RENTDZ est une plateforme de mise en relation entre des sociétés de location de véhicules établies en Algérie et des clients souhaitant louer un véhicule. RENTDZ n'est pas propriétaire des véhicules proposés.</p>
<h2>2. Compte client</h2><p>Le client est responsable de l'exactitude des informations fournies et de la confidentialité de ses identifiants. Tout compte présentant des activités frauduleuses peut être suspendu.</p>
<h2>3. Réservation</h2><p>Une réservation n'est ferme qu'après confirmation par la société de location. Le prix affiché avant validation est calculé par la plateforme et détaillé poste par poste.</p>
<h2>4. Documents</h2><p>Le client s'engage à fournir un permis de conduire valide. Les documents sont conservés de manière privée pour la durée légale nécessaire puis supprimés.</p>
<h2>5. Annulation</h2><p>Les conditions d'annulation et de remboursement applicables sont affichées avant confirmation et rappelées dans l'espace client.</p>
<h2>6. Responsabilité</h2><p>Le contrat de location est conclu entre le client et la société de location. Les obligations relatives au véhicule, à l'assurance et aux dommages relèvent de ce contrat.</p>
<h2>7. Droit applicable</h2><p>Les présentes conditions sont soumises au droit algérien.</p>
</div></section>"""
    return html_response(layout(req, title="Conditions générales", body=body,
                                canonical="/legal/conditions", page_class="page-static"))


@get("/legal/confidentialite")
def privacy(req: Request):
    body = """
<section class="pagehead"><div class="container"><h1>Politique de confidentialité</h1>
<p class="pagehead__sub">Version de démonstration — à faire valider avant mise en production.</p></div></section>
<section class="section"><div class="container container--narrow prose prose--legal">
<h2>Données collectées</h2><p>Identité, coordonnées, informations de permis de conduire, historique de réservations et de paiements, journaux techniques de connexion.</p>
<h2>Finalités</h2><p>Gestion des réservations, vérification d'éligibilité à la conduite, facturation, prévention de la fraude, support client et obligations légales.</p>
<h2>Documents sensibles</h2><p>Les documents téléversés sont stockés hors de l'espace public, accessibles uniquement via des liens temporaires signés, par le titulaire du compte, la société de location concernée et les équipes habilitées. Chaque accès est journalisé.</p>
<h2>Durée de conservation</h2><p>Les documents sont supprimés automatiquement à l'issue de la durée de conservation paramétrée par l'administrateur.</p>
<h2>Vos droits</h2><p>Vous pouvez demander l'accès, la rectification ou la suppression de vos données via un ticket de support.</p>
<h2>Paiements</h2><p>Aucun numéro de carte ni cryptogramme n'est stocké par RENTDZ. Les paiements en ligne sont traités par les prestataires agréés.</p>
</div></section>"""
    return html_response(layout(req, title="Politique de confidentialité", body=body,
                                canonical="/legal/confidentialite", page_class="page-static"))


@get("/robots.txt")
def robots(req: Request):
    from ..http import Response
    txt = (f"User-agent: *\nAllow: /\n"
           "Disallow: /mon-espace\nDisallow: /loueur\nDisallow: /admin\n"
           "Disallow: /api/\nDisallow: /reserver\nDisallow: /reservation\n"
           f"Sitemap: {Config.APP_URL}/sitemap.xml\n")
    return Response(200, txt.encode(), {"Content-Type": "text/plain; charset=utf-8"})


@get("/sitemap.xml")
def sitemap(req: Request):
    from ..http import Response
    urls = ["/", "/vehicules", "/destinations", "/comment-ca-marche", "/aide",
            "/devenir-loueur", "/legal/conditions", "/legal/confidentialite"]
    urls += [f'/location/{r["slug"]}' for r in db.query("SELECT slug FROM wilayas WHERE active=1")]
    urls += [f'/vehicules/{r["slug"]}' for r in db.query(
        """SELECT slug FROM vehicles WHERE deleted_at IS NULL AND approval_status='approved'
            ORDER BY updated_at DESC LIMIT 2000""")]
    items = "".join(f"<url><loc>{Config.APP_URL}{u}</loc></url>" for u in urls)
    xml = ('<?xml version="1.0" encoding="UTF-8"?>'
           '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + items + "</urlset>")
    return Response(200, xml.encode(), {"Content-Type": "application/xml; charset=utf-8"})


def render_not_found(req) -> str:
    body = f"""
<section class="errorpage">
  <div class="container container--narrow">
    <p class="errorpage__code">404</p>
    <h1>{e(t('error.not_found', req.locale))}</h1>
    <p class="errorpage__text">La page demandée n'existe pas ou a été déplacée.</p>
    <div class="errorpage__actions">
      <a class="btn btn--primary" href="/">Retour à l'accueil</a>
      <a class="btn btn--ghost" href="/vehicules">Voir les véhicules</a>
    </div>
  </div>
</section>"""
    return layout(req, title="Page introuvable", body=body, page_class="page-error")


def render_error_page(req, status: int, message: str) -> str:
    body = f"""
<section class="errorpage">
  <div class="container container--narrow">
    <p class="errorpage__code">{status}</p>
    <h1>{e(message)}</h1>
    <div class="errorpage__actions">
      <a class="btn btn--primary" href="/">Retour à l'accueil</a>
      {'<a class="btn btn--ghost" href="/connexion">Se connecter</a>' if status == 401 else ''}
    </div>
  </div>
</section>"""
    return layout(req, title=f"Erreur {status}", body=body, page_class="page-error")
