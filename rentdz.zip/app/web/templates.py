"""Server-rendered shell: semantic HTML, real meta/OG/JSON-LD, LTR+RTL aware."""
from __future__ import annotations
import html, json
from ..config import Config
from ..i18n import t, is_rtl, direction, money, human_date, label, CATEGORY_LABELS, STATUS_LABELS
from ..services import settings_service as S


def e(value) -> str:
    """Escape everything that reaches the DOM. Never interpolate raw user text."""
    return html.escape("" if value is None else str(value), quote=True)


def attr(value) -> str:
    return e(value).replace("\n", " ")


def safe_json(obj) -> str:
    """
    JSON destined for a <script> block. json.dumps alone is NOT safe here:
    a payload containing </script> would break out of the element. Escaping
    <, > and & as unicode sequences keeps the JSON valid and inert.
    """
    return (json.dumps(obj, ensure_ascii=False, default=str)
            .replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("&", "\\u0026").replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029"))


NAV = [("/vehicules", "nav.vehicles"), ("/destinations", "nav.destinations"),
       ("/comment-ca-marche", "nav.how"), ("/aide", "nav.help")]


def layout(req, *, title: str, body: str, description: str = "", canonical: str = "",
           og_image: str = "", json_ld: dict | None = None, page_class: str = "",
           scripts: tuple = (), preload_state: dict | None = None) -> str:
    loc = req.locale
    rtl = is_rtl(loc)
    brand = S.get("company_name") or "RENTDZ"
    desc = description or t("hero.subtitle", loc)
    user = req.user
    unread = 0
    if user:
        from ..services.notification_service import unread_count
        unread = unread_count(user["id"])

    nav_links = "".join(
        f'<a class="nav__link" href="{href}">{e(t(key, loc))}</a>' for href, key in NAV)

    if user:
        menu_items = [f'<a href="/mon-espace">{e(t("nav.dashboard", loc))}</a>',
                      f'<a href="/mon-espace/reservations">{e(t("nav.bookings", loc))}</a>']
        if user["company_ids"]:
            menu_items.append(f'<a href="/loueur">{e(t("nav.fleet", loc))}</a>')
        if {"admin", "super_admin", "support_agent", "finance_manager"} & set(user["roles"]):
            menu_items.append(f'<a href="/admin">{e(t("nav.admin", loc))}</a>')
        account = f"""
        <div class="usermenu" data-usermenu>
          <button class="usermenu__btn" type="button" aria-haspopup="true" aria-expanded="false"
                  aria-label="Menu du compte">
            <span class="avatar" aria-hidden="true">{e((user['full_name'] or '?')[:1].upper())}</span>
            <span class="usermenu__name">{e(user['full_name'].split(' ')[0])}</span>
            {'<span class="badge badge--dot" aria-label="notifications non lues">' + str(unread) + '</span>' if unread else ''}
          </button>
          <div class="usermenu__panel" role="menu">
            {''.join(menu_items)}
            <a href="/mon-espace/notifications">Notifications{f' ({unread})' if unread else ''}</a>
            <button type="button" data-logout class="usermenu__logout">{e(t('nav.logout', loc))}</button>
          </div>
        </div>"""
    else:
        account = f"""
        <a class="btn btn--ghost btn--sm" href="/connexion">{e(t('nav.login', loc))}</a>
        <a class="btn btn--primary btn--sm" href="/inscription">{e(t('nav.register', loc))}</a>"""

    lang_switch = "".join(
        f'<a class="langswitch__item{" is-active" if l == loc else ""}" href="?lang={l}" '
        f'hreflang="{l}" rel="alternate">{l.upper()}</a>'
        for l in (S.get("enabled_locales") or ["fr", "ar", "en"]))

    ld = ""
    if json_ld:
        ld = f'<script type="application/ld+json">{safe_json(json_ld)}</script>'

    state = ""
    if preload_state is not None:
        state = ('<script id="preload-state" type="application/json">'
                 + safe_json(preload_state) + "</script>")

    script_tags = "".join(f'<script src="/static/js/{s}" defer></script>' for s in scripts)
    canonical_tag = f'<link rel="canonical" href="{attr(Config.APP_URL + canonical)}">' if canonical else ""

    return f"""<!DOCTYPE html>
<html lang="{loc}" dir="{direction(loc)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(title)} · {e(brand)}</title>
<meta name="description" content="{attr(desc)}">
<meta name="theme-color" content="#0b1220">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{attr(brand)}">
<meta property="og:title" content="{attr(title)}">
<meta property="og:description" content="{attr(desc)}">
<meta property="og:locale" content="{'ar_DZ' if loc == 'ar' else 'fr_DZ' if loc == 'fr' else 'en_US'}">
{f'<meta property="og:image" content="{attr(og_image)}">' if og_image else ''}
<meta name="twitter:card" content="summary_large_image">
{canonical_tag}
<link rel="icon" href="/static/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/static/css/app.css">
{ld}
</head>
<body class="{page_class}{' is-rtl' if rtl else ''}" data-locale="{loc}" data-dir="{direction(loc)}">
<a class="skiplink" href="#main">Aller au contenu principal</a>
<header class="site-header" data-header>
  <div class="container site-header__inner">
    <a class="brand" href="/" aria-label="{attr(brand)} — {attr(S.get('company_tagline'))}">
      <span class="brand__mark" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M3 13.5 5 8.2A2.6 2.6 0 0 1 7.4 6.5h9.2A2.6 2.6 0 0 1 19 8.2l2 5.3v4.3a1 1 0 0 1-1 1h-1.6a1 1 0 0 1-1-1v-.7H6.6v.7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"
                stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
          <circle cx="7.6" cy="14.6" r="1.15" fill="currentColor"/>
          <circle cx="16.4" cy="14.6" r="1.15" fill="currentColor"/>
        </svg>
      </span>
      <span class="brand__text">RENT<span class="brand__dz">DZ</span></span>
    </a>
    <nav class="nav" aria-label="Navigation principale">{nav_links}</nav>
    <div class="site-header__actions">
      <div class="langswitch" role="group" aria-label="Langue">{lang_switch}</div>
      {account}
      <button class="burger" type="button" data-burger aria-label="Ouvrir le menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
  <nav class="mobilenav" data-mobilenav aria-label="Navigation mobile">
    {nav_links}
    {'<a href="/mon-espace">' + e(t('nav.dashboard', loc)) + '</a>' if user else ''}
    {'<a href="/loueur">' + e(t('nav.fleet', loc)) + '</a>' if user and user['company_ids'] else ''}
    {'<button type="button" data-logout>' + e(t('nav.logout', loc)) + '</button>' if user
      else '<a href="/connexion">' + e(t('nav.login', loc)) + '</a><a href="/inscription">' + e(t('nav.register', loc)) + '</a>'}
  </nav>
</header>
<main id="main">{body}</main>
<footer class="site-footer">
  <div class="container site-footer__grid">
    <div>
      <div class="brand brand--footer"><span class="brand__text">RENT<span class="brand__dz">DZ</span></span></div>
      <p class="site-footer__tag">{e(S.get('company_tagline'))}</p>
      <p class="site-footer__muted">Location de véhicules en Algérie · Prix en dinars (DA)</p>
    </div>
    <div>
      <h2 class="site-footer__title">Explorer</h2>
      <a href="/vehicules">Tous les véhicules</a>
      <a href="/destinations">Destinations</a>
      <a href="/comment-ca-marche">Comment ça marche</a>
      <a href="/devenir-loueur">Devenir loueur</a>
    </div>
    <div>
      <h2 class="site-footer__title">Assistance</h2>
      <a href="/aide">Centre d'aide</a>
      <a href="/mon-espace/support">Nous contacter</a>
      <a href="/legal/conditions">Conditions générales</a>
      <a href="/legal/confidentialite">Confidentialité</a>
    </div>
    <div>
      <h2 class="site-footer__title">Contact</h2>
      <a href="mailto:{attr(S.get('support_email'))}">{e(S.get('support_email'))}</a>
      <a href="tel:{attr(S.get('support_phone'))}">{e(S.get('support_phone'))}</a>
      <p class="site-footer__muted">Africa/Algiers · DZD</p>
    </div>
  </div>
  <div class="container site-footer__bottom">
    <span>© 2026 RENTDZ</span>
    <span>{e(Config.APP_ENV)}{' · données de démonstration' if Config.DEMO_MODE else ''}</span>
  </div>
</footer>
{state}
<script src="/static/js/app.js" defer></script>
{script_tags}
</body>
</html>"""


# ── shared partials ──────────────────────────────────────────────────────────
def vehicle_card(v: dict, loc: str = "fr", *, query: str = "") -> str:
    img = (f'<img src="/media/{attr(v["image"])}" alt="{attr(v["brand"])} {attr(v["model"])}" '
           f'loading="lazy" decoding="async" width="400" height="260">' if v.get("image")
           else '<div class="vcard__placeholder" aria-hidden="true">🚗</div>')
    rating = (f'<span class="vcard__rating" aria-label="Note {v["rating_avg"]} sur 5">★ '
              f'{v["rating_avg"]:.1f} <small>({v["rating_count"]})</small></span>'
              if v.get("rating_count") else '<span class="vcard__rating vcard__rating--new">Nouveau</span>')
    est = ""
    if v.get("estimated_total"):
        est = (f'<span class="vcard__est">{e(money(v["estimated_total"], loc))} '
               f'/ {v["estimated_days"]} {e(t("price.days", loc))}</span>')
    return f"""
<article class="vcard">
  <a class="vcard__media" href="/vehicules/{attr(v['slug'])}{query}" tabindex="-1" aria-hidden="true">{img}</a>
  <div class="vcard__body">
    <div class="vcard__top">
      <span class="chip chip--cat">{e(label(CATEGORY_LABELS, v.get('category'), loc))}</span>
      {rating}
    </div>
    <h3 class="vcard__title">
      <a href="/vehicules/{attr(v['slug'])}{query}">{e(v['brand'])} {e(v['model'])}
        <span class="vcard__year">{e(v['year'])}</span></a>
    </h3>
    <ul class="vcard__specs">
      <li>{'Automatique' if v['transmission'] == 'automatic' else 'Manuelle'}</li>
      <li>{e(v['seats'])} places</li>
      <li>{e({'petrol':'Essence','diesel':'Diesel','hybrid':'Hybride','electric':'Électrique','gpl':'GPL'}.get(v['fuel'], v['fuel']))}</li>
    </ul>
    <p class="vcard__meta">{e(v.get('wilaya') or v.get('location_name') or '')} · {e(v.get('company_name'))}</p>
    <div class="vcard__foot">
      <div class="vcard__price">
        <strong>{e(money(v['daily_price'], loc))}</strong><span>{e(t('vehicle.per_day', loc))}</span>
        {est}
      </div>
      <a class="btn btn--primary btn--sm" href="/vehicules/{attr(v['slug'])}{query}">{e(t('vehicle.details', loc))}</a>
    </div>
  </div>
</article>"""


def empty_state(icon: str, title: str, text: str = "", cta: tuple | None = None) -> str:
    button = f'<a class="btn btn--primary" href="{attr(cta[1])}">{e(cta[0])}</a>' if cta else ""
    return f"""<div class="empty">
      <div class="empty__icon" aria-hidden="true">{icon}</div>
      <h3 class="empty__title">{e(title)}</h3>
      {f'<p class="empty__text">{e(text)}</p>' if text else ''}
      {button}
    </div>"""


def status_pill(status: str, loc: str = "fr") -> str:
    tone = {
        "confirmed": "ok", "active": "ok", "completed": "neutral", "paid": "ok",
        "approved": "ok", "available": "ok",
        "pending": "warn", "awaiting_payment": "warn", "processing": "warn",
        "maintenance": "warn", "partially_paid": "warn", "reserved": "warn",
        "cancelled": "bad", "rejected": "bad", "expired": "bad", "failed": "bad",
        "suspended": "bad", "no_show": "bad", "unavailable": "bad", "inactive": "neutral",
    }.get(status, "neutral")
    return f'<span class="pill pill--{tone}">{e(label(STATUS_LABELS, status, loc))}</span>'


def skeleton(rows: int = 3, kind: str = "card") -> str:
    if kind == "card":
        return '<div class="grid grid--cards">' + "".join(
            '<div class="skeleton skeleton--card"><div class="skeleton__media"></div>'
            '<div class="skeleton__line"></div><div class="skeleton__line skeleton__line--short"></div></div>'
            for _ in range(rows)) + "</div>"
    return "".join('<div class="skeleton skeleton__line"></div>' for _ in range(rows))


def breadcrumbs(items: list[tuple[str, str]]) -> str:
    parts, ld_items = [], []
    for i, (name, href) in enumerate(items):
        last = i == len(items) - 1
        parts.append(f'<li>{e(name)}</li>' if last
                     else f'<li><a href="{attr(href)}">{e(name)}</a></li>')
        ld_items.append({"@type": "ListItem", "position": i + 1, "name": name,
                         "item": Config.APP_URL + href})
    ld = safe_json({"@context": "https://schema.org", "@type": "BreadcrumbList",
                    "itemListElement": ld_items})
    return (f'<nav class="crumbs" aria-label="Fil d\'Ariane"><ol>{"".join(parts)}</ol></nav>'
            f'<script type="application/ld+json">{ld}</script>')
