"""RENTDZ - plateforme de location de voitures en Algérie."""
__version__ = "1.0.0"
