"""
Environment-driven configuration. No secret is ever hardcoded.
Reads .env (KEY=VALUE, # comments) then real environment, which wins.
"""
from __future__ import annotations
import os, secrets, sys
from pathlib import Path

BASE_DIR    = Path(__file__).resolve().parent.parent
STORAGE_DIR = BASE_DIR / "storage"
DOCS_DIR    = STORAGE_DIR / "documents"      # private, never web-served
UPLOAD_DIR  = STORAGE_DIR / "uploads"        # vehicle photos, public-readable
DB_DIR      = STORAGE_DIR / "db"
ENV_PATH    = BASE_DIR / ".env"


def _load_env_file(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        data[k.strip()] = v
    return data


_FILE_ENV = _load_env_file(ENV_PATH)


def env(key: str, default=None, cast=str):
    val = os.environ.get(key, _FILE_ENV.get(key, None))
    if val is None or val == "":
        return default
    if cast is bool:
        return str(val).lower() in ("1", "true", "yes", "on")
    if cast is int:
        try:
            return int(val)
        except ValueError:
            return default
    return val


def env_present(key: str) -> bool:
    v = os.environ.get(key, _FILE_ENV.get(key, ""))
    return bool(v and v.strip() and not v.strip().startswith("__"))


class Config:
    APP_NAME   = env("APP_NAME", "RENTDZ")
    APP_ENV    = env("APP_ENV", "development")           # development | production
    APP_URL    = env("APP_URL", "http://127.0.0.1:8000")
    HOST       = env("HOST", "127.0.0.1")
    PORT       = env("PORT", 8000, int)
    DEBUG      = env("DEBUG", APP_ENV != "production", bool)

    DATABASE_URL = env("DATABASE_URL", f"sqlite:///{DB_DIR / 'rentdz.db'}")

    # Auth
    AUTH_SECRET      = env("AUTH_SECRET")
    SESSION_TTL_HOURS = env("SESSION_TTL_HOURS", 72, int)
    COOKIE_SECURE    = env("COOKIE_SECURE", APP_ENV == "production", bool)
    PASSWORD_MIN_LEN = env("PASSWORD_MIN_LEN", 10, int)
    PBKDF2_ITERATIONS = env("PBKDF2_ITERATIONS", 260000, int)
    MAX_LOGIN_ATTEMPTS = env("MAX_LOGIN_ATTEMPTS", 8, int)
    LOCKOUT_MINUTES  = env("LOCKOUT_MINUTES", 15, int)

    # Locale
    DEFAULT_LOCALE = env("DEFAULT_LOCALE", "fr")
    LOCALES        = ("fr", "ar", "en")
    RTL_LOCALES    = ("ar",)
    CURRENCY       = env("CURRENCY", "DZD")
    TIMEZONE       = env("TIMEZONE", "Africa/Algiers")
    COUNTRY        = "DZ"

    # Uploads
    MAX_UPLOAD_MB       = env("MAX_UPLOAD_MB", 8, int)
    MAX_REQUEST_MB      = env("MAX_REQUEST_MB", 12, int)
    ALLOWED_IMAGE_MIMES = ("image/jpeg", "image/png", "image/webp")
    ALLOWED_DOC_MIMES   = ("image/jpeg", "image/png", "image/webp", "application/pdf")

    # External services -- integration architecture is built, credentials optional.
    EMAIL_PROVIDER   = env("EMAIL_PROVIDER", "log")      # log | smtp | api
    EMAIL_API_KEY    = env("EMAIL_API_KEY")
    EMAIL_FROM       = env("EMAIL_FROM", "no-reply@rentdz.dz")
    EMAIL_FROM_NAME  = env("EMAIL_FROM_NAME", "RENTDZ")
    SMTP_HOST        = env("SMTP_HOST"); SMTP_PORT = env("SMTP_PORT", 587, int)
    SMTP_USER        = env("SMTP_USER"); SMTP_PASSWORD = env("SMTP_PASSWORD")

    SMS_PROVIDER     = env("SMS_PROVIDER", "none")
    SMS_API_KEY      = env("SMS_API_KEY")
    SMS_SENDER       = env("SMS_SENDER", "RENTDZ")
    WHATSAPP_API_KEY = env("WHATSAPP_API_KEY")

    MAPS_PROVIDER    = env("MAPS_PROVIDER", "osm")       # osm | google | mapbox
    MAPS_API_KEY     = env("MAPS_API_KEY")

    PAYMENT_STRIPE_KEY      = env("PAYMENT_STRIPE_KEY")
    PAYMENT_STRIPE_WEBHOOK  = env("PAYMENT_STRIPE_WEBHOOK_SECRET")
    PAYMENT_SATIM_MERCHANT  = env("PAYMENT_SATIM_MERCHANT_ID")   # CIB / Edahabia (SATIM)
    PAYMENT_SATIM_KEY       = env("PAYMENT_SATIM_API_KEY")
    PAYMENT_SATIM_WEBHOOK   = env("PAYMENT_SATIM_WEBHOOK_SECRET")
    PAYMENT_PAYPAL_ID       = env("PAYPAL_CLIENT_ID")
    PAYMENT_PAYPAL_SECRET   = env("PAYPAL_CLIENT_SECRET")

    STORAGE_DRIVER   = env("STORAGE_DRIVER", "local")    # local | s3
    S3_BUCKET        = env("S3_BUCKET"); S3_KEY = env("S3_KEY"); S3_SECRET = env("S3_SECRET")

    DEMO_MODE        = env("DEMO_MODE", APP_ENV != "production", bool)
    RATE_LIMIT_ENABLED = env("RATE_LIMIT_ENABLED", True, bool)

    @classmethod
    def db_path(cls) -> Path:
        url = cls.DATABASE_URL
        if url.startswith("sqlite:///"):
            return Path(url[len("sqlite:///"):])
        raise RuntimeError("Only sqlite:/// URLs are supported by this build.")

    @classmethod
    def secret(cls) -> str:
        """AUTH_SECRET is mandatory in production; dev gets an on-disk dev secret."""
        if cls.AUTH_SECRET:
            return cls.AUTH_SECRET
        if cls.APP_ENV == "production":
            print("FATAL: AUTH_SECRET must be set in production.", file=sys.stderr)
            raise SystemExit(2)
        dev = STORAGE_DIR / ".dev_secret"
        if not dev.exists():
            STORAGE_DIR.mkdir(parents=True, exist_ok=True)
            dev.write_text(secrets.token_hex(32), encoding="utf-8")
        return dev.read_text(encoding="utf-8").strip()

    @classmethod
    def integration_status(cls) -> dict:
        """Powers the admin 'configuration required' screen. Never leaks values."""
        def st(ok: bool):
            return "configured" if ok else "configuration_required"
        return {
            "email":    {"provider": cls.EMAIL_PROVIDER,
                         "status": st(cls.EMAIL_PROVIDER == "smtp" and env_present("SMTP_HOST")
                                      or cls.EMAIL_PROVIDER == "api" and env_present("EMAIL_API_KEY")),
                         "vars": ["EMAIL_PROVIDER", "SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "EMAIL_API_KEY"]},
            "sms":      {"provider": cls.SMS_PROVIDER, "status": st(env_present("SMS_API_KEY")),
                         "vars": ["SMS_PROVIDER", "SMS_API_KEY", "SMS_SENDER"]},
            "whatsapp": {"provider": "meta", "status": st(env_present("WHATSAPP_API_KEY")),
                         "vars": ["WHATSAPP_API_KEY"]},
            "maps":     {"provider": cls.MAPS_PROVIDER,
                         "status": "configured" if cls.MAPS_PROVIDER == "osm" or env_present("MAPS_API_KEY")
                                   else "configuration_required",
                         "vars": ["MAPS_PROVIDER", "MAPS_API_KEY"]},
            "stripe":   {"provider": "stripe", "status": st(env_present("PAYMENT_STRIPE_KEY")),
                         "vars": ["PAYMENT_STRIPE_KEY", "PAYMENT_STRIPE_WEBHOOK_SECRET"]},
            "satim":    {"provider": "SATIM (CIB / Edahabia)", "status": st(env_present("PAYMENT_SATIM_API_KEY")),
                         "vars": ["PAYMENT_SATIM_MERCHANT_ID", "PAYMENT_SATIM_API_KEY", "PAYMENT_SATIM_WEBHOOK_SECRET"]},
            "paypal":   {"provider": "paypal", "status": st(env_present("PAYPAL_CLIENT_ID")),
                         "vars": ["PAYPAL_CLIENT_ID", "PAYPAL_CLIENT_SECRET"]},
            "storage":  {"provider": cls.STORAGE_DRIVER,
                         "status": "configured" if cls.STORAGE_DRIVER == "local" or env_present("S3_BUCKET")
                                   else "configuration_required",
                         "vars": ["STORAGE_DRIVER", "S3_BUCKET", "S3_KEY", "S3_SECRET"]},
        }

    @classmethod
    def production_readiness(cls) -> list[dict]:
        checks = []
        def add(name, ok, detail):
            checks.append({"check": name, "ok": bool(ok), "detail": detail})
        add("AUTH_SECRET set", env_present("AUTH_SECRET"), "Required to sign sessions in production.")
        add("DEBUG disabled", not cls.DEBUG, "Debug must be off in production.")
        add("Secure cookies", cls.COOKIE_SECURE or cls.APP_ENV != "production", "Session cookie needs Secure over HTTPS.")
        add("Demo mode off", not cls.DEMO_MODE or cls.APP_ENV != "production", "Demo accounts must not exist in production.")
        add("HTTPS app URL", cls.APP_URL.startswith("https://") or cls.APP_ENV != "production", "APP_URL should be https in production.")
        add("Rate limiting on", cls.RATE_LIMIT_ENABLED, "Protects auth and booking endpoints.")
        add("Email deliverable", cls.integration_status()["email"]["status"] == "configured",
            "Without it, mails stay queued in the outbox (never silently 'sent').")
        return checks


for _d in (STORAGE_DIR, DOCS_DIR, UPLOAD_DIR, DB_DIR):
    _d.mkdir(parents=True, exist_ok=True)
