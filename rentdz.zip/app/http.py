"""Minimal but strict HTTP layer: routing, sessions, CSRF, JSON, uploads, errors."""
from __future__ import annotations
import json, re, traceback, uuid, logging, mimetypes, os
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

from .config import Config, BASE_DIR
from . import db
from .security import (SECURITY_HEADERS, ValidationError, token_hash, new_token,
                       utc_str, in_hours, rate_limited)

log = logging.getLogger("rentdz")

SESSION_COOKIE = "rentdz_session"
CSRF_HEADER = "X-CSRF-Token"
SAFE_METHODS = ("GET", "HEAD", "OPTIONS")


class HttpError(Exception):
    def __init__(self, status: int, code: str, message: str, extra: dict | None = None):
        self.status, self.code, self.message, self.extra = status, code, message, extra or {}
        super().__init__(message)


class Unauthorized(HttpError):
    def __init__(self, message="Vous devez vous connecter pour continuer."):
        super().__init__(401, "unauthorized", message)


class Forbidden(HttpError):
    def __init__(self, message="Vous n'avez pas l'autorisation d'effectuer cette action."):
        super().__init__(403, "forbidden", message)


class NotFound(HttpError):
    def __init__(self, message="Ressource introuvable."):
        super().__init__(404, "not_found", message)


class Conflict(HttpError):
    def __init__(self, message="Conflit détecté.", code="conflict", extra=None):
        super().__init__(409, code, message, extra)


class BadRequest(HttpError):
    def __init__(self, message="Requête invalide.", extra=None):
        super().__init__(400, "bad_request", message, extra)


class TooMany(HttpError):
    def __init__(self, message="Trop de tentatives. Veuillez réessayer plus tard."):
        super().__init__(429, "rate_limited", message)


# ── request ──────────────────────────────────────────────────────────────────
class Request:
    def __init__(self, handler: "Handler", method: str, path: str, query: dict,
                 headers, body: bytes):
        self.handler = handler
        self.method = method
        self.path = path
        self.query = query
        self.headers = headers
        self.body = body
        self.params: dict[str, str] = {}
        self.user: dict | None = None
        self.session: dict | None = None
        self.request_id = uuid.uuid4().hex[:12]
        self._json = None
        self._form = None
        self._files = None

    # -- client info
    @property
    def ip(self) -> str:
        fwd = self.headers.get("X-Forwarded-For", "")
        if fwd:
            return fwd.split(",")[0].strip()[:45]
        return (self.handler.client_address[0] if self.handler.client_address else "")[:45]

    @property
    def user_agent(self) -> str:
        return (self.headers.get("User-Agent") or "")[:255]

    @property
    def locale(self) -> str:
        q = (self.query.get("lang") or [None])[0]
        if q in Config.LOCALES:
            return q
        cookie = self.cookies.get("rentdz_lang")
        if cookie in Config.LOCALES:
            return cookie
        if self.user and self.user.get("locale") in Config.LOCALES:
            return self.user["locale"]
        accept = (self.headers.get("Accept-Language") or "").lower()
        for loc in ("fr", "ar", "en"):
            if loc in accept:
                return loc
        return Config.DEFAULT_LOCALE

    @property
    def cookies(self) -> dict:
        raw = self.headers.get("Cookie")
        if not raw:
            return {}
        c = SimpleCookie()
        try:
            c.load(raw)
        except Exception:
            return {}
        return {k: v.value for k, v in c.items()}

    # -- bodies
    def json(self) -> dict:
        if self._json is None:
            if not self.body:
                self._json = {}
            else:
                try:
                    parsed = json.loads(self.body.decode("utf-8"))
                except Exception:
                    raise BadRequest("Corps de requête JSON invalide.")
                if not isinstance(parsed, dict):
                    raise BadRequest("Le corps de la requête doit être un objet JSON.")
                self._json = parsed
        return self._json

    def form(self) -> dict:
        ctype = (self.headers.get("Content-Type") or "")
        if self._form is None:
            if ctype.startswith("application/json"):
                self._form = self.json()
            elif ctype.startswith("application/x-www-form-urlencoded"):
                self._form = {k: v[0] for k, v in parse_qs(self.body.decode("utf-8", "replace")).items()}
            elif ctype.startswith("multipart/form-data"):
                self._parse_multipart(ctype)
            else:
                self._form = {}
        return self._form

    def files(self) -> dict:
        if self._files is None:
            self.form()
            if self._files is None:
                self._files = {}
        return self._files

    def _parse_multipart(self, ctype: str) -> None:
        self._form, self._files = {}, {}
        m = re.search(r'boundary="?([^";]+)"?', ctype)
        if not m:
            raise BadRequest("Requête multipart invalide.")
        boundary = ("--" + m.group(1)).encode()
        for part in self.body.split(boundary):
            if not part or part in (b"--\r\n", b"--", b"\r\n"):
                continue
            if b"\r\n\r\n" not in part:
                continue
            head, data = part.split(b"\r\n\r\n", 1)
            data = data.rstrip(b"\r\n")
            headers = head.decode("utf-8", "replace")
            nm = re.search(r'name="([^"]*)"', headers)
            if not nm:
                continue
            name = nm.group(1)
            fn = re.search(r'filename="([^"]*)"', headers)
            if fn and fn.group(1):
                self._files[name] = {"filename": os.path.basename(unquote(fn.group(1)))[:120],
                                     "data": data}
            else:
                self._form[name] = data.decode("utf-8", "replace")

    def q(self, key: str, default=None):
        v = self.query.get(key)
        return v[0] if v else default

    # -- authz
    def require_user(self) -> dict:
        if not self.user:
            raise Unauthorized()
        if self.user.get("status") == "suspended":
            raise Forbidden("Votre compte est suspendu. Contactez le support.")
        return self.user

    def has_perm(self, perm: str) -> bool:
        return bool(self.user and perm in self.user.get("permissions", set()))

    def require_perm(self, *perms: str) -> dict:
        user = self.require_user()
        if not any(p in user["permissions"] for p in perms):
            raise Forbidden()
        return user

    def has_role(self, *codes: str) -> bool:
        return bool(self.user and set(codes) & set(self.user.get("roles", [])))

    def company_ids(self) -> list[int]:
        return list(self.user.get("company_ids", [])) if self.user else []


class Response:
    def __init__(self, status=200, body: bytes = b"", headers: dict | None = None):
        self.status, self.body = status, body
        self.headers = headers or {}
        self.cookies: list[str] = []

    def set_cookie(self, name, value, *, max_age=None, http_only=True,
                   same_site="Lax", path="/", delete=False):
        parts = [f"{name}={value}", f"Path={path}", f"SameSite={same_site}"]
        if delete:
            parts.append("Max-Age=0")
        elif max_age:
            parts.append(f"Max-Age={int(max_age)}")
        if http_only:
            parts.append("HttpOnly")
        if Config.COOKIE_SECURE:
            parts.append("Secure")
        self.cookies.append("; ".join(parts))
        return self


def json_response(data, status=200, headers=None) -> Response:
    body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
    h = {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"}
    h.update(headers or {})
    return Response(status, body, h)


def html_response(html: str, status=200, headers=None) -> Response:
    h = {"Content-Type": "text/html; charset=utf-8"}
    h.update(headers or {})
    return Response(status, html.encode("utf-8"), h)


def redirect(location: str, status=302) -> Response:
    return Response(status, b"", {"Location": location})


def ok(data=None, **extra) -> Response:
    payload = {"ok": True}
    if data is not None:
        payload["data"] = data
    payload.update(extra)
    return json_response(payload)


def error_response(status: int, code: str, message: str, extra: dict | None = None,
                   request_id: str | None = None) -> Response:
    payload = {"ok": False, "error": {"code": code, "message": message}}
    if extra:
        payload["error"].update(extra)
    if request_id:
        payload["error"]["request_id"] = request_id
    return json_response(payload, status)


# ── router ───────────────────────────────────────────────────────────────────
class Route:
    def __init__(self, method, pattern, handler, name=""):
        self.method = method
        self.raw = pattern
        self.name = name or getattr(handler, "__name__", "")
        regex = re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern)
        self.regex = re.compile(f"^{regex}/?$")
        self.handler = handler


ROUTES: list[Route] = []


def route(method: str, pattern: str, name: str = ""):
    def deco(fn):
        ROUTES.append(Route(method.upper(), pattern, fn, name))
        return fn
    return deco


def get(p, name=""):    return route("GET", p, name)
def post(p, name=""):   return route("POST", p, name)
def put(p, name=""):    return route("PUT", p, name)
def patch(p, name=""):  return route("PATCH", p, name)
def delete(p, name=""): return route("DELETE", p, name)


def match(method: str, path: str):
    allowed = set()
    for r in ROUTES:
        m = r.regex.match(path)
        if m:
            if r.method == method:
                return r, m.groupdict()
            allowed.add(r.method)
    return (None, allowed) if allowed else (None, None)


# ── sessions ─────────────────────────────────────────────────────────────────
def load_session(req: Request) -> None:
    token = req.cookies.get(SESSION_COOKIE)
    if not token:
        return
    row = db.one(
        """SELECT s.id, s.user_id, s.csrf_token, s.expires_at,
                  u.email, u.full_name, u.status, u.locale, u.email_verified_at, u.is_demo
             FROM sessions s JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND s.revoked_at IS NULL
              AND s.expires_at > ? AND u.deleted_at IS NULL""",
        (token_hash(token), utc_str()))
    if not row:
        return
    roles = [r["code"] for r in db.query(
        "SELECT r.code FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?",
        (row["user_id"],))]
    perms = {r["permission_code"] for r in db.query(
        """SELECT DISTINCT rp.permission_code
             FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id
            WHERE ur.user_id = ?""", (row["user_id"],))}
    companies = [r["id"] for r in db.query(
        """SELECT id FROM rental_companies WHERE owner_user_id = ? AND deleted_at IS NULL
           UNION SELECT company_id FROM company_staff WHERE user_id = ?""",
        (row["user_id"], row["user_id"]))]
    req.session = {"id": row["id"], "csrf_token": row["csrf_token"]}
    req.user = {
        "id": row["user_id"], "email": row["email"], "full_name": row["full_name"],
        "status": row["status"], "locale": row["locale"],
        "email_verified": bool(row["email_verified_at"]), "is_demo": bool(row["is_demo"]),
        "roles": roles, "permissions": perms, "company_ids": companies,
    }
    db.execute("UPDATE sessions SET last_seen_at = ? WHERE id = ?", (utc_str(), row["id"]))


def create_session(user_id: int, req: Request) -> tuple[str, str]:
    token, csrf = new_token(), new_token(24)
    db.insert("sessions", {
        "token_hash": token_hash(token), "user_id": user_id, "csrf_token": csrf,
        "ip": req.ip, "user_agent": req.user_agent,
        "created_at": utc_str(), "last_seen_at": utc_str(),
        "expires_at": in_hours(Config.SESSION_TTL_HOURS),
    })
    return token, csrf


def revoke_session(session_id: int) -> None:
    db.execute("UPDATE sessions SET revoked_at = ? WHERE id = ?", (utc_str(), session_id))


def check_csrf(req: Request) -> None:
    """Double-submit CSRF: header must match the token bound to the session row."""
    if req.method in SAFE_METHODS or not req.session:
        return
    sent = req.headers.get(CSRF_HEADER) or req.form().get("csrf_token")
    if not sent or sent != req.session["csrf_token"]:
        raise HttpError(403, "csrf_failed", "Session expirée. Rechargez la page et réessayez.")


# ── static files ─────────────────────────────────────────────────────────────
STATIC_ROOT = (BASE_DIR / "app" / "static").resolve()
UPLOAD_ROOT = (BASE_DIR / "storage" / "uploads").resolve()


def serve_file(root, rel_path: str, cache: str) -> Response:
    rel_path = unquote(rel_path).lstrip("/")
    if ".." in rel_path or rel_path.startswith("/") or "\x00" in rel_path:
        raise NotFound()
    target = (root / rel_path).resolve()
    if not str(target).startswith(str(root)) or not target.is_file():
        raise NotFound()
    ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return Response(200, target.read_bytes(),
                    {"Content-Type": ctype, "Cache-Control": cache,
                     "X-Content-Type-Options": "nosniff"})


# ── dispatch ─────────────────────────────────────────────────────────────────
def dispatch(req: Request) -> Response:
    from .i18n import t
    path = req.path

    if path.startswith("/static/"):
        return serve_file(STATIC_ROOT, path[len("/static/"):], "public, max-age=3600")
    if path.startswith("/media/"):
        return serve_file(UPLOAD_ROOT, path[len("/media/"):], "public, max-age=86400")

    r, params = match(req.method, path)
    if r is None:
        if isinstance(params, set):
            return error_response(405, "method_not_allowed", "Méthode non autorisée.",
                                  {"allowed": sorted(params)})
        if path.startswith("/api/"):
            raise NotFound("Point de terminaison introuvable.")
        from .web.views import render_not_found
        return html_response(render_not_found(req), 404)

    req.params = params
    load_session(req)
    check_csrf(req)
    return r.handler(req)


class Handler(BaseHTTPRequestHandler):
    server_version = "RENTDZ"
    sys_version = ""
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # access logging handled in _handle

    def _handle(self):
        started = datetime.now(timezone.utc)
        parsed = urlparse(self.path)
        req = None
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length > Config.MAX_REQUEST_MB * 1024 * 1024:
                self._send(error_response(413, "payload_too_large",
                                          "Fichier ou requête trop volumineux."))
                return
            body = self.rfile.read(length) if length else b""
            req = Request(self, self.command, parsed.path or "/",
                          parse_qs(parsed.query), self.headers, body)
            resp = dispatch(req)
        except HttpError as e:
            resp = self._error(req, e.status, e.code, e.message, e.extra)
        except ValidationError as e:
            resp = self._error(req, 422, "validation_error",
                               "Certains champs sont invalides.", {"fields": e.errors})
        except (OverflowError, UnicodeDecodeError) as e:
            resp = self._error(req, 400, "bad_request",
                               "Requête invalide.", {"debug": repr(e)} if Config.DEBUG else None)
        except BrokenPipeError:
            return
        except Exception as e:
            rid = req.request_id if req else "n/a"
            log.error("[%s] %s %s -> %s\n%s", rid, self.command, parsed.path, e,
                      traceback.format_exc())
            detail = {"debug": repr(e)} if Config.DEBUG else None
            resp = self._error(req, 500, "server_error",
                               "Une erreur est survenue. Veuillez réessayer.", detail)
        try:
            self._send(resp)
        except (BrokenPipeError, ConnectionResetError):
            return
        ms = (datetime.now(timezone.utc) - started).total_seconds() * 1000
        if Config.DEBUG:
            log.info("%s %s %s %.0fms", self.command, parsed.path, resp.status, ms)

    def _error(self, req, status, code, message, extra):
        wants_html = (req is not None and not req.path.startswith("/api/")
                      and "text/html" in (req.headers.get("Accept") or ""))
        if wants_html and status in (401, 403, 404):
            from .web.views import render_error_page
            return html_response(render_error_page(req, status, message), status)
        return error_response(status, code, message, extra,
                              req.request_id if req else None)

    def _send(self, resp: Response):
        body = resp.body or b""
        self.send_response(resp.status)
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        for k, v in resp.headers.items():
            self.send_header(k, v)
        for c in resp.cookies:
            self.send_header("Set-Cookie", c)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD" and body:
            self.wfile.write(body)

    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = _handle

    def finish(self):
        try:
            super().finish()
        finally:
            db.close_conn()


def serve():
    from . import routes_all  # noqa: F401  (registers every route)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    db.migrate()
    srv = ThreadingHTTPServer((Config.HOST, Config.PORT), Handler)
    srv.daemon_threads = True
    print(f"\n  RENTDZ  ·  {Config.APP_ENV}  ·  http://{Config.HOST}:{Config.PORT}\n")
    for c in Config.production_readiness():
        if not c["ok"]:
            print(f"  [!] {c['check']}: {c['detail']}")
    print()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  Arrêt du serveur.")
        srv.shutdown()
